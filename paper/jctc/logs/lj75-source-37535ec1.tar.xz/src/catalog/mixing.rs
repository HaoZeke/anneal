//! Inverted Gelman--Rubin for cooperative search.
//!
//! MCMC wants \(\hat R \to 1\): chains have mixed onto one stationary
//! distribution. Cooperative search splits that diagnostic:
//!
//! - explore-role chains must stay unmixed (\(\hat R\) large);
//! - a sampled incumbent is dominant only when occupant chains have mixed
//!   onto it, it is uniquely deepest among observed attractors, and it is
//!   strictly more occupied than every observed competing basin.
//!
//! Mixing onto a lone icosahedral floor diagnoses one sampled mode. It does
//! not prove that an unobserved lower mode is absent. Catalog saturation and
//! leftover-mass diagnostics quantify search evidence without converting it
//! into a global-optimality certificate.

use std::cmp::Ordering;

/// Gelman--Rubin \(\hat R\) on one scalar series per chain.
///
/// Constant traces at the same value are mixed (\(\hat R = 0\)).
/// Constant traces at different values have \(W = 0\) and \(B > 0\),
/// which is unmixed (\(\hat R = \infty\)). The MCMC
/// [`crate::methods::GelmanRubin`] skip on \(W = 0\) would call that
/// mixed; inverted search cannot.
pub fn rhat_series(chains: &[Vec<f64>]) -> f64 {
    let usable: Vec<&[f64]> = chains
        .iter()
        .map(Vec::as_slice)
        .filter(|chain| chain.len() >= 2)
        .collect();
    if usable.len() < 2 {
        return f64::INFINITY;
    }
    let n = usable.iter().map(|chain| chain.len()).min().unwrap_or(0);
    if n < 2 {
        return f64::INFINITY;
    }
    let windows: Vec<&[f64]> = usable
        .iter()
        .map(|chain| &chain[chain.len() - n..])
        .collect();
    let m = windows.len() as f64;
    let means: Vec<f64> = windows
        .iter()
        .map(|chain| chain.iter().sum::<f64>() / n as f64)
        .collect();
    let vars: Vec<f64> = windows
        .iter()
        .zip(&means)
        .map(|(chain, mean)| {
            chain
                .iter()
                .map(|value| (value - mean).powi(2))
                .sum::<f64>()
                / (n as f64 - 1.0)
        })
        .collect();
    let theta_bar: f64 = means.iter().sum::<f64>() / m;
    let b: f64 = (n as f64 / (m - 1.0))
        * means
            .iter()
            .map(|mean| (mean - theta_bar).powi(2))
            .sum::<f64>();
    let w: f64 = vars.iter().sum::<f64>() / m;
    // Repeated identical f64 values can leave a residual W after
    // (n * x) / n, so treat a vanished within-chain variance as zero.
    if w <= 1e-18 {
        return if b > 1e-18 { f64::INFINITY } else { 0.0 };
    }
    let var_hat = ((n as f64 - 1.0) / n as f64) * w + b / n as f64;
    (var_hat / w).sqrt()
}

/// Vehtari split-\(\hat R\): each chain is cut in half, then
/// [`rhat_series`] runs on the \(2m\) windows. Chains shorter than
/// two [`CERTIFY_DRAWS_PER_HALF`] draws are dropped.
pub fn rhat_split(chains: &[Vec<f64>]) -> f64 {
    let min_half = CERTIFY_DRAWS_PER_HALF;
    let usable: Vec<&[f64]> = chains
        .iter()
        .map(Vec::as_slice)
        .filter(|chain| chain.len() >= 2 * min_half)
        .collect();
    // One chain split in half is not a mixing certificate: two
    // halves of one constant walk have \(\hat R = 0\).
    if usable.len() < 2 {
        return f64::INFINITY;
    }
    let mut halves = Vec::new();
    for chain in usable {
        let mid = chain.len() / 2;
        halves.push(chain[..mid].to_vec());
        halves.push(chain[mid..].to_vec());
    }
    rhat_series(&halves)
}

/// Vehtari, Gelman, Simpson, Carpenter & Bürkner (2021),
/// *Bayesian Anal.* 16:667-718: use the sample only if split
/// \(\hat R<1.01\). Gelman & Rubin (1992) used 1.1; Brooks--Gelman
/// \(6/5\) is the SI algebra identity, not the occupant cut.
pub const MIXED_RHAT: f64 = 1.01;
/// Occupant plus competitor, when a competitor is on file.
pub const CERTIFY_CHAINS: usize = 2;
/// Vehtari split-\(\hat R\) halves per chain.
pub const CERTIFY_SPLIT_HALVES: usize = 2;
/// Vehtari minimum draws per split half.
pub const CERTIFY_DRAWS_PER_HALF: usize = 4;
/// Occupant traces shorter than this do not support the mixing diagnostic.
/// Two quench reports on two random-start families give \(\hat R = 0\) but do
/// not establish convergence or global optimality.
/// `2 × 2 × 4 = 16` (`Hop.certify_min_samples`).
pub const CERTIFY_MIN_SAMPLES: usize =
    CERTIFY_CHAINS * CERTIFY_SPLIT_HALVES * CERTIFY_DRAWS_PER_HALF;

/// Whether \(\hat R\) says the chains have mixed.
pub fn mixed(rhat: f64) -> bool {
    rhat.is_finite() && rhat < MIXED_RHAT
}

/// Occupant split-\(\hat R\) for certification. Series shorter than
/// [`CERTIFY_MIN_SAMPLES`] are dropped, so two-point quenches cannot
/// certify. Explore-role collapse uses [`rhat_split`] on the raw traces.
pub fn occupant_rhat(series: &[Vec<f64>]) -> f64 {
    let usable: Vec<Vec<f64>> = series
        .iter()
        .filter(|chain| chain.len() >= CERTIFY_MIN_SAMPLES)
        .cloned()
        .collect();
    rhat_split(&usable)
}

/// Occupancy and occupant mixing of one packing family or census basin.
#[derive(Debug, Clone, PartialEq)]
pub struct AttractorStrength {
    /// Lowest energy observed among occupants.
    pub energy: f64,
    /// Number of independent chains sitting on this attractor.
    pub occupancy: usize,
    /// Gelman--Rubin \(\hat R\) of occupant energy series.
    pub occupant_rhat: f64,
}

impl AttractorStrength {
    /// Occupant chains have mixed onto this attractor.
    pub fn mixed(&self) -> bool {
        mixed(self.occupant_rhat)
    }
}

/// Strict attraction order: more occupants win; equal occupancy
/// breaks toward the tighter occupant mix.
pub fn stronger(left: &AttractorStrength, right: &AttractorStrength) -> bool {
    match left.occupancy.cmp(&right.occupancy) {
        Ordering::Greater => true,
        Ordering::Less => false,
        Ordering::Equal => {
            left.occupant_rhat.is_finite()
                && right.occupant_rhat.is_finite()
                && left.occupant_rhat < right.occupant_rhat
        }
    }
}

/// Whether an observed minimum is dominant within the sampled attractors.
///
/// A second mixed competitor is required only when a competitor is on file:
/// that competitor must be mixed (an attractor, not a flyby), and the sampled
/// incumbent must be strictly more occupied. An empty competitor set means
/// only that the sample contains one mode. This predicate makes no statement
/// about unobserved modes or global optimality.
pub fn sampled_minimum_is_dominant(
    putative: &AttractorStrength,
    competitors: &[AttractorStrength],
    uniquely_deepest: bool,
) -> bool {
    if !uniquely_deepest || !putative.mixed() {
        return false;
    }
    if competitors.is_empty() {
        return true;
    }
    competitors.iter().any(AttractorStrength::mixed)
        && competitors.iter().all(|other| stronger(putative, other))
}

/// Explore-role chains have collapsed onto one attractor.
pub fn explore_collapsed(explore_series: &[Vec<f64>]) -> bool {
    mixed(rhat_split(explore_series))
}

/// Explore-role failure: mixed energy, or two or more assigned walks
/// rematched onto the frozen incumbent packing.
///
/// One occupied packing with several occupants is a collapse. Waiting
/// for a second family never opens that family. Live family-label
/// \(\hat R\) is not this test: a growing DECAF codebook moves the
/// label under the walks. Distinct packings rematched against the
/// incumbent histogram do not force Leave.
pub fn explore_must_leave(
    energy_explore: &[Vec<f64>],
    n_on_incumbent_packing: usize,
    n_assigned: usize,
) -> bool {
    explore_collapsed(energy_explore) || (n_assigned >= 2 && n_on_incumbent_packing >= 2)
}

/// Inverted Gelman--Rubin evidence consumed by the catalog policy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct MixingEvidence {
    /// Explore-role (or lone-floor) series have mixed.
    pub explore_collapsed: bool,
    /// Incumbent attractor is uniquely deepest and occupant-mixed.
    /// A competitor, when one exists, must also be mixed and less occupied.
    pub certified_attractor: bool,
    /// Asynchronous successive halving discarded this walk at a rung.
    pub pruned: bool,
}

/// Combine attractor strengths and the explore-role series.
pub fn invert_mixing(
    attractors: &[AttractorStrength],
    explore_series: &[Vec<f64>],
) -> MixingEvidence {
    MixingEvidence {
        explore_collapsed: explore_collapsed(explore_series),
        certified_attractor: unique_deepest(attractors).is_some_and(|index| {
            let putative = &attractors[index];
            let competitors: Vec<AttractorStrength> = attractors
                .iter()
                .enumerate()
                .filter(|(other, _)| *other != index)
                .map(|(_, attractor)| attractor.clone())
                .collect();
            sampled_minimum_is_dominant(putative, &competitors, true)
        }),
        pruned: false,
    }
}

fn unique_deepest(attractors: &[AttractorStrength]) -> Option<usize> {
    let mut best: Option<(usize, f64)> = None;
    let mut unique = true;
    for (index, attractor) in attractors.iter().enumerate() {
        if !attractor.energy.is_finite() {
            continue;
        }
        match best {
            None => {
                best = Some((index, attractor.energy));
                unique = true;
            }
            Some((_, energy)) if attractor.energy < energy - 1e-10 => {
                best = Some((index, attractor.energy));
                unique = true;
            }
            Some((_, energy)) if (attractor.energy - energy).abs() <= 1e-10 => {
                unique = false;
            }
            _ => {}
        }
    }
    if unique {
        best.map(|(index, _)| index)
    } else {
        None
    }
}
