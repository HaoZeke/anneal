//! pyo3 entry point for `anneal._core`. Exposes the three preset variants
//! (Boltzmann / Fast / Gsa), a `History` wrapper, and a `run` function
//! that dispatches on the preset type. The Python objective is a callable from
//! an ndarray to a scalar plus `Bounds` for sampling and dimensionality.
//!
//! Internally, `run` wraps the Python callable in a thin `Objective<f64>`
//! adapter that re-acquires the GIL per `eval`. This is acceptable when
//! evaluation cost dominates the per-call GIL overhead (~hundreds of ns),
//! which is true for any non-toy objective.
//!
//! Replica-spawning pyfunctions must [`with_replica_threads`] so this
//! frame is not still holding the GIL when workers attach. Holding it
//! deadlocks: workers wait for the GIL, this frame waits for
//! `thread::scope` to join. Box search ([`ensemble_optimize`]) drops
//! the GIL around the native hop so a Python objective can be called
//! back.

// Python-callable signatures mirror stable keyword APIs.
#![allow(clippy::too_many_arguments)]

use ndarray::{Array1, ArrayView1};
use numpy::{PyArray1, PyReadonlyArray1};
use pyo3::exceptions::{PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyFloat};
use rand::SeedableRng;

use eindir_core::py_objective::{PyBounds as EindirPyBounds, PyObjective};
use eindir_core::{Bounds, Objective};

use crate::history::History;
use crate::variant::{boltzmann_in_box, fast_in_box, gsa_in_box};

mod device;
mod portfolio_peers;

/// Drop the GIL before native search that may call back into Python.
///
/// [`CallableObjective::eval`] attaches the GIL on the worker thread.
/// If this frame still holds it, every worker blocks in `attach` and
/// the caller blocks in `join`.
fn with_replica_threads<F, T>(py: Python<'_>, f: F) -> T
where
    F: FnOnce() -> T + Send,
    T: Send,
{
    py.detach(f)
}

/// Validate a box for methods that sample every coordinate uniformly.
fn validate_box_bounds(low: &[f64], high: &[f64]) -> PyResult<()> {
    validate_box_domain(low, high, false)
}

/// Fixed coordinates are valid only for drivers that preserve those axes.
fn validate_box_domain(low: &[f64], high: &[f64], allow_fixed: bool) -> PyResult<()> {
    if low.len() != high.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if low.is_empty() {
        return Err(PyValueError::new_err(
            "bounds must have at least one dimension",
        ));
    }
    let mut total_width = 0.0;
    for (i, (&lo, &hi)) in low.iter().zip(high.iter()).enumerate() {
        // Reflection folds with period 2 (hi - lo), and the drivers average
        // widths across axes, so both must stay finite.
        if !lo.is_finite() || !hi.is_finite() || !(2.0 * (hi - lo)).is_finite() {
            return Err(PyValueError::new_err(format!(
                "bounds must be finite, with a finite width, at dimension {i}"
            )));
        }
        total_width += hi - lo;
        if !total_width.is_finite() {
            return Err(PyValueError::new_err(
                "the box is too wide: the sum of its widths is not finite",
            ));
        }
        if lo > hi || (!allow_fixed && lo == hi) {
            let relation = if allow_fixed {
                "less than or equal to"
            } else {
                "strictly less than"
            };
            return Err(PyValueError::new_err(format!(
                "low[{i}] must be {relation} high[{i}] (got {lo}, {hi})"
            )));
        }
    }
    Ok(())
}

fn py_view1<'py>(py: Python<'py>, x: ArrayView1<f64>) -> Bound<'py, PyArray1<f64>> {
    match x.as_slice() {
        Some(sl) => PyArray1::from_slice(py, sl),
        None => PyArray1::from_vec(py, x.iter().copied().collect()),
    }
}

fn require_positive_budget(budget: usize) -> PyResult<()> {
    if budget == 0 {
        Err(PyValueError::new_err("budget must be positive"))
    } else {
        Ok(())
    }
}

/// Shared box parse: finite ordered bounds and an optional start.
fn parse_box(
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<(Bounds<f64>, usize, Option<Array1<f64>>)> {
    parse_box_domain(low, high, x0, false)
}

fn parse_box_domain(
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    allow_fixed: bool,
) -> PyResult<(Bounds<f64>, usize, Option<Array1<f64>>)> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    validate_box_domain(&low_vec, &high_vec, allow_fixed)?;
    let dim = low_vec.len();
    let x0 = if let Some(x0) = x0 {
        let sl = x0.as_slice()?;
        if sl.len() != dim {
            return Err(PyValueError::new_err(format!(
                "x0 length {} does not match dimension {}",
                sl.len(),
                dim
            )));
        }
        Some(Array1::from_vec(sl.to_vec()))
    } else {
        None
    };
    Ok((
        Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9),
        dim,
        x0,
    ))
}

struct ParsedBoxSearch {
    bounds: Bounds<f64>,
    dim: usize,
    x0: Option<Array1<f64>>,
    history: crate::methods::ensemble::HistoryMode,
    membership: crate::methods::minima_hopping::HistoryMembership,
}

fn parse_box_search(
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    replicas: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    history: &str,
    membership: &str,
) -> PyResult<ParsedBoxSearch> {
    require_positive_budget(budget)?;
    if replicas == 0 {
        return Err(PyValueError::new_err("replicas must be positive"));
    }
    let (bounds, dim, x0) = parse_box_domain(low, high, x0, true)?;
    let history = match history {
        "none" | "no" => crate::methods::ensemble::HistoryMode::None,
        "private" => crate::methods::ensemble::HistoryMode::Private,
        "shared" => crate::methods::ensemble::HistoryMode::Shared,
        other => {
            return Err(PyValueError::new_err(format!(
                "history must be none, private, or shared, got {other:?}"
            )));
        }
    };
    let membership = crate::methods::minima_hopping::HistoryMembership::parse(Some(membership))
        .map_err(PyValueError::new_err)?;
    Ok(ParsedBoxSearch {
        bounds,
        dim,
        x0,
        history,
        membership,
    })
}

fn validate_max_evals(max_evals: Option<usize>) -> PyResult<()> {
    if max_evals == Some(0) {
        return Err(PyValueError::new_err(
            "max_evals must be at least 1: the start costs one evaluation",
        ));
    }
    Ok(())
}

/// Reads an optional starting point and refuses one that the box drivers
/// could not start from: wrong length, non-finite, or outside `[low, high]`.
fn read_x0(
    x0: Option<PyReadonlyArray1<'_, f64>>,
    low: &[f64],
    high: &[f64],
) -> PyResult<Option<Array1<f64>>> {
    let Some(x0) = x0 else {
        return Ok(None);
    };
    let values = x0.as_slice()?.to_vec();
    if values.len() != low.len() {
        return Err(PyValueError::new_err(format!(
            "x0 has length {} but low and high have length {}",
            values.len(),
            low.len()
        )));
    }
    for (i, &v) in values.iter().enumerate() {
        if !v.is_finite() {
            return Err(PyValueError::new_err(format!("x0[{i}] is not finite")));
        }
        if v < low[i] || v > high[i] {
            return Err(PyValueError::new_err(format!(
                "x0[{i}] = {v} lies outside [{}, {}]",
                low[i], high[i]
            )));
        }
    }
    Ok(Some(Array1::from_vec(values)))
}

// ---------------------------------------------------------------------------
// Preset parameter holders.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Enhanced-sampling bias.
//
// The manuscript's Obj-slot transform, `F_eff(x) = F(x) + V(s(x))`, had no
// Python surface: the bias module existed in the core and could not be reached
// from the installed package. A driver written against the bindings therefore
// could not use the transform the method is described in terms of.
// ---------------------------------------------------------------------------

/// Well-tempered bias keyed on basin identity rather than a collective
/// variable.
///
/// A grid bias must be told which projection to watch, and fails silently when
/// the competing structures do not separate along it. Keying on identity
/// removes the choice: two states are the same basin when their fingerprints
/// lie within `merge_radius`.
///
/// States are flattened `(n_points, 3)` point sets, fingerprinted by sorted
/// pairwise distances, which is invariant to permutation, translation and
/// rotation.
#[pyclass(name = "BasinBias")]
pub struct PyBasinBias {
    inner: crate::bias::BasinBias<crate::bias::SortedPairs>,
}

#[pymethods]
impl PyBasinBias {
    #[new]
    #[pyo3(signature = (n_points, merge_radius = 1e-2, w0 = 0.25, gamma = 5.0))]
    fn new(n_points: usize, merge_radius: f64, w0: f64, gamma: f64) -> PyResult<Self> {
        if n_points < 2 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "n_points must be at least 2",
            ));
        }
        if !(gamma > 1.0) || !(w0 > 0.0) || !(merge_radius > 0.0) {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "require gamma > 1, w0 > 0, merge_radius > 0",
            ));
        }
        Ok(Self {
            inner: crate::bias::BasinBias::new(
                crate::bias::SortedPairs { n_points },
                merge_radius,
                w0,
                gamma,
            ),
        })
    }

    /// Accumulated bias at the basin containing `x`; zero for an unseen basin.
    ///
    /// The numpy bridge yields arrays from a different ndarray release than the
    /// core is built against, so the buffer is reborrowed through a slice.
    fn potential(&self, x: numpy::PyReadonlyArray1<f64>) -> PyResult<f64> {
        use crate::bias::Bias;
        let slice = x
            .as_slice()
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("x must be contiguous"))?;
        let v = ndarray::ArrayView1::from(slice);
        let s = self.inner.cv(v);
        Ok(self.inner.potential(s.view()))
    }

    /// Raise the bias on the basin containing `x`, registering it if unseen.
    fn deposit(&mut self, x: numpy::PyReadonlyArray1<f64>, temp: f64) -> PyResult<()> {
        use crate::bias::Bias;
        if !(temp > 0.0) {
            return Err(pyo3::exceptions::PyValueError::new_err("temp must be > 0"));
        }
        let slice = x
            .as_slice()
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("x must be contiguous"))?;
        let v = ndarray::ArrayView1::from(slice);
        let s = self.inner.cv(v);
        self.inner.deposit(s.view(), temp);
        Ok(())
    }

    /// Distinct basins registered so far.
    #[getter]
    fn n_basins(&self) -> usize {
        self.inner.n_basins()
    }

    /// Deepest accumulated bias over all basins.
    #[getter]
    fn deepest(&self) -> f64 {
        self.inner.deepest()
    }

    /// Good-Turing missing mass: share of basins seen exactly once, estimating
    /// the chance the next visit opens a new one.
    #[getter]
    fn missing_mass(&self) -> f64 {
        self.inner.missing_mass()
    }

    fn __repr__(&self) -> String {
        format!(
            "BasinBias(n_basins={}, deepest={:?}, missing_mass={:?})",
            self.inner.n_basins(),
            self.inner.deepest(),
            self.inner.missing_mass()
        )
    }
}

/// Boltzmann preset parameters: initial temperature and Gaussian step size.
#[pyclass(name = "Boltzmann")]
#[derive(Clone, Copy, Debug)]
pub struct PyBoltzmann {
    /// Initial temperature `T_0`.
    #[pyo3(get, set)]
    pub t_init: f64,
    /// Gaussian per-component standard deviation.
    #[pyo3(get, set)]
    pub sigma: f64,
}

#[pymethods]
impl PyBoltzmann {
    #[new]
    #[pyo3(signature = (t_init = 1.0, sigma = 0.5))]
    fn new(t_init: f64, sigma: f64) -> Self {
        Self { t_init, sigma }
    }

    fn __repr__(&self) -> String {
        format!(
            "Boltzmann(t_init={:?}, sigma={:?})",
            self.t_init, self.sigma
        )
    }
}

/// Fast SA preset parameters: initial temperature and Cauchy scale.
#[pyclass(name = "Fast")]
#[derive(Clone, Copy, Debug)]
pub struct PyFast {
    /// Initial temperature `T_0`.
    #[pyo3(get, set)]
    pub t_init: f64,
    /// Cauchy per-component scale.
    #[pyo3(get, set)]
    pub gamma: f64,
}

#[pymethods]
impl PyFast {
    #[new]
    #[pyo3(signature = (t_init = 1.0, gamma = 0.5))]
    fn new(t_init: f64, gamma: f64) -> Self {
        Self { t_init, gamma }
    }

    fn __repr__(&self) -> String {
        format!("Fast(t_init={:?}, gamma={:?})", self.t_init, self.gamma)
    }
}

/// GSA preset parameters: initial temperature and Tsallis indices.
#[pyclass(name = "Gsa")]
#[derive(Clone, Copy, Debug)]
pub struct PyGsa {
    /// Initial temperature `T_0`.
    #[pyo3(get, set)]
    pub t_init: f64,
    /// Visiting index `q_v in (1, 3)`.
    #[pyo3(get, set)]
    pub q_v: f64,
    /// Acceptance index `q_a` (`1.0` collapses to Metropolis).
    #[pyo3(get, set)]
    pub q_a: f64,
}

#[pymethods]
impl PyGsa {
    #[new]
    #[pyo3(signature = (t_init = 1.0, q_v = 2.62, q_a = 1.7))]
    fn new(t_init: f64, q_v: f64, q_a: f64) -> Self {
        Self { t_init, q_v, q_a }
    }

    fn __repr__(&self) -> String {
        format!(
            "Gsa(t_init={:?}, q_v={:?}, q_a={:?})",
            self.t_init, self.q_v, self.q_a
        )
    }
}

// ---------------------------------------------------------------------------
// History wrapper.
// ---------------------------------------------------------------------------

/// Per-epoch summary line exposed to Python.
#[pyclass(name = "EpochLine")]
#[derive(Clone, Debug)]
pub struct PyEpochLine {
    /// Zero-based epoch index.
    #[pyo3(get)]
    pub epoch: usize,
    /// Temperature at this epoch.
    #[pyo3(get)]
    pub temp: f64,
    /// Proposals accepted in this epoch.
    #[pyo3(get)]
    pub accepted: usize,
    /// Proposals rejected in this epoch.
    #[pyo3(get)]
    pub rejected: usize,
    /// Best objective value seen up to and including this epoch.
    #[pyo3(get)]
    pub best_val: f64,
}

/// Run history exposed to Python.
#[pyclass(name = "History")]
#[derive(Clone, Debug)]
pub struct PyHistory {
    /// Per-epoch summary lines, in epoch order.
    #[pyo3(get)]
    pub epochs: Vec<PyEpochLine>,
    /// Best position seen across the entire run.
    #[pyo3(get)]
    pub best_pos: Vec<f64>,
    /// Best objective value seen across the entire run.
    #[pyo3(get)]
    pub best_val: f64,
    /// Robust rolling mean-shift diagnostic, one flag per epoch.
    #[pyo3(get)]
    pub stationarity_flags: Vec<bool>,
}

#[pymethods]
impl PyHistory {
    /// Total proposals accepted across all epochs.
    #[getter]
    fn total_accepted(&self) -> usize {
        self.epochs.iter().map(|e| e.accepted).sum()
    }

    /// Total proposals rejected across all epochs.
    #[getter]
    fn total_rejected(&self) -> usize {
        self.epochs.iter().map(|e| e.rejected).sum()
    }
}

impl From<History> for PyHistory {
    fn from(h: History) -> Self {
        Self {
            epochs: h
                .epochs
                .into_iter()
                .map(|e| PyEpochLine {
                    epoch: e.epoch,
                    temp: e.temp,
                    accepted: e.accepted,
                    rejected: e.rejected,
                    best_val: e.best_val,
                })
                .collect(),
            best_pos: h.best.pos.to_vec(),
            best_val: h.best.val,
            stationarity_flags: h.stationarity_flags,
        }
    }
}

// ---------------------------------------------------------------------------
// Objective adapter wrapping a Python callable.
// ---------------------------------------------------------------------------

/// What the Python callbacks of one driver call did that a float cannot carry.
///
/// An ordinary exception is scored as the worst value and counted: budget
/// counters stop a driver by raising once their ledger is spent. Anything
/// else ends the run: `KeyboardInterrupt`, `SystemExit`, or a return value
/// that is not a number. Once a run is ending, no further callback is made,
/// and the driver call re-raises the exception when it returns.
#[derive(Default)]
struct CallbackErrors {
    fatal: std::sync::Mutex<Option<PyErr>>,
    aborted: std::sync::Arc<std::sync::atomic::AtomicBool>,
    scored: std::sync::atomic::AtomicUsize,
    first_scored: std::sync::Mutex<Option<String>>,
}

impl CallbackErrors {
    fn aborted(&self) -> bool {
        self.aborted.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// The flag an ending run raises, for a ledger that should close with it.
    fn abort_flag(&self) -> std::sync::Arc<std::sync::atomic::AtomicBool> {
        std::sync::Arc::clone(&self.aborted)
    }

    fn record(&self, py: Python<'_>, err: PyErr) {
        if err.is_instance_of::<pyo3::exceptions::PyException>(py) {
            let previous = self
                .scored
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            if previous == 0 {
                *self.first_scored.lock().expect("callback error lock") = Some(err.to_string());
            }
        } else {
            self.abort(err);
        }
    }

    fn abort(&self, err: PyErr) {
        let mut fatal = self.fatal.lock().expect("callback error lock");
        if fatal.is_none() {
            *fatal = Some(err);
        }
        self.aborted
            .store(true, std::sync::atomic::Ordering::Relaxed);
    }

    /// A number from a callback's return value, or the end of the run.
    fn float(&self, py: Python<'_>, value: &Py<PyAny>) -> f64 {
        match value.extract::<f64>(py) {
            Ok(v) if v.is_nan() => f64::INFINITY,
            Ok(v) => v,
            Err(_) => {
                let kind = value
                    .bind(py)
                    .get_type()
                    .name()
                    .map(|n| n.to_string())
                    .unwrap_or_else(|_| "unknown".to_owned());
                self.abort(pyo3::exceptions::PyTypeError::new_err(format!(
                    "obj_fn must return a float, got {kind}"
                )));
                f64::INFINITY
            }
        }
    }

    /// Re-raises the exception that ended the run, and warns once when
    /// ordinary exceptions were scored as the worst value.
    fn finish(&self, py: Python<'_>) -> PyResult<()> {
        if let Some(err) = self.fatal.lock().expect("callback error lock").take() {
            return Err(err);
        }
        let scored = self.scored.load(std::sync::atomic::Ordering::Relaxed);
        if scored > 0 {
            let first = self
                .first_scored
                .lock()
                .expect("callback error lock")
                .clone()
                .unwrap_or_default();
            let message = std::ffi::CString::new(format!(
                "a callback raised {scored} exception(s): an objective call that raised was scored as the worst value and a gradient call as zero; the first was: {first}"
            ))
            .unwrap_or_default();
            let category = py.get_type::<pyo3::exceptions::PyRuntimeWarning>();
            PyErr::warn(py, category.as_any(), &message, 2)?;
        }
        Ok(())
    }
}

/// Internal objective adapter: a Python callable plus a `Bounds`.
/// Holds the GIL per `eval` call. `Py<PyAny>` is `Send + Sync` because
/// pyo3 ref-counts atomically and gates dereferencing on the GIL.
struct CallableObjective {
    fn_: Py<PyAny>,
    bounds: Bounds<f64>,
    errors: std::sync::Arc<CallbackErrors>,
}

impl CallableObjective {
    fn new(fn_: Py<PyAny>, bounds: Bounds<f64>) -> Self {
        Self {
            fn_,
            bounds,
            errors: std::sync::Arc::default(),
        }
    }

    /// The error record this objective and its gradient share.
    fn errors(&self) -> std::sync::Arc<CallbackErrors> {
        std::sync::Arc::clone(&self.errors)
    }
}

impl Objective<f64> for CallableObjective {
    fn dim(&self) -> usize {
        self.bounds.dims
    }

    fn bounds(&self) -> &Bounds<f64> {
        &self.bounds
    }

    fn eval(&self, x: ArrayView1<f64>) -> f64 {
        if self.errors.aborted() {
            return f64::INFINITY;
        }
        Python::attach(|py| {
            let py_arr = py_view1(py, x);
            match self.fn_.call1(py, (py_arr,)) {
                Ok(r) => self.errors.float(py, &r),
                Err(err) => {
                    self.errors.record(py, err);
                    f64::INFINITY
                }
            }
        })
    }

    /// Batch evaluation for multi-walker / multi-start steps.
    ///
    /// Prefer a Python `eval_batch(X)` method when present (CUTEst SOTA
    /// counters use this for parallel walker objectives). Otherwise evaluate
    /// all rows under a single GIL attach (avoids n attach thrash).
    fn eval_batch(&self, x: ndarray::ArrayView2<f64>) -> Array1<f64> {
        use numpy::PyArray2;
        let n = x.nrows();
        if n == 0 {
            return Array1::zeros(0);
        }
        if self.errors.aborted() {
            return Array1::from(vec![f64::INFINITY; n]);
        }
        Python::attach(|py| {
            // Multi-walker entry: Python objects (e.g. SOTA Counter) may
            // evaluate independent walker proposals in parallel.
            if let Ok(batch_fn) = self.fn_.getattr(py, "eval_batch") {
                let rows: Vec<Vec<f64>> = x
                    .outer_iter()
                    .map(|row| row.iter().copied().collect())
                    .collect();
                let py_arr =
                    PyArray2::from_vec2(py, &rows).expect("anneal: build walker batch array");
                match batch_fn.call1(py, (py_arr,)) {
                    Ok(r) => {
                        return match as_float_vector(py, &r) {
                            Some(values) if values.len() == n => Array1::from_iter(
                                values
                                    .into_iter()
                                    .map(|v| if v.is_nan() { f64::INFINITY } else { v }),
                            ),
                            _ => {
                                self.errors
                                    .abort(pyo3::exceptions::PyTypeError::new_err(format!(
                                        "eval_batch must return {n} floats"
                                    )));
                                Array1::from(vec![f64::INFINITY; n])
                            }
                        };
                    }
                    Err(err) => {
                        self.errors.record(py, err);
                        return Array1::from(vec![f64::INFINITY; n]);
                    }
                }
            }
            // Single attach, serial walkers (cheaper than n attach/release).
            let mut out = Vec::with_capacity(n);
            for row in x.outer_iter() {
                if self.errors.aborted() {
                    out.push(f64::INFINITY);
                    continue;
                }
                let owned: Vec<f64> = row.iter().copied().collect();
                let py_arr = PyArray1::from_vec(py, owned);
                let v = match self.fn_.call1(py, (py_arr,)) {
                    Ok(r) => self.errors.float(py, &r),
                    Err(err) => {
                        self.errors.record(py, err);
                        f64::INFINITY
                    }
                };
                out.push(v);
            }
            Array1::from(out)
        })
    }
}

/// Internal gradient adapter: a Python callable that takes a numpy
/// array `x` and returns a numpy array `grad f(x)` of the same shape.
/// Ceres-style plug-in: PyTorch users pass a callable that does
/// `tensor.requires_grad_(True); f(tensor).backward(); return tensor.grad.numpy()`,
/// JAX users pass `jax.grad(f)`, and analytic users pass a hand-coded
/// gradient. The pyo3 surface remains agnostic.
struct CallablePyGradient {
    fn_: Py<PyAny>,
    dim: usize,
    errors: std::sync::Arc<CallbackErrors>,
}

impl CallablePyGradient {
    fn new(fn_: Py<PyAny>, dim: usize, errors: &std::sync::Arc<CallbackErrors>) -> Self {
        Self {
            fn_,
            dim,
            errors: std::sync::Arc::clone(errors),
        }
    }
}

/// A flat float64 vector from any array-like a callback returns: a NumPy
/// array of another dtype or shape, a list, or a JAX or torch array.
fn as_float_vector(py: Python<'_>, value: &Py<PyAny>) -> Option<Vec<f64>> {
    if let Ok(arr) = value.extract::<PyReadonlyArray1<f64>>(py) {
        return Some(arr.as_array().iter().copied().collect());
    }
    let kwargs = PyDict::new(py);
    kwargs.set_item("dtype", "float64").ok()?;
    let flat = py
        .import("numpy")
        .ok()?
        .call_method("asarray", (value.bind(py),), Some(&kwargs))
        .ok()?
        .call_method0("ravel")
        .ok()?;
    let arr: PyReadonlyArray1<f64> = flat.extract().ok()?;
    Some(arr.as_array().iter().copied().collect())
}

impl eindir_core::Gradient<f64> for CallablePyGradient {
    fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
        if self.errors.aborted() {
            return Array1::zeros(self.dim);
        }
        Python::attach(|py| {
            let py_arr = py_view1(py, x);
            match self.fn_.call1(py, (py_arr,)) {
                Ok(r) => match as_float_vector(py, &r) {
                    Some(values) if values.len() == self.dim => Array1::from(values),
                    _ => {
                        self.errors
                            .abort(pyo3::exceptions::PyTypeError::new_err(format!(
                                "grad_fn must return {} numbers",
                                self.dim
                            )));
                        Array1::zeros(self.dim)
                    }
                },
                Err(err) => {
                    self.errors.record(py, err);
                    Array1::zeros(self.dim)
                }
            }
        })
    }

    fn dim(&self) -> usize {
        self.dim
    }
}

/// Runs HMC-driven SA with a user-supplied gradient and returns a `History`.
///
/// The trajectory kernel uses the Omelyan minimum-norm integrator.
/// q-Gaussian momentum follows the Tsallis/GSA construction.
///
/// Args:
///   obj_fn: Python callable `f(numpy.ndarray) -> float`.
///   grad_fn: Python callable `g(numpy.ndarray) -> numpy.ndarray`. Pass
///            `jax.grad(f)`, a torch `.backward()`-based wrapper, or
///            a hand-coded analytic gradient. Ceres-style plug-in.
///   low, high: numpy box bounds.
///   t_init: initial temperature for the log-cooling schedule.
///   epsilon: Omelyan integrator step size.
///   l_steps: number of Omelyan steps per HMC trajectory.
///   q: Tsallis momentum index. Default `1.0` (Gaussian). Values
///      `q in (1, 1 + 2/dim)` enable q-Gaussian momentum -- heavy-tailed
///      draws that help HMC-SA escape local cups on multimodal
///      objectives. For `dim=5`, `q < 1.4`; for `dim=10`, `q < 1.2`.
///   n_epochs, steps_per_epoch, seed.
///   x0: optional deterministic starting position.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, t_init = 5.0, epsilon = 0.05, l_steps = 5, q = 1.0, n_epochs = 100, steps_per_epoch = 50, seed = 42, x0 = None))]
#[allow(clippy::too_many_arguments)]
fn run_hmc(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    t_init: f64,
    epsilon: f64,
    l_steps: usize,
    q: f64,
    n_epochs: usize,
    steps_per_epoch: usize,
    seed: u64,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<PyHistory> {
    use crate::cool::LogCool;
    use crate::hmc::{GaussianMomentum, HmcSaSampler, OmelyanIntegrator, QGaussianMomentum};

    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    validate_box_bounds(&low_vec, &high_vec)?;
    let dim = low_vec.len();
    let q_max = 1.0 + 2.0 / dim as f64;
    if q > 1.0 && q >= q_max {
        return Err(pyo3::exceptions::PyValueError::new_err(format!(
            "q-Gaussian momentum requires q < 1 + 2/dim = {q_max} for dim = {dim}; got q = {q}"
        )));
    }
    let x0_arr = if let Some(arr) = x0 {
        let values = arr.as_slice()?.to_vec();
        if values.len() != dim {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "x0 must have the same length as low and high",
            ));
        }
        Some(Array1::from_vec(values))
    } else {
        None
    };
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let cool = LogCool::new(t_init, 2.0_f64);
    let integrator = OmelyanIntegrator::new(epsilon, l_steps, t_init);
    let history = if q <= 1.0 + 1e-9 {
        let sampler =
            HmcSaSampler::with_momentum(obj, grad, cool.clone(), GaussianMomentum, integrator);
        let sampler = if let Some(pos) = x0_arr {
            sampler.with_initial_pos(pos)
        } else {
            sampler
        };
        crate::runner::run_rs(sampler, &cool, n_epochs, steps_per_epoch, seed)
    } else {
        let sampler = HmcSaSampler::with_momentum(
            obj,
            grad,
            cool.clone(),
            QGaussianMomentum::new(q),
            integrator,
        );
        let sampler = if let Some(pos) = x0_arr {
            sampler.with_initial_pos(pos)
        } else {
            sampler
        };
        crate::runner::run_rs(sampler, &cool, n_epochs, steps_per_epoch, seed)
    };
    errors.finish(py)?;
    Ok(PyHistory::from(history))
}

/// Refines a supplied starting point with bounded L-BFGS polish.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, x0, max_fevals = 200, step0 = 1.0, grad_tol = 1e-8))]
fn polish(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    x0: PyReadonlyArray1<'_, f64>,
    max_fevals: usize,
    step0: f64,
    grad_tol: f64,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    let x0_vec = x0.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() || low_vec.len() != x0_vec.len() {
        return Err(PyValueError::new_err(
            "low, high, and x0 must have the same length",
        ));
    }
    if max_fevals < 1 {
        return Err(PyValueError::new_err("max_fevals must be positive"));
    }
    if step0 <= 0.0 {
        return Err(PyValueError::new_err("step0 must be positive"));
    }
    if grad_tol < 0.0 {
        return Err(PyValueError::new_err("grad_tol must be non-negative"));
    }

    let dim = low_vec.len();
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = crate::projected_gradient_polish(
        &obj,
        &grad,
        Array1::from_vec(x0_vec),
        max_fevals,
        step0,
        grad_tol,
    );

    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("projected_grad_norm", result.projected_grad_norm)?;
    out.set_item("projected_stationary", result.projected_stationary)?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Refines QMC starts with bounded L-BFGS polish.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, n_starts, max_fevals_per_start, seed = 0, step0 = 1.0, grad_tol = 1e-8, top_k = 0))]
fn qmc_polish(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    n_starts: usize,
    max_fevals_per_start: usize,
    seed: u64,
    step0: f64,
    grad_tol: f64,
    top_k: usize,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if n_starts < 1 {
        return Err(PyValueError::new_err("n_starts must be positive"));
    }
    if max_fevals_per_start < 1 {
        return Err(PyValueError::new_err(
            "max_fevals_per_start must be positive",
        ));
    }
    if step0 <= 0.0 {
        return Err(PyValueError::new_err("step0 must be positive"));
    }
    if grad_tol < 0.0 {
        return Err(PyValueError::new_err("grad_tol must be non-negative"));
    }

    let dim = low_vec.len();
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = crate::qmc_projected_gradient_polish(
        &obj,
        &grad,
        n_starts,
        max_fevals_per_start,
        seed,
        step0,
        grad_tol,
        top_k,
    );

    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_starts", result.n_starts)?;
    out.set_item("n_polished", result.n_polished)?;
    out.set_item("polished_values", result.polished_values)?;
    out.set_item(
        "polished_projected_grad_norms",
        result.polished_projected_grad_norms,
    )?;
    out.set_item("polished_stationary", result.polished_stationary)?;
    errors.finish(py)?;
    Ok(out.into())
}

fn qmc_polish_result_to_dict(
    py: Python<'_>,
    result: crate::QmcPolishResult,
) -> PyResult<Py<PyDict>> {
    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_starts", result.n_starts)?;
    out.set_item("n_polished", result.n_polished)?;
    out.set_item("polished_values", result.polished_values)?;
    out.set_item(
        "polished_projected_grad_norms",
        result.polished_projected_grad_norms,
    )?;
    out.set_item("polished_stationary", result.polished_stationary)?;
    Ok(out.into())
}

/// Refines QMC starts using an `eindir` native objective/gradient handle.
#[pyfunction]
#[pyo3(signature = (objective, n_starts, max_fevals_per_start, seed = 0, step0 = 1.0, grad_tol = 1e-8, top_k = 0))]
fn qmc_polish_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    n_starts: usize,
    max_fevals_per_start: usize,
    seed: u64,
    step0: f64,
    grad_tol: f64,
    top_k: usize,
) -> PyResult<Py<PyDict>> {
    if n_starts < 1 {
        return Err(PyValueError::new_err("n_starts must be positive"));
    }
    if max_fevals_per_start < 1 {
        return Err(PyValueError::new_err(
            "max_fevals_per_start must be positive",
        ));
    }
    if step0 <= 0.0 {
        return Err(PyValueError::new_err("step0 must be positive"));
    }
    if grad_tol < 0.0 {
        return Err(PyValueError::new_err("grad_tol must be non-negative"));
    }

    let result = crate::qmc_projected_gradient_polish(
        &*objective,
        &*objective,
        n_starts,
        max_fevals_per_start,
        seed,
        step0,
        grad_tol,
        top_k,
    );
    qmc_polish_result_to_dict(py, result)
}

/// Runs a QMC best/1/bin differential-evolution scout.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, max_evals, seed = 0, population_size = 30, weight_min = 0.5, weight_span = 0.5, crossover_rate = 0.7))]
fn qmc_best1bin_scout(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    max_evals: usize,
    seed: u64,
    population_size: usize,
    weight_min: f64,
    weight_span: f64,
    crossover_rate: f64,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if low_vec.is_empty() {
        return Err(PyValueError::new_err(
            "bounds must have at least one dimension",
        ));
    }
    if max_evals < 1 {
        return Err(PyValueError::new_err("max_evals must be positive"));
    }
    if population_size < 4 {
        return Err(PyValueError::new_err("population_size must be at least 4"));
    }
    if max_evals < population_size {
        return Err(PyValueError::new_err(
            "max_evals must cover the initial population",
        ));
    }
    if !weight_min.is_finite() || weight_min < 0.0 {
        return Err(PyValueError::new_err(
            "weight_min must be finite and non-negative",
        ));
    }
    if !weight_span.is_finite() || weight_span < 0.0 {
        return Err(PyValueError::new_err(
            "weight_span must be finite and non-negative",
        ));
    }
    if !crossover_rate.is_finite() || !(0.0..=1.0).contains(&crossover_rate) {
        return Err(PyValueError::new_err("crossover_rate must be in [0, 1]"));
    }

    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = crate::qmc_best1bin_scout(
        &obj,
        max_evals,
        seed,
        population_size,
        weight_min,
        weight_span,
        crossover_rate,
    );
    errors.finish(py)?;
    qmc_polish_result_to_dict(py, result)
}

/// Runs a QMC best/1/bin scout using an `eindir` native objective handle.
#[pyfunction]
#[pyo3(signature = (objective, max_evals, seed = 0, population_size = 30, weight_min = 0.5, weight_span = 0.5, crossover_rate = 0.7))]
fn qmc_best1bin_scout_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    max_evals: usize,
    seed: u64,
    population_size: usize,
    weight_min: f64,
    weight_span: f64,
    crossover_rate: f64,
) -> PyResult<Py<PyDict>> {
    if max_evals < 1 {
        return Err(PyValueError::new_err("max_evals must be positive"));
    }
    if population_size < 4 {
        return Err(PyValueError::new_err("population_size must be at least 4"));
    }
    if max_evals < population_size {
        return Err(PyValueError::new_err(
            "max_evals must cover the initial population",
        ));
    }
    if !weight_min.is_finite() || weight_min < 0.0 {
        return Err(PyValueError::new_err(
            "weight_min must be finite and non-negative",
        ));
    }
    if !weight_span.is_finite() || weight_span < 0.0 {
        return Err(PyValueError::new_err(
            "weight_span must be finite and non-negative",
        ));
    }
    if !crossover_rate.is_finite() || !(0.0..=1.0).contains(&crossover_rate) {
        return Err(PyValueError::new_err("crossover_rate must be in [0, 1]"));
    }

    let result = crate::qmc_best1bin_scout(
        &*objective,
        max_evals,
        seed,
        population_size,
        weight_min,
        weight_span,
        crossover_rate,
    );
    qmc_polish_result_to_dict(py, result)
}

fn validate_qmc_gsa_global_search_args(
    max_evals: usize,
    n_chains: usize,
    t_init: f64,
    q_v: f64,
    q_a: f64,
) -> PyResult<()> {
    if max_evals < 1 {
        return Err(PyValueError::new_err("max_evals must be positive"));
    }
    if n_chains < 1 {
        return Err(PyValueError::new_err("n_chains must be positive"));
    }
    if !t_init.is_finite() || t_init <= 0.0 {
        return Err(PyValueError::new_err("t_init must be finite and positive"));
    }
    if !(q_v > 1.0 && q_v < 3.0) {
        return Err(PyValueError::new_err("q_v must lie in (1, 3)"));
    }
    if !q_a.is_finite() {
        return Err(PyValueError::new_err("q_a must be finite"));
    }
    Ok(())
}

/// Runs bounded QMC-initialized generalized simulated annealing.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, max_evals, seed = 0, n_chains = 30, t_init = 1.0, q_v = 2.62, q_a = 1.7, x0 = None))]
fn qmc_gsa_global_search(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    max_evals: usize,
    seed: u64,
    n_chains: usize,
    t_init: f64,
    q_v: f64,
    q_a: f64,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    validate_box_bounds(&low_vec, &high_vec)?;
    validate_qmc_gsa_global_search_args(max_evals, n_chains, t_init, q_v, q_a)?;
    let start = read_x0(x0, &low_vec, &high_vec)?;

    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = crate::qmc_gsa_global_search_from(
        &obj,
        max_evals,
        seed,
        n_chains,
        t_init,
        q_v,
        q_a,
        start.as_ref().map(|x| x.view()),
    );
    errors.finish(py)?;
    qmc_polish_result_to_dict(py, result)
}

/// Runs bounded QMC-initialized GSA using a native objective handle.
#[pyfunction]
#[pyo3(signature = (objective, max_evals, seed = 0, n_chains = 30, t_init = 1.0, q_v = 2.62, q_a = 1.7, x0 = None))]
fn qmc_gsa_global_search_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    max_evals: usize,
    seed: u64,
    n_chains: usize,
    t_init: f64,
    q_v: f64,
    q_a: f64,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    validate_qmc_gsa_global_search_args(max_evals, n_chains, t_init, q_v, q_a)?;
    let bounds = <PyObjective as Objective<f64>>::bounds(&objective);
    let start = read_x0(
        x0,
        bounds.low.as_slice().expect("contiguous bounds"),
        bounds.high.as_slice().expect("contiguous bounds"),
    )?;

    let result = crate::qmc_gsa_global_search_from(
        &*objective,
        max_evals,
        seed,
        n_chains,
        t_init,
        q_v,
        q_a,
        start.as_ref().map(|x| x.view()),
    );
    qmc_polish_result_to_dict(py, result)
}

/// Runs a local shifted-QMC trust-region poll.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, center, max_evals, seed = 0, radius_fraction = 0.0, n_levels = 3, points_per_level = 0))]
fn qmc_trust_region_poll(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    center: PyReadonlyArray1<'_, f64>,
    max_evals: usize,
    seed: u64,
    radius_fraction: f64,
    n_levels: usize,
    points_per_level: usize,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    let center_vec = center.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() || low_vec.len() != center_vec.len() {
        return Err(PyValueError::new_err(
            "low, high, and center must have the same length",
        ));
    }
    if low_vec.is_empty() {
        return Err(PyValueError::new_err(
            "bounds must have at least one dimension",
        ));
    }
    if max_evals < 1 {
        return Err(PyValueError::new_err("max_evals must be positive"));
    }
    if !radius_fraction.is_finite() || radius_fraction < 0.0 {
        return Err(PyValueError::new_err(
            "radius_fraction must be finite and non-negative",
        ));
    }
    if n_levels < 1 {
        return Err(PyValueError::new_err("n_levels must be positive"));
    }

    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = crate::qmc_trust_region_poll(
        &obj,
        Array1::from_vec(center_vec),
        max_evals,
        seed,
        radius_fraction,
        n_levels,
        points_per_level,
    );
    errors.finish(py)?;
    qmc_polish_result_to_dict(py, result)
}

/// Runs a local shifted-QMC trust-region poll using a native objective handle.
#[pyfunction]
#[pyo3(signature = (objective, center, max_evals, seed = 0, radius_fraction = 0.0, n_levels = 3, points_per_level = 0))]
fn qmc_trust_region_poll_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    center: PyReadonlyArray1<'_, f64>,
    max_evals: usize,
    seed: u64,
    radius_fraction: f64,
    n_levels: usize,
    points_per_level: usize,
) -> PyResult<Py<PyDict>> {
    let center_vec = center.as_slice()?.to_vec();
    if center_vec.len() != objective.dim() {
        return Err(PyValueError::new_err(
            "center dimension must match objective bounds",
        ));
    }
    if max_evals < 1 {
        return Err(PyValueError::new_err("max_evals must be positive"));
    }
    if !radius_fraction.is_finite() || radius_fraction < 0.0 {
        return Err(PyValueError::new_err(
            "radius_fraction must be finite and non-negative",
        ));
    }
    if n_levels < 1 {
        return Err(PyValueError::new_err("n_levels must be positive"));
    }

    let result = crate::qmc_trust_region_poll(
        &*objective,
        Array1::from_vec(center_vec),
        max_evals,
        seed,
        radius_fraction,
        n_levels,
        points_per_level,
    );
    qmc_polish_result_to_dict(py, result)
}

/// Refines shifted QMC starts with bounded L-BFGS polish.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, n_starts, max_fevals_per_start, seed = 0, n_replicates = 1, step0 = 1.0, grad_tol = 1e-8, top_k = 0))]
fn shifted_qmc_polish(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    n_starts: usize,
    max_fevals_per_start: usize,
    seed: u64,
    n_replicates: usize,
    step0: f64,
    grad_tol: f64,
    top_k: usize,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if n_starts < 1 {
        return Err(PyValueError::new_err("n_starts must be positive"));
    }
    if max_fevals_per_start < 1 {
        return Err(PyValueError::new_err(
            "max_fevals_per_start must be positive",
        ));
    }
    if n_replicates < 1 {
        return Err(PyValueError::new_err("n_replicates must be positive"));
    }
    if step0 <= 0.0 {
        return Err(PyValueError::new_err("step0 must be positive"));
    }
    if grad_tol < 0.0 {
        return Err(PyValueError::new_err("grad_tol must be non-negative"));
    }

    let dim = low_vec.len();
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = crate::shifted_qmc_projected_gradient_polish(
        &obj,
        &grad,
        n_starts,
        max_fevals_per_start,
        seed,
        n_replicates,
        step0,
        grad_tol,
        top_k,
    );

    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_starts", result.n_starts)?;
    out.set_item("n_polished", result.n_polished)?;
    out.set_item("polished_values", result.polished_values)?;
    out.set_item(
        "polished_projected_grad_norms",
        result.polished_projected_grad_norms,
    )?;
    out.set_item("polished_stationary", result.polished_stationary)?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Rank-1 (mean-field) independence-sampler SA: fit a separable additive
/// surrogate, then spend the budget on tempered per-coordinate independence
/// proposals accepted by Metropolis on the true objective. Values only -- no
/// gradient. Returns `{best_pos, best_val, n_evals}`.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, max_fevals, seed=0, degree=8, grid_m=65,
                    local_frac=0.2, n_epochs=40, n_pilot=0))]
#[allow(clippy::too_many_arguments)]
fn additive_independence(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    max_fevals: usize,
    seed: u64,
    degree: usize,
    grid_m: usize,
    local_frac: f64,
    n_epochs: usize,
    n_pilot: usize,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if max_fevals < 1 {
        return Err(PyValueError::new_err("max_fevals must be positive"));
    }
    if degree < 1 {
        return Err(PyValueError::new_err("degree must be positive"));
    }
    // The backfitting fit reuses every pilot point across all coordinates, so
    // the pilot scales with the per-coordinate degree, not the dimension. A
    // dimension-scaled pilot would swallow the whole budget on high-dimensional
    // CUTEst problems and leave nothing to sample.
    let pilot = if n_pilot == 0 {
        (32 * degree).max(256)
    } else {
        n_pilot
    };
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = crate::methods::additive_independence_sa(
        &obj, seed, max_fevals, degree, grid_m, local_frac, n_epochs, pilot,
    );
    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Estimate the characteristic frequency used to scale the GLE drift.
#[pyfunction]
fn estimate_gle_omega0(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
) -> PyResult<f64> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    let dim = low_vec.len();
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let omega0 = crate::methods::estimate_gle_omega0(&obj, &grad);
    errors.finish(py)?;
    Ok(omega0)
}

fn gle_langevin_x0(
    x0: Option<PyReadonlyArray1<'_, f64>>,
    dim: usize,
) -> PyResult<Option<Array1<f64>>> {
    let Some(x0) = x0 else {
        return Ok(None);
    };
    let values = x0.as_slice()?.to_vec();
    if values.len() != dim {
        return Err(PyValueError::new_err(
            "x0 must have the same length as the bounds",
        ));
    }
    if values.iter().any(|value| !value.is_finite()) {
        return Err(PyValueError::new_err("x0 must contain only finite values"));
    }
    Ok(Some(Array1::from_vec(values)))
}

fn validate_gle_args(max_fevals: usize, omega0: Option<f64>) -> PyResult<()> {
    if max_fevals < 1 {
        return Err(PyValueError::new_err("max_fevals must be positive"));
    }
    if omega0.is_some_and(|omega| !omega.is_finite() || omega <= 0.0) {
        return Err(PyValueError::new_err("omega0 must be positive"));
    }
    Ok(())
}

fn gle_langevin_result_to_dict(
    py: Python<'_>,
    result: crate::methods::GleLangevinResult,
) -> PyResult<Py<PyDict>> {
    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos.to_vec()))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("omega0", result.omega0)?;
    out.set_item("dt", result.dt)?;
    out.set_item(
        "preconditioner_diag",
        PyArray1::from_vec(py, result.preconditioner_diag.to_vec()),
    )?;
    out.set_item("n_preconditioner_grads", result.n_preconditioner_grads)?;
    Ok(out.into())
}

/// GLE-thermostatted Langevin annealing: gradient-driven BAB dynamics with a
/// colored-noise (generalized Langevin) thermostat that flattens the sampling
/// efficiency across the curvature band. Returns `{best_pos, best_val, n_evals}`.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, max_fevals, seed=0,
                    omega0=None, dt=0.2, n_epochs=40, x0=None))]
#[allow(clippy::too_many_arguments)]
fn gle_langevin(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    max_fevals: usize,
    seed: u64,
    omega0: Option<f64>,
    dt: f64,
    n_epochs: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    validate_gle_args(max_fevals, omega0)?;
    let dim = low_vec.len();
    let x0 = gle_langevin_x0(x0, dim)?;
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = if let Some(omega0) = omega0 {
        crate::methods::gle_langevin_sa(&obj, &grad, seed, max_fevals, omega0, dt, n_epochs, x0)
    } else {
        crate::methods::gle_langevin_adaptive_sa(&obj, &grad, seed, max_fevals, dt, n_epochs, x0)
    };
    errors.finish(py)?;
    gle_langevin_result_to_dict(py, result)
}

/// GLE-Langevin annealing with a diagonal adaptive coordinate preconditioner.
#[pyfunction]
#[pyo3(signature = (obj_fn, grad_fn, low, high, max_fevals, seed=0,
                    omega0=None, dt=0.2, n_epochs=40, x0=None,
                    preconditioner_probes=None))]
#[allow(clippy::too_many_arguments)]
fn gle_langevin_preconditioned(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    max_fevals: usize,
    seed: u64,
    omega0: Option<f64>,
    dt: f64,
    n_epochs: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    preconditioner_probes: Option<usize>,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    validate_gle_args(max_fevals, omega0)?;
    let dim = low_vec.len();
    let x0 = gle_langevin_x0(x0, dim)?;
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = if let Some(omega0) = omega0 {
        crate::methods::gle_langevin_sa(&obj, &grad, seed, max_fevals, omega0, dt, n_epochs, x0)
    } else {
        crate::methods::gle_langevin_preconditioned_sa(
            &obj,
            &grad,
            seed,
            max_fevals,
            dt,
            n_epochs,
            x0,
            preconditioner_probes,
        )
    };
    errors.finish(py)?;
    gle_langevin_result_to_dict(py, result)
}

/// GLE-Langevin annealing using an `eindir` native objective/gradient handle.
#[pyfunction]
#[pyo3(signature = (objective, max_fevals, seed=0, omega0=None, dt=0.2,
                    n_epochs=40, x0=None))]
#[allow(clippy::too_many_arguments)]
fn gle_langevin_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    max_fevals: usize,
    seed: u64,
    omega0: Option<f64>,
    dt: f64,
    n_epochs: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    validate_gle_args(max_fevals, omega0)?;
    let x0 = gle_langevin_x0(x0, objective.dim())?;
    let result = if let Some(omega0) = omega0 {
        crate::methods::gle_langevin_sa(
            &*objective,
            &*objective,
            seed,
            max_fevals,
            omega0,
            dt,
            n_epochs,
            x0,
        )
    } else {
        crate::methods::gle_langevin_adaptive_sa(
            &*objective,
            &*objective,
            seed,
            max_fevals,
            dt,
            n_epochs,
            x0,
        )
    };
    gle_langevin_result_to_dict(py, result)
}

/// Preconditioned GLE-Langevin annealing using a native objective/gradient handle.
#[pyfunction]
#[pyo3(signature = (objective, max_fevals, seed=0, omega0=None, dt=0.2,
                    n_epochs=40, x0=None, preconditioner_probes=None))]
#[allow(clippy::too_many_arguments)]
fn gle_langevin_preconditioned_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    max_fevals: usize,
    seed: u64,
    omega0: Option<f64>,
    dt: f64,
    n_epochs: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    preconditioner_probes: Option<usize>,
) -> PyResult<Py<PyDict>> {
    validate_gle_args(max_fevals, omega0)?;
    let x0 = gle_langevin_x0(x0, objective.dim())?;
    let result = if let Some(omega0) = omega0 {
        crate::methods::gle_langevin_sa(
            &*objective,
            &*objective,
            seed,
            max_fevals,
            omega0,
            dt,
            n_epochs,
            x0,
        )
    } else {
        crate::methods::gle_langevin_preconditioned_sa(
            &*objective,
            &*objective,
            seed,
            max_fevals,
            dt,
            n_epochs,
            x0,
            preconditioner_probes,
        )
    };
    gle_langevin_result_to_dict(py, result)
}

// ---------------------------------------------------------------------------
// Thompson-allocated portfolio driver.
// ---------------------------------------------------------------------------

fn portfolio_result_to_dict(
    py: Python<'_>,
    result: crate::PortfolioResult,
) -> PyResult<Py<PyDict>> {
    let out = PyDict::new(py);
    out.set_item("best_pos", PyArray1::from_vec(py, result.best_pos))?;
    out.set_item("best_val", result.best_val)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    let pulls = PyDict::new(py);
    let successes = PyDict::new(py);
    for stat in &result.arm_stats {
        pulls.set_item(stat.name, stat.pulls)?;
        successes.set_item(stat.name, stat.successes)?;
    }
    out.set_item("arm_pulls", pulls)?;
    out.set_item("arm_successes", successes)?;
    Ok(out.into())
}

/// Classical population-controlled diffusion search (DMC-inspired arm).
///
/// Walkers, diffusion proposals, weight-based branch/kill, and population
/// control to a target size. Not quantum DMC.
///
/// When `x0` is provided, walker 0 is seeded at that point (clipped into the
/// box), matching the protocol anchor used by classical SA and dual annealing.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, target_n = 16, steps_per_control = 4, x0 = None))]
fn dmc_population_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    target_n: usize,
    steps_per_control: usize,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    require_positive_budget(budget)?;
    let (bounds, dim, seed_arr) = parse_box(low, high, x0)?;
    let seed_view = seed_arr.as_ref().map(|a| a.view());
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0xd1c_00b0);
    let result = match grad_fn {
        Some(grad_fn) => {
            let grad = CallablePyGradient::new(grad_fn, dim, &errors);
            crate::methods::dmc_population::run_dmc_population_seeded(
                &obj,
                Some(&grad),
                budget,
                seed,
                target_n,
                steps_per_control,
                crate::methods::dmc_population::DEFAULT_BETA0,
                seed_view,
                &mut rng,
            )
        }
        None => {
            crate::methods::dmc_population::run_dmc_population_seeded::<_, CallablePyGradient, _>(
                &obj,
                None,
                budget,
                seed,
                target_n,
                steps_per_control,
                crate::methods::dmc_population::DEFAULT_BETA0,
                seed_view,
                &mut rng,
            )
        }
    };
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("final_population", result.final_population)?;
    out.set_item("controls", result.controls)?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Gap-Proportional Metropolis Descent (GPMD).
///
/// Derived operating law: T = (1/2)·(f−f_best)/d so that the dimensionless
/// temperature θ = T d / gap equals θ⋆ = 1/2, inside the positive state-gain
/// window θ ∈ (0, 2) of the ES-sphere Metropolis model. See
/// `docs/derivations/gpmd_algorithm.org`.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, x0 = None))]
fn gpmd_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    require_positive_budget(budget)?;
    let (bounds, dim, seed_arr) = parse_box(low, high, x0)?;
    let seed_view = seed_arr.as_ref().map(|a| a.view());
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = match grad_fn {
        Some(grad_fn) => {
            let grad = CallablePyGradient::new(grad_fn, dim, &errors);
            crate::methods::gpmd::gpmd_optimize(&obj, Some(&grad), budget, seed, seed_view)
        }
        None => crate::methods::gpmd::gpmd_optimize::<_, CallablePyGradient>(
            &obj, None, budget, seed, seed_view,
        ),
    };
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_accept", result.n_accept)?;
    out.set_item("n_propose", result.n_propose)?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Standalone whitened BFWT annealed descent (AmSa).
///
/// One adaptive Metropolis chain with BFWT temperature (D11), Haario
/// covariance whitening (anisotropic critical-temperature result),
/// Robbins--Monro scale control toward the design acceptance 0.32, an
/// online barrier estimate from rejected uphill moves, IPOP-style reseeds
/// on stagnation, and a stall-recovering projected quasi-Newton polish
/// tail on the final quarter of the budget when a gradient is available.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, x0 = None))]
fn amsa_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    require_positive_budget(budget)?;
    let (bounds, dim, seed_arr) = parse_box(low, high, x0)?;
    let seed_view = seed_arr.as_ref().map(|a| a.view());
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = match grad_fn {
        Some(grad_fn) => {
            let grad = CallablePyGradient::new(grad_fn, dim, &errors);
            crate::methods::amsa::amsa_optimize(&obj, Some(&grad), budget, seed, seed_view)
        }
        None => crate::methods::amsa::amsa_optimize::<_, CallablePyGradient>(
            &obj, None, budget, seed, seed_view,
        ),
    };
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_reseeds", result.n_reseeds)?;
    errors.finish(py)?;
    Ok(out.into())
}

fn coverage_decisions_dict<'py>(
    py: Python<'py>,
    stats: &crate::methods::box_hopping::CoverageDecisionStats,
) -> PyResult<Bound<'py, PyDict>> {
    let out = PyDict::new(py);
    out.set_item("comparisons", stats.comparisons)?;
    out.set_item("unresolved", stats.unresolved)?;
    out.set_item("accepted", stats.accepted)?;
    out.set_item("peer_overlap", stats.peer_overlap)?;
    out.set_item("peer_delta_changes", stats.peer_delta_changes)?;
    out.set_item("probability_changes", stats.probability_changes)?;
    out.set_item("drawn_comparisons", stats.drawn_comparisons)?;
    out.set_item("drawn_disagreements", stats.drawn_disagreements)?;
    out.set_item("probability_change_sum", stats.probability_change_sum)?;
    out.set_item("max_probability_change", stats.max_probability_change)?;
    out.set_item("max_abs_peer_delta", stats.max_abs_peer_delta)?;
    out.set_item(
        "max_abs_peer_delta_over_temperature",
        stats.max_abs_peer_delta_over_temperature,
    )?;
    Ok(out)
}

/// Communicating box hops: Gaussian kick, quench, shared Euclidean history.
///
/// Four (or `replicas`) algebraic hops divide one work-unit budget. They
/// share a Euclidean minimum history and Goedecker escape feedback. This is
/// not cluster hopping: the move is a reflected Gaussian on the box. A
/// callback raising `BaseException` that is not an `Exception` stops the
/// ensemble at once and is re-raised. The best point found is kept.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, x0 = None,
                    replicas = 4, history = "shared", membership = "accepted"))]
#[allow(clippy::too_many_arguments)]
fn box_ensemble_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    replicas: usize,
    history: &str,
    membership: &str,
) -> PyResult<Py<PyDict>> {
    let parsed = parse_box_search(low, high, budget, replicas, x0, history, membership)?;
    let seed_view = parsed.x0.as_ref().map(|a| a.view());
    let config = crate::methods::box_hopping::BoxEnsembleConfig {
        replicas,
        budget,
        history: parsed.history,
        membership: parsed.membership,
        identity_tol: crate::methods::box_hopping::IDENTITY_TOL,
        shared_deposits: 8,
        shared_visit_policy: crate::methods::minima_hopping::SharedVisitPolicy::Tabu,
        ..crate::methods::box_hopping::BoxEnsembleConfig::default()
    };
    let Some(grad_fn) = grad_fn else {
        return Err(PyValueError::new_err(
            "box_ensemble_optimize requires grad_fn; use ensemble_optimize without a gradient",
        ));
    };
    let obj = CallableObjective::new(obj_fn, parsed.bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let dim = parsed.dim;
    let grad = CallablePyGradient::new(grad_fn, dim, &errors);
    let result = with_replica_threads(py, || {
        crate::methods::box_hopping::box_ensemble_optimize(&obj, &grad, seed, seed_view, &config)
    });
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("hops", result.hops)?;
    out.set_item("history_observations", result.history_observations)?;
    out.set_item("history_minima", result.history_minima)?;
    out.set_item("history_refusals", result.history_cost.1)?;
    out.set_item("history_seconds", result.history_cost.2)?;
    out.set_item("shared_deposits", result.shared_deposits)?;
    out.set_item("coverage_observations", result.coverage.local_observations)?;
    out.set_item("coverage_published", result.coverage.published_visits)?;
    out.set_item(
        "coverage_applied_foreign",
        result.coverage.applied_foreign_visits,
    )?;
    out.set_item(
        "coverage_capped_foreign",
        result.coverage.capped_foreign_visits,
    )?;
    out.set_item(
        "coverage_regions_per_chain",
        result.coverage.per_chain_regions,
    )?;
    out.set_item("coverage_recrossings", result.coverage.recrossings)?;
    out.set_item(
        "coverage_peer_recrossings",
        result.coverage.peer_recrossings,
    )?;
    out.set_item(
        "coverage_peer_only_recrossings",
        result.coverage.peer_only_recrossings,
    )?;
    out.set_item("coverage_escape_updates", result.coverage.escape_updates)?;
    out.set_item("coverage_novel_arrivals", result.coverage.novel_arrivals)?;
    out.set_item("coverage_novelty_updates", result.coverage.novelty_updates)?;
    out.set_item(
        "coverage_published_samples",
        result.coverage.published_samples,
    )?;
    out.set_item(
        "coverage_applied_foreign_samples",
        result.coverage.applied_foreign_samples,
    )?;
    out.set_item(
        "coverage_sample_peer_checks",
        result.coverage.sample_peer_checks,
    )?;
    out.set_item(
        "coverage_sample_anchor_overlaps",
        result.coverage.sample_anchor_overlaps,
    )?;
    out.set_item(
        "coverage_sample_anchor_only_overlaps",
        result.coverage.sample_anchor_only_overlaps,
    )?;
    out.set_item("coverage_sample_overlaps", result.coverage.sample_overlaps)?;
    out.set_item(
        "coverage_repelled_proposals",
        result.coverage.repelled_proposals,
    )?;
    out.set_item(
        "coverage_constrained_repulsions",
        result.coverage.constrained_repulsions,
    )?;
    out.set_item(
        "coverage_decisions",
        coverage_decisions_dict(py, &result.coverage_decisions)?,
    )?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Box search split on gradient: hop-and-quench, or the values-only portfolio.
///
/// A callback raising `BaseException` that is not an `Exception` stops the
/// search at once and is re-raised. The best point found is kept.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, x0 = None,
                    replicas = 4, history = "shared", membership = "accepted", *,
                    coverage_shared = None, coverage_radius = None, coverage_neighbors = None))]
#[allow(clippy::too_many_arguments)]
fn ensemble_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    replicas: usize,
    history: &str,
    membership: &str,
    coverage_shared: Option<bool>,
    coverage_radius: Option<f64>,
    coverage_neighbors: Option<usize>,
) -> PyResult<Py<PyDict>> {
    let parsed = parse_box_search(low, high, budget, replicas, x0, history, membership)?;
    if coverage_radius.is_some_and(|radius| !radius.is_finite() || radius <= 0.0) {
        return Err(PyValueError::new_err(
            "coverage radius must be finite and positive",
        ));
    }
    let seed_view = parsed.x0.as_ref().map(|a| a.view());
    let obj = CallableObjective::new(obj_fn, parsed.bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let dim = parsed.dim;
    let history_mode = parsed.history;
    let membership = parsed.membership;
    let coverage =
        (coverage_shared.is_some() || coverage_radius.is_some() || coverage_neighbors.is_some())
            .then(|| {
                let defaults = crate::methods::box_hopping::BoxCoverageConfig::default();
                crate::methods::box_hopping::BoxCoverageConfig {
                    shared: coverage_shared.unwrap_or(matches!(
                        history_mode,
                        crate::methods::ensemble::HistoryMode::Shared
                    )),
                    radius: coverage_radius.unwrap_or(defaults.radius),
                    neighbors: coverage_neighbors.unwrap_or(defaults.neighbors),
                    ..defaults
                }
            });
    let result = with_replica_threads(py, || {
        let grad = grad_fn.map(|fn_| CallablePyGradient::new(fn_, dim, &errors));
        if let Some(coverage) = coverage.as_ref() {
            let config = crate::methods::box_hopping::BoxEnsembleConfig {
                replicas,
                budget,
                history: history_mode,
                membership,
                ..Default::default()
            };
            crate::methods::box_hopping::ensemble_hop_optimize_with_config(
                &obj,
                grad.as_ref(),
                seed,
                seed_view,
                &config,
                coverage,
            )
        } else {
            crate::methods::box_hopping::ensemble_hop_optimize(
                &obj,
                grad.as_ref(),
                seed,
                seed_view,
                budget,
                replicas,
                history_mode,
                membership,
            )
        }
    });
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("charged", result.charged)?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("hops", result.hops)?;
    out.set_item("history_observations", result.history_observations)?;
    out.set_item("history_minima", result.history_minima)?;
    out.set_item("history_refusals", result.history_cost.1)?;
    out.set_item("history_seconds", result.history_cost.2)?;
    out.set_item("coverage_observations", result.coverage.local_observations)?;
    out.set_item("coverage_published", result.coverage.published_visits)?;
    out.set_item(
        "coverage_applied_foreign",
        result.coverage.applied_foreign_visits,
    )?;
    out.set_item(
        "coverage_capped_foreign",
        result.coverage.capped_foreign_visits,
    )?;
    out.set_item(
        "coverage_regions_per_chain",
        result.coverage.per_chain_regions,
    )?;
    out.set_item("coverage_recrossings", result.coverage.recrossings)?;
    out.set_item(
        "coverage_peer_recrossings",
        result.coverage.peer_recrossings,
    )?;
    out.set_item(
        "coverage_peer_only_recrossings",
        result.coverage.peer_only_recrossings,
    )?;
    out.set_item("coverage_escape_updates", result.coverage.escape_updates)?;
    out.set_item("coverage_novel_arrivals", result.coverage.novel_arrivals)?;
    out.set_item("coverage_novelty_updates", result.coverage.novelty_updates)?;
    out.set_item(
        "coverage_published_samples",
        result.coverage.published_samples,
    )?;
    out.set_item(
        "coverage_applied_foreign_samples",
        result.coverage.applied_foreign_samples,
    )?;
    out.set_item(
        "coverage_sample_peer_checks",
        result.coverage.sample_peer_checks,
    )?;
    out.set_item(
        "coverage_sample_anchor_overlaps",
        result.coverage.sample_anchor_overlaps,
    )?;
    out.set_item(
        "coverage_sample_anchor_only_overlaps",
        result.coverage.sample_anchor_only_overlaps,
    )?;
    out.set_item("coverage_sample_overlaps", result.coverage.sample_overlaps)?;
    out.set_item(
        "coverage_repelled_proposals",
        result.coverage.repelled_proposals,
    )?;
    out.set_item(
        "coverage_constrained_repulsions",
        result.coverage.constrained_repulsions,
    )?;
    out.set_item(
        "coverage_decisions",
        coverage_decisions_dict(py, &result.coverage_decisions)?,
    )?;
    errors.finish(py)?;
    Ok(out.into())
}

/// Budget-Feasible Window Temperature (BFWT / D11).
///
/// Clamps design temperature T_des = (1/2)·gap/d into the D6∩D7 window
/// [b_hat/log(B+e), 2·gap/d]. When `barrier_hat` is 0, recovers GPMD.
/// Local law under the
/// stated models only — not a dual-annealing field-SOTA claim.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, barrier_hat = 0.0, grad_fn = None, x0 = None))]
fn bfwt_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    barrier_hat: f64,
    grad_fn: Option<Py<PyAny>>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    require_positive_budget(budget)?;
    if !barrier_hat.is_finite() || barrier_hat < 0.0 {
        return Err(PyValueError::new_err(
            "barrier_hat must be a finite non-negative float",
        ));
    }
    let (bounds, dim, seed_arr) = parse_box(low, high, x0)?;
    let seed_view = seed_arr.as_ref().map(|a| a.view());
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let result = match grad_fn {
        Some(grad_fn) => {
            let grad = CallablePyGradient::new(grad_fn, dim, &errors);
            crate::methods::bfwt::bfwt_optimize(
                &obj,
                Some(&grad),
                budget,
                seed,
                barrier_hat,
                seed_view,
            )
        }
        None => crate::methods::bfwt::bfwt_optimize::<_, CallablePyGradient>(
            &obj,
            None,
            budget,
            seed,
            barrier_hat,
            seed_view,
        ),
    };
    let out = PyDict::new(py);
    out.set_item("best_val", result.best_val)?;
    out.set_item("best_pos", py_view1(py, result.best_pos.view()))?;
    out.set_item("n_evals", result.n_evals)?;
    out.set_item("n_grads", result.n_grads)?;
    out.set_item("n_accept", result.n_accept)?;
    out.set_item("last_mode", result.last_mode.as_str())?;
    errors.finish(py)?;
    Ok(out.into())
}

/// A bare `usize` extraction truncates a float. Neighbour counts are whole.
fn coverage_neighbor_count(value: &Bound<'_, PyAny>) -> PyResult<usize> {
    if value.is_instance_of::<PyFloat>() {
        return Err(PyTypeError::new_err(
            "coverage_neighbors must be an integer",
        ));
    }
    value.extract()
}

/// Runs the Thompson-allocated portfolio global optimizer.
///
/// One generic driver with a single budget knob: a discounted
/// Beta-Bernoulli posterior over the library's building blocks (QMC
/// restart descent, adaptive basin hopping, archive-fit
/// additive-surrogate independence proposals, best/1/bin differential
/// evolution, preconditioned GLE-Langevin, shifted-QMC trust-region
/// polls, generalized simulated annealing, the Bayesian-pilot tuned
/// classical point, parallel tempering, q-Gaussian HMC, and the
/// active-subspace collapse) allocates budget slices by Thompson
/// sampling under a decaying uniform floor. Objective and
/// native-gradient evaluations share the budget at one unit each; all
/// scheduler quantities derive from the budget, the dimension, and the
/// arm count.
///
/// Args:
///   obj_fn: Python callable `f(numpy.ndarray) -> float`.
///   low, high: numpy box bounds.
///   budget: combined objective + gradient evaluation budget.
///   seed: RNG seed.
///   grad_fn: optional gradient callable; enables the gradient arms
///            and the final polish.
///
/// A callback raising `BaseException` that is not an `Exception` stops the
/// portfolio at once and is re-raised. The best point found is kept.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, budget, seed = 0, grad_fn = None, noise_sigma = None, policy = "auto", x0 = None, *, replicas = 1, coverage_shared = true, coverage_radius = 0.05, coverage_neighbors = 0))]
fn global_optimize(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    budget: usize,
    seed: u64,
    grad_fn: Option<Py<PyAny>>,
    noise_sigma: Option<f64>,
    policy: &str,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    replicas: usize,
    coverage_shared: bool,
    coverage_radius: f64,
    #[pyo3(from_py_with = coverage_neighbor_count)] coverage_neighbors: usize,
) -> PyResult<Py<PyDict>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    validate_box_bounds(&low_vec, &high_vec)?;
    if budget == 0 {
        return Err(PyValueError::new_err("budget must be positive"));
    }
    let start = read_x0(x0, &low_vec, &high_vec)?;
    let dim = low_vec.len();
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    if let Some(sigma) = noise_sigma
        && (sigma <= 0.0 || !sigma.is_finite())
    {
        return Err(PyValueError::new_err(
            "noise_sigma must be positive and finite",
        ));
    }
    let pol = match policy {
        "auto" | "Auto" | "" => crate::PortfolioPolicy::Auto,
        "legacy" | "Legacy" => crate::PortfolioPolicy::Legacy,
        other => {
            return Err(PyValueError::new_err(format!(
                "policy must be 'auto' or 'legacy', got {other:?}"
            )));
        }
    };
    if replicas == 0 {
        return Err(PyValueError::new_err("replicas must be positive"));
    }
    if !coverage_radius.is_finite() || coverage_radius <= 0.0 {
        return Err(PyValueError::new_err(
            "coverage_radius must be positive and finite",
        ));
    }
    let x0_view = start.as_ref().map(|x| x.view());
    if replicas > 1 {
        let config = crate::methods::portfolio::PortfolioEnsembleConfig {
            replicas,
            budget,
            noise_sigma,
            policy: pol,
            coverage: crate::methods::BoxCoverageConfig {
                shared: coverage_shared,
                radius: coverage_radius,
                neighbors: coverage_neighbors,
                ..crate::methods::BoxCoverageConfig::default()
            },
        };
        let grad = grad_fn.map(|fn_| CallablePyGradient::new(fn_, dim, &errors));
        let out = portfolio_peers::run(py, &obj, grad.as_ref(), seed, &config);
        errors.finish(py)?;
        return out;
    }
    let result = match grad_fn {
        Some(grad_fn) => {
            let grad = CallablePyGradient::new(grad_fn, dim, &errors);
            crate::portfolio_optimize_from(
                &obj,
                Some(&grad),
                budget,
                seed,
                noise_sigma,
                pol,
                x0_view,
            )
        }
        None => crate::portfolio_optimize_from::<_, CallablePyGradient>(
            &obj,
            None,
            budget,
            seed,
            noise_sigma,
            pol,
            x0_view,
        ),
    };
    errors.finish(py)?;
    portfolio_result_to_dict(py, result)
}

/// Runs the portfolio global optimizer with a native objective handle.
#[pyfunction]
#[pyo3(signature = (objective, budget, seed = 0, use_gradient = true, noise_sigma = None, x0 = None))]
fn global_optimize_objective(
    py: Python<'_>,
    objective: PyRef<'_, PyObjective>,
    budget: usize,
    seed: u64,
    use_gradient: bool,
    noise_sigma: Option<f64>,
    x0: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    if budget == 0 {
        return Err(PyValueError::new_err("budget must be positive"));
    }
    if let Some(sigma) = noise_sigma
        && (sigma <= 0.0 || !sigma.is_finite())
    {
        return Err(PyValueError::new_err(
            "noise_sigma must be positive and finite",
        ));
    }
    let bounds = <PyObjective as Objective<f64>>::bounds(&objective);
    let start = read_x0(
        x0,
        bounds.low.as_slice().expect("contiguous bounds"),
        bounds.high.as_slice().expect("contiguous bounds"),
    )?;
    let x0_view = start.as_ref().map(|x| x.view());
    let policy = crate::PortfolioPolicy::Auto;
    let result = if use_gradient {
        crate::portfolio_optimize_from(
            &*objective,
            Some(&*objective),
            budget,
            seed,
            noise_sigma,
            policy,
            x0_view,
        )
    } else {
        crate::portfolio_optimize_from::<_, PyObjective>(
            &*objective,
            None,
            budget,
            seed,
            noise_sigma,
            policy,
            x0_view,
        )
    };
    portfolio_result_to_dict(py, result)
}

// ---------------------------------------------------------------------------
// Preset enum + dispatch.
// ---------------------------------------------------------------------------

/// Preset selector accepted by `run`. Matches one of the three
/// IISE-manuscript points.
#[derive(FromPyObject)]
enum Preset {
    #[pyo3(transparent)]
    Boltzmann(PyBoltzmann),
    #[pyo3(transparent)]
    Fast(PyFast),
    #[pyo3(transparent)]
    Gsa(PyGsa),
}

impl Preset {
    /// Refuses parameters the component constructors would panic on.
    fn validate(&self) -> PyResult<()> {
        let (t_init, scale, scale_name) = match self {
            Preset::Boltzmann(p) => (p.t_init, p.sigma, "sigma"),
            Preset::Fast(p) => (p.t_init, p.gamma, "gamma"),
            Preset::Gsa(p) => (p.t_init, 1.0, "scale"),
        };
        if !(t_init.is_finite() && t_init > 0.0) {
            return Err(PyValueError::new_err(format!(
                "t_init must be positive and finite, got {t_init}"
            )));
        }
        if !(scale.is_finite() && scale > 0.0) {
            return Err(PyValueError::new_err(format!(
                "{scale_name} must be positive and finite, got {scale}"
            )));
        }
        if let Preset::Gsa(p) = self {
            if !(p.q_v > 1.0 && p.q_v < 3.0) {
                return Err(PyValueError::new_err(format!(
                    "q_v must lie in (1, 3), got {}",
                    p.q_v
                )));
            }
            if !p.q_a.is_finite() {
                return Err(PyValueError::new_err("q_a must be finite"));
            }
        }
        Ok(())
    }
}

/// Runs the SA driver inside the box and returns a `History`.
///
/// Every proposal is mirror-reflected into `[low, high]`, so every point
/// `obj_fn` sees, and the returned `best_pos`, lies inside the box.
///
/// Args:
///   obj_fn: Python callable `f(numpy.ndarray) -> float` evaluated at every
///           proposal. Held via the GIL.
///   low, high: numpy arrays defining the box. Same length defines the
///              objective dimensionality.
///   preset: one of `Boltzmann()`, `Fast()`, `Gsa()` from `anneal`.
///   n_epochs, steps_per_epoch: SA loop dimensions.
///   seed: u64 seed for the StdRng.
///   x0: optional starting point inside the box; a uniform draw otherwise.
///   max_evals: optional cap on calls to `obj_fn`, the start included. The
///              cooling schedule still spans `n_epochs`; the cap ends the run
///              inside the epoch where it falls.
///
/// The start costs one evaluation, so the run makes
/// `1 + n_epochs * steps_per_epoch` calls to `obj_fn`, or `max_evals` when
/// that is smaller. A callback raising `BaseException` that is not an
/// `Exception` stops the walk at once. The best point found is kept, and
/// the exception is re-raised.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, preset, n_epochs = 100, steps_per_epoch = 200, seed = 42, x0 = None, max_evals = None))]
fn run(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    preset: Preset,
    n_epochs: usize,
    steps_per_epoch: usize,
    seed: u64,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    max_evals: Option<usize>,
) -> PyResult<PyHistory> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    validate_box_bounds(&low_vec, &high_vec)?;
    preset.validate()?;
    validate_max_evals(max_evals)?;
    let start = read_x0(x0, &low_vec, &high_vec)?;
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let history = match preset {
        Preset::Boltzmann(p) => {
            let v = boltzmann_in_box(obj, p.t_init, p.sigma)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_variant_from(v, n_epochs, steps_per_epoch, seed, start, max_evals)
        }
        Preset::Fast(p) => {
            let v = fast_in_box(obj, p.t_init, p.gamma)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_variant_from(v, n_epochs, steps_per_epoch, seed, start, max_evals)
        }
        Preset::Gsa(p) => {
            let v = gsa_in_box(obj, p.t_init, p.q_v, p.q_a)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_variant_from(v, n_epochs, steps_per_epoch, seed, start, max_evals)
        }
    };
    errors.finish(py)?;
    Ok(PyHistory::from(history))
}

/// Low-discrepancy points scaled to the supplied box bounds.
#[pyfunction]
#[pyo3(signature = (low, high, n, skip = 1))]
fn low_discrepancy_points(
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    n: usize,
    skip: u64,
) -> PyResult<Vec<Vec<f64>>> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if low_vec.is_empty() {
        return Err(PyValueError::new_err(
            "bounds must have at least one dimension",
        ));
    }
    if low_vec
        .iter()
        .zip(high_vec.iter())
        .any(|(&lo, &hi)| hi < lo)
    {
        return Err(PyValueError::new_err(
            "each upper bound must be greater than or equal to the lower bound",
        ));
    }
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 0.0);
    let points = eindir_core::low_discrepancy_points(&bounds, n, skip);
    Ok(points.outer_iter().map(|row| row.to_vec()).collect())
}

/// Low-discrepancy BGSA pilot draws `(T_0, sigma, q_v)`.
#[pyfunction]
#[pyo3(signature = (n, seed = 42))]
fn pilot_draws_qmc(n: usize, seed: u64) -> PyResult<Vec<Vec<f64>>> {
    let prior = crate::methods::PilotPrior::default();
    let draws = crate::methods::pilot_draws_qmc(&prior, n, seed);
    Ok(draws
        .into_iter()
        .map(|(t_init, sigma, q_v)| vec![t_init, sigma, q_v])
        .collect())
}

/// Runs the SA driver inside the box from a low-discrepancy multistart design.
///
/// `x0`, when supplied, replaces the first design point. Every start costs one
/// evaluation, so the run makes `n_starts * (1 + n_epochs * steps_per_epoch)`
/// calls to `obj_fn`, and every one of them lies inside `[low, high]`.
/// `max_evals`, when supplied, is split as evenly as possible over the starts
/// and caps the total.
#[pyfunction]
#[pyo3(signature = (obj_fn, low, high, preset, n_starts = 8, n_epochs = 100, steps_per_epoch = 200, seed = 42, x0 = None, max_evals = None))]
fn run_qmc(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    low: PyReadonlyArray1<'_, f64>,
    high: PyReadonlyArray1<'_, f64>,
    preset: Preset,
    n_starts: usize,
    n_epochs: usize,
    steps_per_epoch: usize,
    seed: u64,
    x0: Option<PyReadonlyArray1<'_, f64>>,
    max_evals: Option<usize>,
) -> PyResult<PyHistory> {
    let low_vec = low.as_slice()?.to_vec();
    let high_vec = high.as_slice()?.to_vec();
    validate_max_evals(max_evals)?;
    if low_vec.len() != high_vec.len() {
        return Err(PyValueError::new_err(
            "low and high must have the same length",
        ));
    }
    if low_vec.is_empty() {
        return Err(PyValueError::new_err(
            "bounds must have at least one dimension",
        ));
    }
    if low_vec.iter().zip(high_vec.iter()).any(|(&lo, &hi)| {
        !lo.is_finite() || !hi.is_finite() || !(2.0 * (hi - lo)).is_finite() || hi < lo
    }) || !low_vec
        .iter()
        .zip(high_vec.iter())
        .map(|(&lo, &hi)| hi - lo)
        .sum::<f64>()
        .is_finite()
    {
        return Err(PyValueError::new_err(
            "each bound must be finite and each upper bound must be greater than or equal to the lower bound",
        ));
    }
    preset.validate()?;
    let start = read_x0(x0, &low_vec, &high_vec)?;
    let bounds = Bounds::new(Array1::from_vec(low_vec), Array1::from_vec(high_vec), 1e-9);
    let obj = CallableObjective::new(obj_fn, bounds);
    let errors = obj.errors();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let history = match preset {
        Preset::Boltzmann(p) => {
            let v = boltzmann_in_box(obj, p.t_init, p.sigma)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_qmc_variant_from(
                v,
                n_starts,
                n_epochs,
                steps_per_epoch,
                seed,
                start,
                max_evals,
            )
        }
        Preset::Fast(p) => {
            let v = fast_in_box(obj, p.t_init, p.gamma)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_qmc_variant_from(
                v,
                n_starts,
                n_epochs,
                steps_per_epoch,
                seed,
                start,
                max_evals,
            )
        }
        Preset::Gsa(p) => {
            let v = gsa_in_box(obj, p.t_init, p.q_v, p.q_a)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
            crate::runner::run_rs_qmc_variant_from(
                v,
                n_starts,
                n_epochs,
                steps_per_epoch,
                seed,
                start,
                max_evals,
            )
        }
    };
    errors.finish(py)?;
    Ok(PyHistory::from(history))
}

/// Empirical OSA (Ball, Branke & Meisel 2018) acceptance rate and mean samples
/// per decision for a true cost difference `delta` observed through
/// `Normal(delta, sigma^2)` noise. Exposes the first-class Rust noise-aware
/// acceptance component (`noise_accept::OsaAccept`) to Python; mirrors the
/// reference `experiments/osa.py::acceptance_rate`.
#[pyfunction]
#[pyo3(signature = (delta, temp, sigma, trials = 20000, c_star = 0.0, seed = 0))]
fn osa_acceptance_rate(
    delta: f64,
    temp: f64,
    sigma: f64,
    trials: usize,
    c_star: f64,
    seed: u64,
) -> PyResult<(f64, f64)> {
    if temp.partial_cmp(&0.0) != Some(std::cmp::Ordering::Greater) {
        return Err(PyValueError::new_err("temp must be positive"));
    }
    if sigma.partial_cmp(&0.0) != Some(std::cmp::Ordering::Greater) {
        return Err(PyValueError::new_err("sigma must be positive"));
    }
    let osa = crate::noise_accept::OsaAccept::with_params(c_star, 100_000);
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
    Ok(osa.acceptance_rate(delta, temp, sigma, trials, &mut rng))
}

// ---------------------------------------------------------------------------
// Measured cluster-search layer.
// ---------------------------------------------------------------------------

/// Driver settings for the cluster-search layer.
///
/// Construct with [`Config.recommended`], [`Config.derived`], or
/// [`Config.for_cluster`]. The recommended stack is the measured
/// default: composed surface relocations, depth-rewarded move
/// allocation, and tabu on stall.
#[pyclass(name = "Config")]
#[derive(Clone)]
pub struct PyClusterConfig {
    inner: crate::methods::cluster_hopping::Config,
    recommended: bool,
}

#[pymethods]
impl PyClusterConfig {
    /// Measured configuration for `n` points.
    #[staticmethod]
    fn recommended(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::recommended(n),
            recommended: true,
        })
    }

    /// Communicating paper arm: orbit kernel plus recognition, not recommended.
    #[staticmethod]
    fn communicating(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::communicating(n),
            recommended: false,
        })
    }

    /// Recommended flags with the cost-asymmetric screen and budget-window
    /// temperature. Not the measured configuration.
    #[staticmethod]
    fn derived(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::derived(n),
            recommended: true,
        })
    }

    /// Plain Wales-Doye protocol for `n` points (comparison baseline).
    #[staticmethod]
    fn for_cluster(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::for_cluster(n),
            recommended: false,
        })
    }

    /// The communicating arm on `n` rigid TIP4P waters.
    #[staticmethod]
    fn communicating_tip4p(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::communicating_tip4p(n),
            recommended: false,
        })
    }

    /// The recommended arm on `n` rigid TIP4P waters.
    #[staticmethod]
    fn recommended_tip4p(n: usize) -> PyResult<Self> {
        if n < 2 {
            return Err(PyValueError::new_err("n must be at least 2"));
        }
        Ok(Self {
            inner: crate::methods::cluster_hopping::Config::recommended_tip4p(n),
            recommended: true,
        })
    }

    /// Points in a state; the state length is `3 * n_points`, or `6 *
    /// n_points` molecules on a rigid-body configuration.
    #[getter]
    fn n_points(&self) -> usize {
        self.inner.n_points
    }

    /// Whether the state is rigid bodies: centres, then rotations.
    #[getter]
    fn rigid_body(&self) -> bool {
        self.inner.rigid_body_geometry.is_some()
    }

    /// How far above the incumbent a screened trial may land.
    #[getter]
    fn screen_margin(&self) -> f64 {
        self.inner.screen_margin
    }

    /// Whether the energy screen credits the descent its pass left undone.
    #[getter]
    fn calibrated_screen(&self) -> bool {
        self.inner.calibrated_screen
    }

    /// Whether a full relaxation below the incumbent continues until it
    /// stops descending.
    #[getter]
    fn finish_improving(&self) -> bool {
        self.inner.finish_improving
    }

    /// Composed surface-relocation burst arm.
    #[getter]
    fn burst_moves(&self) -> bool {
        matches!(
            self.inner.move_library,
            crate::methods::cluster_hopping::MoveLibrary::LeanBurst
        )
    }

    /// Discounted Thompson allocation over move arms.
    #[getter]
    fn allocate_moves(&self) -> bool {
        self.inner.allocate_moves
    }

    /// Reward move arms by the depth they reach.
    #[getter]
    fn depth_reward(&self) -> bool {
        self.inner.depth_reward
    }

    /// Orbit completion once per newly entered basin.
    #[getter]
    fn orbit_complete_on_new(&self) -> bool {
        self.inner.orbit_complete_on_new
    }

    /// Shared-history visit policy: `tabu` or `recognition`.
    #[getter]
    fn shared_visit_policy(&self) -> &'static str {
        match self.inner.shared_visit_policy {
            crate::methods::minima_hopping::SharedVisitPolicy::Tabu => "tabu",
            crate::methods::minima_hopping::SharedVisitPolicy::Recognition => "recognition",
        }
    }

    /// Quarantine the stalled funnel.
    #[getter]
    fn tabu_on_stall(&self) -> bool {
        self.inner.tabu_on_stall
    }

    /// Cost-asymmetric Bayes-screen threshold, if that screen is on.
    #[getter]
    fn bayes_threshold(&self) -> f64 {
        self.inner.bayes_threshold
    }

    /// Budget-window temperature rather than fixed \(T=0.8\).
    #[getter]
    fn budget_window(&self) -> bool {
        self.inner.budget_window
    }

    fn __repr__(&self) -> String {
        if self.inner.bayes_screen && self.inner.budget_window {
            format!("Config.derived({})", self.inner.n_points)
        } else if !self.inner.surfaces.is_empty()
            && self.inner.orbit_complete_on_new
            && matches!(
                self.inner.shared_visit_policy,
                crate::methods::minima_hopping::SharedVisitPolicy::Recognition
            )
        {
            format!("Config.communicating({})", self.inner.n_points)
        } else if self.recommended {
            format!("Config.recommended({})", self.inner.n_points)
        } else {
            format!("Config.for_cluster({})", self.inner.n_points)
        }
    }
}

/// Work ledger: every objective or gradient evaluation is one charged unit.
#[pyclass(name = "Ledger")]
pub struct PyLedger {
    inner: crate::methods::cluster_hopping::Ledger,
}

#[pymethods]
impl PyLedger {
    /// Creates a ledger with `budget` charged evaluations.
    #[new]
    fn new(budget: usize) -> Self {
        Self {
            inner: crate::methods::cluster_hopping::Ledger::new(budget),
        }
    }

    /// Charged evaluations the ledger was created with.
    #[getter]
    fn budget(&self) -> usize {
        self.inner.budget()
    }

    /// Charged evaluations spent.
    #[getter]
    fn spent(&self) -> usize {
        self.inner.spent()
    }

    /// Charged evaluations remaining.
    #[getter]
    fn remaining(&self) -> usize {
        self.inner.remaining()
    }

    /// Lowest objective value seen, or `+inf` if none.
    #[getter]
    fn best(&self) -> f64 {
        self.inner.best
    }

    fn __repr__(&self) -> String {
        format!(
            "Ledger(budget={}, spent={}, best={:?})",
            self.inner.budget(),
            self.inner.spent(),
            self.inner.best
        )
    }
}

/// Combined Python energy plus gradient, for the cluster-search driver.
struct CallableDiffObjective {
    fn_: Py<PyAny>,
    grad_fn: Py<PyAny>,
    bounds: Bounds<f64>,
    gradient_scale: f64,
    errors: std::sync::Arc<CallbackErrors>,
}

impl Objective<f64> for CallableDiffObjective {
    fn dim(&self) -> usize {
        self.bounds.dims
    }

    fn bounds(&self) -> &Bounds<f64> {
        &self.bounds
    }

    fn eval(&self, x: ArrayView1<f64>) -> f64 {
        if self.errors.aborted() {
            return f64::INFINITY;
        }
        Python::attach(|py| {
            let py_arr = py_view1(py, x);
            match self.fn_.call1(py, (py_arr,)) {
                Ok(r) => self.errors.float(py, &r),
                Err(err) => {
                    self.errors.record(py, err);
                    f64::INFINITY
                }
            }
        })
    }
}

impl eindir_core::gradient::Gradient<f64> for CallableDiffObjective {
    fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
        let dim = Objective::dim(self);
        if self.errors.aborted() {
            return Array1::zeros(dim);
        }
        Python::attach(|py| {
            let py_arr = py_view1(py, x);
            match self.grad_fn.call1(py, (py_arr,)) {
                Ok(r) => match as_float_vector(py, &r) {
                    Some(values) if values.len() == dim => Array1::from_iter(
                        values.into_iter().map(|value| self.gradient_scale * value),
                    ),
                    _ => {
                        self.errors
                            .abort(pyo3::exceptions::PyTypeError::new_err(format!(
                                "grad_fn must return {dim} numbers"
                            )));
                        Array1::zeros(dim)
                    }
                },
                Err(err) => {
                    self.errors.record(py, err);
                    Array1::zeros(dim)
                }
            }
        })
    }

    fn dim(&self) -> usize {
        self.bounds.dims
    }
}

impl eindir_core::gradient::DifferentiableObjective<f64> for CallableDiffObjective {}

fn cluster_gradient_scale(
    py: Python<'_>,
    obj_fn: &Py<PyAny>,
    grad_fn: &Py<PyAny>,
    cfg: &crate::methods::cluster_hopping::Config,
    seed: u64,
    at: Option<ArrayView1<'_, f64>>,
    errors: &CallbackErrors,
) -> PyResult<f64> {
    use crate::methods::cluster_hopping::random_cluster_in_radius;

    // The probe follows the run's callback rules: an ordinary exception or a
    // value that cannot orient the gradient leaves the callback taken as a
    // gradient, counted in the run's warning; KeyboardInterrupt, SystemExit
    // and a return that is not a number end the call.
    let call = |f: &Py<PyAny>, x: Vec<f64>| -> PyResult<Option<Py<PyAny>>> {
        match f.call1(py, (PyArray1::from_vec(py, x),)) {
            Ok(value) => Ok(Some(value)),
            Err(err) if err.is_instance_of::<pyo3::exceptions::PyException>(py) => {
                errors.record(py, err);
                Ok(None)
            }
            Err(err) => Err(err),
        }
    };
    let as_energy = |value: Py<PyAny>| -> PyResult<f64> {
        value.extract::<f64>(py).map_err(|_| {
            let kind = value
                .bind(py)
                .get_type()
                .name()
                .map(|n| n.to_string())
                .unwrap_or_else(|_| "unknown".to_owned());
            pyo3::exceptions::PyTypeError::new_err(format!(
                "obj_fn must return a float, got {kind}"
            ))
        })
    };

    // A rigid-body state is not a point set, so it is probed where the caller
    // starts rather than at a random compact cluster.
    let probe = match at {
        Some(at) => at.to_owned(),
        None => {
            let mut rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x6a09_e667_f3bc_c909);
            random_cluster_in_radius(
                cfg.n_points,
                cfg.start_radius(),
                cfg.min_separation,
                &mut rng,
            )
        }
    };
    if at.is_none() && probe.len() != 3 * cfg.n_points {
        return Err(PyValueError::new_err(
            "could not construct a gradient-orientation probe",
        ));
    }

    let Some(gradient_result) = call(grad_fn, probe.to_vec())? else {
        return Ok(1.0);
    };
    let gradient = match as_float_vector(py, &gradient_result) {
        Some(values) if values.len() == probe.len() => values,
        _ => {
            return Err(pyo3::exceptions::PyTypeError::new_err(format!(
                "grad_fn must return {} numbers",
                probe.len()
            )));
        }
    };
    if gradient.iter().any(|value| !value.is_finite()) {
        return Ok(1.0);
    }
    let Some((index, component)) = gradient
        .iter()
        .enumerate()
        .max_by(|(_, left), (_, right)| left.abs().total_cmp(&right.abs()))
    else {
        return Ok(1.0);
    };
    if component.abs() <= f64::EPSILON.sqrt() {
        return Ok(1.0);
    }

    let step = f64::EPSILON.cbrt() * (1.0 + probe[index].abs());
    let mut plus = probe.to_vec();
    let mut minus = probe.to_vec();
    plus[index] += step;
    minus[index] -= step;
    let Some(plus_value) = call(obj_fn, plus.to_vec())? else {
        return Ok(1.0);
    };
    let plus_value = as_energy(plus_value)?;
    let Some(minus_value) = call(obj_fn, minus.to_vec())? else {
        return Ok(1.0);
    };
    let minus_value = as_energy(minus_value)?;
    if !plus_value.is_finite() || !minus_value.is_finite() {
        return Ok(1.0);
    }
    let numerical = (plus_value - minus_value) / (2.0 * step);
    let noise_floor = f64::EPSILON.sqrt() * (1.0 + component.abs());
    if !numerical.is_finite() || numerical.abs() <= noise_floor {
        return Ok(1.0);
    }
    Ok(if component * numerical < 0.0 {
        -1.0
    } else {
        1.0
    })
}

fn cluster_bounds(n: usize, dim: usize, length_scale: f64) -> Bounds<f64> {
    let extent = 4.0 * 2.0_f64.powf(1.0 / 6.0) * (n as f64).cbrt() * length_scale;
    Bounds::new(
        Array1::from_elem(dim, -extent),
        Array1::from_elem(dim, extent),
        0.0,
    )
}

fn recommended_with_scale(n: usize, length_scale: f64) -> crate::methods::cluster_hopping::Config {
    let mut cfg = crate::methods::cluster_hopping::Config::with_scales(n, length_scale, 1.0);
    cfg.allocate_moves = true;
    cfg.return_screen = true;
    cfg.orbit_complete_on_new = true;
    cfg
}

/// Residual archive search on the measured recommended preset.
///
/// Uses the same warm-started relax and charged gradient as
/// [`crate::methods::cluster_search::search`]. `archive_search` clones the
/// config and turns `return_screen` on there; the preset itself is unchanged.
#[cfg(feature = "graphkey")]
fn cluster_archive_search(
    py: Python<'_>,
    obj: &CallableDiffObjective,
    cfg: &crate::methods::cluster_hopping::Config,
    ledger: &mut crate::methods::cluster_hopping::Ledger,
    seed: u64,
) -> PyResult<Py<PyDict>> {
    use crate::methods::archive_search::{Archive, archive_search};
    use crate::methods::cluster_hopping::random_cluster_in_radius;
    use crate::methods::warm_lbfgs::WarmLbfgs;
    use eindir_core::gradient::{DifferentiableObjective, Gradient};
    use rand::SeedableRng;

    let mut opt = WarmLbfgs::default();
    let mut relax =
        |led: &mut crate::methods::cluster_hopping::Ledger, x: ArrayView1<f64>, iters: usize| {
            opt.forget();
            let (f, xr, _) = opt.minimize(x, iters, |v| {
                if !led.charge() {
                    return None;
                }
                Some(obj.value_and_gradient(v))
            });
            // Same charged convergence check as the recommended search path.
            if led.charge() {
                let _ = Gradient::grad(obj, xr.view())
                    .iter()
                    .fold(0.0_f64, |a, v| a.max(v.abs()))
                    < cfg.record_gradient;
            }
            (f, xr)
        };
    let mut grad = |led: &mut crate::methods::cluster_hopping::Ledger,
                    x: ArrayView1<f64>|
     -> Option<Array1<f64>> {
        if !led.charge() {
            return None;
        }
        Some(Gradient::grad(obj, x))
    };
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
    let start = random_cluster_in_radius(
        cfg.n_points,
        cfg.start_radius(),
        cfg.min_separation,
        &mut rng,
    );
    let mut archive = Archive::new();
    let out = archive_search(
        cfg,
        start.view(),
        ledger,
        &mut relax,
        Some(&mut grad),
        &mut archive,
        &mut rng,
    );
    let dim = 3 * cfg.n_points;
    let best = out
        .best_state
        .map(|a| a.to_vec())
        .unwrap_or_else(|| vec![0.0; dim]);
    let dict = PyDict::new(py);
    dict.set_item("best", PyArray1::from_vec(py, best))?;
    dict.set_item("best_energy", out.best)?;
    dict.set_item("hops", out.full)?;
    dict.set_item("charged", out.charged)?;
    dict.set_item("floors", out.floors)?;
    dict.set_item("returned", out.returned)?;
    dict.set_item("events", out.events)?;
    dict.set_item("nve_unavailable", out.nve_unavailable)?;
    Ok(dict.into())
}

#[cfg(not(feature = "graphkey"))]
fn cluster_archive_search(
    _py: Python<'_>,
    _obj: &CallableDiffObjective,
    _cfg: &crate::methods::cluster_hopping::Config,
    _ledger: &mut crate::methods::cluster_hopping::Ledger,
    _seed: u64,
) -> PyResult<Py<PyDict>> {
    Err(PyValueError::new_err(
        "ras=True requires building with the graphkey feature",
    ))
}

struct InterleavedChart<'a> {
    inner: &'a CallableDiffObjective,
    n_molecules: usize,
    bounds: Bounds<f64>,
}

impl InterleavedChart<'_> {
    fn to_user(&self, block: ArrayView1<f64>) -> Array1<f64> {
        let slice = block.as_slice().unwrap_or(&[]);
        Array1::from_vec(crate::potentials::interleaved_gmin_from_block(slice))
    }

    fn to_block_gradient(&self, user: ArrayView1<f64>) -> Array1<f64> {
        let n = self.n_molecules;
        let mut block = Array1::zeros(6 * n);
        if user.len() != 6 * n {
            return block;
        }
        for molecule in 0..n {
            for k in 0..3 {
                block[3 * molecule + k] = user[6 * molecule + k];
                block[3 * n + 3 * molecule + k] = -user[6 * molecule + 3 + k];
            }
        }
        block
    }
}

impl Objective<f64> for InterleavedChart<'_> {
    fn dim(&self) -> usize {
        6 * self.n_molecules
    }

    fn bounds(&self) -> &Bounds<f64> {
        &self.bounds
    }

    fn eval(&self, x: ArrayView1<f64>) -> f64 {
        self.inner.eval(self.to_user(x).view())
    }
}

impl eindir_core::gradient::Gradient<f64> for InterleavedChart<'_> {
    fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
        let user = self.inner.grad(self.to_user(x).view());
        self.to_block_gradient(user.view())
    }

    fn dim(&self) -> usize {
        6 * self.n_molecules
    }
}

impl eindir_core::gradient::DifferentiableObjective<f64> for InterleavedChart<'_> {
    fn value_and_gradient(&self, x: ArrayView1<f64>) -> (f64, Array1<f64>) {
        let user = self.to_user(x);
        let (energy, gradient) = eindir_core::gradient::DifferentiableObjective::value_and_gradient(
            self.inner,
            user.view(),
        );
        (energy, self.to_block_gradient(gradient.view()))
    }
}

fn rigid_probe(
    cfg: &crate::methods::cluster_hopping::Config,
    seed: u64,
    interleaved: bool,
) -> Vec<f64> {
    use crate::methods::cluster_hopping::random_cluster_in_radius;
    use rand::SeedableRng;

    let n = cfg.n_points;
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x6a09_e667_f3bc_c909);
    let centres = random_cluster_in_radius(n, cfg.start_radius(), cfg.min_separation, &mut rng);
    let mut block = vec![0.0; 6 * n];
    if centres.len() == 3 * n {
        if let Some(slice) = centres.as_slice() {
            block[..3 * n].copy_from_slice(slice);
        }
    } else {
        for i in 0..n {
            let angle = i as f64 * 2.399963229728653;
            let radius = cfg.container.max(1.0) * ((i as f64 + 0.5) / n as f64).cbrt();
            block[3 * i] = radius * angle.cos();
            block[3 * i + 1] = radius * angle.sin();
        }
    }
    for i in 0..n {
        block[3 * n + 3 * i] = 0.25;
        block[3 * n + 3 * i + 1] = -0.15;
    }
    if interleaved {
        crate::potentials::interleaved_gmin_from_block(&block)
    } else {
        block
    }
}

/// Runs the measured cluster-search layer on a user energy and gradient.
///
/// `recommended=True` uses `Config.recommended(n)`; otherwise
/// `Config.for_cluster(n)`. `communicating=True` uses
/// `Config.communicating(n)` and overrides both. A charged central-difference
/// probe distinguishes gradients from force-valued callbacks when the budget
/// can cover it. Every objective or gradient evaluation is charged to a ledger
/// of `budget` units. Returns `{best, best_energy, hops, nve_unavailable}`.
/// `nve_unavailable` is set when a constant-energy escape was requested and
/// the `rgsaddle` feature is off. The `python` feature enables it.
/// `ras=True` runs residual archive search on `Config.recommended(n)` and
/// also reports `charged`, `floors`, `returned`, `events`, and
/// `nve_unavailable`.
///
/// Args:
///   obj_fn: Python callable `f(numpy.ndarray) -> float`.
///   grad_fn: Python gradient or force callable `g(numpy.ndarray) -> numpy.ndarray`.
///   n: number of points. A Cartesian state is `3n`. `rigid=True` or
///     `water_sites` is `n` bodies and a `6n` state.
///   budget: charged evaluations.
///   seed: RNG seed.
///   recommended: measured stack when true, Wales-Doye baseline when false.
///   derived: cost-asymmetric Bayes screen and budget-window temperature
///     on top of the measured flags. Overrides `recommended` when true.
///   communicating: orbit plus recognition. Overrides `recommended` and
///     `derived` when true. Not `Config.recommended`.
///   ras: residual archive search on the recommended preset. Keyword-only;
///     default false. Does not change `Config.recommended`.
///   start: optional flat start. Cartesian length is `3n`. A rigid or water
///     start is `6n`, block Rodrigues unless `layout` is `interleaved`.
///   length_scale: optional physical length. When set with the recommended
///     preset, hops use `with_scales` instead of the reduced LJ container.
///     Ignored once `species` or `rigid` selects a chart: those keep the
///     stock preset and adapt geometry afterwards. Excluded by `water_sites`.
///   species: optional label per point. Two or more labels add a swap move.
///     A wide diameter ratio also tries one downhill unlike-pair exchange
///     beside the escape.
///   sigmas: optional Lennard-Jones diameter per point, same length as
///     `species`. Large diameters are swapped out of the inner shell.
///   rigid: when true, `n` is the number of rigid bodies and the hop state
///     is centres followed by Rodrigues rotations. More than ten bodies
///     hold the acceptance factor at 4 and scale the orientation amplitude
///     toward an acceptance ratio of one half. Ten or fewer do not. The
///     quench is the same L-BFGS descent, and a rigid record accepts the
///     root-mean-square force. The chain keeps the eight lowest distinct
///     minima of its quenched start, accepted quenches and lowest
///     recorded minimum. Each stall follows 1000 hops with no new
///     lowest minimum. At each stall the walker moves to the lowest kept
///     minimum that is neither its own nor one of the last four stall
///     destinations. When no kept minimum qualifies, the walker stays
///     put. Nothing is drawn, the target is not read, and the lowest
///     minimum is kept.
///   layout: `block` (centres, then rotations) or `interleaved` (GMIN
///     centre and angle-axis per body). Interleaved rotations are negated
///     at the boundary because that angle-axis map is the opposite sense.
///   target: stop once a recorded energy is at or below this value.
///   water_sites: optional flat 9-vector of the O, H, H positions of one
///     rigid water in its body frame, in angstrom, about the point its
///     rotation turns about. When set, `n` counts molecules and the state is
///     `6n`: `n` centres, then `n` exponential-map rotation vectors that turn
///     the body frame actively (Rodrigues). The presets become
///     `Config.communicating_tip4p(n)`, `Config.recommended_tip4p(n)`, or
///     `Config.for_tip4p(n)` when both are false, with these sites as the
///     rigid geometry. Needs `start`. Excludes `ras`, `derived`,
///     `length_scale`, `rigid`, `species`, `sigmas`, and a non-block layout.
///
/// A callback raising `BaseException` that is not an `Exception`, such as
/// `KeyboardInterrupt`, stops the search at once. The best state found is
/// kept, and the exception is raised from this call.
#[pyfunction]
#[pyo3(signature = (
    obj_fn,
    grad_fn,
    n,
    budget,
    seed = 0,
    recommended = true,
    derived = false,
    communicating = false,
    *,
    ras = false,
    start = None,
    length_scale = None,
    species = None,
    sigmas = None,
    rigid = false,
    layout = "block",
    target = None,
    water_sites = None,
))]
fn cluster_search(
    py: Python<'_>,
    obj_fn: Py<PyAny>,
    grad_fn: Py<PyAny>,
    n: usize,
    budget: usize,
    seed: u64,
    recommended: bool,
    derived: bool,
    communicating: bool,
    ras: bool,
    start: Option<PyReadonlyArray1<'_, f64>>,
    length_scale: Option<f64>,
    species: Option<Vec<u32>>,
    sigmas: Option<Vec<f64>>,
    rigid: bool,
    layout: &str,
    target: Option<f64>,
    water_sites: Option<PyReadonlyArray1<'_, f64>>,
) -> PyResult<Py<PyDict>> {
    use crate::methods::cluster_hopping::Config;

    if n < 2 {
        return Err(PyValueError::new_err("n must be at least 2"));
    }
    if budget < 1 {
        return Err(PyValueError::new_err("budget must be positive"));
    }
    if let Some(scale) = length_scale
        && (!scale.is_finite() || scale <= 0.0)
    {
        return Err(PyValueError::new_err(
            "length_scale must be finite and positive",
        ));
    }
    if rigid && species.is_some() {
        return Err(PyValueError::new_err(
            "rigid bodies and species swaps are different charts",
        ));
    }
    if sigmas.is_some() && species.is_none() {
        return Err(PyValueError::new_err("sigmas require species"));
    }
    if layout != "block" && layout != "interleaved" {
        return Err(PyValueError::new_err("layout must be block or interleaved"));
    }
    if !rigid && layout != "block" {
        return Err(PyValueError::new_err(
            "interleaved layout is the rigid-body chart",
        ));
    }
    if ras && (rigid || species.is_some()) {
        return Err(PyValueError::new_err("ras is the cartesian archive search"));
    }
    let water = match water_sites {
        None => None,
        Some(sites) => {
            let sl = sites.as_slice()?;
            if sl.len() != 9 {
                return Err(PyValueError::new_err(format!(
                    "water_sites length {} must be 9 (O, H, H)",
                    sl.len()
                )));
            }
            if ras || derived || length_scale.is_some() {
                return Err(PyValueError::new_err(
                    "water_sites excludes ras, derived and length_scale",
                ));
            }
            if rigid || species.is_some() || sigmas.is_some() || layout != "block" {
                return Err(PyValueError::new_err(
                    "water_sites excludes rigid, species, sigmas and a non-block layout",
                ));
            }
            if start.is_none() {
                return Err(PyValueError::new_err("water_sites needs a start"));
            }
            let sites = sl.chunks(3).map(|c| [c[0], c[1], c[2]]).collect();
            Some(
                crate::rigid_body::RigidBodyGeometry::new(sites, vec![8, 1, 1])
                    .map_err(PyValueError::new_err)?,
            )
        }
    };
    let interleaved = rigid && layout == "interleaved";
    let rigid_chart = water.is_some() || rigid;
    let dim = if rigid_chart { 6 * n } else { 3 * n };
    let start = match start {
        Some(start) => {
            let sl = start.as_slice()?;
            if sl.len() != dim {
                return Err(PyValueError::new_err(format!(
                    "start length {} must be {} = {}",
                    sl.len(),
                    if rigid_chart { "6*n" } else { "3*n" },
                    dim
                )));
            }
            Some(Array1::from_vec(sl.to_vec()))
        }
        None => None,
    };
    let scale = length_scale.unwrap_or(1.0);
    let stock = species.is_some() || rigid;
    let has_water = water.is_some();
    let mut cfg = if let Some(geometry) = water {
        let mut cfg = if communicating {
            Config::communicating_tip4p(n)
        } else if recommended {
            Config::recommended_tip4p(n)
        } else {
            Config::for_tip4p(n)
        };
        cfg.rigid_body_geometry = Some(geometry);
        cfg
    } else if ras {
        Config::recommended(n)
    } else if communicating {
        Config::communicating(n)
    } else if derived {
        Config::derived(n)
    } else if recommended {
        if length_scale.is_some() && !stock {
            recommended_with_scale(n, scale)
        } else {
            Config::recommended(n)
        }
    } else if length_scale.is_some() && !stock {
        Config::with_scales(n, scale, 1.0)
    } else {
        Config::for_cluster(n)
    };
    if !has_water && stock {
        cfg = if communicating {
            Config::communicating(n)
        } else if derived {
            Config::derived(n)
        } else if recommended {
            Config::recommended(n)
        } else {
            Config::for_cluster(n)
        };
        if rigid {
            cfg = cfg.with_rigid_bodies(crate::potentials::gmin_water_geometry());
        }
        if let Some(labels) = species {
            cfg = cfg.with_species(labels, sigmas);
        }
    }
    let errors: std::sync::Arc<CallbackErrors> = std::sync::Arc::default();
    let _caller_stop = crate::caller_stop::Bind::new(errors.abort_flag());
    let mut ledger =
        crate::methods::cluster_hopping::Ledger::with_stop(budget, errors.abort_flag());
    if let Some(limit) = target {
        if !limit.is_finite() {
            return Err(PyValueError::new_err("target must be finite"));
        }
        ledger.stop_below(limit);
    }
    let gradient_scale = if budget >= 4 {
        let probe_owned = if rigid_chart {
            Some(match start.as_ref() {
                Some(start) => start.clone(),
                None => Array1::from_vec(rigid_probe(&cfg, seed, interleaved)),
            })
        } else {
            None
        };
        let scale = cluster_gradient_scale(
            py,
            &obj_fn,
            &grad_fn,
            &cfg,
            seed,
            probe_owned.as_ref().map(|probe| probe.view()),
            &errors,
        )?;
        for _ in 0..3 {
            assert!(ledger.charge());
        }
        scale
    } else {
        1.0
    };
    let extent = cfg.container.max(1.0) * 4.0;
    let bounds = if rigid {
        Bounds::new(
            Array1::from_elem(dim, -extent),
            Array1::from_elem(dim, extent),
            0.0,
        )
    } else {
        cluster_bounds(n, dim, scale)
    };
    let obj = CallableDiffObjective {
        fn_: obj_fn,
        grad_fn,
        bounds,
        gradient_scale,
        errors: std::sync::Arc::clone(&errors),
    };
    if ras {
        let out = cluster_archive_search(py, &obj, &cfg, &mut ledger, seed);
        errors.finish(py)?;
        return out;
    }
    let (out, _) = if interleaved {
        let chart = InterleavedChart {
            inner: &obj,
            n_molecules: n,
            bounds: Bounds::new(
                Array1::from_elem(dim, -extent),
                Array1::from_elem(dim, extent),
                0.0,
            ),
        };
        let started = match start.as_ref() {
            Some(start) => Array1::from_vec(crate::potentials::block_from_interleaved_gmin(
                start.as_slice().unwrap_or(&[]),
            )),
            None => Array1::from_vec(rigid_probe(&cfg, seed.wrapping_add(1), false)),
        };
        crate::methods::cluster_search::search_from(&chart, &cfg, &mut ledger, started.view(), seed)
    } else if let Some(start) = start {
        crate::methods::cluster_search::search_from(&obj, &cfg, &mut ledger, start.view(), seed)
    } else if rigid {
        let started = Array1::from_vec(rigid_probe(&cfg, seed.wrapping_add(1), false));
        crate::methods::cluster_search::search_from(&obj, &cfg, &mut ledger, started.view(), seed)
    } else {
        crate::methods::cluster_search::search(&obj, &cfg, &mut ledger, seed)
    }
    .map_err(|err| PyValueError::new_err(err.to_string()))?;
    errors.finish(py)?;
    let best_block = out
        .best_state
        .map(|value| value.to_vec())
        .unwrap_or_else(|| vec![0.0; dim]);
    let best = if interleaved {
        crate::potentials::interleaved_gmin_from_block(&best_block)
    } else {
        best_block
    };
    let dict = PyDict::new(py);
    dict.set_item("best", PyArray1::from_vec(py, best))?;
    dict.set_item("best_energy", out.best)?;
    dict.set_item("hops", out.hops)?;
    dict.set_item("nve_unavailable", out.nve_unavailable)?;
    Ok(dict.into())
}

// ---------------------------------------------------------------------------
// Module entry point.
// ---------------------------------------------------------------------------

/// pyo3 module initialiser. Exposed to Python as `anneal._core`.
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", crate::version::ANNEAL_VERSION)?;
    device::register(m)?;
    m.add_class::<PyBasinBias>()?;
    m.add_class::<PyBoltzmann>()?;
    m.add_class::<PyFast>()?;
    m.add_class::<PyGsa>()?;
    m.add_class::<PyEpochLine>()?;
    m.add_class::<PyHistory>()?;
    m.add_class::<PyClusterConfig>()?;
    m.add_class::<PyLedger>()?;
    m.add_class::<EindirPyBounds>()?;
    m.add_class::<PyObjective>()?;
    m.add_function(wrap_pyfunction!(cluster_search, m)?)?;
    m.add_function(wrap_pyfunction!(low_discrepancy_points, m)?)?;
    m.add_function(wrap_pyfunction!(osa_acceptance_rate, m)?)?;
    m.add_function(wrap_pyfunction!(pilot_draws_qmc, m)?)?;
    m.add_function(wrap_pyfunction!(run, m)?)?;
    m.add_function(wrap_pyfunction!(run_hmc, m)?)?;
    m.add_function(wrap_pyfunction!(polish, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_polish, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_polish_objective, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_best1bin_scout, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_best1bin_scout_objective, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_gsa_global_search, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_gsa_global_search_objective, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_trust_region_poll, m)?)?;
    m.add_function(wrap_pyfunction!(qmc_trust_region_poll_objective, m)?)?;
    m.add_function(wrap_pyfunction!(shifted_qmc_polish, m)?)?;
    m.add_function(wrap_pyfunction!(additive_independence, m)?)?;
    m.add_function(wrap_pyfunction!(estimate_gle_omega0, m)?)?;
    m.add_function(wrap_pyfunction!(gle_langevin, m)?)?;
    m.add_function(wrap_pyfunction!(gle_langevin_objective, m)?)?;
    m.add_function(wrap_pyfunction!(gle_langevin_preconditioned, m)?)?;
    m.add_function(wrap_pyfunction!(gle_langevin_preconditioned_objective, m)?)?;
    m.add_function(wrap_pyfunction!(run_qmc, m)?)?;
    m.add_function(wrap_pyfunction!(dmc_population_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(gpmd_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(amsa_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(box_ensemble_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(ensemble_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(bfwt_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(global_optimize, m)?)?;
    m.add_function(wrap_pyfunction!(global_optimize_objective, m)?)?;
    Ok(())
}
