//! History-conditioned escape feedback, after Goedecker's minima hopping.
//!
//! Goedecker, J. Chem. Phys. 120, 9911 (2004).
//!
//! The campaign's own measurements say what is missing. From the structure a
//! 75-point search settles into, none of 1800 single moves across the whole
//! kernel set reaches anything lower, so crossing needs a sequence of accepted
//! uphill quenches and a reason to accept them that does not destroy descent.
//! A continuous collective variable cannot supply that reason: the Q4 gap
//! between the two funnels is 0.023, under any usable deposition width.
//!
//! This crate already keeps a history of visited basins and uses it to deposit
//! bias. Minima hopping uses a history for something else: to scale the *next
//! escape*. Revisiting a known minimum makes the next attempt more violent
//! rather than the current one less attractive.
//!
//! That difference is the whole mechanism and it is worth stating precisely,
//! because the two are complementary and must stay separable:
//!
//! | | escape feedback | basin bias |
//! |---|---|---|
//! | what a revisit raises | the escape scale | the potential on that basin |
//! | acceptance | adaptive threshold on the energy rise | Metropolis on `F + V` |
//! | transition regions | left crossable | filled if revisited |
//!
//! Goedecker argues against flooding transition regions for exactly this
//! reason: the region between funnels has to stay crossable, so the response to
//! a revisit should be a harder push rather than a higher potential where the
//! chain needs to pass.
//!
//! Revisits increase the escape scale up to the configured ceiling; this
//! bounded feedback does not guarantee departure from every funnel. Shared
//! history can increase the penalty for rediscovering another chain's minimum
//! without replacing the receiving chain's state or random stream.
//! Schoenborn, Goedecker, Roy and Oganov,
//! J. Chem. Phys. 130, 144108 (2009), multiply the known-minimum update by
//! `1 + c ln(N)` for visit count `N`, and report that this finds the LJ75 Marks
//! decahedron where a cut-and-splice evolutionary algorithm does not.

use std::collections::HashMap;
#[cfg(feature = "rgsaddle")]
use std::sync::Mutex;

use ndarray::{Array1, ArrayView1};
use rand::Rng;
#[cfg(feature = "rgsaddle")]
use rand_distr::{Distribution, StandardNormal};
#[cfg(feature = "rgsaddle")]
use rgmin::{Manifold, ManifoldKind};
#[cfg(feature = "rgsaddle")]
use rgsaddle::internal::{CartAxis, Translation};
#[cfg(feature = "rgsaddle")]
use rgsaddle::{Constraints, PointSurface, SamdConfig, SamdSession, soften_velocity_on};

/// Failure from one constant-energy (NVE) minima-hopping escape.
///
/// The same enum with and without the `rgsaddle` feature. A feature build
/// converts `rgsaddle::SaddleError` into these variants. `FeatureDisabled`
/// is the result when the escape is not compiled.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum NveError {
    /// The state or the controls do not match the integrator.
    #[error("shape mismatch: {0}")]
    Shape(String),
    /// The surface did not return a finite energy and gradient.
    #[error("surface evaluation failed: {0}")]
    Surface(String),
    /// A value that must be finite was not.
    #[error("non-finite value in {0}")]
    NonFinite(&'static str),
    /// The delegated integrator stopped.
    #[error("solver step failed: {0}")]
    Solver(String),
    /// The escape is compiled only with the `rgsaddle` feature.
    #[error("rgsaddle feature is not enabled")]
    FeatureDisabled,
}

#[cfg(feature = "rgsaddle")]
impl From<rgsaddle::SaddleError> for NveError {
    fn from(error: rgsaddle::SaddleError) -> Self {
        match error {
            rgsaddle::SaddleError::Shape(message) => Self::Shape(message),
            rgsaddle::SaddleError::Surface(message) => Self::Surface(message),
            rgsaddle::SaddleError::NonFinite(site) => Self::NonFinite(site),
            rgsaddle::SaddleError::Solver(message)
            | rgsaddle::SaddleError::Invalid(message)
            | rgsaddle::SaddleError::Stalled(message) => Self::Solver(message),
        }
    }
}

/// Finite modified-dimer softening of a Gaussian launch direction.
///
/// The fields match `rgsaddle::VelocitySofteningConfig`. The feature build
/// copies them into that type before `soften_velocity_on`, so the published
/// displacement, mixing, and probe count are unchanged.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VelocitySofteningConfig {
    /// Modified-dimer probes of the launch direction.
    pub steps: usize,
    /// Finite-difference displacement of each probe.
    pub displacement: f64,
    /// Mix of the soft direction into the launch velocity.
    pub mixing: f64,
}

impl Default for VelocitySofteningConfig {
    fn default() -> Self {
        Self {
            steps: 0,
            displacement: 0.1,
            mixing: 0.15,
        }
    }
}

#[path = "minima_hopping/history.rs"]
mod history;
pub use history::{
    HistoryHook, HistoryMembership, HistoryObservation, HistoryReport, MinimumHistory,
    MinimumHistoryError, SerializedWitness, SharedDesignHistory, SharedMinimumHistory,
    history_feedback_membership,
};

/// Geometry on which an MD escape evolves.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MdEscapeGeometry {
    /// Unconstrained Euclidean coordinates of any dimension.
    Euclidean,
    /// Cartesian coordinates modulo rigid translation and rotation.
    RigidQuotient,
}

/// Short NVE escape controls for minima hopping.
#[derive(Debug, Clone, Copy)]
pub struct MdEscapeConfig {
    /// Velocity-Verlet step in the surface's reduced time units.
    pub dt: f64,
    /// Potential-energy minima crossed before stopping the trajectory.
    pub potential_minima: usize,
    /// Hard cap on Verlet steps when the requested crossings are not reached.
    pub maximum_steps: usize,
    /// Coordinate geometry used for velocity projection and retraction.
    pub geometry: MdEscapeGeometry,
    /// Published finite modified-dimer softening of the Gaussian direction.
    pub softening: Option<VelocitySofteningConfig>,
    /// A time-series minimum counts only after the energy has fallen by
    /// at least this much from the highest point since the previous
    /// counted minimum. Zero keeps every wiggle. A positive value is the
    /// barrier the escape has to cross before it is allowed to stop.
    pub minimum_rise: f64,
    /// Stop once the root-mean-square displacement from the launch reaches
    /// this value. Infinite disables the cap.
    pub max_rms: f64,
    /// A potential minimum counts as the end of the escape only when its
    /// root-mean-square displacement from the launch is at least this large.
    /// Zero keeps every minimum.
    pub min_well_rms: f64,
}

impl Default for MdEscapeConfig {
    fn default() -> Self {
        Self {
            dt: 0.01,
            potential_minima: 2,
            maximum_steps: 2_000,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        }
    }
}

/// Endpoint and accounting evidence from one MD escape.
#[derive(Debug, Clone)]
pub struct MdEscapeReport {
    /// Last point on the MD trajectory.
    pub position: Array1<f64>,
    /// Verlet steps completed.
    pub steps: usize,
    /// Potential-energy minima detected along the trajectory.
    pub potential_minima: usize,
    /// Potential energy at the last point.
    pub energy: f64,
    /// Kinetic energy at the last point.
    pub kinetic: f64,
    /// Force evaluations used to soften the launch direction.
    pub softening_evaluations: usize,
    /// Difference between the largest and smallest potential energy sampled.
    pub potential_energy_span: f64,
    /// Difference between the largest and smallest total energy sampled.
    pub total_energy_span: f64,
    /// Geometry farthest from the launch, by root-mean-square displacement.
    pub far_position: Array1<f64>,
    /// Root-mean-square displacement of [`Self::far_position`] from the launch.
    pub far_rms: f64,
}

impl MdEscapeReport {
    /// Relative NVE drift used by the established minima-hopping step control.
    pub fn energy_conservation_ratio(&self) -> f64 {
        if self.potential_energy_span.is_finite() && self.potential_energy_span > 0.0 {
            self.total_energy_span / self.potential_energy_span
        } else {
            f64::INFINITY
        }
    }
}

/// Energy-conservation feedback for the Verlet step between escape attempts.
///
/// The update follows the production minima-hopping controller: a trajectory
/// with total-energy drift below one percent of its potential-energy excursion
/// grows the step by 1.05; any other trajectory shrinks it by the same factor.
#[derive(Debug, Clone, Copy)]
pub struct MdTimeStepFeedback {
    time_step: f64,
    minimum_time_step: f64,
}

impl MdTimeStepFeedback {
    /// Start the controller at `time_step` with a hard stability floor.
    pub fn new(time_step: f64, minimum_time_step: f64) -> Self {
        assert!(time_step.is_finite() && time_step > 0.0);
        assert!(minimum_time_step.is_finite() && minimum_time_step > 0.0);
        assert!(minimum_time_step <= time_step);
        Self {
            time_step,
            minimum_time_step,
        }
    }

    /// Current Verlet step.
    pub fn time_step(&self) -> f64 {
        self.time_step
    }

    /// Observe one NVE report and return the step for the next escape.
    pub fn observe(&mut self, report: &MdEscapeReport) -> f64 {
        const FACTOR: f64 = 1.05;
        const CONSERVATION_TOLERANCE: f64 = 1e-2;
        if report.energy_conservation_ratio() < CONSERVATION_TOLERANCE {
            self.time_step *= FACTOR;
        } else {
            self.time_step = (self.time_step / FACTOR).max(self.minimum_time_step);
        }
        self.time_step
    }
}

#[cfg(feature = "rgsaddle")]
fn sampled_energy_span(minimum: f64, maximum: f64) -> f64 {
    if minimum.is_finite() && maximum.is_finite() && maximum >= minimum {
        maximum - minimum
    } else {
        0.0
    }
}

#[cfg(feature = "rgsaddle")]
struct CallbackSurface<'a, F> {
    evaluate: Mutex<&'a mut F>,
}

#[cfg(feature = "rgsaddle")]
impl<F> PointSurface for CallbackSurface<'_, F>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
{
    fn eval(&self, x: ArrayView1<f64>) -> Result<(f64, Array1<f64>), rgsaddle::SaddleError> {
        let mut evaluate = self
            .evaluate
            .lock()
            .map_err(|_| rgsaddle::SaddleError::Surface("NVE evaluator lock poisoned".into()))?;
        (*evaluate)(x)
            .ok_or_else(|| rgsaddle::SaddleError::Surface("evaluation budget exhausted".into()))
    }
}

/// Run the NVE escape of minima hopping through `rgsaddle::SamdSession`.
///
/// The Gaussian initial velocity is projected onto `geometry` and rescaled to
/// exactly `initial_kinetic`. With an infinite SAMD thermostat time, the BDP
/// rescale is the identity and the delegated velocity-Verlet trajectory is
/// microcanonical. The host loop stops after `potential_minima` local minima
/// in the potential-energy trace, as in the Goedecker algorithm.
#[cfg(feature = "rgsaddle")]
pub fn nve_escape<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    nve_escape_with_frozen(start, initial_kinetic, config, evaluate, rng, None)
}

/// Escape with the hopping loop's frozen Cartesian frame.
///
/// Fixed atoms define the frame instead of the rigid quotient. An absent or
/// all-mobile mask keeps the configured geometry and its stepping path.
#[cfg(feature = "rgsaddle")]
pub(crate) fn nve_escape_with_frozen<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
    frozen_atoms: Option<&[bool]>,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    nve_escape_launch(
        start,
        initial_kinetic,
        None,
        config,
        evaluate,
        rng,
        frozen_atoms,
    )
}

/// Same escape as [`nve_escape`], with the launch velocity seeded by
/// `seed_direction` when that vector has the right length.
///
/// The seed is the covering displacement. Softening, when the config
/// asks for it, mixes the seed toward the softest direction. A small
/// Gaussian part remains so two nearby covers do not collapse onto one
/// trajectory. `None` is the unbiased Gaussian launch.
#[cfg(feature = "rgsaddle")]
pub fn nve_escape_seeded<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    seed_direction: Option<ArrayView1<f64>>,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    nve_escape_launch(
        start,
        initial_kinetic,
        seed_direction,
        config,
        evaluate,
        rng,
        None,
    )
}

#[cfg(feature = "rgsaddle")]
fn nve_escape_launch<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    seed_direction: Option<ArrayView1<f64>>,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
    frozen_atoms: Option<&[bool]>,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    if start.is_empty()
        || !config.dt.is_finite()
        || config.dt <= 0.0
        || config.potential_minima == 0
        || config.maximum_steps == 0
        || !initial_kinetic.is_finite()
        || initial_kinetic <= 0.0
    {
        return Err(NveError::Shape(
            "NVE escape needs a nonempty state and positive finite controls".into(),
        ));
    }
    if config.geometry == MdEscapeGeometry::RigidQuotient && !start.len().is_multiple_of(3) {
        return Err(NveError::Shape(
            "rigid-quotient NVE escape needs a 3N Cartesian state".into(),
        ));
    }

    let frozen_chart = match frozen_atoms {
        Some(frozen) => {
            if !start.len().is_multiple_of(3) || frozen.len() != start.len() / 3 {
                return Err(NveError::Shape(
                    "frozen NVE escape needs one mask entry per Cartesian atom".into(),
                ));
            }
            if frozen.iter().any(|fixed| *fixed) {
                let mut chart = Constraints::new(frozen.len())?;
                for (atom, fixed) in frozen.iter().copied().enumerate() {
                    if fixed {
                        for axis in CartAxis::ALL {
                            chart.fix_translation(
                                Translation::new(vec![atom], axis)?,
                                start,
                                None,
                            )?;
                        }
                    }
                }
                Some(chart)
            } else {
                None
            }
        }
        None => None,
    };
    let configured_manifold = match config.geometry {
        MdEscapeGeometry::Euclidean => ManifoldKind::Euclidean,
        MdEscapeGeometry::RigidQuotient => ManifoldKind::RigidQuotient,
    };
    let manifold: &dyn Manifold = match frozen_chart.as_ref() {
        Some(chart) => chart,
        None => &configured_manifold,
    };
    let mut velocity = if let Some(direction) = seed_direction.filter(|d| d.len() == start.len()) {
        let mut mixed = direction.to_owned();
        // A per-coordinate draw of fixed width is larger than a unit seed
        // once the dimension is high, and the covering direction disappears.
        // The noise is a quarter of the seed's own length.
        let seed_norm = mixed.dot(&mixed).sqrt().max(1.0e-12);
        let mut noise = Array1::<f64>::zeros(mixed.len());
        for slot in noise.iter_mut() {
            *slot = StandardNormal.sample(rng);
        }
        let noise_norm = noise.dot(&noise).sqrt().max(1.0e-12);
        let mix = 0.25 * seed_norm / noise_norm;
        for (slot, draw) in mixed.iter_mut().zip(noise.iter()) {
            *slot += mix * *draw;
        }
        mixed
    } else {
        Array1::from_iter(start.iter().map(|_| {
            let draw: f64 = StandardNormal.sample(rng);
            draw
        }))
    };
    velocity = manifold.project(&start.to_owned(), &velocity);
    let surface = CallbackSurface {
        evaluate: Mutex::new(evaluate),
    };
    let softening = config
        .softening
        .map(|softening| rgsaddle::VelocitySofteningConfig {
            steps: softening.steps,
            displacement: softening.displacement,
            mixing: softening.mixing,
        });
    let softening_evaluations = if let Some(softening) = softening {
        let report = soften_velocity_on(manifold, start, velocity.view(), &surface, softening)?;
        velocity = report.direction;
        report.evaluations
    } else {
        0
    };

    let unscaled_kinetic = 0.5 * velocity.dot(&velocity);
    if !unscaled_kinetic.is_finite() || unscaled_kinetic <= 1e-16 {
        return Err(NveError::Solver(
            "NVE velocity has no component in the free coordinates".into(),
        ));
    }
    velocity *= (initial_kinetic / unscaled_kinetic).sqrt();

    let samd_config = SamdConfig {
        dt: config.dt,
        tau: f64::INFINITY,
        t0: 1.0,
        tf: 1.0,
        ngen: config.maximum_steps,
        exponential: false,
    };
    let origin = start.to_owned();
    let mut session = SamdSession::new(samd_config, origin.clone(), velocity, &surface)?;
    let noise = Array1::zeros(origin.len());
    let mut previous_energy = None;
    let mut minima = 0usize;
    let mut down = 0u32;
    let mut up = 0u32;
    let mut bottom_energy = f64::INFINITY;
    let mut bottom_position = origin.clone();
    let mut last_energy = f64::NAN;
    let mut last_kinetic = initial_kinetic;
    let mut peak = f64::NEG_INFINITY;
    let mut completed = 0usize;
    let n_atoms = (origin.len() / 3).max(1) as f64;
    let mut far_position = origin.clone();
    let mut far_rms = 0.0;
    let mut well: Option<Array1<f64>> = None;
    let mut minimum_potential = f64::INFINITY;
    let mut maximum_potential = f64::NEG_INFINITY;
    let mut minimum_total = f64::INFINITY;
    let mut maximum_total = f64::NEG_INFINITY;

    for steps in 1..=config.maximum_steps {
        let report = match frozen_chart.as_ref() {
            Some(chart) => session.step_on(chart, &surface, noise.view())?,
            None => match config.geometry {
                MdEscapeGeometry::Euclidean => session.step(&surface, noise.view())?,
                MdEscapeGeometry::RigidQuotient => {
                    session.step_on(&configured_manifold, &surface, noise.view())?
                }
            },
        };
        completed = steps;
        last_energy = report.energy;
        last_kinetic = report.kinetic;
        if report.energy.is_finite() {
            minimum_potential = minimum_potential.min(report.energy);
            maximum_potential = maximum_potential.max(report.energy);
        }
        let total_energy = report.energy + report.kinetic;
        if total_energy.is_finite() {
            minimum_total = minimum_total.min(total_energy);
            maximum_total = maximum_total.max(total_energy);
        }
        let mut shift = 0.0;
        for (there, here) in session.position().iter().zip(origin.iter()) {
            let delta = there - here;
            shift += delta * delta;
        }
        let rms = (shift / n_atoms).sqrt();
        if rms > far_rms {
            far_rms = rms;
            far_position = session.position().to_owned();
        }
        if config.max_rms.is_finite() && far_rms >= config.max_rms {
            break;
        }
        if last_energy > peak {
            peak = last_energy;
        }
        if let Some(previous) = previous_energy {
            if report.energy < previous {
                if up > 0 {
                    down = 1;
                    up = 0;
                    bottom_energy = report.energy;
                    bottom_position = session.position().to_owned();
                } else {
                    down += 1;
                    if report.energy < bottom_energy {
                        bottom_energy = report.energy;
                        bottom_position = session.position().to_owned();
                    }
                }
            } else if report.energy > previous {
                up += 1;
                // One down and one up is a wiggle. A valley is two
                // decreases into the bottom and two increases out of it.
                if down >= 2 && up >= 2 && peak - bottom_energy >= config.minimum_rise {
                    minima += 1;
                    let saved_energy = bottom_energy;
                    let saved_position = bottom_position.clone();
                    let mut from_launch = 0.0;
                    for (there, here) in saved_position.iter().zip(origin.iter()) {
                        let delta = there - here;
                        from_launch += delta * delta;
                    }
                    let well_rms = (from_launch / n_atoms).sqrt();
                    down = 0;
                    up = 0;
                    bottom_energy = f64::INFINITY;
                    peak = report.energy;
                    let far_enough =
                        config.min_well_rms > 0.0 && well_rms + 1.0e-12 >= config.min_well_rms;
                    let counted_enough =
                        config.min_well_rms <= 0.0 && minima >= config.potential_minima;
                    if far_enough || counted_enough {
                        well = Some(saved_position);
                        last_energy = saved_energy;
                        break;
                    }
                }
            }
        }
        previous_energy = Some(report.energy);
    }

    Ok(MdEscapeReport {
        position: well.unwrap_or_else(|| session.position().to_owned()),
        steps: completed,
        potential_minima: minima,
        energy: last_energy,
        kinetic: last_kinetic,
        softening_evaluations,
        potential_energy_span: sampled_energy_span(minimum_potential, maximum_potential),
        total_energy_span: sampled_energy_span(minimum_total, maximum_total),
        far_position,
        far_rms,
    })
}

/// Run the constant-energy (NVE) minima-hopping escape.
///
/// The `rgsaddle` feature is off in this build. The call returns
/// [`NveError::FeatureDisabled`].
#[cfg(not(feature = "rgsaddle"))]
pub fn nve_escape<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    let _ = (start, initial_kinetic, config, evaluate, rng);
    Err(NveError::FeatureDisabled)
}

#[cfg(not(feature = "rgsaddle"))]
pub(crate) fn nve_escape_with_frozen<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
    frozen_atoms: Option<&[bool]>,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    let _ = (start, initial_kinetic, config, evaluate, rng, frozen_atoms);
    Err(NveError::FeatureDisabled)
}

/// Run the constant-energy (NVE) escape from a supplied launch direction.
///
/// The `rgsaddle` feature is off in this build. The call returns
/// [`NveError::FeatureDisabled`].
#[cfg(not(feature = "rgsaddle"))]
pub fn nve_escape_seeded<F, R>(
    start: ArrayView1<f64>,
    initial_kinetic: f64,
    seed_direction: Option<ArrayView1<f64>>,
    config: &MdEscapeConfig,
    evaluate: &mut F,
    rng: &mut R,
) -> Result<MdEscapeReport, NveError>
where
    F: for<'a> FnMut(ArrayView1<'a, f64>) -> Option<(f64, Array1<f64>)> + Send,
    R: Rng + ?Sized,
{
    let _ = (
        start,
        initial_kinetic,
        seed_direction,
        config,
        evaluate,
        rng,
    );
    Err(NveError::FeatureDisabled)
}

/// A sequence of quenched minima that is allowed to descend only.
///
/// Leary's monotonic sequence basin hopping: a proposed minimum continues
/// the sequence when it is strictly lower than the head, and a higher
/// quench ends the sequence and starts another at that quench. The rule
/// does not read a target structure. It also cannot leave a funnel,
/// because every accepted step goes deeper into the basin the sequence
/// already occupies.
#[derive(Debug, Clone, Copy)]
pub struct MonotonicSequence {
    /// Energy of the current head.
    pub head: f64,
    /// Accepted steps in the current sequence, including the head.
    pub length: usize,
    /// Times a higher quench restarted the sequence.
    pub restarts: usize,
}

impl MonotonicSequence {
    /// A sequence whose head is `start`.
    pub fn new(start: f64) -> Self {
        Self {
            head: start,
            length: 1,
            restarts: 0,
        }
    }

    /// Continue when `energy` is strictly below the head. Otherwise restart.
    pub fn propose(&mut self, energy: f64) -> bool {
        if energy < self.head {
            self.head = energy;
            self.length += 1;
            true
        } else {
            self.head = energy;
            self.length = 1;
            self.restarts += 1;
            false
        }
    }
}

/// What a chain does when a quench returns to a basin it has already sat in.
///
/// None of these reads the coordinates of a target minimum. [`Revisit::Tabu`]
/// spends the proposal. [`Revisit::Monotonic`] only descends, so it stays in
/// the funnel. [`Revisit::Escape`] raises the next excursion and leaves the
/// pass between basins unfilled.
pub enum Revisit {
    /// Metropolis on the quenched energies. A return is an ordinary move.
    Metropolis,
    /// Reject a return to the basin the chain is in.
    Tabu,
    /// Descend-only sequence.
    Monotonic(MonotonicSequence),
    /// Goedecker feedback, with Schoenborn's visit factor when
    /// [`EscapeFeedback::visits_coeff`] is positive.
    Escape(EscapeFeedback),
}

impl Revisit {
    /// Whether a quench of energy `new_energy` from `current_energy` is kept,
    /// given whether it returned to the basin the chain is in.
    pub fn keep(&mut self, current_energy: f64, new_energy: f64, returned: bool) -> bool {
        match self {
            Self::Metropolis => new_energy < current_energy,
            Self::Tabu => !returned && new_energy < current_energy,
            Self::Monotonic(sequence) => sequence.propose(new_energy),
            Self::Escape(feedback) => {
                let delta = new_energy - current_energy;
                feedback.accept(delta)
            }
        }
    }
}

/// What a quench was, relative to the history.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Visit {
    /// The basin the chain was already in.
    Same,
    /// A basin the history has seen before, but not the current one.
    Known,
    /// A basin not in the history.
    New,
}

/// Escape scale and acceptance threshold, both driven by the history.
///
/// Defaults are Goedecker's: the escape scale grows by 1.05 on a revisit and
/// shrinks by the same factor on a discovery, and the acceptance threshold
/// moves the other way, so roughly half of proposals are accepted without a
/// temperature being chosen.
#[derive(Debug, Clone)]
pub struct EscapeFeedback {
    /// Current escape scale, in whatever units the caller's move takes.
    escape: f64,
    /// Current acceptance threshold on the energy rise.
    threshold: f64,
    /// Growth on returning to the current basin.
    pub beta_same: f64,
    /// Growth on reaching a basin already in the history.
    pub beta_known: f64,
    /// Shrink on reaching a new basin.
    pub beta_new: f64,
    /// Enhanced feedback: the known-basin growth is multiplied by
    /// `1 + visits_coeff * ln(visits)`, so a repeatedly seen basin is escaped
    /// harder than one seen once (Schönborn et al.).
    pub visits_coeff: f64,
    /// Threshold multiplier on acceptance; below one.
    pub alpha_accept: f64,
    /// Threshold multiplier on rejection; above one.
    pub alpha_reject: f64,
    /// Ceiling on the escape scale.
    ///
    /// A streak of revisits grows the scale geometrically, and an unbounded
    /// scale eventually proposes a structure so scattered that its relaxation
    /// costs far more than an ordinary one. The ceiling keeps the charged cost
    /// of a proposal bounded without removing the escalation.
    ///
    /// The default of four is set by that cost, not by taste. At a ceiling of
    /// sixty-four an LJ38 run paid 138 charged evaluations per hop against 39
    /// without the controller, so the same budget bought 2173 hops rather than
    /// 7775 and the run solved 1 seed in 8 where the plain chain solved 8.
    /// Escalation that prices itself out of the budget is not escalation.
    pub escape_ceiling: f64,
    /// Floor on the escape scale, so a run of discoveries cannot drive it to
    /// zero and freeze the search.
    pub escape_floor: f64,
    visits: HashMap<usize, u32>,
    /// Driver-local basin IDs are independent of the catalog's numeric IDs.
    driver_local_visits: HashMap<usize, u32>,
    /// Counts of each outcome, for reporting.
    pub n_same: usize,
    /// Quenches that landed in a known other basin.
    pub n_known: usize,
    /// Quenches that opened a new basin.
    pub n_new: usize,
}

/// How a shared-history report drives this chain's escape and acceptance.
///
/// [`SharedVisitPolicy::Tabu`] is Schoenborn sharing: a basin another chain
/// already holds is known here, and the visit count inflates the escape.
/// Measured on hist75 that loses to a matched single chain (12-14/48 against
/// 16/48). [`SharedVisitPolicy::Recognition`] keeps the catalog for identity
/// and quench refunds (certified minima fill the screen stand-in bank);
/// the controller stays on this chain's own standing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub enum SharedVisitPolicy {
    /// Peer visits classify the basin as known and inflate escape.
    #[default]
    Tabu,
    /// Peer visits identify the basin only. Escape stays local; certified
    /// quenches fill the screen stand-in bank.
    Recognition,
}

impl EscapeFeedback {
    /// Controller starting at `escape` and `threshold`, with Goedecker's rates.
    pub fn new(escape: f64, threshold: f64) -> Self {
        assert!(escape > 0.0, "the escape scale must be positive");
        assert!(threshold > 0.0, "the acceptance threshold must be positive");
        Self {
            escape,
            threshold,
            beta_same: 1.05,
            beta_known: 1.05,
            beta_new: 1.0 / 1.05,
            visits_coeff: 0.1,
            alpha_accept: 1.0 / 1.05,
            alpha_reject: 1.05,
            escape_ceiling: escape * 4.0,
            escape_floor: escape / 4.0,
            visits: HashMap::new(),
            driver_local_visits: HashMap::new(),
            n_same: 0,
            n_known: 0,
            n_new: 0,
        }
    }

    /// Current escape scale.
    pub fn escape(&self) -> f64 {
        self.escape
    }

    /// Current acceptance threshold.
    pub fn threshold(&self) -> f64 {
        self.threshold
    }

    /// Basins in the history.
    pub fn known_basins(&self) -> usize {
        self.visits.len()
    }

    /// Times `basin` has been recorded.
    pub fn visits(&self, basin: usize) -> u32 {
        self.visits.get(&basin).copied().unwrap_or(0)
    }

    /// Register the starting minimum without applying escape feedback.
    ///
    /// The first minimum is part of the history even though no escape has
    /// reached it. Recording it leaves both adaptive controls at their stated
    /// initial values and makes a later return classify as known.
    pub fn register_initial(&mut self, basin: usize) {
        self.visits.entry(basin).or_insert(1);
    }

    /// Classifies a quench without recording it.
    pub fn classify(&self, current: Option<usize>, reached: usize) -> Visit {
        if current == Some(reached) {
            Visit::Same
        } else if self.visits.contains_key(&reached) {
            Visit::Known
        } else {
            Visit::New
        }
    }

    /// Records a quench and updates the escape scale.
    ///
    /// Returns what the quench was. The scale rises on a revisit and falls on a
    /// discovery, subject to the configured scale bounds. A chain that keeps
    /// returning escalates toward its ceiling, and one that keeps finding new
    /// structures settles down to explore them.
    pub fn observe(&mut self, current: Option<usize>, reached: usize) -> Visit {
        let visit = self.classify(current, reached);
        let prior_visits = self.visits(reached).max(1) as f64;
        self.apply_escape_feedback(visit, prior_visits);
        *self.visits.entry(reached).or_insert(0) += 1;
        visit
    }

    /// Register an occupied driver-local basin without applying feedback.
    pub(crate) fn register_driver_local_initial(&mut self, basin: usize) {
        self.register_initial(basin);
        self.driver_local_visits.entry(basin).or_insert(1);
    }

    /// Retain a local observation whose feedback uses an authoritative report.
    pub(crate) fn remember_driver_local(&mut self, basin: usize) {
        *self.driver_local_visits.entry(basin).or_insert(0) += 1;
    }

    /// Apply local feedback without treating catalog IDs as local evidence.
    pub(crate) fn observe_driver_local(&mut self, current: Option<usize>, reached: usize) -> Visit {
        let prior_visits = self.driver_local_visits.get(&reached).copied();
        let visit = if current == Some(reached) {
            Visit::Same
        } else if prior_visits.is_some() {
            Visit::Known
        } else {
            Visit::New
        };
        self.apply_escape_feedback(visit, prior_visits.unwrap_or(0).max(1) as f64);
        self.remember_driver_local(reached);
        *self.visits.entry(reached).or_insert(0) += 1;
        visit
    }

    /// Records a quench using the authoritative same-PES catalog history.
    ///
    /// `basin_visits` includes this observation. A basin first found by a
    /// different replica is therefore known even when this controller's local
    /// map has not seen it. The global count also drives enhanced feedback.
    ///
    /// This is [`SharedVisitPolicy::Tabu`]. Recognition keeps the catalog
    /// report off the controller: call [`Self::observe_driver_local`] with
    /// this chain's own basin ids.
    pub fn observe_shared(
        &mut self,
        current: Option<usize>,
        reached: usize,
        new_basin: bool,
        basin_visits: u64,
    ) -> Visit {
        let visit = if current == Some(reached) {
            Visit::Same
        } else if new_basin {
            Visit::New
        } else {
            Visit::Known
        };
        let prior_visits = basin_visits.saturating_sub(1).max(1) as f64;
        self.apply_escape_feedback(visit, prior_visits);
        let observed = u32::try_from(basin_visits.max(1)).unwrap_or(u32::MAX);
        self.visits
            .entry(reached)
            .and_modify(|visits| *visits = (*visits).max(observed))
            .or_insert(observed);
        visit
    }

    /// Increase escape after polishing returns from outside a covered region.
    ///
    /// Coverage-region IDs and counts are independent of minimum identity.
    /// The caller supplies prior admitted visits without registering a minimum
    /// or duplicating an authoritative minimum-history feedback update.
    pub(crate) fn observe_coverage_return(&mut self, same: bool, prior_visits: u64) {
        let visit = if same { Visit::Same } else { Visit::Known };
        self.apply_escape_feedback(visit, prior_visits.max(1) as f64);
    }

    /// Settle the bounded escape scale after reaching an unexplored region.
    /// Region novelty supplies no stationary-point identity or minimum record.
    pub(crate) fn observe_coverage_discovery(&mut self) {
        self.apply_escape_feedback(Visit::New, 1.0);
    }

    fn apply_escape_feedback(&mut self, visit: Visit, prior_visits: f64) {
        match visit {
            Visit::Same => {
                self.escape *= self.beta_same;
                self.n_same += 1;
            }
            Visit::Known => {
                self.escape *= self.beta_known * (1.0 + self.visits_coeff * prior_visits.ln());
                self.n_known += 1;
            }
            Visit::New => {
                self.escape *= self.beta_new;
                self.n_new += 1;
            }
        }
        self.escape = self.escape.clamp(self.escape_floor, self.escape_ceiling);
    }

    /// Whether to accept a move of energy rise `delta`, updating the threshold.
    ///
    /// The rule is Goedecker's: accept when the rise is under the threshold,
    /// then move the threshold so the acceptance rate sits near a half. No
    /// temperature appears, which is the point: a Metropolis temperature cold
    /// enough to polish cannot cross and one hot enough to cross cannot polish,
    /// while this threshold adapts to whichever the chain is currently failing
    /// at.
    pub fn accept(&mut self, delta: f64) -> bool {
        let ok = delta < self.threshold;
        if ok {
            self.threshold *= self.alpha_accept;
        } else {
            self.threshold *= self.alpha_reject;
        }
        // Kept positive and finite; a threshold at zero rejects everything and
        // one that has run away accepts everything.
        self.threshold = self.threshold.clamp(1e-9, 1e6);
        ok
    }

    /// Fraction of quenches that were discoveries.
    ///
    /// A run whose fraction is near zero is revisiting and should be
    /// escalating; one near one is wandering and should be settling. Reported
    /// because it says whether the feedback is doing anything.
    pub fn discovery_rate(&self) -> f64 {
        let total = self.n_same + self.n_known + self.n_new;
        if total == 0 {
            return f64::NAN;
        }
        self.n_new as f64 / total as f64
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ndarray::{Array1, ArrayView1};
    use rand::SeedableRng;
    use rand::rngs::StdRng;

    /// Wide parabola at the origin, narrow parabola of depth -1 at x = 6.
    fn two_funnel(x: f64) -> f64 {
        let wide = 0.05 * x * x;
        let narrow = 8.0 * (x - 6.0) * (x - 6.0) - 1.0;
        wide.min(narrow)
    }

    fn quench_1d(mut x: f64) -> (f64, f64) {
        for _ in 0..80 {
            let eps = 1e-4;
            let slope = (two_funnel(x + eps) - two_funnel(x - eps)) / (2.0 * eps);
            x -= 0.05 * slope;
        }
        (x, two_funnel(x))
    }

    #[test]
    #[cfg(not(feature = "rgsaddle"))]
    fn nve_escape_reports_the_missing_feature() {
        let start = Array1::from_vec(vec![0.0, 0.0, 0.0]);
        let mut evaluate = |_x: ArrayView1<f64>| None;
        let mut rng = StdRng::seed_from_u64(1);
        let result = nve_escape(
            start.view(),
            0.5,
            &MdEscapeConfig::default(),
            &mut evaluate,
            &mut rng,
        );
        assert!(matches!(result, Err(NveError::FeatureDisabled)));
    }

    #[test]
    fn a_fixed_step_stays_in_the_wide_funnel() {
        let (x, energy) = quench_1d(0.0);
        assert!(x.abs() < 0.2, "{x}");
        for _ in 0..30 {
            let (y, _) = quench_1d(x + 0.4);
            assert!(
                (y - 6.0).abs() > 0.5,
                "a short step reached the narrow funnel at {y}"
            );
        }
        assert!(energy.abs() < 1e-6);
    }

    #[test]
    fn an_escalating_escape_reaches_the_narrow_funnel() {
        let mut feedback = EscapeFeedback::new(0.4, 2.0);
        feedback.escape_ceiling = 8.0;
        feedback.beta_same = 1.3;
        feedback.register_initial(0);
        let mut x = 0.0;
        let mut basin = 0usize;
        for _ in 0..24 {
            let (y, energy) = quench_1d(x + feedback.escape());
            let reached = usize::from((y - 6.0).abs() < 0.5);
            feedback.observe(Some(basin), reached);
            if energy < two_funnel(x) {
                x = y;
                basin = reached;
            }
            if basin == 1 {
                break;
            }
        }
        assert_eq!(basin, 1, "escape scale ended at {}", feedback.escape());
        assert!(two_funnel(x) < -0.5);
    }

    #[test]
    fn a_monotonic_sequence_does_not_leave_the_wide_funnel() {
        let mut sequence = MonotonicSequence::new(two_funnel(0.0));
        let mut x = 0.0;
        for _ in 0..20 {
            let (y, energy) = quench_1d(x + 0.4);
            if sequence.propose(energy) {
                x = y;
            }
        }
        assert!(x.abs() < 0.2);
        assert!(sequence.restarts > 0);
    }

    #[test]
    fn tabu_rejects_a_return_and_keeps_a_descent() {
        let mut policy = Revisit::Tabu;
        assert!(!policy.keep(0.0, -0.1, true));
        assert!(policy.keep(0.0, -0.1, false));
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn nve_escape_stops_after_the_requested_potential_minimum_in_generic_nd() {
        let start = Array1::zeros(5);
        let config = MdEscapeConfig {
            dt: 0.05,
            potential_minima: 1,
            maximum_steps: 200,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        let mut evaluations = 0usize;
        let mut evaluate = |x: ArrayView1<f64>| {
            evaluations += 1;
            Some((0.5 * x.dot(&x), x.to_owned()))
        };
        let mut rng = StdRng::seed_from_u64(17);

        let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();

        assert_eq!(report.potential_minima, 1);
        assert!(report.steps < config.maximum_steps);
        assert_eq!(evaluations, report.steps + 1);
        assert_eq!(report.position.len(), 5);
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn nve_escape_requires_sustained_turning_point_and_returns_its_frame() {
        let start = Array1::zeros(5);
        let config = MdEscapeConfig {
            dt: 0.01,
            potential_minima: 1,
            maximum_steps: 20,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        // The first three samples contain a one-step wiggle. The final five
        // contain two decreases into the minimum and two increases out of it.
        let energies = [99.0, 3.0, 2.0, 3.0, 2.0, 1.0, 2.0, 3.0];
        let mut evaluations = 0usize;
        let mut evaluate = |x: ArrayView1<f64>| {
            let energy = energies[evaluations];
            evaluations += 1;
            Some((energy, Array1::zeros(x.len())))
        };
        let mut rng = StdRng::seed_from_u64(17);

        let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();

        assert_eq!(report.steps, 7);
        assert_eq!(report.potential_minima, 1);
        assert_eq!(report.energy, 1.0);
        assert!((report.position.dot(&report.position).sqrt() - 0.05).abs() < 1e-12);
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn flat_and_monotonic_paths_do_not_count_as_potential_minima() {
        let start = Array1::zeros(5);
        let config = MdEscapeConfig {
            dt: 0.01,
            potential_minima: 2,
            maximum_steps: 12,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        for slope in [0.0, -1.0, 1.0] {
            let mut evaluations = 0;
            let mut evaluate = |x: ArrayView1<f64>| {
                let energy = slope * evaluations as f64;
                evaluations += 1;
                Some((energy, Array1::zeros(x.len())))
            };
            let mut rng = StdRng::seed_from_u64(17);
            let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();
            assert_eq!(
                report.potential_minima, 0,
                "slope {slope} has no turning point"
            );
            assert_eq!(report.steps, config.maximum_steps);
            assert_eq!(evaluations, report.steps + 1);
        }
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn separated_sustained_valleys_count_once_each() {
        let start = Array1::zeros(5);
        let config = MdEscapeConfig {
            dt: 0.01,
            potential_minima: 2,
            maximum_steps: 20,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        let energies = [99.0, 3.0, 2.0, 1.0, 2.0, 3.0, 2.0, 1.0, 2.0, 3.0];
        let mut evaluations = 0;
        let mut evaluate = |x: ArrayView1<f64>| {
            let energy = energies[evaluations];
            evaluations += 1;
            Some((energy, Array1::zeros(x.len())))
        };
        let mut rng = StdRng::seed_from_u64(17);
        let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();
        assert_eq!(report.potential_minima, 2);
        assert_eq!(report.steps, 9);
        assert_eq!(report.energy, 1.0);
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn nve_escape_reports_the_energy_spans_needed_for_step_control() {
        let start = Array1::zeros(5);
        let config = MdEscapeConfig {
            dt: 0.01,
            potential_minima: 1,
            maximum_steps: 200,
            geometry: MdEscapeGeometry::Euclidean,
            softening: None,
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        let mut evaluate = |x: ArrayView1<f64>| Some((0.5 * x.dot(&x), x.to_owned()));
        let mut rng = StdRng::seed_from_u64(17);

        let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();

        assert!(report.potential_energy_span > 0.0);
        assert!(report.total_energy_span >= 0.0);
        assert!(report.energy_conservation_ratio() < 0.01);
    }

    #[test]
    fn time_step_feedback_tracks_relative_nve_energy_conservation() {
        let mut feedback = MdTimeStepFeedback::new(0.08, 0.001);
        let mut report = MdEscapeReport {
            position: Array1::zeros(3),
            steps: 5,
            potential_minima: 1,
            energy: 0.0,
            kinetic: 1.0,
            softening_evaluations: 0,
            potential_energy_span: 2.0,
            total_energy_span: 0.01,
            far_position: Array1::zeros(3),
            far_rms: 0.0,
        };

        assert!((feedback.observe(&report) - 0.084).abs() < 1e-12);
        report.total_energy_span = 0.04;
        assert!((feedback.observe(&report) - 0.08).abs() < 1e-12);
        for _ in 0..200 {
            feedback.observe(&report);
        }
        assert!(feedback.time_step() >= 0.001);
    }

    #[cfg(feature = "rgsaddle")]
    #[test]
    fn softened_nve_charges_direction_probes_and_suppresses_the_hard_mode() {
        let start = Array1::zeros(2);
        let config = MdEscapeConfig {
            dt: 0.01,
            potential_minima: 1,
            maximum_steps: 1,
            geometry: MdEscapeGeometry::Euclidean,
            softening: Some(VelocitySofteningConfig {
                steps: 20,
                displacement: 0.1,
                mixing: 0.15,
            }),
            minimum_rise: 0.0,
            max_rms: f64::INFINITY,
            min_well_rms: 0.0,
        };
        let mut evaluations = 0usize;
        let mut evaluate = |x: ArrayView1<f64>| {
            evaluations += 1;
            Some((
                0.5 * (100.0 * x[0] * x[0] + x[1] * x[1]),
                Array1::from(vec![100.0 * x[0], x[1]]),
            ))
        };
        let mut rng = StdRng::seed_from_u64(17);

        let report = nve_escape(start.view(), 0.5, &config, &mut evaluate, &mut rng).unwrap();

        assert_eq!(report.softening_evaluations, 20);
        assert_eq!(evaluations, report.softening_evaluations + report.steps + 1);
        assert!(report.position[0].abs() < 1e-5, "{:?}", report.position);
        assert!(report.position[1].abs() > 0.009);
    }

    #[test]
    fn initial_minimum_remains_known_after_the_chain_leaves_it() {
        let mut feedback = EscapeFeedback::new(1.0, 1.0);
        feedback.register_initial(7);

        assert_eq!(feedback.classify(Some(8), 7), Visit::Known);
        assert_eq!(feedback.visits(7), 1);
        assert_eq!(feedback.escape(), 1.0);
    }

    #[test]
    fn revisiting_the_same_basin_escalates_the_escape() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        let before = f.escape();
        for _ in 0..10 {
            assert_eq!(f.observe(Some(3), 3), Visit::Same);
        }
        assert!(
            f.escape() > before * 1.5,
            "ten returns should escalate: {} from {before}",
            f.escape()
        );
    }

    #[test]
    fn discovery_settles_the_escape_down() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        for k in 0..10 {
            assert_eq!(f.observe(Some(999), k), Visit::New);
        }
        assert!(
            f.escape() < 1.0,
            "a run of discoveries should settle: {}",
            f.escape()
        );
    }

    /// The property the mechanism exists for: a chain that cannot leave keeps
    /// escalating, so no funnel is permanent.
    #[test]
    fn a_trapped_chain_escalates_without_bound_up_to_the_ceiling() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        for _ in 0..500 {
            f.observe(Some(0), 0);
        }
        assert!(
            (f.escape() - f.escape_ceiling).abs() < 1e-9,
            "a permanently trapped chain should reach the ceiling, got {}",
            f.escape()
        );
    }

    #[test]
    fn a_repeatedly_seen_basin_is_escaped_harder_than_a_new_one() {
        let mut a = EscapeFeedback::new(1.0, 1.0);
        // Basin 1 seen many times, then returned to from elsewhere.
        for _ in 0..20 {
            a.observe(Some(1), 1);
        }
        let before = a.escape();
        a.observe(Some(2), 1);
        let jump_known = a.escape() / before;

        let mut b = EscapeFeedback::new(1.0, 1.0);
        b.observe(Some(2), 1);
        let jump_first = b.escape() / 1.0;
        assert!(
            jump_known > jump_first,
            "enhanced feedback should push harder on a familiar basin: \
             {jump_known} against {jump_first}"
        );
    }

    #[test]
    fn enhanced_feedback_is_logarithmic_in_the_visit_count() {
        let mut feedback = EscapeFeedback::new(1.0, 1.0);
        feedback.register_initial(7);

        let before_first = feedback.escape();
        feedback.observe(Some(8), 7);
        let first_ratio = feedback.escape() / before_first;
        let before_second = feedback.escape();
        feedback.observe(Some(8), 7);
        let second_ratio = feedback.escape() / before_second;

        assert!((first_ratio - feedback.beta_known).abs() < 1e-12);
        let expected = feedback.beta_known * (1.0 + feedback.visits_coeff * 2.0_f64.ln());
        assert!((second_ratio - expected).abs() < 1e-12);
    }

    #[test]
    fn shared_history_marks_another_replicas_basin_as_known() {
        let mut feedback = EscapeFeedback::new(1.0, 1.0);
        feedback.register_initial(3);

        let before = feedback.escape();
        let visit = feedback.observe_shared(Some(3), 9, false, 8);

        assert_eq!(visit, Visit::Known);
        let expected = feedback.beta_known * (1.0 + feedback.visits_coeff * 7.0_f64.ln());
        assert!((feedback.escape() / before - expected).abs() < 1e-12);
        assert_eq!(feedback.visits(9), 8);
    }

    #[test]
    fn recognition_keeps_a_peer_basin_new_for_this_chain() {
        let mut tabu = EscapeFeedback::new(1.0, 1.0);
        tabu.register_initial(3);
        let tabu_before = tabu.escape();
        assert_eq!(tabu.observe_shared(Some(3), 9, false, 8), Visit::Known);
        let tabu_ratio = tabu.escape() / tabu_before;

        let mut rec = EscapeFeedback::new(1.0, 1.0);
        rec.register_driver_local_initial(3);
        let rec_before = rec.escape();
        assert_eq!(rec.observe_driver_local(Some(3), 9), Visit::New);
        let rec_ratio = rec.escape() / rec_before;

        assert!(
            rec_ratio < tabu_ratio,
            "recognition must not inherit the peer visit penalty: {rec_ratio} against {tabu_ratio}"
        );
        assert_eq!(rec.n_new, 1);
        assert_eq!(rec.n_known, 0);
        assert_eq!(SharedVisitPolicy::default(), SharedVisitPolicy::Tabu);
    }

    #[test]
    fn the_threshold_settles_near_half_acceptance() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        // A stream of rises drawn from a fixed distribution; the threshold
        // should find the level that accepts about half of them.
        let rises: Vec<f64> = (0..4000)
            .map(|i| ((i * 7919 + 13) % 1000) as f64 / 500.0)
            .collect();
        let mut accepted = 0usize;
        for (k, d) in rises.iter().enumerate() {
            let ok = f.accept(*d);
            if k >= 2000 && ok {
                accepted += 1;
            }
        }
        let rate = accepted as f64 / 2000.0;
        assert!(
            (0.3..0.7).contains(&rate),
            "acceptance settled at {rate}, which is not near a half"
        );
    }

    #[test]
    fn the_escape_scale_stays_within_its_bounds() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        for _ in 0..1000 {
            f.observe(Some(0), 0);
        }
        assert!(f.escape() <= f.escape_ceiling + 1e-12);
        let mut g = EscapeFeedback::new(1.0, 1.0);
        for k in 0..1000 {
            g.observe(Some(usize::MAX), k);
        }
        assert!(g.escape() >= g.escape_floor - 1e-12);
    }

    #[test]
    fn classification_distinguishes_the_three_cases() {
        let mut f = EscapeFeedback::new(1.0, 1.0);
        assert_eq!(f.classify(Some(1), 1), Visit::Same);
        assert_eq!(f.classify(Some(1), 2), Visit::New);
        f.observe(Some(1), 2);
        assert_eq!(f.classify(Some(1), 2), Visit::Known);
        assert_eq!(f.classify(Some(2), 2), Visit::Same);
    }

    #[cfg(feature = "rgsaddle")]
    mod geometry_controls {
        use super::super::{
            MdEscapeConfig, MdEscapeGeometry, MdEscapeReport, NveError, VelocitySofteningConfig,
            nve_escape, nve_escape_with_frozen,
        };
        use ndarray::{Array1, ArrayView1, array};
        use rand::rngs::StdRng;
        use rand::{Rng, SeedableRng};

        fn config(geometry: MdEscapeGeometry, softening_steps: usize) -> MdEscapeConfig {
            MdEscapeConfig {
                dt: 0.01,
                potential_minima: 1,
                maximum_steps: 6,
                geometry,
                softening: (softening_steps > 0).then_some(VelocitySofteningConfig {
                    steps: softening_steps,
                    ..Default::default()
                }),
                minimum_rise: 0.0,
                max_rms: f64::INFINITY,
                min_well_rms: 0.0,
            }
        }

        fn reaction_surface(x: ArrayView1<f64>, reference: ArrayView1<f64>) -> (f64, Array1<f64>) {
            let delta = &x - &reference;
            let reaction = [2.0, -3.0, 4.0];
            let mut gradient = delta.clone();
            let mut energy = 0.5 * delta.iter().skip(3).map(|value| value * value).sum::<f64>();
            for coordinate in 0..3 {
                energy += reaction[coordinate] * delta[coordinate];
                gradient[coordinate] = reaction[coordinate];
            }
            (energy, gradient)
        }

        #[test]
        fn frozen_frames_constrain_softening_and_md_with_nonzero_reaction_forces() {
            let start = array![0.3, -0.7, 1.2, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0];
            for softening_steps in [0, 4] {
                let config = config(MdEscapeGeometry::Euclidean, softening_steps);
                let mut frames = Vec::new();
                let mut evaluate = |x: ArrayView1<f64>| {
                    frames.push(x.to_owned());
                    Some(reaction_surface(x, start.view()))
                };
                let mut rng = StdRng::seed_from_u64(17);
                let report = nve_escape_with_frozen(
                    start.view(),
                    0.05,
                    &config,
                    &mut evaluate,
                    &mut rng,
                    Some(&[true, false, false]),
                )
                .unwrap();

                assert_eq!(report.steps, config.maximum_steps);
                assert_eq!(report.softening_evaluations, softening_steps);
                assert_eq!(frames.len(), report.steps + 1 + softening_steps);
                assert!(frames.iter().any(|x| {
                    x.iter()
                        .zip(start.iter())
                        .skip(3)
                        .any(|(actual, initial)| actual.to_bits() != initial.to_bits())
                }));
                for frame in &frames {
                    for coordinate in 0..3 {
                        assert_eq!(
                            frame[coordinate].to_bits(),
                            start[coordinate].to_bits(),
                            "fixed coordinate {coordinate} moved with {softening_steps} softening probes"
                        );
                    }
                }
                assert_eq!(
                    report.energy.to_bits(),
                    reaction_surface(report.position.view(), start.view())
                        .0
                        .to_bits()
                );
            }
        }

        #[test]
        fn all_frozen_frames_fail_without_evaluating_the_surface() {
            let start = array![-1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0];
            for geometry in [MdEscapeGeometry::Euclidean, MdEscapeGeometry::RigidQuotient] {
                for softening_steps in [0, 4] {
                    let config = config(geometry, softening_steps);
                    let mut evaluations = 0;
                    let mut evaluate = |x: ArrayView1<f64>| {
                        evaluations += 1;
                        Some((0.0, Array1::<f64>::zeros(x.len())))
                    };
                    let mut rng = StdRng::seed_from_u64(17);
                    let result = nve_escape_with_frozen(
                        start.view(),
                        0.05,
                        &config,
                        &mut evaluate,
                        &mut rng,
                        Some(&[true; 3]),
                    );

                    assert!(matches!(result, Err(NveError::Solver(_))));
                    assert_eq!(evaluations, 0);
                }
            }
        }

        fn pair_surface(x: ArrayView1<f64>) -> (f64, Array1<f64>) {
            let reference = array![-1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0];
            let mut energy = 0.0;
            let mut gradient = Array1::<f64>::zeros(x.len());
            for i in 0..3 {
                for j in i + 1..3 {
                    let mut residual = 0.0;
                    for axis in 0..3 {
                        let delta = x[3 * i + axis] - x[3 * j + axis];
                        let target = reference[3 * i + axis] - reference[3 * j + axis];
                        residual += delta * delta - target * target;
                    }
                    energy += 0.25 * residual * residual;
                    for axis in 0..3 {
                        let force = residual * (x[3 * i + axis] - x[3 * j + axis]);
                        gradient[3 * i + axis] += force;
                        gradient[3 * j + axis] -= force;
                    }
                }
            }
            (energy, gradient)
        }

        fn report_bits(report: &MdEscapeReport) -> Vec<u64> {
            report
                .position
                .iter()
                .copied()
                .chain([
                    report.energy,
                    report.kinetic,
                    report.potential_energy_span,
                    report.total_energy_span,
                ])
                .map(f64::to_bits)
                .collect()
        }

        #[test]
        fn all_mobile_masks_preserve_unconstrained_traces_reports_and_rng() {
            let start = array![-1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0];
            for geometry in [MdEscapeGeometry::Euclidean, MdEscapeGeometry::RigidQuotient] {
                for softening_steps in [0, 4] {
                    let config = config(geometry, softening_steps);
                    let mut direct_frames = Vec::new();
                    let mut direct_surface = |x: ArrayView1<f64>| {
                        direct_frames
                            .push(x.iter().map(|value| value.to_bits()).collect::<Vec<_>>());
                        Some(pair_surface(x))
                    };
                    let mut direct_rng = StdRng::seed_from_u64(17);
                    let direct = nve_escape(
                        start.view(),
                        0.05,
                        &config,
                        &mut direct_surface,
                        &mut direct_rng,
                    )
                    .unwrap();
                    let mut masked_frames = Vec::new();
                    let mut masked_surface = |x: ArrayView1<f64>| {
                        masked_frames
                            .push(x.iter().map(|value| value.to_bits()).collect::<Vec<_>>());
                        Some(pair_surface(x))
                    };
                    let mut masked_rng = StdRng::seed_from_u64(17);
                    let masked = nve_escape_with_frozen(
                        start.view(),
                        0.05,
                        &config,
                        &mut masked_surface,
                        &mut masked_rng,
                        Some(&[false; 3]),
                    )
                    .unwrap();

                    assert_eq!(direct_frames, masked_frames);
                    assert_eq!(report_bits(&direct), report_bits(&masked));
                    assert_eq!(direct.steps, masked.steps);
                    assert_eq!(direct.potential_minima, masked.potential_minima);
                    assert_eq!(direct.softening_evaluations, masked.softening_evaluations);
                    assert_eq!(direct_frames.len(), direct.steps + 1 + softening_steps);
                    assert_eq!(direct_rng.random::<u64>(), masked_rng.random::<u64>());
                }
            }
        }
    }
}
