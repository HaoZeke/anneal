//! GLE-thermostatted Langevin dynamics as a simulated-annealing driver.
//!
//! This is the colored-noise point of the algebra: a gradient-driven sampler
//! whose Move slot is BAB Langevin dynamics and whose thermostat is the
//! generalized Langevin equation (Ceriotti-Bussi-Parrinello) rather than a
//! single white-noise friction. A white-noise thermostat critically damps one
//! frequency, so an ill-conditioned objective -- a wide spread of Hessian
//! curvatures -- has most modes far from critical and decorrelating slowly. The
//! GLE shapes a frequency-dependent friction from a few auxiliary momenta,
//! flattening the sampling efficiency across the curvature band, and the
//! temperature is annealed so the trajectory settles into a basin. Conditioning
//! is handled by the noise spectrum exactly as the `1/sqrt(D)` proposal scale
//! handles dimension; both are Move-slot transforms every driver could read.

use eindir_core::{GleThermostat, Objective, optimal_sampling_drift};
use ndarray::{Array1, Array2};
use rand::SeedableRng;
use rand::rngs::StdRng;

use eindir_core::Gradient;

/// Characteristic frequency used when local curvature does not yield a finite estimate.
pub const DEFAULT_GLE_OMEGA0: f64 = 0.2;
/// Optimal-sampling drift is fitted across this upper/lower frequency ratio.
const GLE_BAND_RATIO: f64 = 100.0;
/// Maximum timestep fraction of the fastest fitted GLE frequency.
const GLE_TIMESTEP_RESOLUTION: f64 = 0.2;
/// Numerical floor for timestep clipping.
const GLE_MIN_TIMESTEP: f64 = 1e-6;
/// Numerical floor for positive frequencies and curvatures.
const GLE_FREQUENCY_FLOOR: f64 = 1e-12;
/// Final annealing temperature as a fraction of the initial temperature.
const GLE_ANNEAL_TEMPERATURE_FLOOR_RATIO: f64 = 1e-3;

/// Noise law for a Langevin optimization trajectory.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum GleNoise {
    /// Fitted extended-state thermostat across the configured frequency band.
    Colored,
    /// Scalar Langevin friction, with no auxiliary momentum rows.
    White {
        /// Positive finite damping rate for the physical momentum.
        friction: f64,
    },
}

impl GleNoise {
    pub(crate) fn validate(self) {
        if let Self::White { friction } = self {
            assert!(
                friction.is_finite() && friction > 0.0,
                "friction must be finite and positive"
            );
        }
    }

    fn drift(self, omega0: f64) -> Array2<f64> {
        match self {
            Self::Colored => optimal_sampling_drift(omega0),
            Self::White { friction } => Array2::from_elem((1, 1), friction),
        }
    }
}

/// Persistent optimization noise; positions and raw forces belong to the caller.
/// Segment boundaries do not redraw physical or auxiliary momenta. A caller
/// that changes its position through quench or rejection supplies a fresh force.
pub(crate) struct LangevinStepper {
    drift: Array2<f64>,
    thermostat: GleThermostat,
    momentum: Array2<f64>,
    scale: Array1<f64>,
    rng: StdRng,
    temperature: f64,
    pub(crate) dt: f64,
}

impl LangevinStepper {
    pub(crate) fn new(
        noise: GleNoise,
        omega0: f64,
        dt: f64,
        temperature: f64,
        scale: Array1<f64>,
        seed: u64,
    ) -> Self {
        noise.validate();
        assert!(
            omega0.is_finite() && omega0 > 0.0,
            "omega0 must be finite and positive"
        );
        assert!(dt.is_finite() && dt > 0.0, "dt must be finite and positive");
        assert!(
            scale.iter().all(|s| s.is_finite() && *s > 0.0),
            "scale must be finite and positive"
        );
        let dt = dt
            .min(GLE_TIMESTEP_RESOLUTION / (GLE_BAND_RATIO * omega0).max(GLE_FREQUENCY_FLOOR))
            .max(GLE_MIN_TIMESTEP);
        let drift = noise.drift(omega0);
        let thermostat = GleThermostat::canonical(&drift, dt, temperature, 1.0);
        let covariance = Array2::<f64>::eye(drift.nrows()) * temperature;
        let mut rng = StdRng::seed_from_u64(seed);
        let momentum = thermostat.sample_stationary(&covariance, scale.len(), 1.0, &mut rng);
        Self {
            drift,
            thermostat,
            momentum,
            scale,
            rng,
            temperature,
            dt,
        }
    }

    pub(crate) fn set_temperature(&mut self, temperature: f64) {
        if temperature == self.temperature {
            return;
        }
        self.momentum *= (temperature / self.temperature).sqrt();
        self.thermostat = GleThermostat::canonical(&self.drift, self.dt, temperature, 1.0);
        self.temperature = temperature;
    }

    /// One BAB step and thermostat update: exactly one gradient and objective.
    /// The boundary operation is box clipping, not a manifold retraction.
    pub(crate) fn step<O: Objective<f64>, G: Gradient<f64>>(
        &mut self,
        obj: &O,
        grad: &G,
        x: &mut Array1<f64>,
        raw_gradient: &mut Array1<f64>,
    ) -> f64 {
        self.step_with_proposal(obj, grad, x, raw_gradient, |_| {})
    }

    /// Correct a feasible position before raw force evaluation, so cached
    /// forces always belong to the positions the objective actually samples.
    pub(crate) fn step_with_proposal<
        O: Objective<f64>,
        G: Gradient<f64>,
        P: FnMut(&mut Array1<f64>),
    >(
        &mut self,
        obj: &O,
        grad: &G,
        x: &mut Array1<f64>,
        raw_gradient: &mut Array1<f64>,
        mut proposal: P,
    ) -> f64 {
        let mut p = self.momentum.row(0).to_owned();
        p = &p - &(&(&*raw_gradient * &self.scale) * (0.5 * self.dt));
        *x = &*x + &(&(&p * &self.scale) * self.dt);
        *x = obj.bounds().clip(x.view());
        proposal(x);
        *raw_gradient = grad.grad(x.view());
        let value = obj.eval(x.view());
        p = &p - &(&(&*raw_gradient * &self.scale) * (0.5 * self.dt));
        self.momentum.row_mut(0).assign(&p);
        self.thermostat
            .step(&mut self.momentum.view_mut(), &mut self.rng);
        value
    }
}

/// Result of a GLE-Langevin annealing run.
#[derive(Clone, Debug)]
pub struct GleLangevinResult {
    /// Best-seen position.
    pub best_pos: Vec<f64>,
    /// Best-seen objective value.
    pub best_val: f64,
    /// Gradient evaluations consumed (the work unit at parity with the field).
    pub n_evals: usize,
    /// Characteristic frequency used to scale the colored-noise drift.
    pub omega0: f64,
    /// Timestep after resolving the upper end of the GLE frequency band.
    pub dt: f64,
    /// Diagonal entries of the position-space preconditioning matrix.
    pub preconditioner_diag: Vec<f64>,
    /// Gradient probes spent calibrating the frequency or diagonal preconditioner.
    pub n_preconditioner_grads: usize,
}

/// Diagonal GLE preconditioner in transformed coordinates.
#[derive(Clone, Debug)]
pub struct GlePreconditioner {
    /// Coordinate scale `x_j = scale_j z_j`.
    pub scale: Array1<f64>,
    /// Diagonal entries of the position-space preconditioner.
    pub diag: Array1<f64>,
    /// Characteristic transformed frequency.
    pub omega0: f64,
    /// Gradient probes consumed by the estimate.
    pub n_grads: usize,
}

fn fallback_gle_omega0(low: &Array1<f64>, high: &Array1<f64>) -> f64 {
    let diagonal = low
        .iter()
        .zip(high.iter())
        .map(|(lo, hi)| {
            let width = hi - lo;
            width * width
        })
        .sum::<f64>()
        .sqrt();
    if diagonal.is_finite() && diagonal > 0.0 {
        (1.0 / diagonal).max(GLE_FREQUENCY_FLOOR)
    } else {
        DEFAULT_GLE_OMEGA0
    }
}

fn unit_gle_preconditioner(dim: usize, omega0: f64) -> GlePreconditioner {
    GlePreconditioner {
        scale: Array1::from_elem(dim, 1.0),
        diag: Array1::from_elem(dim, 1.0),
        omega0,
        n_grads: 0,
    }
}

fn default_gle_preconditioner_probe_budget(max_fevals: usize, dim: usize) -> usize {
    let probe_pairs = max_fevals.saturating_sub(1).checked_div(2).unwrap_or(0);
    let root_budget = (probe_pairs as f64).sqrt().floor() as usize;
    probe_pairs.min(root_budget).min(dim)
}

fn gle_preconditioner_probe_budget(
    max_fevals: usize,
    dim: usize,
    configured_probes: Option<usize>,
) -> usize {
    let probe_pairs = max_fevals.saturating_sub(1).checked_div(2).unwrap_or(0);
    configured_probes
        .unwrap_or_else(|| default_gle_preconditioner_probe_budget(max_fevals, dim))
        .min(probe_pairs)
        .min(dim)
}

fn gle_lower_band_frequency(target_frequency: f64) -> f64 {
    (target_frequency / GLE_BAND_RATIO.sqrt()).max(GLE_FREQUENCY_FLOOR)
}

fn splitmix64(mut value: u64) -> u64 {
    value = value.wrapping_add(0x9E37_79B9_7F4A_7C15);
    value = (value ^ (value >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    value ^ (value >> 31)
}

/// Deterministic Rademacher direction for one curvature probe.
///
/// One probe pair recovers the full diagonal exactly when the Hessian
/// is diagonal: `d_i (H d)_i = H_ii` for `d_i in {-1, +1}`.
fn gle_probe_direction(seed: u64, probe: usize, dim: usize) -> Array1<f64> {
    Array1::from_iter((0..dim).map(|axis| {
        let bits = splitmix64(seed ^ ((probe as u64) << 32) ^ axis as u64);
        if bits & 1 == 0 { 1.0 } else { -1.0 }
    }))
}

/// Estimate a diagonal coordinate preconditioner from local gradient curvature.
pub fn estimate_gle_preconditioner<O, G>(
    obj: &O,
    grad: &G,
    seed: u64,
    max_probes: usize,
) -> GlePreconditioner
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    let bounds = obj.bounds();
    let dim = bounds.dims;
    if dim == 0 {
        return unit_gle_preconditioner(0, DEFAULT_GLE_OMEGA0);
    }
    let low = &bounds.low;
    let high = &bounds.high;
    let fallback = fallback_gle_omega0(low, high);
    let center = (low + high) * 0.5;
    let probes = max_probes;
    if probes == 0 {
        return unit_gle_preconditioner(dim, fallback);
    }
    let min_width = low
        .iter()
        .zip(high.iter())
        .filter_map(|(lo, hi)| {
            let width = hi - lo;
            (width.is_finite() && width > 0.0).then_some(width)
        })
        .fold(f64::INFINITY, f64::min);
    if !min_width.is_finite() || min_width <= 0.0 {
        return unit_gle_preconditioner(dim, fallback);
    }
    let step = (f64::EPSILON.cbrt() * min_width).max(f64::EPSILON.sqrt());
    let mut curvature_sum = Array1::<f64>::zeros(dim);
    let mut used = 0usize;
    let mut n_grads = 0usize;

    for probe in 0..probes {
        let direction = gle_probe_direction(seed, probe, dim);
        let xp = bounds.clip((&center + &(&direction * step)).view());
        let xm = bounds.clip((&center - &(&direction * step)).view());
        let gp = grad.grad(xp.view());
        let gm = grad.grad(xm.view());
        n_grads += 2;
        if gp.len() != dim
            || gm.len() != dim
            || gp.iter().any(|value| !value.is_finite())
            || gm.iter().any(|value| !value.is_finite())
        {
            continue;
        }
        let hv = (&gp - &gm) * (0.5 / step);
        curvature_sum += &(&direction * &hv);
        used += 1;
    }

    if used == 0 {
        return GlePreconditioner {
            n_grads,
            ..unit_gle_preconditioner(dim, fallback)
        };
    }
    let curvature = curvature_sum.mapv(|value| (value / used as f64).abs());

    let mut positive: Vec<f64> = curvature
        .iter()
        .copied()
        .filter(|value| value.is_finite() && *value > GLE_FREQUENCY_FLOOR)
        .collect();
    if positive.is_empty() {
        return GlePreconditioner {
            n_grads,
            ..unit_gle_preconditioner(dim, fallback)
        };
    }
    positive.sort_by(|left, right| left.total_cmp(right));
    let reference = positive[positive.len() / 2].max(GLE_FREQUENCY_FLOOR);
    let scale = curvature.mapv(|value| {
        if value.is_finite() && value > GLE_FREQUENCY_FLOOR {
            (reference / value).sqrt()
        } else {
            1.0
        }
    });
    let diag = scale.mapv(|value| value * value);
    GlePreconditioner {
        scale,
        diag,
        omega0: gle_lower_band_frequency(reference.sqrt()),
        n_grads,
    }
}

/// Estimate the characteristic GLE frequency from local gradient curvature.
pub fn estimate_gle_omega0<O, G>(obj: &O, grad: &G) -> f64
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    estimate_gle_omega0_with_probe_budget(obj, grad, obj.bounds().dims).0
}

fn estimate_gle_omega0_with_probe_budget<O, G>(
    obj: &O,
    grad: &G,
    max_probe_pairs: usize,
) -> (f64, usize)
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    let bounds = obj.bounds();
    let dim = bounds.dims;
    if dim == 0 {
        return (DEFAULT_GLE_OMEGA0, 0);
    }
    let low = &bounds.low;
    let high = &bounds.high;
    let center = (low + high) * 0.5;
    let rel_step = f64::EPSILON.cbrt();
    let min_step = f64::EPSILON.sqrt();
    let mut frequencies = Vec::with_capacity(dim);
    let mut n_grads = 0;
    for axis in 0..dim {
        if n_grads / 2 >= max_probe_pairs {
            break;
        }
        let width = high[axis] - low[axis];
        if !width.is_finite() || width <= 0.0 {
            continue;
        }
        let step = (rel_step * width.abs()).max(min_step);
        let mut xp = center.clone();
        let mut xm = center.clone();
        xp[axis] = (center[axis] + step).min(high[axis]);
        xm[axis] = (center[axis] - step).max(low[axis]);
        let denom = xp[axis] - xm[axis];
        if !denom.is_finite() || denom.abs() <= min_step {
            continue;
        }
        let gp = grad.grad(xp.view());
        let gm = grad.grad(xm.view());
        n_grads += 2;
        if gp.len() != dim
            || gm.len() != dim
            || gp.iter().any(|v| !v.is_finite())
            || gm.iter().any(|v| !v.is_finite())
        {
            continue;
        }
        let curvature = (gp[axis] - gm[axis]) / denom;
        if curvature.is_finite() && curvature != 0.0 {
            frequencies.push(curvature.abs().sqrt());
        }
    }
    frequencies.sort_by(|left, right| left.total_cmp(right));
    let omega0 = frequencies
        .into_iter()
        .find(|omega| omega.is_finite() && *omega > 0.0)
        .unwrap_or_else(|| fallback_gle_omega0(low, high));
    (omega0, n_grads)
}

/// Run GLE-thermostatted Langevin annealing on `obj` with gradient `grad`.
///
/// `max_fevals` bounds the gradient evaluations (one per dynamics step).
/// `omega0` is the characteristic frequency the fitted optimal-sampling drift is
/// scaled to (it flattens the sampling efficiency across the configured band),
/// `dt` the timestep (clamped so the fastest band frequency is resolved), and
/// `n_epochs` the number of geometric temperature levels. Returns the best
/// objective value at budget parity.
#[allow(clippy::too_many_arguments)]
pub fn gle_langevin_sa<O, G>(
    obj: &O,
    grad: &G,
    seed: u64,
    max_fevals: usize,
    omega0: f64,
    dt: f64,
    n_epochs: usize,
    x0: Option<Array1<f64>>,
) -> GleLangevinResult
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    let dim = obj.bounds().dims;
    let scale = Array1::from_elem(dim, 1.0);
    run_gle_langevin_scaled_sa(
        obj,
        grad,
        seed,
        max_fevals,
        omega0,
        dt,
        n_epochs,
        x0,
        &scale,
        Array1::from_elem(dim, 1.0),
        0,
    )
}

#[allow(clippy::too_many_arguments)]
fn run_gle_langevin_scaled_sa<O, G>(
    obj: &O,
    grad: &G,
    seed: u64,
    max_fevals: usize,
    omega0: f64,
    dt: f64,
    n_epochs: usize,
    x0: Option<Array1<f64>>,
    scale: &Array1<f64>,
    preconditioner_diag: Array1<f64>,
    n_preconditioner_grads: usize,
) -> GleLangevinResult
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    assert!(max_fevals > 0, "max_fevals must be positive");
    assert!(
        omega0.is_finite() && omega0 > 0.0,
        "omega0 must be positive"
    );
    let bounds = obj.bounds().clone();
    let dim = bounds.dims;
    assert_eq!(scale.len(), dim, "scale length must match dimension");

    // Resolve the fastest fitted frequency with the configured timestep fraction.
    let omega_hi = GLE_BAND_RATIO * omega0;
    let dt = dt
        .min(GLE_TIMESTEP_RESOLUTION / omega_hi.max(GLE_FREQUENCY_FLOOR))
        .max(GLE_MIN_TIMESTEP);

    // Start from the supplied anchor or the box centre.
    let mut x: Array1<f64> = x0
        .filter(|candidate| {
            candidate.len() == dim && candidate.iter().all(|value| value.is_finite())
        })
        .map(|candidate| bounds.clip(candidate.view()))
        .unwrap_or_else(|| (&bounds.low + &bounds.high) * 0.5);
    let fx = obj.eval(x.view());
    let mut best_val = fx;
    let mut best_pos = x.clone();

    let t_hi = fx.abs().max(1.0);
    let t_lo = GLE_ANNEAL_TEMPERATURE_FLOOR_RATIO * t_hi;
    let dynamics_budget = max_fevals.saturating_sub(n_preconditioner_grads).max(1);
    let n_epochs = n_epochs.clamp(1, dynamics_budget);
    let steps = (dynamics_budget / n_epochs).max(1);

    let mut g = grad.grad(x.view());
    let mut n_evals = n_preconditioner_grads + 1;
    if n_evals >= max_fevals {
        return GleLangevinResult {
            best_pos: best_pos.to_vec(),
            best_val,
            n_evals,
            omega0,
            dt,
            preconditioner_diag: preconditioner_diag.to_vec(),
            n_preconditioner_grads,
        };
    }

    let mut stepper =
        LangevinStepper::new(GleNoise::Colored, omega0, dt, t_hi, scale.clone(), seed);
    'outer: for epoch in 0..n_epochs {
        if crate::caller_stop::raised() {
            break;
        }
        let frac = epoch as f64 / (n_epochs.max(2) - 1) as f64;
        let temperature = t_hi * (t_lo / t_hi).powf(frac);
        stepper.set_temperature(temperature);
        for _ in 0..steps {
            if crate::caller_stop::raised() {
                break 'outer;
            }
            let fy = stepper.step(obj, grad, &mut x, &mut g);
            n_evals += 1;
            if fy < best_val {
                best_val = fy;
                best_pos = x.clone();
            }
            if n_evals >= max_fevals {
                break 'outer;
            }
        }
    }
    GleLangevinResult {
        best_pos: best_pos.to_vec(),
        best_val,
        n_evals,
        omega0,
        dt,
        preconditioner_diag: preconditioner_diag.to_vec(),
        n_preconditioner_grads,
    }
}

/// Run GLE-Langevin annealing with a diagonal adaptive coordinate transform.
#[allow(clippy::too_many_arguments)]
pub fn gle_langevin_preconditioned_sa<O, G>(
    obj: &O,
    grad: &G,
    seed: u64,
    max_fevals: usize,
    dt: f64,
    n_epochs: usize,
    x0: Option<Array1<f64>>,
    max_preconditioner_probes: Option<usize>,
) -> GleLangevinResult
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    let max_probes =
        gle_preconditioner_probe_budget(max_fevals, obj.bounds().dims, max_preconditioner_probes);
    let preconditioner = if max_probes > 0 {
        estimate_gle_preconditioner(obj, grad, seed, max_probes)
    } else {
        let bounds = obj.bounds();
        unit_gle_preconditioner(bounds.dims, fallback_gle_omega0(&bounds.low, &bounds.high))
    };
    run_gle_langevin_scaled_sa(
        obj,
        grad,
        seed,
        max_fevals,
        preconditioner.omega0,
        dt,
        n_epochs,
        x0,
        &preconditioner.scale,
        preconditioner.diag,
        preconditioner.n_grads.min(max_fevals.saturating_sub(1)),
    )
}

/// Run GLE-Langevin annealing with a frequency estimated from the objective.
pub fn gle_langevin_adaptive_sa<O, G>(
    obj: &O,
    grad: &G,
    seed: u64,
    max_fevals: usize,
    dt: f64,
    n_epochs: usize,
    x0: Option<Array1<f64>>,
) -> GleLangevinResult
where
    O: Objective<f64>,
    G: Gradient<f64>,
{
    assert!(max_fevals > 0, "max_fevals must be positive");
    let dim = obj.bounds().dims;
    // Complete probe pairs share the gradient allowance with initialization.
    let max_probe_pairs = ((max_fevals - 1) / 2).min(dim);
    let (omega0, n_probe_grads) = estimate_gle_omega0_with_probe_budget(obj, grad, max_probe_pairs);
    let scale = Array1::from_elem(dim, 1.0);
    run_gle_langevin_scaled_sa(
        obj,
        grad,
        seed,
        max_fevals,
        omega0,
        dt,
        n_epochs,
        x0,
        &scale,
        Array1::from_elem(dim, 1.0),
        n_probe_grads,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use eindir_core::Bounds;
    use ndarray::ArrayView1;

    // Ill-conditioned separable quadratic: curvatures span three decades.
    struct IllConditioned {
        bounds: Bounds<f64>,
        a: Array1<f64>,
    }
    impl Objective<f64> for IllConditioned {
        fn eval(&self, x: ArrayView1<f64>) -> f64 {
            self.a
                .iter()
                .zip(x.iter())
                .map(|(&ai, &xi)| ai * xi * xi)
                .sum()
        }
        fn bounds(&self) -> &Bounds<f64> {
            &self.bounds
        }
        fn dim(&self) -> usize {
            self.bounds.dims
        }
    }
    struct IllGrad {
        a: Array1<f64>,
    }
    impl Gradient<f64> for IllGrad {
        fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
            Array1::from_iter(self.a.iter().zip(x.iter()).map(|(&ai, &xi)| 2.0 * ai * xi))
        }
        fn dim(&self) -> usize {
            self.a.len()
        }
    }

    #[test]
    fn gle_langevin_descends_ill_conditioned_quadratic() {
        // condition number 1000 (a_j from 0.05 to 50); the colored-noise
        // thermostat should drive every coordinate's curvature toward the
        // minimum so the objective falls well below the box-centre value.
        let dim = 8;
        let a = Array1::from_vec(vec![0.05, 0.2, 1.0, 5.0, 50.0, 0.5, 2.0, 10.0]);
        let bounds = Bounds::new(
            Array1::from_elem(dim, -5.0),
            Array1::from_elem(dim, 5.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a };
        let centre_val = obj.eval(Array1::<f64>::zeros(dim).view()); // 0 at the optimum
        let res = gle_langevin_sa(&obj, &grad, 0, 4000, 0.2, 0.2, 40, None);
        assert!(res.n_evals <= 4000);
        // optimum is 0; require the run to get close from the start basin
        assert!(
            res.best_val < 1e-2 + centre_val,
            "GLE-Langevin did not descend: best {}",
            res.best_val
        );
    }

    #[test]
    fn gle_langevin_starts_from_supplied_anchor() {
        let dim = 2;
        let a = Array1::from_vec(vec![1.0, 2.0]);
        let bounds = Bounds::new(
            Array1::from_elem(dim, -1.0),
            Array1::from_elem(dim, 1.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a };
        let x0 = Array1::from_vec(vec![0.25, -0.5]);

        let res = gle_langevin_sa(&obj, &grad, 11, 1, 0.2, 0.2, 1, Some(x0.clone()));

        assert_eq!(res.n_evals, 1);
        assert_eq!(res.best_pos, x0.to_vec());
    }

    #[test]
    fn gle_frequency_estimate_tracks_quadratic_curvature() {
        let dim = 2;
        let omega = 3.0;
        let curvature = omega * omega;
        let bounds = Bounds::new(
            Array1::from_elem(dim, -1.0),
            Array1::from_elem(dim, 1.0),
            0.0,
        );
        struct FrequencyQuadratic {
            bounds: Bounds<f64>,
            curvature: f64,
        }
        impl Objective<f64> for FrequencyQuadratic {
            fn eval(&self, x: ArrayView1<f64>) -> f64 {
                0.5 * self.curvature * x.iter().map(|xi| xi * xi).sum::<f64>()
            }
            fn bounds(&self) -> &Bounds<f64> {
                &self.bounds
            }
            fn dim(&self) -> usize {
                self.bounds.dims
            }
        }
        struct FrequencyGrad {
            curvature: f64,
            dim: usize,
        }
        impl Gradient<f64> for FrequencyGrad {
            fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
                Array1::from_iter(x.iter().map(|xi| self.curvature * xi))
            }
            fn dim(&self) -> usize {
                self.dim
            }
        }
        let obj = FrequencyQuadratic { bounds, curvature };
        let grad = FrequencyGrad { curvature, dim };

        let estimated = estimate_gle_omega0(&obj, &grad);

        assert!((estimated - omega).abs() <= omega * f64::EPSILON.cbrt());
    }

    #[test]
    fn gle_preconditioner_balances_diagonal_quadratic_curvatures() {
        let dim = 5;
        let a = Array1::from_vec(vec![0.05, 0.2, 1.0, 5.0, 50.0]);
        let bounds = Bounds::new(
            Array1::from_elem(dim, -4.0),
            Array1::from_elem(dim, 4.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a: a.clone() };

        let preconditioner = estimate_gle_preconditioner(&obj, &grad, 13, dim);
        let target_curvature = GLE_BAND_RATIO * preconditioner.omega0 * preconditioner.omega0;

        assert_eq!(preconditioner.diag.len(), dim);
        assert_eq!(preconditioner.scale.len(), dim);
        assert!(preconditioner.n_grads > 0);
        for (diag, curvature) in preconditioner.diag.iter().zip(a.iter().map(|ai| 2.0 * ai)) {
            assert!(
                (diag * curvature - target_curvature).abs() <= target_curvature * 1e-8,
                "diag {diag} did not balance curvature {curvature} toward {target_curvature}",
            );
        }
    }

    #[test]
    fn gle_preconditioner_probe_updates_every_diagonal_coordinate() {
        let dim = 64;
        let a = Array1::from_iter((0..dim).map(|axis| 0.5 + axis as f64));
        let bounds = Bounds::new(
            Array1::from_elem(dim, -4.0),
            Array1::from_elem(dim, 4.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a: a.clone() };

        let preconditioner = estimate_gle_preconditioner(&obj, &grad, 13, 1);
        let target_curvature = GLE_BAND_RATIO * preconditioner.omega0 * preconditioner.omega0;

        assert_eq!(preconditioner.n_grads, 2);
        for (diag, curvature) in preconditioner.diag.iter().zip(a.iter().map(|ai| 2.0 * ai)) {
            assert!(
                (diag * curvature - target_curvature).abs() <= target_curvature * 1e-8,
                "diag {diag} did not balance curvature {curvature} toward {target_curvature}",
            );
        }
    }

    #[test]
    fn preconditioned_gle_reports_matrix_and_probe_work() {
        let dim = 8;
        let a = Array1::from_vec(vec![0.05, 0.2, 1.0, 5.0, 50.0, 0.5, 2.0, 10.0]);
        let bounds = Bounds::new(
            Array1::from_elem(dim, -5.0),
            Array1::from_elem(dim, 5.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a };

        let res = gle_langevin_preconditioned_sa(&obj, &grad, 0, 300, 0.2, 20, None, None);

        assert_eq!(res.preconditioner_diag.len(), dim);
        assert!(res.n_preconditioner_grads > 0);
        assert!(res.n_evals <= 300);
        assert!(
            res.preconditioner_diag
                .iter()
                .all(|value| value.is_finite() && *value > 0.0)
        );
    }

    #[test]
    fn preconditioned_gle_caps_curvature_probe_work() {
        let dim = 64;
        let a = Array1::from_iter((0..dim).map(|axis| 1.0 + axis as f64));
        let bounds = Bounds::new(
            Array1::from_elem(dim, -5.0),
            Array1::from_elem(dim, 5.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a };

        let res = gle_langevin_preconditioned_sa(&obj, &grad, 0, 300, 0.2, 20, None, None);
        let expected_probe_cap = 2 * gle_preconditioner_probe_budget(300, dim, None);

        assert_eq!(res.preconditioner_diag.len(), dim);
        assert!(
            res.n_preconditioner_grads <= expected_probe_cap,
            "used {} gradient probes",
            res.n_preconditioner_grads,
        );
        assert!(res.n_evals <= 300);
    }

    #[test]
    fn preconditioned_gle_honors_configured_probe_count() {
        let dim = 8;
        let a = Array1::from_iter((0..dim).map(|axis| 1.0 + axis as f64));
        let bounds = Bounds::new(
            Array1::from_elem(dim, -5.0),
            Array1::from_elem(dim, 5.0),
            0.0,
        );
        let obj = IllConditioned {
            bounds,
            a: a.clone(),
        };
        let grad = IllGrad { a };

        let res = gle_langevin_preconditioned_sa(&obj, &grad, 0, 300, 0.2, 20, None, Some(dim));

        assert_eq!(res.n_preconditioner_grads, 2 * dim);
        assert_eq!(res.preconditioner_diag.len(), dim);
        assert!(res.n_evals <= 300);
    }

    #[test]
    fn gle_short_temperature_epochs_preserve_colored_memory() {
        use std::sync::Mutex;

        struct FlatTrace {
            bounds: Bounds<f64>,
            objective_points: Mutex<Vec<Array1<f64>>>,
            gradient_points: Mutex<Vec<Array1<f64>>>,
        }

        impl Objective<f64> for FlatTrace {
            fn eval(&self, x: ArrayView1<f64>) -> f64 {
                self.objective_points.lock().unwrap().push(x.to_owned());
                0.0
            }

            fn bounds(&self) -> &Bounds<f64> {
                &self.bounds
            }

            fn dim(&self) -> usize {
                self.bounds.dims
            }
        }

        impl Gradient<f64> for FlatTrace {
            fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
                self.gradient_points.lock().unwrap().push(x.to_owned());
                Array1::zeros(x.len())
            }

            fn dim(&self) -> usize {
                self.bounds.dims
            }
        }

        let dim = 2;
        let seed = 0x6c65;
        let omega0 = 0.2;
        let dt = 0.01;
        let hot_temperature = 1.0;
        let cold_temperature = 1e-3;
        let start = Array1::zeros(dim);
        let drift = optimal_sampling_drift(omega0);
        let hot = GleThermostat::canonical(&drift, dt, hot_temperature, 1.0);
        let covariance = Array2::<f64>::eye(drift.nrows()) * hot_temperature;
        let mut oracle_rng = StdRng::seed_from_u64(seed);
        let mut retained = hot.sample_stationary(&covariance, dim, 1.0, &mut oracle_rng);
        let first = &start + &(retained.row(0).to_owned() * dt);
        hot.step(&mut retained.view_mut(), &mut oracle_rng);
        retained *= (cold_temperature / hot_temperature).sqrt();
        let second = &first + &(retained.row(0).to_owned() * dt);
        let surface = FlatTrace {
            bounds: Bounds::new(
                Array1::from_elem(dim, -1e6),
                Array1::from_elem(dim, 1e6),
                0.0,
            ),
            objective_points: Mutex::new(Vec::new()),
            gradient_points: Mutex::new(Vec::new()),
        };

        let result = gle_langevin_sa(
            &surface,
            &surface,
            seed,
            3,
            omega0,
            0.2,
            2,
            Some(start.clone()),
        );

        let objectives = surface.objective_points.lock().unwrap();
        let gradients = surface.gradient_points.lock().unwrap();
        assert_eq!(result.n_evals, 3);
        assert_eq!(result.dt, dt);
        assert_eq!(objectives.len(), 3);
        assert_eq!(gradients.len(), 3);
        assert_eq!(*gradients, *objectives);
        assert_eq!(objectives[0], start);
        assert_eq!(objectives[1], first);
        assert_eq!(
            objectives[2], second,
            "temperature changes retain and rescale the thermostat-updated state"
        );
    }

    #[test]
    fn adaptive_gle_counts_frequency_probes_inside_the_gradient_budget() {
        use std::sync::atomic::{AtomicUsize, Ordering};

        struct CountedGradient {
            inner: IllGrad,
            calls: AtomicUsize,
        }

        impl Gradient<f64> for CountedGradient {
            fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
                self.calls.fetch_add(1, Ordering::Relaxed);
                self.inner.grad(x)
            }

            fn dim(&self) -> usize {
                self.inner.dim()
            }
        }

        let a = Array1::from_vec(vec![1.0, 3.0, 9.0]);
        let objective = IllConditioned {
            bounds: Bounds::new(Array1::from_elem(3, -5.0), Array1::from_elem(3, 5.0), 0.0),
            a: a.clone(),
        };
        let anchor = Array1::from_vec(vec![1.0, -0.5, 0.25]);
        let mut observations = Vec::new();
        for budget in [1, 4, 13] {
            let gradient = CountedGradient {
                inner: IllGrad { a: a.clone() },
                calls: AtomicUsize::new(0),
            };
            let result = gle_langevin_adaptive_sa(
                &objective,
                &gradient,
                17,
                budget,
                0.2,
                2,
                Some(anchor.clone()),
            );
            observations.push((
                budget,
                gradient.calls.load(Ordering::Relaxed),
                result.n_evals,
            ));
        }

        for (budget, actual_calls, reported_calls) in observations {
            assert!(
                actual_calls <= budget,
                "gradient budget {budget} permits no uncharged frequency probes: actual {actual_calls}"
            );
            assert_eq!(
                reported_calls, actual_calls,
                "gradient accounting must include frequency probes at budget {budget}"
            );
        }
    }

    struct FlatGleTrace {
        bounds: Bounds<f64>,
        gradient_value: f64,
        objective_points: std::sync::Mutex<Vec<Array1<f64>>>,
        gradient_points: std::sync::Mutex<Vec<Array1<f64>>>,
    }

    impl FlatGleTrace {
        fn new(dim: usize, gradient_value: f64) -> Self {
            Self {
                bounds: Bounds::new(
                    Array1::from_elem(dim, -1e6),
                    Array1::from_elem(dim, 1e6),
                    0.0,
                ),
                gradient_value,
                objective_points: std::sync::Mutex::new(Vec::new()),
                gradient_points: std::sync::Mutex::new(Vec::new()),
            }
        }
    }

    impl Objective<f64> for FlatGleTrace {
        fn eval(&self, x: ArrayView1<f64>) -> f64 {
            self.objective_points.lock().unwrap().push(x.to_owned());
            0.0
        }

        fn bounds(&self) -> &Bounds<f64> {
            &self.bounds
        }

        fn dim(&self) -> usize {
            self.bounds.dims
        }
    }

    impl Gradient<f64> for FlatGleTrace {
        fn grad(&self, x: ArrayView1<f64>) -> Array1<f64> {
            self.gradient_points.lock().unwrap().push(x.to_owned());
            Array1::from_elem(x.len(), self.gradient_value)
        }

        fn dim(&self) -> usize {
            self.bounds.dims
        }
    }

    #[test]
    fn preconditioner_fallback_counts_every_consumed_gradient_probe() {
        let mut probe_counts = Vec::new();
        for gradient_value in [0.0, f64::NAN] {
            let surface = FlatGleTrace::new(3, gradient_value);
            let preconditioner = estimate_gle_preconditioner(&surface, &surface, 19, 2);
            let actual = surface.gradient_points.lock().unwrap().len();
            assert_eq!(preconditioner.scale, Array1::from_elem(3, 1.0));
            assert_eq!(preconditioner.diag, Array1::from_elem(3, 1.0));
            probe_counts.push((gradient_value.is_nan(), actual, preconditioner.n_grads));
        }

        let surface = FlatGleTrace::new(3, 0.0);
        let result = gle_langevin_preconditioned_sa(
            &surface,
            &surface,
            19,
            5,
            0.2,
            2,
            Some(Array1::from_vec(vec![0.25, -0.5, 0.75])),
            Some(2),
        );
        let actual = surface.gradient_points.lock().unwrap().len();

        assert_eq!(
            probe_counts,
            vec![(false, 4, 4), (true, 4, 4)],
            "flat and rejected curvature probes remain charged when the metric falls back"
        );
        assert!(
            actual <= 5,
            "five gradient units cannot pay for {actual} calls"
        );
        assert_eq!(result.n_evals, actual);
        assert_eq!(result.n_preconditioner_grads, 4);
    }

    #[test]
    fn gle_temperature_changes_retain_auxiliary_rows() {
        let dim = 2;
        let seed = 0x617578;
        let dt = 0.01;
        let drift = optimal_sampling_drift(0.2);
        let hot = GleThermostat::canonical(&drift, dt, 1.0, 1.0);
        let cold = GleThermostat::canonical(&drift, dt, 1e-3, 1.0);
        let covariance = Array2::<f64>::eye(drift.nrows());
        let mut oracle_rng = StdRng::seed_from_u64(seed);
        let mut retained = hot.sample_stationary(&covariance, dim, 1.0, &mut oracle_rng);
        let mut position = Array1::<f64>::zeros(dim);
        let mut expected = vec![position.clone()];
        for _ in 0..2 {
            position = &position + &(retained.row(0).to_owned() * dt);
            expected.push(position.clone());
            hot.step(&mut retained.view_mut(), &mut oracle_rng);
        }

        let temperature_scale = 1e-3_f64.sqrt();
        let mut physical_only = Array2::<f64>::zeros(retained.raw_dim());
        physical_only
            .row_mut(0)
            .assign(&(retained.row(0).to_owned() * temperature_scale));
        let mut physical_only_rng = oracle_rng.clone();
        let mut physical_only_position = position.clone();
        retained *= temperature_scale;
        for step in 0..2 {
            position = &position + &(retained.row(0).to_owned() * dt);
            expected.push(position.clone());
            physical_only_position =
                &physical_only_position + &(physical_only.row(0).to_owned() * dt);
            if step == 0 {
                assert_eq!(physical_only_position, position);
            }
            cold.step(&mut retained.view_mut(), &mut oracle_rng);
            cold.step(&mut physical_only.view_mut(), &mut physical_only_rng);
        }
        assert_ne!(
            physical_only_position, position,
            "the trajectory distinguishes full auxiliary memory from physical momentum alone"
        );

        let surface = FlatGleTrace::new(dim, 0.0);
        let result = gle_langevin_sa(
            &surface,
            &surface,
            seed,
            5,
            0.2,
            0.2,
            2,
            Some(Array1::zeros(dim)),
        );
        let objectives = surface.objective_points.lock().unwrap();
        let gradients = surface.gradient_points.lock().unwrap();
        assert_eq!(result.n_evals, 5);
        assert_eq!(result.dt, dt);
        assert_eq!(objectives.len(), 5);
        assert_eq!(gradients.len(), 5);
        assert_eq!(*objectives, expected);
        assert_eq!(*gradients, expected);
    }
}
