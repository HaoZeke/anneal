//! Same-system scheduling and evidence for minimum-mode transition searches.
//!
//! A ledger belongs to one PES/system-signature coordinator. It never compares
//! energies, basin identifiers, local-environment classes, or outcomes across
//! systems. Replicas communicate by claiming concrete transition experiments
//! and reporting their charged cost and certified result. Failed and duplicate
//! searches remain evidence, preventing the ensemble from blindly repeating
//! work that another live chain has performed.

use std::collections::{BTreeMap, BTreeSet};

use ndarray::ArrayView2;

use crate::catalog::leftover_esty_upper;
use crate::pes_exploration::RideMethod;

/// Minimum stationary observations required for saddle-coverage retirement.
pub const SADDLE_COVERAGE_MINIMUM_OBSERVATIONS: u64 = 20;
/// Maximum one-sided unseen-saddle mass accepted as covered.
pub const SADDLE_COVERAGE_MAX_UNSEEN_MASS: f64 = 0.05;

/// One sign of a localized initial mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum RideDirection {
    /// Displace opposite to the generated mode.
    Negative,
    /// Displace along the generated mode.
    Positive,
}

/// One representative atom for a local-environment class.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct EnvironmentTarget {
    /// Coordinator-local environment class.
    pub class: u32,
    /// Representative atom in the source structure.
    pub atom: u32,
}

/// Leader-clustered invariant local environments for one system signature.
#[derive(Debug, Clone)]
pub struct EnvironmentBook {
    radius_squared: f64,
    feature_dim: Option<usize>,
    leaders: Vec<Vec<f64>>,
}

impl EnvironmentBook {
    /// Construct a codebook with a fixed within-system feature radius.
    pub fn new(radius: f64) -> Result<Self, RideLedgerError> {
        if !radius.is_finite() || radius <= 0.0 {
            return Err(RideLedgerError::InvalidEnvironmentRadius);
        }
        Ok(Self {
            radius_squared: radius * radius,
            feature_dim: None,
            leaders: Vec::new(),
        })
    }

    /// Assign every atom and return one representative for each present class.
    ///
    /// Rows must be rotation/permutation-invariant local features produced by
    /// the caller's descriptor contract. Classes are coordinator-local and
    /// therefore cannot identify or compare environments from another PES.
    pub fn observe(
        &mut self,
        features: ArrayView2<'_, f64>,
    ) -> Result<Vec<EnvironmentTarget>, RideLedgerError> {
        if features.nrows() == 0 || features.ncols() == 0 {
            return Err(RideLedgerError::EmptyEnvironmentFeatures);
        }
        if features.iter().any(|value| !value.is_finite()) {
            return Err(RideLedgerError::NonfiniteEnvironmentFeature);
        }
        match self.feature_dim {
            Some(expected) if expected != features.ncols() => {
                return Err(RideLedgerError::EnvironmentFeatureDimension {
                    expected,
                    actual: features.ncols(),
                });
            }
            None => self.feature_dim = Some(features.ncols()),
            Some(_) => {}
        }

        let mut representatives = BTreeMap::<u32, u32>::new();
        for (atom, row) in features.rows().into_iter().enumerate() {
            let nearest = self
                .leaders
                .iter()
                .enumerate()
                .map(|(class, leader)| {
                    let squared = row
                        .iter()
                        .zip(leader)
                        .map(|(left, right)| {
                            let delta = left - right;
                            delta * delta
                        })
                        .sum::<f64>();
                    (class, squared)
                })
                .filter(|(_, squared)| *squared <= self.radius_squared)
                .min_by(|left, right| {
                    left.1
                        .total_cmp(&right.1)
                        .then_with(|| left.0.cmp(&right.0))
                })
                .map(|(class, _)| class);
            let class = match nearest {
                Some(class) => class,
                None => {
                    self.leaders.push(row.to_vec());
                    self.leaders.len() - 1
                }
            };
            let class = u32::try_from(class).map_err(|_| RideLedgerError::CounterOverflow)?;
            let atom = u32::try_from(atom).map_err(|_| RideLedgerError::CounterOverflow)?;
            representatives.entry(class).or_insert(atom);
        }
        Ok(representatives
            .into_iter()
            .map(|(class, atom)| EnvironmentTarget { class, atom })
            .collect())
    }

    /// Number of invariant local-environment classes observed in this system.
    pub fn class_count(&self) -> usize {
        self.leaders.len()
    }

    /// Invariant feature vector represented by one coordinator-local class.
    pub fn feature(&self, class: u32) -> Option<&[f64]> {
        self.leaders
            .get(usize::try_from(class).ok()?)
            .map(Vec::as_slice)
    }
}

/// A quenched minimum eligible for transition exploration.
#[derive(Debug, Clone, PartialEq)]
pub struct RideSource {
    /// Exact basin identifier within one system catalogue.
    pub basin: u64,
    /// PES energy used only to order sources within this system.
    pub energy: f64,
    /// Distinct local environments and representative atoms.
    pub environments: Vec<EnvironmentTarget>,
}

/// Finite initial portfolio crossed with every source environment and sign.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RidePortfolio {
    mode_ranks: u16,
    methods: Vec<RideMethod>,
}

impl RidePortfolio {
    /// Construct a portfolio with mode ranks `0..mode_ranks`.
    pub fn new(mode_ranks: u16, mut methods: Vec<RideMethod>) -> Result<Self, RideLedgerError> {
        if mode_ranks == 0 {
            return Err(RideLedgerError::EmptyModePortfolio);
        }
        methods.sort_unstable();
        methods.dedup();
        if methods.is_empty() {
            return Err(RideLedgerError::EmptyMethodPortfolio);
        }
        Ok(Self {
            mode_ranks,
            methods,
        })
    }

    /// Number of initial mode ranks explored for each environment and method.
    pub fn mode_ranks(&self) -> u16 {
        self.mode_ranks
    }

    /// Minimum-mode solvers in deterministic scheduling order.
    pub fn methods(&self) -> &[RideMethod] {
        &self.methods
    }
}

/// Scientific identity of one transition-search arm.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct RideArm {
    /// Exact source minimum.
    pub source_basin: u64,
    /// Source-local environment class selected for perturbation.
    pub environment_class: u32,
    /// Ranked localized mode seed.
    pub mode_rank: u16,
    /// Sign of the initial displacement.
    pub direction: RideDirection,
    /// Minimum-mode solver.
    pub method: RideMethod,
}

/// One exclusive assignment to a live replica.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RideWorkOrder {
    /// Monotonic coordinator-local experiment identifier.
    pub id: u64,
    /// Replica holding the exclusive claim.
    pub replica: u32,
    /// Scientific arm being evaluated.
    pub arm: RideArm,
    /// Atom representing the arm's local-environment class.
    pub representative_atom: u32,
    /// One-based attempt number for this arm.
    pub attempt: u64,
    /// Caller-controlled deterministic random seed.
    pub seed: u64,
}

/// Explicit unsuccessful outcome shared with every replica.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum RideFailure {
    /// The source quench did not reach its force condition.
    QuenchNotConverged,
    /// Legacy aggregate for a saddle search that did not reach its force condition.
    SaddleNotConverged,
    /// Minimum-mode following exhausted its iteration allowance.
    MinimumModeNotConverged,
    /// Partitioned rational-function refinement exhausted its iteration allowance.
    PrfoNotConverged,
    /// Independent saddle certification rejected the final force norm.
    SaddleForceNotConverged,
    /// Expanding along the supplied mode did not leave positive curvature.
    ActivationNotEscaped,
    /// A force-converged minimum-mode ride no longer had negative curvature.
    MinimumModeLostCurvature,
    /// Receiving-side certification found no unstable mode.
    NoNegativeMode,
    /// Receiving-side certification found more than one unstable mode.
    HigherIndex,
    /// An IRC branch did not settle in a minimum.
    IrcNotConverged,
    /// Both IRC branches reached the same exact minimum.
    CollapsedConnection,
    /// The PES evaluator failed or returned invalid values.
    Surface,
    /// The charged-work budget ended during the experiment.
    BudgetExhausted,
    /// Both downhill branches miss the minimum from which the ride started.
    DisconnectedConnection,
}

/// Receiving-side result of a claimed experiment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RideOutcome {
    /// An index-one saddle with two exact, distinct IRC endpoints.
    Certified {
        /// Exact saddle identifier within the same system catalogue.
        saddle: u64,
        /// Exact minima connected by the saddle.
        endpoints: [u64; 2],
    },
    /// An index-one saddle whose descent did not expose a distinct edge.
    ///
    /// The saddle can be exported to the landscape database and sent to other
    /// replicas for deflation even though it contributes no graph edge.
    Unresolved {
        /// Exact saddle identifier within the same system catalogue.
        saddle: u64,
        /// Connectivity failure observed after saddle certification.
        failure: RideFailure,
    },
    /// Classified execution failure retained for diagnostics.
    Failed(RideFailure),
}

/// Credit assigned by the coordinator rather than trusted from a worker.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RideCredit {
    /// Whether receiving-side certification accepted a physical connection.
    pub certified_connection: bool,
    /// Whether both branches are distinct representatives of one exact basin.
    pub degenerate_rearrangement: bool,
    /// Typed negative evidence, absent for a certified connection.
    pub failure: Option<RideFailure>,
    /// Whether this report introduced a previously unseen exact saddle.
    pub novel_saddle: bool,
    /// Whether this report introduced a previously unseen endpoint pair.
    pub novel_edge: bool,
    /// Producer plus receiving-side PES evaluations charged for this report.
    pub total_charged_evaluations: u64,
}

/// Exact-saddle Good--Turing/Esty coverage evidence for one PES.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SaddleCoverage {
    /// Successful stationary-saddle observations, including reobservations.
    pub observations: u64,
    /// Exact saddles observed once.
    pub singletons: u64,
    /// Exact saddles observed twice.
    pub doubletons: u64,
    /// One-sided Esty upper bound on unseen saddle mass.
    pub unseen_mass_upper: Option<f64>,
    /// Whether the observation floor and unseen-mass condition both hold.
    pub saturated: bool,
}

/// Invalid source, claim, or report.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum RideLedgerError {
    /// At least one ranked mode is required.
    #[error("ride portfolio needs at least one mode rank")]
    EmptyModePortfolio,
    /// At least one minimum-mode solver is required.
    #[error("ride portfolio needs at least one method")]
    EmptyMethodPortfolio,
    /// Source energies must be finite.
    #[error("ride source energy must be finite")]
    NonfiniteSourceEnergy,
    /// A source needs at least one local target.
    #[error("ride source has no local-environment targets")]
    EmptyEnvironmentSet,
    /// Environment clustering needs a finite positive radius.
    #[error("local-environment radius must be finite and positive")]
    InvalidEnvironmentRadius,
    /// A local descriptor must contain at least one atom and one feature.
    #[error("local-environment feature matrix must be nonempty")]
    EmptyEnvironmentFeatures,
    /// All local descriptors in one codebook use one feature schema.
    #[error("local-environment feature dimension is {actual}, expected {expected}")]
    EnvironmentFeatureDimension {
        /// Dimension established by the first observation.
        expected: usize,
        /// Dimension supplied by this observation.
        actual: usize,
    },
    /// Local descriptor rows must contain only finite values.
    #[error("local-environment feature matrix contains a nonfinite value")]
    NonfiniteEnvironmentFeature,
    /// A work identifier is unknown to this ledger.
    #[error("unknown ride work order {0}")]
    UnknownWork(u64),
    /// Only the replica holding a claim may report it.
    #[error("replica {replica} does not own ride work order {work}")]
    WrongReplica {
        /// Reporting replica.
        replica: u32,
        /// Claimed work identifier.
        work: u64,
    },
    /// A repeated delivery must carry the same scientific result and cost.
    #[error("ride work order {0} was reported with conflicting content")]
    ConflictingReport(u64),
    /// A monotonic counter cannot be represented.
    #[error("ride-ledger counter overflow")]
    CounterOverflow,
}

#[derive(Debug, Clone)]
struct SourceRecord {
    energy: f64,
    representatives: BTreeMap<u32, u32>,
}

#[derive(Debug, Clone)]
struct CompletedReport {
    replica: u32,
    charged_evaluations: u64,
    outcome: RideOutcome,
    credit: RideCredit,
}

/// Append-only shared evidence and exclusive live claims for one PES.
#[derive(Debug, Clone)]
pub struct RideLedger {
    portfolio: RidePortfolio,
    sources: BTreeMap<u64, SourceRecord>,
    arm_completions: BTreeMap<RideArm, u64>,
    environment_completions: BTreeMap<(u64, u32), u64>,
    mode_completions: BTreeMap<(u64, u32, u16), u64>,
    active: BTreeMap<u64, RideWorkOrder>,
    active_arms: BTreeSet<RideArm>,
    replica_work: BTreeMap<u32, u64>,
    completed_reports: BTreeMap<u64, CompletedReport>,
    saddle_visits: BTreeMap<u64, u64>,
    degenerate_saddles: BTreeSet<u64>,
    edges: BTreeSet<[u64; 2]>,
    next_work: u64,
    completed_attempts: u64,
    certified_connections: u64,
    charged_evaluations: u64,
}

impl RideLedger {
    /// Create an empty ledger for one coordinator-owned system signature.
    pub fn new(portfolio: RidePortfolio) -> Self {
        Self {
            portfolio,
            sources: BTreeMap::new(),
            arm_completions: BTreeMap::new(),
            environment_completions: BTreeMap::new(),
            mode_completions: BTreeMap::new(),
            active: BTreeMap::new(),
            active_arms: BTreeSet::new(),
            replica_work: BTreeMap::new(),
            completed_reports: BTreeMap::new(),
            saddle_visits: BTreeMap::new(),
            degenerate_saddles: BTreeSet::new(),
            edges: BTreeSet::new(),
            next_work: 0,
            completed_attempts: 0,
            certified_connections: 0,
            charged_evaluations: 0,
        }
    }

    /// Add one exact source minimum or refresh its energy.
    ///
    /// The first complete local-environment observation fixes the source's
    /// portfolio. Re-observing the same exact basin may refine its energy and
    /// representative atom for an existing class, but cannot append classes
    /// produced by numerical drift around the same minimum.
    pub fn register_source(&mut self, source: RideSource) -> Result<(), RideLedgerError> {
        if !source.energy.is_finite() {
            return Err(RideLedgerError::NonfiniteSourceEnergy);
        }
        if source.environments.is_empty() {
            return Err(RideLedgerError::EmptyEnvironmentSet);
        }
        if let Some(record) = self.sources.get_mut(&source.basin) {
            record.energy = record.energy.min(source.energy);
            for target in source.environments {
                if let Some(atom) = record.representatives.get_mut(&target.class) {
                    *atom = (*atom).min(target.atom);
                }
            }
            return Ok(());
        }
        let mut representatives = BTreeMap::<u32, u32>::new();
        for target in source.environments {
            representatives
                .entry(target.class)
                .and_modify(|atom| *atom = (*atom).min(target.atom))
                .or_insert(target.atom);
        }
        self.sources.insert(
            source.basin,
            SourceRecord {
                energy: source.energy,
                representatives,
            },
        );
        Ok(())
    }

    /// Claim an experiment using only balanced action-space tie breaking.
    ///
    /// The coordinator uses [`Self::claim_ranked`] for scientific selection.
    /// This convenience path assigns least-exposed environment, mode, and exact
    /// arms without interpreting saddle or edge outcomes as rewards.
    pub fn claim(&mut self, replica: u32, seed: u64) -> Option<RideWorkOrder> {
        self.claim_ranked(replica, seed, &BTreeMap::new())
    }

    /// Claim one exact action chosen by an external joint-batch allocator.
    ///
    /// An active arm remains exclusive, while retrying from the replica that
    /// already holds work returns its existing order unchanged.
    pub fn claim_arm(
        &mut self,
        replica: u32,
        seed: u64,
        selected: &RideArm,
    ) -> Option<RideWorkOrder> {
        if let Some(id) = self.replica_work.get(&replica) {
            return self.active.get(id).cloned();
        }
        let (arm, representative_atom) = self
            .arms()
            .find(|(arm, _)| arm == selected && !self.active_arms.contains(arm))?;
        self.issue_claim(replica, seed, arm, representative_atom)
    }

    /// Claim the unheld action with the largest minimum-information score.
    ///
    /// Scores are supplied by a terminal-energy model outside the network
    /// ledger. Exposure counts break exact score ties so concurrent chains do
    /// not repeat one action. Saddle identity, edge novelty, and connectivity
    /// never enter the ordering.
    pub fn claim_ranked(
        &mut self,
        replica: u32,
        seed: u64,
        scores: &BTreeMap<RideArm, f64>,
    ) -> Option<RideWorkOrder> {
        if let Some(id) = self.replica_work.get(&replica) {
            return self.active.get(id).cloned();
        }

        let selected = self
            .arms()
            .filter(|(arm, _)| !self.active_arms.contains(arm))
            .max_by(|(left, left_atom), (right, right_atom)| {
                scores
                    .get(left)
                    .copied()
                    .unwrap_or(0.0)
                    .total_cmp(&scores.get(right).copied().unwrap_or(0.0))
                    .then_with(|| {
                        self.environment_attempts(right)
                            .cmp(&self.environment_attempts(left))
                    })
                    .then_with(|| self.mode_attempts(right).cmp(&self.mode_attempts(left)))
                    .then_with(|| self.arm_attempts(right).cmp(&self.arm_attempts(left)))
                    .then_with(|| {
                        self.source_energy(right.source_basin)
                            .total_cmp(&self.source_energy(left.source_basin))
                    })
                    .then_with(|| right.cmp(left))
                    .then_with(|| right_atom.cmp(left_atom))
            })?;
        self.issue_claim(replica, seed, selected.0, selected.1)
    }

    fn issue_claim(
        &mut self,
        replica: u32,
        seed: u64,
        arm: RideArm,
        representative_atom: u32,
    ) -> Option<RideWorkOrder> {
        let attempt = self
            .arm_completions
            .get(&arm)
            .map_or(1, |completed| completed.saturating_add(1));
        let id = self.next_work;
        self.next_work = self.next_work.checked_add(1)?;
        let order = RideWorkOrder {
            id,
            replica,
            arm: arm.clone(),
            representative_atom,
            attempt,
            seed,
        };
        self.active_arms.insert(arm);
        self.replica_work.insert(replica, id);
        self.active.insert(id, order.clone());
        Some(order)
    }

    /// Report charged cost and a certified or classified result.
    ///
    /// Repeated delivery of the same completed report is idempotent. Novelty
    /// is computed from the canonical endpoint pair held by the coordinator.
    pub fn report(
        &mut self,
        replica: u32,
        work: u64,
        charged_evaluations: u64,
        outcome: RideOutcome,
    ) -> Result<RideCredit, RideLedgerError> {
        if let Some(completed) = self.completed_reports.get(&work) {
            if completed.replica != replica {
                return Err(RideLedgerError::WrongReplica { replica, work });
            }
            return if completed.charged_evaluations == charged_evaluations
                && completed.outcome == outcome
            {
                Ok(completed.credit)
            } else {
                Err(RideLedgerError::ConflictingReport(work))
            };
        }
        let order = self
            .active
            .get(&work)
            .ok_or(RideLedgerError::UnknownWork(work))?;
        if order.replica != replica {
            return Err(RideLedgerError::WrongReplica { replica, work });
        }

        let (failure, saddle) = match &outcome {
            RideOutcome::Certified { saddle, .. } => (None, Some(*saddle)),
            RideOutcome::Unresolved {
                saddle, failure, ..
            } => (Some(*failure), Some(*saddle)),
            RideOutcome::Failed(failure) => (Some(*failure), None),
        };
        let certified_connection = failure.is_none();
        let degenerate_rearrangement = matches!(
            &outcome,
            RideOutcome::Certified { endpoints, .. } if endpoints[0] == endpoints[1]
        );
        let canonical_edge = match &outcome {
            RideOutcome::Certified { endpoints, .. } if endpoints[0] != endpoints[1] => {
                Some(if endpoints[0] < endpoints[1] {
                    *endpoints
                } else {
                    [endpoints[1], endpoints[0]]
                })
            }
            RideOutcome::Certified { .. }
            | RideOutcome::Unresolved { .. }
            | RideOutcome::Failed(_) => None,
        };

        let order = self
            .active
            .remove(&work)
            .expect("validated work remains active");
        self.active_arms.remove(&order.arm);
        self.replica_work.remove(&replica);

        let novel_saddle = if let Some(saddle) = saddle {
            let visits = self.saddle_visits.entry(saddle).or_default();
            let novel = *visits == 0;
            *visits = visits
                .checked_add(1)
                .ok_or(RideLedgerError::CounterOverflow)?;
            novel
        } else {
            false
        };
        if degenerate_rearrangement && let Some(saddle) = saddle {
            self.degenerate_saddles.insert(saddle);
        }
        let novel_edge = canonical_edge.is_some_and(|edge| self.edges.insert(edge));
        increment_count(&mut self.arm_completions, order.arm.clone())?;
        increment_count(
            &mut self.mode_completions,
            (
                order.arm.source_basin,
                order.arm.environment_class,
                order.arm.mode_rank,
            ),
        )?;
        increment_count(
            &mut self.environment_completions,
            (order.arm.source_basin, order.arm.environment_class),
        )?;
        if certified_connection {
            self.certified_connections = self
                .certified_connections
                .checked_add(1)
                .ok_or(RideLedgerError::CounterOverflow)?;
        }
        self.completed_attempts = self
            .completed_attempts
            .checked_add(1)
            .ok_or(RideLedgerError::CounterOverflow)?;
        self.charged_evaluations = self
            .charged_evaluations
            .checked_add(charged_evaluations)
            .ok_or(RideLedgerError::CounterOverflow)?;
        let credit = RideCredit {
            certified_connection,
            degenerate_rearrangement,
            failure,
            novel_saddle,
            novel_edge,
            total_charged_evaluations: charged_evaluations,
        };
        self.completed_reports.insert(
            work,
            CompletedReport {
                replica,
                charged_evaluations,
                outcome,
                credit,
            },
        );
        Ok(credit)
    }

    /// Release a replica's unfinished claim without fabricating an outcome.
    pub fn release(&mut self, replica: u32) -> Option<RideWorkOrder> {
        let id = self.replica_work.remove(&replica)?;
        let order = self.active.remove(&id)?;
        self.active_arms.remove(&order.arm);
        Some(order)
    }

    /// Number of completed transition experiments.
    pub fn completed_attempts(&self) -> u64 {
        self.completed_attempts
    }

    /// Number of reports containing a certified index-one connection.
    pub fn certified_connections(&self) -> u64 {
        self.certified_connections
    }

    /// Number of unique exact endpoint pairs.
    pub fn unique_edges(&self) -> usize {
        self.edges.len()
    }

    /// Number of exact saddles returning to a symmetry-equivalent basin.
    pub fn unique_degenerate_rearrangements(&self) -> usize {
        self.degenerate_saddles.len()
    }

    /// Number of unique exact index-one saddles.
    pub fn unique_saddles(&self) -> usize {
        self.saddle_visits.len()
    }

    /// Good--Turing/Esty evidence from exact saddle reobservations.
    pub fn saddle_coverage(&self) -> SaddleCoverage {
        let observations = self.saddle_visits.values().copied().sum::<u64>();
        let singletons = self
            .saddle_visits
            .values()
            .filter(|visits| **visits == 1)
            .count() as u64;
        let doubletons = self
            .saddle_visits
            .values()
            .filter(|visits| **visits == 2)
            .count() as u64;
        let unseen_mass_upper = leftover_esty_upper(observations, singletons, doubletons);
        SaddleCoverage {
            observations,
            singletons,
            doubletons,
            unseen_mass_upper,
            saturated: observations >= SADDLE_COVERAGE_MINIMUM_OBSERVATIONS
                && unseen_mass_upper.is_some_and(|upper| upper < SADDLE_COVERAGE_MAX_UNSEEN_MASS),
        }
    }

    /// Whether at least one portfolio arm is not held by a live replica.
    pub fn has_claimable_work(&self) -> bool {
        self.arms().any(|(arm, _)| !self.active_arms.contains(&arm))
    }

    /// Unheld action portfolio with each representative atom.
    pub fn claimable_arms(&self) -> Vec<(RideArm, u32)> {
        self.arms()
            .filter(|(arm, _)| !self.active_arms.contains(arm))
            .collect()
    }

    /// At most `limit` claimable arms, least attempted first and, among
    /// equally attempted arms, from the deepest source. The arm count is
    /// sources times environment classes times modes times directions
    /// times methods, thousands on a live LJ75 book; a plan that scores
    /// every one builds a joint posterior quadratic in that count.
    pub fn claimable_arms_ranked(&self, limit: usize) -> Vec<(RideArm, u32)> {
        let mut arms = self.claimable_arms();
        arms.sort_by(|(left, left_atom), (right, right_atom)| {
            self.arm_attempts(left)
                .cmp(&self.arm_attempts(right))
                .then_with(|| {
                    self.environment_attempts(left)
                        .cmp(&self.environment_attempts(right))
                })
                .then_with(|| {
                    self.source_energy(left.source_basin)
                        .total_cmp(&self.source_energy(right.source_basin))
                })
                .then_with(|| left.cmp(right))
                .then_with(|| left_atom.cmp(right_atom))
        });
        arms.truncate(limit);
        arms
    }

    /// PES evaluations charged to completed experiments.
    pub fn charged_evaluations(&self) -> u64 {
        self.charged_evaluations
    }

    /// Number of exclusive claims held by live replicas.
    pub fn active_attempts(&self) -> usize {
        self.active.len()
    }

    /// Active order identified by its coordinator-issued work id.
    pub fn active_order(&self, work: u64) -> Option<&RideWorkOrder> {
        self.active.get(&work)
    }

    fn source_energy(&self, basin: u64) -> f64 {
        self.sources
            .get(&basin)
            .map_or(f64::INFINITY, |source| source.energy)
    }

    fn environment_attempts(&self, arm: &RideArm) -> u64 {
        let key = (arm.source_basin, arm.environment_class);
        self.environment_completions
            .get(&key)
            .copied()
            .unwrap_or(0)
            .saturating_add(
                self.active_arms
                    .iter()
                    .filter(|active| {
                        active.source_basin == arm.source_basin
                            && active.environment_class == arm.environment_class
                    })
                    .count() as u64,
            )
    }

    fn arm_attempts(&self, arm: &RideArm) -> u64 {
        self.arm_completions
            .get(arm)
            .copied()
            .unwrap_or(0)
            .saturating_add(u64::from(self.active_arms.contains(arm)))
    }

    fn mode_attempts(&self, arm: &RideArm) -> u64 {
        let key = (arm.source_basin, arm.environment_class, arm.mode_rank);
        self.mode_completions
            .get(&key)
            .copied()
            .unwrap_or(0)
            .saturating_add(
                self.active_arms
                    .iter()
                    .filter(|active| {
                        active.source_basin == arm.source_basin
                            && active.environment_class == arm.environment_class
                            && active.mode_rank == arm.mode_rank
                    })
                    .count() as u64,
            )
    }

    fn arms(&self) -> impl Iterator<Item = (RideArm, u32)> + '_ {
        self.sources
            .iter()
            .flat_map(move |(&source_basin, source)| {
                source
                    .representatives
                    .iter()
                    .flat_map(move |(&environment_class, &atom)| {
                        (0..self.portfolio.mode_ranks).flat_map(move |mode_rank| {
                            [RideDirection::Negative, RideDirection::Positive]
                                .into_iter()
                                .flat_map(move |direction| {
                                    self.portfolio.methods.iter().copied().map(move |method| {
                                        (
                                            RideArm {
                                                source_basin,
                                                environment_class,
                                                mode_rank,
                                                direction,
                                                method,
                                            },
                                            atom,
                                        )
                                    })
                                })
                        })
                    })
            })
    }
}

fn increment_count<K: Ord>(counts: &mut BTreeMap<K, u64>, key: K) -> Result<(), RideLedgerError> {
    let count = counts.entry(key).or_default();
    *count = count
        .checked_add(1)
        .ok_or(RideLedgerError::CounterOverflow)?;
    Ok(())
}
