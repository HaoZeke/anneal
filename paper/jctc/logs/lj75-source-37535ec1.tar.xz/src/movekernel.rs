//! The move-kernel trait of the IISE manuscript: `Move : S x R_>0 -> Delta(S)`.

use eindir_core::Bounds;
use ndarray::{Array1, ArrayView1};
use num_traits::Float;
use rand::Rng;
use rand_distr::{Cauchy as CauchyDist, Distribution, Normal as NormalDist};

use crate::neigh::{BoxConstrained, ContinuousR_n, Neighborhood};

/// A temperature-indexed proposal kernel.
///
/// IISE manuscript law L2 requires `supp(Move(i, T)) subseteq Neigh(i)`.
/// Implementors override `supports_in` to advertise this constraint for the
/// sampled-validation constructor. The conservative default is `false`.
pub trait MoveKernel<T: Float>: Send + Sync {
    /// Draws a proposal point from the kernel at temperature `t`.
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<T>, t: T, rng: &mut R) -> Array1<T>;

    /// For a kernel that proposes `i + d` with a step `d` drawn independently of
    /// `i`, draws `d` for a point of `dim` coordinates exactly as `propose`
    /// would, so that [`Reflected`] can mirror a sum `i + d` that overflows.
    /// `None`, the default, for any other kernel.
    fn displacement<R: Rng + ?Sized>(&self, _dim: usize, _t: T, _rng: &mut R) -> Option<Array1<T>> {
        None
    }

    /// Witnesses L2: returns `true` iff `supp(propose) subseteq n` over the
    /// implementor's declared domain. Sampled validation also exercises the
    /// proposal behavior. Default `false`.
    fn supports_in<N: Neighborhood<T>>(&self, _n: &N) -> bool {
        false
    }
}

/// Isotropic Gaussian proposal: `j = i + sigma * z`, `z ~ N(0, I)`.
///
/// Component-wise standard normal scaled by `sigma`. Symmetric kernel.
#[derive(Clone, Debug)]
pub struct Gaussian {
    /// Per-component standard deviation.
    pub sigma: f64,
}

impl Gaussian {
    /// Constructs a Gaussian kernel. Asserts `sigma > 0`.
    pub fn new(sigma: f64) -> Self {
        assert!(sigma > 0.0, "sigma must be positive");
        Self { sigma }
    }

    fn step<R: Rng + ?Sized>(&self, dim: usize, rng: &mut R) -> Array1<f64> {
        let dist = NormalDist::new(0.0, self.sigma).expect("sigma > 0");
        Array1::from_iter((0..dim).map(|_| dist.sample(rng)))
    }
}

impl MoveKernel<f64> for Gaussian {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, _t: f64, rng: &mut R) -> Array1<f64> {
        self.step(i.len(), rng) + i
    }

    fn displacement<R: Rng + ?Sized>(
        &self,
        dim: usize,
        _t: f64,
        rng: &mut R,
    ) -> Option<Array1<f64>> {
        Some(self.step(dim, rng))
    }

    fn supports_in<N: Neighborhood<f64>>(&self, _n: &N) -> bool {
        // The sampled-validation path verifies proposals against the supplied
        // neighborhood. Certified construction uses CertifiedMoveFor instead.
        true
    }
}

/// Cauchy proposal: `j = i + gamma * c`, `c_k ~ Cauchy(0, 1)` component-wise.
/// Symmetric, heavy-tailed kernel (Szu-Hartley Fast SA). This is the `q_v = 2`
/// case of the generalized visiting sampler [`TsallisVisit`]: at `q_v = 2` the
/// Schuur transform `x / |y|^{(q_v-1)/(3-q_v)}` reduces to `x / |y|`, a standard
/// Cauchy drawn independently per coordinate.
#[derive(Clone, Debug)]
pub struct Cauchy {
    /// Per-component scale parameter.
    pub gamma: f64,
}

impl Cauchy {
    /// Constructs a Cauchy kernel. Asserts `gamma > 0`.
    pub fn new(gamma: f64) -> Self {
        assert!(gamma > 0.0, "gamma must be positive");
        Self { gamma }
    }

    fn step<R: Rng + ?Sized>(&self, dim: usize, rng: &mut R) -> Array1<f64> {
        let dist = CauchyDist::new(0.0, self.gamma).expect("gamma > 0");
        Array1::from_iter((0..dim).map(|_| dist.sample(rng)))
    }
}

impl MoveKernel<f64> for Cauchy {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, _t: f64, rng: &mut R) -> Array1<f64> {
        self.step(i.len(), rng) + i
    }

    fn displacement<R: Rng + ?Sized>(
        &self,
        dim: usize,
        _t: f64,
        rng: &mut R,
    ) -> Option<Array1<f64>> {
        Some(self.step(dim, rng))
    }

    fn supports_in<N: Neighborhood<f64>>(&self, _n: &N) -> bool {
        true
    }
}

/// `ln Gamma(x)` for real `x > 0`: the Lanczos approximation (g = 7, n = 9,
/// accurate to ~1e-13) summed in logarithms, so it stays finite where
/// `Gamma(x)` itself overflows (`x` beyond about 171). Near `q_v = 1` the
/// visiting scale needs `ln Gamma(1 / (q_v - 1) - 1/2)` for arguments in the
/// thousands.
fn ln_gamma(x: f64) -> f64 {
    const G: f64 = 7.0;
    const C: [f64; 9] = [
        0.999_999_999_999_809_9,
        676.520_368_121_885_1,
        -1_259.139_216_722_402_8,
        771.323_428_777_653_1,
        -176.615_029_162_140_6,
        12.507_343_278_686_905,
        -0.138_571_095_265_720_12,
        9.984_369_578_019_572e-6,
        1.505_632_735_149_311_6e-7,
    ];
    if x < 0.5 {
        let pi = std::f64::consts::PI;
        return pi.ln() - (pi * x).sin().abs().ln() - ln_gamma(1.0 - x);
    }
    let x = x - 1.0;
    let mut a = C[0];
    let t = x + G + 0.5;
    for (i, &c) in C.iter().enumerate().skip(1) {
        a += c / (x + i as f64);
    }
    0.5 * (2.0 * std::f64::consts::PI).ln() + (x + 0.5) * t.ln() - t + a.ln()
}

/// Generalized (Tsallis) simulated-annealing visiting kernel
/// (doi:10.1016/S0378-4371(96)00271-3), tail index `q_v in (1, 3)`.
///
/// Sampled by the Schuur/Xiang transform used by the de-facto-standard GenSA and
/// SciPy `dual_annealing` implementations: per coordinate, with `x_k, y_k ~
/// N(0, 1)` drawn independently,
/// ```text
///   dx_k = sigma(T, q_v) * x_k / |y_k|^{(q_v-1)/(3-q_v)},
/// ```
/// where the scale
/// `sigma = (factor4_p * T^{1/(q_v-1)} / Gamma(1/(q_v-1) - 1/2))^{(q_v-1)/(3-q_v)}`
/// and `factor4_p = sqrt(pi) (q_v-1)^{4-q_v} / (2^{(2-q_v)/(q_v-1)} (3-q_v))`.
/// Proposals are tail-clipped at `+/- TAIL_LIMIT` (1e8) to bound the heavy tail,
/// matching SciPy. The 1-D marginal is a `q`-Gaussian whose `T`-scaling is
/// `T^{1/(3-q_v)}`.
///
/// Special cases:
///   - `q_v == 2`: per-coordinate Cauchy (`x/|y|`), the Fast-SA limit.
///   - `q_v -> 1+`: light-tailed (Gaussian) limit.
///   - `q_v -> 3-`: very heavy tail.
#[derive(Clone, Debug)]
pub struct TsallisVisit {
    /// Tsallis visiting index. Practical range: `(1, 3)`.
    pub q_v: f64,
}

/// SciPy `dual_annealing` `TAIL_LIMIT`: visiting steps are clipped to this.
const VISIT_TAIL_LIMIT: f64 = 1.0e8;

/// Prepared Schuur/Xiang transform shared by native and array visiting kernels.
#[derive(Clone, Copy, Debug)]
pub struct TsallisVisitParameters {
    /// Multiplier of the numerator's standard-normal sample.
    pub scale: f64,
    /// Power of the absolute denominator standard-normal sample.
    pub exponent: f64,
    /// Magnitude beyond which a displacement is randomized within the tail cap.
    pub tail_limit: f64,
}

impl TsallisVisit {
    /// Constructs a Tsallis visit kernel. Asserts `1 < q_v < 3`.
    pub fn new(q_v: f64) -> Self {
        assert!(q_v > 1.0 && q_v < 3.0, "q_v must lie in (1, 3)");
        Self { q_v }
    }

    /// `ln sigma(T, q_v)` of the visiting scale. Near `q_v = 3` the scale
    /// itself underflows to zero while `|y|^{-exponent}` overflows, and their
    /// product is NaN; the step is formed from logarithms instead.
    fn log_sigma(&self, t: f64) -> f64 {
        let qv = self.q_v;
        // SciPy dual_annealing VisitingDistribution constants (qv-dependent).
        let ln_factor2 = (4.0 - qv) * (qv - 1.0).ln();
        let ln_factor3 = (2.0 - qv) / (qv - 1.0) * std::f64::consts::LN_2;
        let ln_factor4_p =
            0.5 * std::f64::consts::PI.ln() + ln_factor2 - ln_factor3 - (3.0 - qv).ln();
        // factor6 = pi (1-f5) / sin(pi(1-f5)) / Gamma(2-f5) = Gamma(f5) by Euler reflection.
        let factor5 = 1.0 / (qv - 1.0) - 0.5;
        let ln_factor6 = ln_gamma(factor5);
        let ln_factor1 = t.ln() / (qv - 1.0);
        let exponent = (qv - 1.0) / (3.0 - qv);
        exponent * (ln_factor4_p + ln_factor1 - ln_factor6)
    }

    /// Prepare the native visiting transform at the supplied temperature.
    pub fn parameters(&self, t: f64) -> TsallisVisitParameters {
        let exponent = (self.q_v - 1.0) / (3.0 - self.q_v);
        let ln_sigma = self.log_sigma(t);
        let scale = if ln_sigma.is_finite() {
            ln_sigma.exp()
        } else {
            0.0
        };
        TsallisVisitParameters {
            scale,
            exponent,
            tail_limit: VISIT_TAIL_LIMIT,
        }
    }
}

impl MoveKernel<f64> for TsallisVisit {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, t: f64, rng: &mut R) -> Array1<f64> {
        let parameters = self.parameters(t);
        let ln_sigma = self.log_sigma(t);
        let ln_tail = VISIT_TAIL_LIMIT.ln();
        let normal = NormalDist::new(0.0, 1.0).expect("std normal");
        Array1::from_iter(i.iter().map(|&xi| {
            let x: f64 = normal.sample(rng);
            let y: f64 = normal.sample(rng);
            // The prepared scale and exponent are the visiting step. The
            // logarithm is the same product when that form underflows.
            let direct = parameters.scale * x / y.abs().powf(parameters.exponent);
            let step = if parameters.scale.is_finite()
                && parameters.scale > 0.0
                && direct.is_finite()
                && direct.abs() <= parameters.tail_limit
            {
                direct
            } else {
                let ln_v = ln_sigma + x.abs().ln() - parameters.exponent * y.abs().ln();
                let magnitude = if ln_v.is_nan() || ln_v > ln_tail {
                    VISIT_TAIL_LIMIT * rng.random::<f64>()
                } else {
                    ln_v.exp()
                };
                magnitude.copysign(x)
            };
            xi + step
        }))
    }

    fn supports_in<N: Neighborhood<f64>>(&self, _n: &N) -> bool {
        true
    }
}

/// Folds a single coordinate into `[lo, hi]` by mirror reflection across the
/// two walls (a triangle wave of period `2 (hi - lo)`). Reflection is a
/// volume-preserving involution per wall, so wrapping a symmetric base kernel
/// in it keeps the proposal symmetric: `q(x -> y) = q(y -> x)`. The Metropolis
/// test therefore still targets the box-restricted Gibbs measure with no
/// Hastings correction (manuscript law L1 holds for the reflected proposal).
/// A finite box whose period overflows folds across the wall that was crossed.
/// An infinite wall folds as `+-f64::MAX`. An offset `x - lo` that overflows,
/// or an infinite `x`, is folded at quarter scale; a NaN goes to `lo`.
pub fn reflect_coord(x: f64, lo: f64, hi: f64) -> f64 {
    let w = hi - lo;
    if w.is_nan() || w <= 0.0 {
        return lo;
    }
    // A point already in the box is its own image. Folding it anyway can
    // round `lo + (x - lo)` past `hi` by an ulp.
    if (lo..=hi).contains(&x) {
        return x;
    }
    let period = 2.0 * w;
    let offset = x - lo;
    if period.is_finite() && offset.is_finite() {
        let mut y = offset.rem_euclid(period);
        if y > w {
            y = period - y;
        }
        // `hi - lo` and `lo + y` both round, so the sum can land one ulp past `hi`.
        return (lo + y).max(lo).min(hi);
    }
    // Both walls are finite and the offset is finite, so the period is the
    // part that overflowed. One fold across the crossed wall, then at most
    // one more across the other, stays exact.
    if lo.is_finite() && hi.is_finite() && offset.is_finite() {
        let fold = |d: f64| if d < w { d } else { w - (d - w) };
        return if x < lo {
            (lo + fold(lo - x)).max(lo).min(hi)
        } else {
            (hi - fold(x - hi)).min(hi).max(lo)
        };
    }
    reflect_quarter(0.25 * x, lo, hi)
}

/// [`reflect_coord`] of `4 x4`, which need not be representable, for a point
/// outside the box whose offset overflows or whose wall is infinite, folded
/// at quarter scale: differences of quarters of values within `+-f64::MAX`
/// are finite, and scaling by a power of two is exact above the subnormals.
/// The overshoot is measured from the crossed wall, so a small one stays
/// exact. An infinite wall folds as `+-f64::MAX`.
fn reflect_quarter(x4: f64, lo: f64, hi: f64) -> f64 {
    let (lo, hi) = (lo.max(f64::MIN), hi.min(f64::MAX));
    let (lo4, hi4) = (0.25 * lo, 0.25 * hi);
    let w = hi4 - lo4;
    let fold = |d: f64| {
        let r = d % (2.0 * w);
        if r < w { r } else { w - (r - w) }
    };
    // A subnormal point just past `hi` can round onto `hi4` and must still fold
    // from `hi`. An infinite overshoot folds to NaN, which clamping against the
    // crossed wall first sends to that wall.
    if x4 >= hi4 {
        (4.0 * (hi4 - fold(x4 - hi4))).min(hi).max(lo)
    } else {
        (4.0 * (lo4 + fold(lo4 - x4))).max(lo).min(hi)
    }
}

/// [`reflect_coord`] together with its slope there: `1` where the fold keeps
/// the direction (an even number of reflections), `-1` where it reverses it.
/// The chain rule for `x -> f(reflect(x))` multiplies `df` by this slope.
pub fn reflect_coord_with_slope(x: f64, lo: f64, hi: f64) -> (f64, f64) {
    let w = hi - lo;
    if w.is_nan() || w <= 0.0 {
        return (lo, 0.0);
    }
    if (lo..=hi).contains(&x) {
        return (x, 1.0);
    }
    let period = 2.0 * w;
    let offset = x - lo;
    if period.is_finite() && offset.is_finite() {
        let y = offset.rem_euclid(period);
        let slope = if y > w { -1.0 } else { 1.0 };
        return (reflect_coord(x, lo, hi), slope);
    }
    if lo.is_finite() && hi.is_finite() && offset.is_finite() {
        let d = if x < lo { lo - x } else { x - hi };
        let slope = if d < w { -1.0 } else { 1.0 };
        return (reflect_coord(x, lo, hi), slope);
    }
    let image = reflect_coord(x, lo, hi);
    let (lo_c, hi_c) = (lo.max(f64::MIN), hi.min(f64::MAX));
    let (lo4, hi4) = (0.25 * lo_c, 0.25 * hi_c);
    let w4 = hi4 - lo4;
    let x4 = 0.25 * x;
    let d = if x4 >= hi4 { x4 - hi4 } else { lo4 - x4 };
    let r = if w4 > 0.0 && d.is_finite() {
        d % (2.0 * w4)
    } else {
        f64::NAN
    };
    let slope = if !r.is_finite() || r < w4 { -1.0 } else { 1.0 };
    (image, slope)
}

/// Mirror-reflects every coordinate of `x` into `bounds` (see
/// [`reflect_coord`]). Use this in place of boundary clipping for a symmetric
/// random-walk proposal: clipping piles mass on the boundary and breaks the
/// `q(x -> y) = q(y -> x)` symmetry that the Metropolis test relies on, while
/// reflection keeps it.
pub fn reflect_into_box(x: ArrayView1<f64>, bounds: &Bounds<f64>) -> Array1<f64> {
    Array1::from_iter(
        x.iter()
            .enumerate()
            .map(|(k, &xk)| reflect_coord(xk, bounds.low[k], bounds.high[k])),
    )
}

/// Box-reflecting adapter: wraps an inner move kernel and mirror-reflects each
/// proposed coordinate back into the supplied box. Unlike clipping (which piles
/// probability mass on the boundary and breaks proposal symmetry), reflection
/// keeps the proposal symmetric, so `Reflected<M>` is safe to pair with
/// [`BoxConstrained`](crate::neigh::BoxConstrained) and satisfies L1/L2 without
/// a Hastings term whenever the inner kernel `M` is symmetric (`Gaussian`,
/// `Cauchy`, `TsallisVisit`). When `M` exposes its step `d` through
/// [`MoveKernel::displacement`], a sum `i + d` that overflows `f64` is mirrored
/// as the exact sum would be, and a coordinate whose step is itself infinite
/// stays put; neither depends on `i`, so the proposal stays symmetric.
#[derive(Clone, Debug)]
pub struct Reflected<M> {
    /// Inner symmetric move kernel.
    pub inner: M,
    /// Box the proposals are reflected into.
    pub bounds: Bounds<f64>,
}

impl<M> Reflected<M> {
    /// Wraps `inner` so every proposal is mirror-reflected into `bounds`.
    pub fn new(inner: M, bounds: Bounds<f64>) -> Self {
        Self { inner, bounds }
    }
}

impl<M: MoveKernel<f64>> MoveKernel<f64> for Reflected<M> {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, t: f64, rng: &mut R) -> Array1<f64> {
        let step = self.inner.displacement(i.len(), t, rng);
        let mut p = match &step {
            Some(d) => d + &i,
            None => self.inner.propose(i, t, rng),
        };
        for (k, pk) in p.iter_mut().enumerate() {
            let (lo, hi) = (self.bounds.low[k], self.bounds.high[k]);
            if let Some(d) = &step
                && !pk.is_finite()
                && i[k].is_finite()
            {
                *pk = if d[k].is_finite() {
                    reflect_quarter(0.25 * i[k] + 0.25 * d[k], lo, hi)
                } else {
                    i[k]
                };
            } else if !(lo..=hi).contains(pk) {
                // `reflect_coord` rebuilds an in-box value as `lo + (x - lo)`,
                // which rounds, so only coordinates outside the box are folded.
                *pk = reflect_coord(*pk, lo, hi);
            }
        }
        p
    }

    fn supports_in<N: Neighborhood<f64>>(&self, _n: &N) -> bool {
        // Reflected proposals stay inside `bounds`, so support is contained in
        // any neighborhood that the box is contained in -- in particular the
        // matching `BoxConstrained`.
        true
    }
}

/// Marker witness: `Gaussian`, `Cauchy`, and `TsallisVisit` all have
/// full-R^n support, so they are safe with `ContinuousR_n` but escape
/// `BoxConstrained` without clipping (use [`Reflected`] to fold them into a
/// box). These free functions let the
/// proptest sweep witness L2 structurally without redefining the trait.
pub fn supports_continuous(_dim: usize) -> bool {
    true
}

/// True iff the kernel is safe to use directly with the supplied
/// box-constrained neighborhood. Always `false` for the unbounded
/// kernels shipped here.
pub fn supports_box<T: Float>(_b: &BoxConstrained<T>) -> bool {
    false
}

/// True iff `ContinuousR_n` is the matching neighborhood. Used by the
/// proptest sweep as the structural witness for L2 on unconstrained kernels.
pub fn supports_r_n(_n: &ContinuousR_n) -> bool {
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use eindir_core::Bounds;
    use ndarray::array;
    use rand::SeedableRng;
    use rand::rngs::StdRng;

    #[test]
    fn reflect_coord_exact_unit_interval() {
        let f = |x| reflect_coord(x, 0.0, 1.0);
        assert!((f(0.3) - 0.3).abs() < 1e-12);
        assert!((f(1.2) - 0.8).abs() < 1e-12); // reflect across hi = 1
        assert!((f(-0.3) - 0.3).abs() < 1e-12); // reflect across lo = 0
        assert!((f(2.3) - 0.3).abs() < 1e-12); // full period back
        assert!((f(1.0) - 1.0).abs() < 1e-12); // boundary fixed
        assert!((f(0.0) - 0.0).abs() < 1e-12);
        assert!((f(2.0) - 0.0).abs() < 1e-12);
    }

    #[test]
    fn reflect_coord_shifted_box() {
        // lo = -5, hi = 5, width 10.
        assert!((reflect_coord(7.0, -5.0, 5.0) - 3.0).abs() < 1e-12);
        assert!((reflect_coord(-7.0, -5.0, 5.0) + 3.0).abs() < 1e-12);
        assert!((reflect_coord(0.0, -5.0, 5.0) - 0.0).abs() < 1e-12);
    }

    #[test]
    fn reflect_coord_stays_in_the_closed_box_under_rounding() {
        // `0.3 - (-1.0)` rounds up to 1.3, so the unguarded fold returned
        // `-1.0 + 1.3 = 0.30000000000000004` for a point on the upper wall.
        assert_eq!(reflect_coord(0.3, -1.0, 0.3), 0.3);
        for x in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let r = reflect_coord(x, -1.0, 0.3);
            assert!((-1.0..=0.3).contains(&r), "{x} folded to {r}");
        }
    }

    #[test]
    fn reflect_coord_mirrors_when_twice_the_width_overflows() {
        let near = |a: f64, b: f64| (a - b).abs() <= 1e-12 * b.abs();
        // Finite boxes wider than half the f64 range, then one whose width
        // itself overflows.
        assert!(near(reflect_coord(6.1e307, -6e307, 6e307), 5.9e307));
        assert!(near(reflect_coord(-6.1e307, -6e307, 6e307), -5.9e307));
        // More than the width past `hi`, so it also folds off `lo`.
        let (lo, hi) = (-f64::MAX, 1e308 - f64::MAX);
        assert!(near(reflect_coord(5e307, lo, hi), -1.5e308));
        assert!(near(reflect_coord(1.5e308, -1e308, 1e308), 0.5e308));
        assert!(near(reflect_coord(-1.5e308, -1e308, 1e308), -0.5e308));
        assert_eq!(reflect_coord(0.5e308, -1e308, 1e308), 0.5e308);
        // An infinite overshoot stops on the wall it crossed.
        assert_eq!(reflect_coord(f64::INFINITY, -1e308, 1e308), 1e308);
        assert_eq!(reflect_coord(f64::NEG_INFINITY, -6e307, 6e307), -6e307);
    }

    #[test]
    fn reflect_coord_mirrors_when_the_offset_from_lo_overflows() {
        let near = |a: f64, b: f64| (a - b).abs() <= 1e-12 * b.abs();
        let m = f64::MAX;
        // `x - lo` overflows although twice the width is finite.
        assert!(near(reflect_coord(8.5e307, -1e308, -9e307), -9.5e307));
        assert!(near(reflect_coord(-9.5e307, 9e307, 1e308), 9.5e307));
        assert!(near(reflect_coord(0.5 * m, -0.6 * m, -0.1 * m), -0.5 * m));
        // Twice the width overflows too.
        assert!(near(reflect_coord(m, -m, -0.45 * m), -0.8 * m));
        // The infinite wall of a half-infinite box mirrors as `+-f64::MAX`.
        assert!(near(
            reflect_coord(-0.25 * m, 0.5 * m, f64::INFINITY),
            0.75 * m
        ));
        assert!(near(
            reflect_coord(0.25 * m, f64::NEG_INFINITY, -0.5 * m),
            -0.75 * m
        ));
        // An infinite `x` stops on the wall it crossed, whatever the width.
        assert_eq!(reflect_coord(f64::INFINITY, 1e308, 1.7e308), 1.7e308);
        assert_eq!(reflect_coord(f64::INFINITY, -1.0, 0.3), 0.3);
        assert_eq!(reflect_coord(f64::NEG_INFINITY, -1.0, 0.3), -1.0);
        // A subnormal point just past `hi` stays by `hi` at quarter scale.
        let r = reflect_coord(f64::from_bits(2025), -m, f64::from_bits(2024));
        assert!(r >= f64::from_bits(2023), "{r:e}");
    }

    #[test]
    fn reflect_coord_mirrors_across_the_finite_wall_of_a_half_infinite_box() {
        let inf = f64::INFINITY;
        assert_eq!(reflect_coord(-0.5, 0.0, inf), 0.5);
        assert_eq!(reflect_coord(-3.0, 0.0, inf), 3.0);
        assert_eq!(reflect_coord(0.5, -inf, 0.0), -0.5);
        assert_eq!(reflect_coord(2.0, -inf, -1.0), -4.0);
        assert_eq!(reflect_coord(7.0, 0.0, inf), 7.0);
        assert_eq!(reflect_coord(-inf, 0.0, inf), 0.0);
        assert_eq!(reflect_coord(inf, -inf, 0.0), 0.0);
    }

    #[test]
    fn reflect_coord_is_involution_on_a_wall() {
        // Reflecting twice across a single wall returns the original value when
        // the point lands within one period of it.
        let lo = -2.0;
        let hi = 3.0;
        for &x in &[3.4_f64, 2.9, -1.5, 0.0, 4.99] {
            let r = reflect_coord(x, lo, hi);
            assert!(r >= lo - 1e-12 && r <= hi + 1e-12, "{r} not in box");
        }
    }

    #[test]
    fn reflect_coord_leaves_a_point_in_the_box_unchanged() {
        for &x in &[-3.0, -1.2345678901234567, 0.0, 0.7] {
            assert_eq!(reflect_coord(x, -3.0, 0.7).to_bits(), x.to_bits());
        }
        for &x in &[0.7000000000000001, 1.3, 4.4, -6.7, 12.1] {
            let r = reflect_coord(x, -3.0, 0.7);
            assert!((-3.0..=0.7).contains(&r), "{x} folded to {r}");
        }
    }

    #[test]
    fn reflect_slope_flips_on_odd_folds() {
        assert_eq!(reflect_coord_with_slope(0.5, 0.0, 1.0), (0.5, 1.0));
        let (y, s) = reflect_coord_with_slope(1.25, 0.0, 1.0);
        assert!((y - 0.75).abs() < 1e-12 && s == -1.0);
        let (y, s) = reflect_coord_with_slope(-0.25, 0.0, 1.0);
        assert!((y - 0.25).abs() < 1e-12 && s == -1.0);
        let (y, s) = reflect_coord_with_slope(2.25, 0.0, 1.0);
        assert!((y - 0.25).abs() < 1e-12 && s == 1.0);
    }

    #[test]
    fn ln_gamma_matches_gamma_and_survives_overflow() {
        // Reference values of ln Gamma(x) from libm's lgamma.
        let reference = [
            (0.1, 2.252712651734206),
            (0.5, 0.5723649429247001),
            (1.0, 0.0),
            (2.5, 0.2846828704729192),
            (7.0, 6.579251212010101),
            (30.0, 71.257038967168),
            (150.0, 600.0094705553274),
            (2000.0, 13198.923448054265),
        ];
        for (x, expected) in reference {
            let got = ln_gamma(x);
            assert!(
                (got - expected).abs() < 1e-10 * (1.0 + expected.abs()),
                "ln_gamma({x}) = {got}, expected {expected}"
            );
        }
    }

    #[test]
    fn tsallis_visit_moves_near_q_v_one() {
        // The light-tailed limit: steps are finite, nonzero, and not tail redraws.
        let mut rng = StdRng::seed_from_u64(13);
        let x = array![0.0, 0.0, 0.0];
        for q_v in [1.0001, 1.001, 1.005, 1.01] {
            let kernel = TsallisVisit::new(q_v);
            let mut moved = 0;
            for _ in 0..500 {
                let p = kernel.propose(x.view(), 1.0, &mut rng);
                assert!(
                    p.iter().all(|v| v.is_finite() && v.abs() < 1e3),
                    "q_v {q_v}: {p}"
                );
                moved += usize::from(p.iter().any(|v| *v != 0.0));
            }
            assert_eq!(moved, 500, "q_v {q_v}");
        }
    }

    #[test]
    fn tsallis_visit_is_finite_near_q_v_three() {
        let mut rng = StdRng::seed_from_u64(11);
        let x = array![0.0, 0.0, 0.0];
        for q_v in [2.9, 2.99, 2.999, 2.9999] {
            let kernel = TsallisVisit::new(q_v);
            for t in [1e-3, 1.0, 50.0] {
                for _ in 0..500 {
                    let p = kernel.propose(x.view(), t, &mut rng);
                    assert!(p.iter().all(|v| v.is_finite()), "q_v {q_v} t {t}: {p}");
                }
            }
        }
    }

    #[test]
    fn reflected_gaussian_stays_in_box() {
        let bounds = Bounds::new(array![-1.0, -1.0, -1.0], array![1.0, 1.0, 1.0], 1e-9);
        let kernel = Reflected::new(Gaussian::new(5.0), bounds.clone());
        let mut rng = StdRng::seed_from_u64(7);
        let x = array![0.0, 0.0, 0.0];
        for _ in 0..2000 {
            let p = kernel.propose(x.view(), 1.0, &mut rng);
            for k in 0..3 {
                assert!(
                    p[k] >= bounds.low[k] - 1e-9 && p[k] <= bounds.high[k] + 1e-9,
                    "reflected proposal escaped the box: {}",
                    p[k]
                );
            }
        }
    }

    /// Proposes `i + step` on every coordinate.
    struct Step(f64);

    impl MoveKernel<f64> for Step {
        fn propose<R: Rng + ?Sized>(
            &self,
            i: ArrayView1<f64>,
            _t: f64,
            _rng: &mut R,
        ) -> Array1<f64> {
            i.mapv(|x| x + self.0)
        }

        fn displacement<R: Rng + ?Sized>(
            &self,
            dim: usize,
            _t: f64,
            _rng: &mut R,
        ) -> Option<Array1<f64>> {
            Some(Array1::from_elem(dim, self.0))
        }
    }

    #[test]
    fn reflected_mirrors_a_sum_that_overflows() {
        let near = |a: f64, b: f64| (a - b).abs() <= 1e-12 * b.abs();
        let (m, inf) = (f64::MAX, f64::INFINITY);
        let mut rng = StdRng::seed_from_u64(1);
        let mut propose = |step: f64, x: f64, lo: f64, hi: f64| {
            let kernel = Reflected::new(Step(step), Bounds::new(array![lo], array![hi], 0.0));
            kernel.propose(array![x].view(), 1.0, &mut rng)[0]
        };
        assert!(near(propose(0.5 * m, 0.9 * m, 0.0, m), 0.6 * m));
        assert!(near(propose(-0.6 * m, -0.6 * m, -m, -0.5 * m), -0.8 * m));
        assert!(near(propose(0.5 * m, 0.9 * m, 0.5 * m, inf), 0.6 * m));
        // An infinite step has no mirror image, so the coordinate stays put.
        assert_eq!(propose(inf, 0.25, 0.0, 1.0), 0.25);
        assert_eq!(propose(-inf, 0.25, 0.0, 1.0), 0.25);
    }
}

// ---------------------------------------------------------------------------
// Cluster move kernels.
//
// A state here is a flattened `(n_points, 3)` point set. The kernels above
// perturb every coordinate independently, which explores within a packing and
// rarely leaves one: reaching a different morphology needs atoms to move in
// concert. These three change the packing instead of jiggling it, and are the
// moves the atomic cluster literature relies on for the sizes where a fixed
// displacement stalls.
// ---------------------------------------------------------------------------

/// Centre of mass of a flattened point set.
fn centroid(x: ArrayView1<f64>, n: usize) -> [f64; 3] {
    let mut c = [0.0; 3];
    for i in 0..n {
        for k in 0..3 {
            c[k] += x[3 * i + k];
        }
    }
    for v in c.iter_mut() {
        *v /= n as f64;
    }
    c
}

/// Rodrigues rotation of `v` about a unit `axis` by `angle`.
fn rotate(v: [f64; 3], axis: [f64; 3], angle: f64) -> [f64; 3] {
    let (s, c) = angle.sin_cos();
    let dot = v[0] * axis[0] + v[1] * axis[1] + v[2] * axis[2];
    let cross = [
        axis[1] * v[2] - axis[2] * v[1],
        axis[2] * v[0] - axis[0] * v[2],
        axis[0] * v[1] - axis[1] * v[0],
    ];
    [
        v[0] * c + cross[0] * s + axis[0] * dot * (1.0 - c),
        v[1] * c + cross[1] * s + axis[1] * dot * (1.0 - c),
        v[2] * c + cross[2] * s + axis[2] * dot * (1.0 - c),
    ]
}

fn random_unit<R: Rng + ?Sized>(rng: &mut R) -> [f64; 3] {
    let nd = NormalDist::new(0.0, 1.0).expect("unit normal");
    loop {
        let v = [nd.sample(rng), nd.sample(rng), nd.sample(rng)];
        let n = (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt();
        if n > 1e-12 {
            return [v[0] / n, v[1] / n, v[2] / n];
        }
    }
}

/// Moves the least-coordinated point onto the surface of the set.
///
/// A point in a poor site is what blocks a better packing, and relocating it
/// changes the structure rather than perturbing it. Coordination is counted
/// within `neighbour_cutoff`, which keeps the kernel independent of the
/// objective: no energy evaluation is spent choosing the point to move.
pub struct SurfaceRelocate {
    /// Points in the state; the state length must be `3 * n_points`.
    pub n_points: usize,
    /// Separation below which two points count as neighbours.
    pub neighbour_cutoff: f64,
}

impl MoveKernel<f64> for SurfaceRelocate {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, _t: f64, rng: &mut R) -> Array1<f64> {
        let n = self.n_points;
        let mut out = i.to_owned();
        if n < 2 {
            return out;
        }
        let mut coord = vec![0usize; n];
        for a in 0..n {
            for b in 0..n {
                if a == b {
                    continue;
                }
                let mut d2 = 0.0;
                for k in 0..3 {
                    let d = i[3 * a + k] - i[3 * b + k];
                    d2 += d * d;
                }
                if d2.sqrt() < self.neighbour_cutoff {
                    coord[a] += 1;
                }
            }
        }
        let worst = (0..n).min_by_key(|&a| coord[a]).unwrap_or(0);
        let c = centroid(i, n);
        let mut shell: f64 = 0.0;
        for a in 0..n {
            if a == worst {
                continue;
            }
            let mut d2 = 0.0;
            for k in 0..3 {
                let d = i[3 * a + k] - c[k];
                d2 += d * d;
            }
            shell = shell.max(d2.sqrt());
        }
        let dir = random_unit(rng);
        let r = shell * (0.85 + 0.20 * rng.random::<f64>());
        for k in 0..3 {
            out[3 * worst + k] = c[k] + dir[k] * r;
        }
        out
    }
}

/// Moves the least-coordinated point into the best hollow site the set
/// itself offers.
///
/// The dynamic lattice of Shao, Cheng and Cai: every triangle of mutually
/// neighbouring points defines an apex site at the neighbour distance from
/// all three, on the side facing away from the centroid. Sites that overlap
/// a point are discarded, the rest are scored by how many neighbours the
/// moved point would gain there, and the best site wins. Nothing is a
/// template: the lattice is read off the structure being moved, and no
/// energy is evaluated to choose the site.
///
/// Shao, X.; Cheng, L.; Cai, W. *J. Comput. Chem.* **2004**, *25*, 1693
/// <https://doi.org/10.1002/jcc.20096>.
pub struct HollowRelocate {
    /// Points in the state; the state length must be `3 * n_points`.
    pub n_points: usize,
    /// Separation below which two points count as neighbours.
    pub neighbour_cutoff: f64,
}

impl HollowRelocate {
    /// Candidate hollow sites of `i`, ignoring point `mover`, as positions
    /// with the coordination the mover would gain there.
    pub fn sites(&self, i: ArrayView1<f64>, mover: usize) -> Vec<([f64; 3], usize)> {
        let n = self.n_points;
        let cut2 = self.neighbour_cutoff * self.neighbour_cutoff;
        let pos = |a: usize| [i[3 * a], i[3 * a + 1], i[3 * a + 2]];
        let dist2 = |p: [f64; 3], q: [f64; 3]| {
            (p[0] - q[0]) * (p[0] - q[0])
                + (p[1] - q[1]) * (p[1] - q[1])
                + (p[2] - q[2]) * (p[2] - q[2])
        };
        let others: Vec<usize> = (0..n).filter(|&a| a != mover).collect();
        let mut nb: Vec<Vec<usize>> = vec![Vec::new(); n];
        let mut nearest = vec![f64::INFINITY; n];
        for (u, &a) in others.iter().enumerate() {
            for &b in &others[u + 1..] {
                let d2 = dist2(pos(a), pos(b));
                if d2 < cut2 {
                    nb[a].push(b);
                    nb[b].push(a);
                }
                nearest[a] = nearest[a].min(d2);
                nearest[b] = nearest[b].min(d2);
            }
        }
        // The bond length is the median nearest-neighbour distance, which a
        // stray far point cannot drag the way a mean can.
        let mut nn: Vec<f64> = others
            .iter()
            .map(|&a| nearest[a])
            .filter(|d2| d2.is_finite())
            .map(f64::sqrt)
            .collect();
        if nn.is_empty() {
            return Vec::new();
        }
        nn.sort_by(|a, b| a.total_cmp(b));
        let bond = nn[nn.len() / 2];
        let exclusion2 = (0.85 * bond) * (0.85 * bond);
        let c = centroid(i, n);
        let mut sites = Vec::new();
        for &a in &others {
            for &b in &nb[a] {
                if b <= a {
                    continue;
                }
                for &d in &nb[b] {
                    if d <= b || !nb[a].contains(&d) {
                        continue;
                    }
                    let (pa, pb, pd) = (pos(a), pos(b), pos(d));
                    let centre = [
                        (pa[0] + pb[0] + pd[0]) / 3.0,
                        (pa[1] + pb[1] + pd[1]) / 3.0,
                        (pa[2] + pb[2] + pd[2]) / 3.0,
                    ];
                    let u = [pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]];
                    let v = [pd[0] - pa[0], pd[1] - pa[1], pd[2] - pa[2]];
                    let normal = [
                        u[1] * v[2] - u[2] * v[1],
                        u[2] * v[0] - u[0] * v[2],
                        u[0] * v[1] - u[1] * v[0],
                    ];
                    let norm =
                        (normal[0] * normal[0] + normal[1] * normal[1] + normal[2] * normal[2])
                            .sqrt();
                    if norm < 1e-12 {
                        continue;
                    }
                    // Apex height from the circumradius of the triangle at
                    // the bond length; a triangle wider than a bond spans has
                    // no apex at that distance.
                    let radius2 = dist2(centre, pa);
                    let height2 = bond * bond - radius2;
                    if height2 <= 0.0 {
                        continue;
                    }
                    let height = height2.sqrt();
                    let outward = if (centre[0] - c[0]) * normal[0]
                        + (centre[1] - c[1]) * normal[1]
                        + (centre[2] - c[2]) * normal[2]
                        >= 0.0
                    {
                        1.0
                    } else {
                        -1.0
                    };
                    let site = [
                        centre[0] + outward * height * normal[0] / norm,
                        centre[1] + outward * height * normal[1] / norm,
                        centre[2] + outward * height * normal[2] / norm,
                    ];
                    let mut overlap = false;
                    let mut coordination = 0usize;
                    for &e in &others {
                        let d2 = dist2(site, pos(e));
                        if d2 < exclusion2 {
                            overlap = true;
                            break;
                        }
                        if d2 < cut2 {
                            coordination += 1;
                        }
                    }
                    if !overlap {
                        sites.push((site, coordination));
                    }
                }
            }
        }
        sites
    }
}

impl MoveKernel<f64> for HollowRelocate {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, t: f64, rng: &mut R) -> Array1<f64> {
        let n = self.n_points;
        if n < 4 {
            return SurfaceRelocate {
                n_points: n,
                neighbour_cutoff: self.neighbour_cutoff,
            }
            .propose(i, t, rng);
        }
        let mut coord = vec![0usize; n];
        let cut2 = self.neighbour_cutoff * self.neighbour_cutoff;
        for a in 0..n {
            for b in (a + 1)..n {
                let mut d2 = 0.0;
                for k in 0..3 {
                    let d = i[3 * a + k] - i[3 * b + k];
                    d2 += d * d;
                }
                if d2 < cut2 {
                    coord[a] += 1;
                    coord[b] += 1;
                }
            }
        }
        let worst = (0..n).min_by_key(|&a| coord[a]).unwrap_or(0);
        let sites = self.sites(i, worst);
        let Some(best) = sites.iter().map(|(_, c)| *c).max() else {
            return SurfaceRelocate {
                n_points: n,
                neighbour_cutoff: self.neighbour_cutoff,
            }
            .propose(i, t, rng);
        };
        let candidates: Vec<&([f64; 3], usize)> =
            sites.iter().filter(|(_, c)| *c == best).collect();
        let pick = candidates[rng.random_range(0..candidates.len())].0;
        let mut out = i.to_owned();
        for k in 0..3 {
            out[3 * worst + k] = pick[k];
        }
        out
    }
}

/// Greedy dynamic-lattice fill: repeated hollow-site relocations of the
/// loosest point until the surface stops improving, as one proposal.
///
/// This is the inner loop of dynamic lattice searching: the site list is
/// rebuilt from the structure after every relocation, the least-coordinated
/// point moves to the site that gains it the most neighbours, and the sweep
/// ends when the best site offers no more than the point already has, or
/// after `max_moves`. A single relaxation then pays for the whole sweep.
pub struct HollowFill {
    /// Points in the state; the state length must be `3 * n_points`.
    pub n_points: usize,
    /// Separation below which two points count as neighbours.
    pub neighbour_cutoff: f64,
    /// Relocations one sweep may compose.
    pub max_moves: usize,
}

impl MoveKernel<f64> for HollowFill {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, t: f64, rng: &mut R) -> Array1<f64> {
        let n = self.n_points;
        let single = HollowRelocate {
            n_points: n,
            neighbour_cutoff: self.neighbour_cutoff,
        };
        if n < 4 {
            return single.propose(i, t, rng);
        }
        let cut2 = self.neighbour_cutoff * self.neighbour_cutoff;
        let mut cur = i.to_owned();
        let mut moved_any = false;
        for _ in 0..self.max_moves.max(1) {
            let mut coord = vec![0usize; n];
            for a in 0..n {
                for b in (a + 1)..n {
                    let mut d2 = 0.0;
                    for k in 0..3 {
                        let d = cur[3 * a + k] - cur[3 * b + k];
                        d2 += d * d;
                    }
                    if d2 < cut2 {
                        coord[a] += 1;
                        coord[b] += 1;
                    }
                }
            }
            let worst = (0..n).min_by_key(|&a| coord[a]).unwrap_or(0);
            let sites = single.sites(cur.view(), worst);
            let Some(best) = sites.iter().map(|(_, c)| *c).max() else {
                break;
            };
            if best <= coord[worst] {
                break;
            }
            let candidates: Vec<&([f64; 3], usize)> =
                sites.iter().filter(|(_, c)| *c == best).collect();
            let pick = candidates[rng.random_range(0..candidates.len())].0;
            for k in 0..3 {
                cur[3 * worst + k] = pick[k];
            }
            moved_any = true;
        }
        if moved_any {
            cur
        } else {
            // Nothing to fill: the surface is already saturated, so hand the
            // hop to the plain relocation rather than proposing the same
            // structure back.
            single.propose(i, t, rng)
        }
    }
}

/// Rotates the outer half of the set against its core.
///
/// Packings that share a core differ in how the surface sits on it, so twisting
/// the shell probes that difference in one move.
pub struct ShellRotate {
    /// Points in the state.
    pub n_points: usize,
}

impl MoveKernel<f64> for ShellRotate {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, _t: f64, rng: &mut R) -> Array1<f64> {
        let n = self.n_points;
        let mut out = i.to_owned();
        if n < 2 {
            return out;
        }
        let c = centroid(i, n);
        let mut radii: Vec<f64> = (0..n)
            .map(|a| {
                let mut d2 = 0.0;
                for k in 0..3 {
                    let d = i[3 * a + k] - c[k];
                    d2 += d * d;
                }
                d2.sqrt()
            })
            .collect();
        let mut sorted = radii.clone();
        sorted.sort_by(|x, y| x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal));
        let median = sorted[n / 2];
        let axis = random_unit(rng);
        let angle = 0.3 + (std::f64::consts::PI - 0.3) * rng.random::<f64>();
        for a in 0..n {
            if radii[a] <= median {
                continue;
            }
            let v = [i[3 * a] - c[0], i[3 * a + 1] - c[1], i[3 * a + 2] - c[2]];
            let w = rotate(v, axis, angle);
            for k in 0..3 {
                out[3 * a + k] = c[k] + w[k];
            }
        }
        radii.clear();
        out
    }
}

/// Enforces an approximate `order`-fold rotation about a random axis.
///
/// The global minima of the hard cluster sizes are highly symmetric, and a
/// nearly symmetric structure is unreachable by independent displacement
/// because every point has to move together. Pairing each point with the
/// nearest image of the rotated set and pulling the two together moves them in
/// concert, which is what a symmetrisation move is for.
pub struct Symmetrise {
    /// Points in the state.
    pub n_points: usize,
    /// Rotation orders to draw from, for example `[2, 3, 4, 5, 6]`.
    pub orders: Vec<usize>,
    /// Largest separation at which a point and an image are considered partners.
    pub pair_cutoff: f64,
}

impl MoveKernel<f64> for Symmetrise {
    fn propose<R: Rng + ?Sized>(&self, i: ArrayView1<f64>, _t: f64, rng: &mut R) -> Array1<f64> {
        let n = self.n_points;
        let mut out = i.to_owned();
        if n < 2 || self.orders.is_empty() {
            return out;
        }
        let c = centroid(i, n);
        let axis = random_unit(rng);
        let order = self.orders[rng.random_range(0..self.orders.len())];
        let angle = 2.0 * std::f64::consts::PI / order.max(1) as f64;
        let blend = 0.3 + 0.4 * rng.random::<f64>();

        let rotated: Vec<[f64; 3]> = (0..n)
            .map(|a| {
                let v = [i[3 * a] - c[0], i[3 * a + 1] - c[1], i[3 * a + 2] - c[2]];
                rotate(v, axis, angle)
            })
            .collect();

        for a in 0..n {
            let v = [i[3 * a] - c[0], i[3 * a + 1] - c[1], i[3 * a + 2] - c[2]];
            let mut best = 0usize;
            let mut best_d = f64::INFINITY;
            for (b, w) in rotated.iter().enumerate() {
                let d =
                    ((v[0] - w[0]).powi(2) + (v[1] - w[1]).powi(2) + (v[2] - w[2]).powi(2)).sqrt();
                if d < best_d {
                    best_d = d;
                    best = b;
                }
            }
            if best_d < self.pair_cutoff {
                for k in 0..3 {
                    out[3 * a + k] = c[k] + (1.0 - blend) * v[k] + blend * rotated[best][k];
                }
            }
        }
        out
    }
}

#[cfg(test)]
mod cluster_move_tests {
    use super::*;
    use rand::SeedableRng;
    use rand::rngs::StdRng;

    /// Regular octahedron: symmetric, so symmetrisation should nearly fix it.
    fn octahedron() -> Array1<f64> {
        Array1::from(vec![
            1.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
            -1.0,
        ])
    }

    fn com(x: &Array1<f64>, n: usize) -> [f64; 3] {
        centroid(x.view(), n)
    }

    #[test]
    fn surface_relocate_moves_exactly_one_point() {
        let k = SurfaceRelocate {
            n_points: 6,
            neighbour_cutoff: 1.6,
        };
        let x = octahedron();
        let mut rng = StdRng::seed_from_u64(1);
        let y = k.propose(x.view(), 1.0, &mut rng);
        let moved = (0..6)
            .filter(|&a| (0..3).any(|c| (x[3 * a + c] - y[3 * a + c]).abs() > 1e-9))
            .count();
        assert_eq!(moved, 1, "relocation must touch a single point");
    }

    #[test]
    fn shell_rotate_preserves_centroid_and_radii() {
        let k = ShellRotate { n_points: 6 };
        let x = octahedron();
        let mut rng = StdRng::seed_from_u64(2);
        let y = k.propose(x.view(), 1.0, &mut rng);
        let cx = com(&x, 6);
        let cy = com(&y, 6);
        for c in 0..3 {
            assert!((cx[c] - cy[c]).abs() < 1e-9, "rotation must not translate");
        }
        // A rotation about the centroid preserves every distance to it.
        let mut rx: Vec<f64> = (0..6)
            .map(|a| {
                ((x[3 * a] - cx[0]).powi(2)
                    + (x[3 * a + 1] - cx[1]).powi(2)
                    + (x[3 * a + 2] - cx[2]).powi(2))
                .sqrt()
            })
            .collect();
        let mut ry: Vec<f64> = (0..6)
            .map(|a| {
                ((y[3 * a] - cy[0]).powi(2)
                    + (y[3 * a + 1] - cy[1]).powi(2)
                    + (y[3 * a + 2] - cy[2]).powi(2))
                .sqrt()
            })
            .collect();
        rx.sort_by(|a, b| a.partial_cmp(b).unwrap());
        ry.sort_by(|a, b| a.partial_cmp(b).unwrap());
        for (a, b) in rx.iter().zip(ry.iter()) {
            assert!((a - b).abs() < 1e-9, "radii multiset must be preserved");
        }
    }

    #[test]
    fn symmetrise_leaves_an_already_symmetric_set_near_itself() {
        let k = Symmetrise {
            n_points: 6,
            orders: vec![4],
            pair_cutoff: 2.5,
        };
        let x = octahedron();
        let mut rng = StdRng::seed_from_u64(3);
        let y = k.propose(x.view(), 1.0, &mut rng);
        // Fourfold axes of an octahedron map it onto itself, so the blend
        // toward a matched image cannot move any point far.
        let mut worst: f64 = 0.0;
        for a in 0..6 {
            let d = ((x[3 * a] - y[3 * a]).powi(2)
                + (x[3 * a + 1] - y[3 * a + 1]).powi(2)
                + (x[3 * a + 2] - y[3 * a + 2]).powi(2))
            .sqrt();
            worst = worst.max(d);
        }
        assert!(worst < 1.5, "symmetric input drifted by {worst}");
    }

    #[test]
    fn symmetrise_increases_symmetry_of_a_distorted_set() {
        // Distortion measure: how far the set is from its own image under the
        // rotation that symmetrisation enforces.
        let mut x = octahedron();
        x[0] += 0.35;
        x[4] -= 0.30;
        x[8] += 0.25;
        let k = Symmetrise {
            n_points: 6,
            orders: vec![4],
            pair_cutoff: 2.5,
        };
        let mut rng = StdRng::seed_from_u64(4);
        let mut improved = 0;
        for _ in 0..24 {
            let y = k.propose(x.view(), 1.0, &mut rng);
            if spread(&y) < spread(&x) {
                improved += 1;
            }
        }
        assert!(
            improved > 0,
            "symmetrisation never reduced the radial spread over 24 draws"
        );
    }

    /// Standard deviation of distances to the centroid: zero for a set whose
    /// points all lie on one shell, which every regular polytope satisfies.
    fn spread(x: &Array1<f64>) -> f64 {
        let n = 6;
        let c = centroid(x.view(), n);
        let r: Vec<f64> = (0..n)
            .map(|a| {
                ((x[3 * a] - c[0]).powi(2)
                    + (x[3 * a + 1] - c[1]).powi(2)
                    + (x[3 * a + 2] - c[2]).powi(2))
                .sqrt()
            })
            .collect();
        let m = r.iter().sum::<f64>() / n as f64;
        (r.iter().map(|v| (v - m).powi(2)).sum::<f64>() / n as f64).sqrt()
    }

    #[test]
    fn kernels_preserve_state_length() {
        let x = octahedron();
        let mut rng = StdRng::seed_from_u64(5);
        let kernels: Vec<Box<dyn Fn(&mut StdRng) -> Array1<f64>>> = vec![
            Box::new(|r| {
                SurfaceRelocate {
                    n_points: 6,
                    neighbour_cutoff: 1.6,
                }
                .propose(octahedron().view(), 1.0, r)
            }),
            Box::new(|r| ShellRotate { n_points: 6 }.propose(octahedron().view(), 1.0, r)),
            Box::new(|r| {
                Symmetrise {
                    n_points: 6,
                    orders: vec![3, 4],
                    pair_cutoff: 2.5,
                }
                .propose(octahedron().view(), 1.0, r)
            }),
        ];
        for k in kernels {
            assert_eq!(k(&mut rng).len(), x.len());
        }
    }

    #[test]
    fn a_loose_point_moves_into_the_best_hollow_site() {
        use rand::SeedableRng;
        // A tetrahedron of four mutual neighbours and a fifth point far away.
        let h = (2.0_f64 / 3.0).sqrt();
        let x = ndarray::Array1::from(vec![
            0.0,
            0.0,
            0.0,
            1.0,
            0.0,
            0.0,
            0.5,
            0.75_f64.sqrt(),
            0.0,
            0.5,
            0.75_f64.sqrt() / 3.0,
            h,
            6.0,
            6.0,
            6.0,
        ]);
        let kernel = HollowRelocate {
            n_points: 5,
            neighbour_cutoff: 1.3,
        };
        let sites = kernel.sites(x.view(), 4);
        assert!(!sites.is_empty(), "a tetrahedron offers hollow sites");
        assert!(
            sites.iter().all(|(_, c)| *c == 3),
            "every face site touches three points: {sites:?}"
        );
        let mut rng = rand::rngs::StdRng::seed_from_u64(3);
        let out = kernel.propose(x.view(), 1.0, &mut rng);
        let moved = [out[12], out[13], out[14]];
        let mut touching = 0;
        for a in 0..4 {
            let d = ((moved[0] - x[3 * a]).powi(2)
                + (moved[1] - x[3 * a + 1]).powi(2)
                + (moved[2] - x[3 * a + 2]).powi(2))
            .sqrt();
            assert!(d > 0.85, "the moved point overlaps point {a}: {d}");
            if d < 1.3 {
                touching += 1;
            }
        }
        assert_eq!(touching, 3);
        for a in 0..4 {
            for k in 0..3 {
                assert_eq!(out[3 * a + k], x[3 * a + k], "only the loose point moves");
            }
        }
    }

    #[test]
    fn the_fill_raises_the_loosest_point_until_the_surface_saturates() {
        use rand::SeedableRng;
        let h = (2.0_f64 / 3.0).sqrt();
        // A tetrahedron with two loose points far away.
        let x = ndarray::Array1::from(vec![
            0.0,
            0.0,
            0.0,
            1.0,
            0.0,
            0.0,
            0.5,
            0.75_f64.sqrt(),
            0.0,
            0.5,
            0.75_f64.sqrt() / 3.0,
            h,
            6.0,
            6.0,
            6.0,
            -6.0,
            -6.0,
            -6.0,
        ]);
        let kernel = HollowFill {
            n_points: 6,
            neighbour_cutoff: 1.3,
            max_moves: 4,
        };
        let mut rng = rand::rngs::StdRng::seed_from_u64(9);
        let out = kernel.propose(x.view(), 1.0, &mut rng);
        let coordination = |a: usize| {
            (0..6)
                .filter(|&b| b != a)
                .filter(|&b| {
                    ((out[3 * a] - out[3 * b]).powi(2)
                        + (out[3 * a + 1] - out[3 * b + 1]).powi(2)
                        + (out[3 * a + 2] - out[3 * b + 2]).powi(2))
                    .sqrt()
                        < 1.3
                })
                .count()
        };
        assert!(
            coordination(4) >= 3,
            "first loose point gained {}",
            coordination(4)
        );
        assert!(
            coordination(5) >= 3,
            "second loose point gained {}",
            coordination(5)
        );
    }
}
