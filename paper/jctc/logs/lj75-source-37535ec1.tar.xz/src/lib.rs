#![warn(missing_docs)]
// Fixed-axis tensor contractions are written with index notation so each loop
// follows the corresponding equation and preserves its bounds visibly.
#![allow(clippy::needless_range_loop)]
// Numerical kernels keep physical inputs explicit; packing them into transport
// structs would obscure the equations without reducing the required state.
#![allow(clippy::too_many_arguments)]
// Callback and evidence tuples encode coupled numerical contracts at their use
// sites, where aliases would hide rather than clarify their components.
#![allow(clippy::type_complexity)]
// Protocol enums keep payloads inline to avoid allocation in the cooperative
// search path; variant size is part of that performance choice.
#![allow(clippy::large_enum_variant)]
// Negated floating-point bounds intentionally classify NaN as invalid. Rewriting
// them as ordered comparisons silently admits NaN.
#![allow(clippy::neg_cmp_op_on_partial_ord)]
//! anneal-core: simulated-annealing components on the eindir typed primitives.
//!
//! This crate ships the typed component algebra (Cool / Neigh / Move / Accept
//! traits, Boltzmann / Fast / Tsallis points, and the SaVariant tuple)
//! consumed by the Python `anneal` package via pyo3.

/// Shared CSA bank over Cap'n Proto. Optional; process-local bank stays default.
#[cfg(feature = "bank-rpc")]
pub mod bank_rpc;
/// Generated Cap'n Proto schema for [`bank_rpc`].
#[cfg(feature = "bank-rpc")]
#[allow(missing_docs, dead_code, clippy::all, non_camel_case_types)]
#[rustfmt::skip]
#[allow(non_snake_case)]
pub mod Bank_capnp {
    include!("bank_rpc/Bank_capnp.rs");
}
/// Generated Cap'n Proto schema for [`raft`] consensus traffic.
#[cfg(feature = "bank-rpc")]
#[allow(missing_docs, dead_code, clippy::all, non_camel_case_types)]
#[rustfmt::skip]
#[allow(non_snake_case)]
pub mod Raft_capnp {
    include!("Raft_capnp.rs");
}
/// Generated Cap'n Proto schema for [`catalog_rpc`].
#[cfg(feature = "bank-rpc")]
#[allow(
    missing_docs,
    dead_code,
    unused_parens,
    clippy::all,
    non_camel_case_types
)]
#[rustfmt::skip]
#[allow(non_snake_case)]
pub mod Catalog_capnp {
    include!("catalog_rpc/Catalog_capnp.rs");
}

/// The acceptance-rule trait: `(delta_e, T) -> p`.
pub mod accept;
/// ACE ν=3 / λ-SOAP CG contraction of a spherical expansion.
pub mod ace;
/// Stan-style windowed adaptation: `trait Adapter<T, S>`.
pub mod adapter;
/// Cost-augmenting bias operators (well-tempered metadynamics, etc.).
/// Proposal allocation and the budget-window temperature law.
pub mod allocate;
/// Dense minimum-cost bipartite assignment.
pub mod assignment;
/// Same-PES atomistic basin and ridge exploration by joint-optimum information.
pub mod atomistic_hybrid;
pub mod bias;
/// Stock-preset searches for binary Lennard-Jones and rigid TIP4P.
pub mod binary_water;
/// Transport proposals from observed attraction-region crossings.
pub mod boundary_transport;
/// Spectral statistics of the curvature, without forming a Hessian.
pub mod calibrate;
/// Caller-owned stop flag bound for the thread that runs a search.
pub mod caller_stop;
/// Declarative campaign configuration: TOML in, channels explicit.
pub mod campaign;
/// Event catalogue keyed by local topology.
pub mod catalog;
/// Pure cooperative-catalog policy and target-free proposals.
pub mod catalog_policy;
/// Versioned cooperative catalog protocol.
#[cfg(feature = "bank-rpc")]
pub mod catalog_rpc;
/// nng pub/sub census bus between the replicas of one cooperative run.
#[cfg(feature = "bank-rpc")]
pub mod census_bus;
/// Versioned objective bridge compatibility descriptors.
pub mod compatibility;
/// Collective variables from the spectrum of the visited-basin graph.
pub mod construct;
/// The cooling-schedule trait: `epoch -> temperature`.
pub mod contextual;
/// Continuous-symmetry projections for non-periodic atomic clusters.
pub mod continuous_symmetry;
pub mod cool;
pub mod cooperative_search;
/// Shared core-class table for cooperative cluster chains.
pub mod coreclass;
pub mod corekey;
/// Continuous symmetry measure averages for a free point set.
pub mod csm;
pub mod curvature;
/// Transport for consensus traffic between server brains.
#[cfg(feature = "bank-rpc")]
pub mod decree_bus;
pub mod delayed;
/// Versioned multiscale invariant coordinates for basin catalogs.
pub mod descriptor_space;
/// Same-PES basin/ridge assignment by minimum-value information.
pub mod discovery_roster;
/// Annealing the distance at which two solutions count as one.
pub mod diversity;
/// A posterior over the density of minima, and acceptance by entropy rather
/// than by energy.
pub mod dos;
/// Environment knobs read one way everywhere.
pub mod env;
/// Error variants returned by `anneal-core`.
pub mod error;
/// Parallel-tempering exchange operator for multi-temperature ensembles.
pub mod exchange;
/// featomic SOAP power-spectrum leftover hop.
#[cfg(feature = "featomic")]
pub mod featomic_hop;
/// First-passage mixture model for splitting a budget over independent chains.
pub mod first_passage;
/// Energy-floor flicker components and record EI.
pub mod floors;
/// Free-energy estimators (Bennett's BAR + descendants).
pub mod free_energy;
/// First-derivative interface for HMC-style samplers.
pub mod funnel_bo;
pub mod funnel_spectral;
/// The gradient-enhanced Gaussian process of gpr_optim, over its C API.
#[cfg(feature = "gpr")]
pub mod gpr;
pub mod grad;
/// Exact basin identity by canonical contact-graph labelling (nauty).
#[cfg(feature = "graphkey")]
pub mod graphkey;
/// Calibrate the model Hessian on a run's own descents.
pub mod hessian_fit;
/// Per-epoch run history returned by `run_rs`.
pub mod history;
/// nng REQ/REP for [`MinimumHistory`] observe / mark_accepted.
#[cfg(feature = "history-nng")]
pub mod history_nng;
/// Hamiltonian Monte Carlo inside SA (Method B Phase 1).
pub mod hmc;
/// Thomson covering of \(S^{d-1}\).
///
/// Plasencia Gutiérrez, M.; Argáez, C.; Jónsson, H. Improved Minimum
/// Mode Following Method for Finding First Order Saddle Points.
/// *J. Chem. Theory Comput.* **2017**, *13* (1), 125-134.
/// <https://doi.org/10.1021/acs.jctc.5b01216>
pub mod hypersphere;
/// Invert known wells so rgmin does not walk a Leave back into them.
pub mod known_basin;
pub mod lattice;
/// Law-witness helpers and the `LawViolation` diagnostic type.
pub mod laws;
/// Local two-shell topology keys (k-ART).
#[cfg(feature = "graphkey")]
pub mod localkey;
/// Short MD segments through external engines (LAMMPS, GROMACS).
pub mod md_engine;
/// Annealing-method extensions built on the typed algebra:
/// MCMC-style multi-chain SA with Gelman-Rubin termination, Bayesian
/// pilot adaptation, parallel tempering, etc.
pub mod methods;
/// Action-outcome models for cost-aware global-minimum information.
pub mod minima_db;
pub mod minimum_information;
pub mod model_hessian;
/// Morphology collective variables: Steinhardt bond order, a SOAP projection
/// and a coordination kernel density estimate, on featomic's descriptors.
pub mod morphology;
/// The move-kernel trait: temperature-indexed proposal sampling.
pub mod movekernel;
/// Cooperative basin and ridge exploration on one arbitrary-dimensional PES.
pub mod nd_hybrid;
/// The neighborhood trait: `state -> set-of-states`.
pub mod neigh;
/// Incremental neighbour table shared across the hop.
pub mod neighbors;
/// nng carrier for Cap'n catalog and bank sockets.
#[cfg(feature = "bank-rpc")]
pub mod nng_rpc;
/// Noise-aware acceptance (Ball, Branke & Meisel 2018 sequential OSA rule).
pub mod noise_accept;
/// Packing mutates: twin a dense plane, or close orbits on a new basin.
pub mod packing;
/// The pure-Rust SA driver loop.
/// Multi-step paths between minima, where one hop cannot cross.
pub mod path;
/// Durable readcon-db snapshots of exact minimum--saddle networks.
pub mod pes_db;
/// rgmin quenches and rgsaddle minimum--saddle--minimum connections.
pub mod pes_exploration;
pub mod potentials;
pub mod quench;
/// Leader consensus over exploration decrees between server brains.
pub mod raft;
/// Joint population assignment across fixed-probe attraction regions.
pub mod region_assignment;
/// Temperature spread across a cooperative ensemble and its exchange.
pub mod replica_exchange;
/// GMRF residual intensity on the class graph.
pub mod residual_field;
/// Budgeted execution of coordinator-issued transition-search work.
#[cfg(feature = "bank-rpc")]
pub mod ride_execution;
/// Shared same-system scheduling evidence for minimum-mode transition searches.
pub mod ride_ledger;
pub mod rigid_body;
/// Deterministic provenance records for engine-backed runs.
pub mod run_manifest;
pub mod runner;
/// Run-time distributions: what a search's time to target supports.
pub mod runtime_distribution;
/// Stan-style single-step sampler trait: `trait Sampler<T>`.
pub mod sampler;
/// Successive-halving population control for a live coordinator roster.
pub mod scaling;
pub mod screen;
/// SOAP power spectrum and Cartesian pullback through `∂p/∂R`.
pub mod soap;
/// Gradient-enhanced Gaussian process over structures, with a SOAP kernel.
pub mod soap_gp;
/// Budgeted perturb--quench source generation for hybrid PES exploration.
pub mod source_escape;
pub mod spectral;
pub mod structure;
pub mod superbasin;
/// Source-keyed relaxation-surface rewards exchanged between chains.
pub mod surface_evidence;
/// How a leftover chain uses the shared packing catalog.
pub mod swarm;
pub mod sym_hessian;
pub mod symmetrise;
/// Endpoint of the quenched-energy distribution, by peaks over threshold.
pub mod tail;
/// Replica exchange: the bias-aware swap ratio, the non-reversible sweep, and
/// a ladder placed by the communication barrier the run measures.
pub mod tempering;
/// Permutation invariants from a three-body tensor, for basin identity.
pub mod tensor_id;
pub mod terminate;
/// Action-conditioned structural transition evidence.
pub mod transition_graph;
pub mod twin;
/// Shared algebra-facing type definitions.
pub mod types;
/// Uncertainty-aware coverage over universal stationary-point descriptors.
pub mod universal_coverage;
/// The fully-typed `SaVariant` tuple satisfying L1-L4.
pub mod variant;
/// Package version metadata.
pub mod version;

/// C ABI surface (cargo-c builds).
#[cfg(feature = "capi")]
pub mod ffi;
/// pyo3 module entry point exposed as `anneal._core`.
#[cfg(feature = "ira")]
pub mod shape;
pub mod shared_bias;

#[cfg(feature = "python")]
pub mod python;

pub use accept::AcceptRule;
pub use adapter::{Adapter, IdentityAdapter};
pub use bias::{Bias, WellTemperedBias};
pub use cool::Cooling;
pub use error::Error;
pub use exchange::{Exchange, MetropolisExchange, TsallisExchange};
pub use free_energy::BarEstimator;
pub use grad::{AnalyticGradient, DifferentiableObjective, FiniteDiffGradient, Gradient};
pub use history::{EpochLine, History, State, trajectory_stationarity_flags};
pub use hmc::{
    HmcIntegrator, HmcSaSampler, LeapfrogIntegrator, LeapfrogResult, NutsSaSampler, NutsTransition,
    OMELYAN_LAMBDA, OmelyanIntegrator,
};
pub use laws::LawViolation;
pub use methods::{
    AmsaResult, ArmStat, BayesianMixingResult, BayesianMixingSampler, BoxEnsembleConfig,
    BoxEnsembleResult, DEFAULT_ALPHA, DEFAULT_BETA0, DEFAULT_GAMMA, DEFAULT_STEPS_PER_CONTROL,
    DEFAULT_TARGET_WALKERS, DmcPopulationResult, EnsembleHopResult, GelmanRubin, GleLangevinResult,
    GlePreconditioner, LaplacePosterior, LocalPolishResult, MultiChainResult, MultiChainSampler,
    MultiChainState, OptimizationRegime, ParallelTemperingSampler, PilotObservation, PilotPrior,
    Population, PortfolioEnsembleConfig, PortfolioEnsembleResult, PortfolioPolicy, PortfolioResult,
    ProblemFeatures, PtChainState, PtResult, Q_V_MAX, Q_V_MIN, QmcPolishResult, RegimeError,
    ShootDirection, TARGET_ACCEPT_RATE, TpeCategorical, TpeContinuous1d, Walker, amsa_optimize,
    arm_prior_boost, arm_slice_multiplier, box_ensemble_optimize, check_accept_path, default_sigma,
    diffusion_displace, dmc_population_optimize, ensemble_hop_optimize, estimate_gle_omega0,
    estimate_gle_preconditioner, exact_accept_allowed, fit_laplace, geometric_ladder,
    gle_langevin_adaptive_sa, gle_langevin_preconditioned_sa, gle_langevin_sa, order_arms,
    pilot_draws, pilot_draws_qmc, population_control, portfolio_ensemble_optimize,
    portfolio_optimize, portfolio_optimize_from, portfolio_optimize_seeded,
    portfolio_optimize_with_policy, portfolio_values_ensemble_optimize, preferred_arm_tail,
    projected_gradient_polish, qmc_best1bin_scout, qmc_gsa_global_search,
    qmc_gsa_global_search_from, qmc_projected_gradient_polish, qmc_trust_region_poll,
    regime_exploit_prob, regime_exploit_width, require_accept_compatible, run_dmc_population,
    select_regime, shifted_qmc_projected_gradient_polish, walker_weight,
};
pub use movekernel::{MoveKernel, Reflected};
pub use neigh::Neighborhood;
pub use noise_accept::{OsaAccept, OsaResult};
pub use runner::{
    qmc_skip_from_seed, run_rs, run_rs_qmc_variant, run_rs_qmc_variant_from,
    run_rs_qmc_variant_from_position, run_rs_qmc_variant_start, run_rs_variant, run_rs_variant_at,
    run_rs_variant_from, run_rs_variant_from_position, run_rs_variant_resumed,
    run_rs_variant_start,
};
pub use sampler::Sampler;
pub use tempering::{
    IndexProcess, Ladder, ReplicaMove, ReplicaTarget, SwapScheme, TARGET_SWAP_ACCEPT,
    beta_step_for_acceptance, biased_swap_log_ratio, swap_log_ratio, swap_probability,
};
pub use variant::SaVariant;
pub use version::ANNEAL_VERSION;
