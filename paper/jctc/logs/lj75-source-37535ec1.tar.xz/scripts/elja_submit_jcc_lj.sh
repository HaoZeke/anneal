#!/usr/bin/env bash
# Submit matched shared/control LJ ensemble arrays on Elja.
set -euo pipefail

STAGE=${1:?development, qualification, or production}
ROOT=${LJ_ROOT:-$HOME/anneal-build}
SOURCE_ROOT=${JCC_SOURCE_ROOT:-$ROOT}
REPRO_ROOT=${ANNEAL_REPRO_ROOT:-$HOME/anneal_repro}
RUNNER=$ROOT/scripts/elja_jcc_lj_causal_pair.sh
OUT_ROOT=${LJ_OUT:-$HOME/ljwork/jcc}
PYTHON=${JCC_PYTHON:-$HOME/rgpot/.pixi/envs/xtbbld/bin/python}
QUALIFIER_PYTHON=${JCC_QUALIFIER_PYTHON:-$PYTHON}
RADIUS_READER=$REPRO_ROOT/workflow/jcc/read_census_radius.py
CAMPAIGN=${JCC_CAMPAIGN:-jcc-2026-${STAGE}}
declare -Ar PAPER_BUDGETS=(
  [38]=400000
  [55]=1000000
  [75]=4000000
  [98]=4000000
  [102]=4000000
  [104]=4000000
)

case "$STAGE" in
  development)
    ENSEMBLES=${JCC_ENSEMBLES:-4}
    SEED_OFFSET_BASE=${SEED_OFFSET_BASE:-0}
    ;;
  qualification)
    ENSEMBLES=${JCC_ENSEMBLES:-12}
    SEED_OFFSET_BASE=${SEED_OFFSET_BASE:-100000}
    ;;
  production)
    ENSEMBLES=${JCC_ENSEMBLES:-24}
    SEED_OFFSET_BASE=${SEED_OFFSET_BASE:-200000}
    ;;
  *)
    echo "stage must be development, qualification, or production" >&2
    exit 2
    ;;
esac

readonly -a JCC_LJ_PROTOCOL_EXPORTS=(
  CATALOG_SHARED_SCREEN=1
  CATALOG_SHARED_BIAS=0
  CATALOG_ENTROPIC_BIAS=0
  CATALOG_HISTO_SCREEN=0
  CATALOG_SEAM_LADDER=1
  CATALOG_FRONTIER_EXCHANGE=0
  CATALOG_COOP_WELLS=1
  CATALOG_BRIDGE=0
  CATALOG_DIFFICULTY=0
  CATALOG_PACKING_PAVE=0
  CATALOG_SEAM_PATIENCE=800
  CATALOG_SEAM_TRACE=0
  CATALOG_HISTO_RADIUS=1.4
  CATALOG_PROBE_INTERVAL=8
  CATALOG_PROBE_SCALE=0.2
  CATALOG_BRIDGE_INTERVAL=64
  QUENCH_NOISE=0
)
protocol_exports=$(IFS=,; printf '%s' "${JCC_LJ_PROTOCOL_EXPORTS[*]}")

if [[ ! -x $RUNNER ]]; then
  echo "missing ensemble runner: $RUNNER" >&2
  exit 1
fi
if [[ ! -x $PYTHON || ! -f $RADIUS_READER ]]; then
  echo "missing census-radius validator or its Python interpreter" >&2
  exit 1
fi
if [[ ! -x $QUALIFIER_PYTHON ]]; then
  echo "missing hard-LJ qualification Python: $QUALIFIER_PYTHON" >&2
  exit 1
fi
SOURCE_COMMIT_FILE=$ROOT/SOURCE_COMMIT
if [[ ! -s $SOURCE_COMMIT_FILE || ! -s $ROOT/BUILD_SHA256SUMS ]]; then
  echo "missing source record or LJ build artifact seal below $ROOT" >&2
  exit 1
fi
IFS= read -r SOURCE_COMMIT <"$SOURCE_COMMIT_FILE"
HEAD=$(git -C "$SOURCE_ROOT" rev-parse HEAD)
if [[ $SOURCE_COMMIT != "$HEAD" ]]; then
  echo "SOURCE_COMMIT=$SOURCE_COMMIT does not match HEAD=$HEAD" >&2
  exit 2
fi
if ! (cd "$SOURCE_ROOT" && git diff --quiet HEAD --); then
  echo "tracked source differs from HEAD=$HEAD" >&2
  (cd "$SOURCE_ROOT" && git status --short >&2)
  exit 2
fi
(cd "$ROOT" && sha256sum -c BUILD_SHA256SUMS)
(cd "$REPRO_ROOT" && sha256sum --check --strict results_jcc/calibration/SHA256SUMS)

mkdir -p "$OUT_ROOT/submissions"
last=$((ENSEMBLES - 1))
for n in 38 55 75 98 102 104; do
  budget=${PAPER_BUDGETS[$n]}
  radius_variable="LJ${n}_CENSUS_RADIUS"
  radius=${!radius_variable:-}
  if [[ -z $radius ]]; then
    radius=$("$PYTHON" "$RADIUS_READER" \
      "$REPRO_ROOT/results_jcc/calibration/lj${n}.json")
  fi
  for arm in shared control; do
    log="$OUT_ROOT/submissions/${STAGE}-lj${n}-${arm}-%A_%a.out"
    sbatch \
      --parsable \
      --job-name="jcc-lj${n}-${arm}" \
      --array="0-${last}" \
      --partition="${ELJA_PARTITION:-s-normal}" \
      --account="${ELJA_ACCOUNT:-chem-ui}" \
      --time="${ELJA_TIME:-2-00:00:00}" \
      --cpus-per-task="${ELJA_CPUS_PER_TASK:-8}" \
      --mem="${ELJA_MEM:-16G}" \
      --output="$log" \
      --export="ALL,CATALOG_CAMPAIGN=${CAMPAIGN},SEED_OFFSET_BASE=${SEED_OFFSET_BASE},JCC_QUALIFIER_PYTHON=${QUALIFIER_PYTHON},${protocol_exports}" \
      "$RUNNER" "$n" "$budget" slurm-array "$radius" "$arm"
  done
done
