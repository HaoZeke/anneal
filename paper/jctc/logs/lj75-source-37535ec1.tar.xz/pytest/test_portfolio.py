"""Tests for the native Thompson-allocated portfolio driver."""

import math

import numpy as np
import pytest

anneal = pytest.importorskip("anneal")

from experiments.tensor_surrogate import AdditiveSurrogate  # noqa: E402


def _styblinski_tang(dim):
    def fn(x):
        return 0.5 * float(np.sum(x**4 - 16.0 * x**2 + 5.0 * x))

    def grad(x):
        return 0.5 * (4.0 * x**3 - 32.0 * x + 5.0)

    low = np.full(dim, -5.0)
    high = np.full(dim, 5.0)
    return fn, grad, low, high


def _rastrigin(dim):
    def fn(x):
        return 10.0 * dim + float(np.sum(x**2 - 10.0 * np.cos(2.0 * np.pi * x)))

    def grad(x):
        return 2.0 * x + 20.0 * np.pi * np.sin(2.0 * np.pi * x)

    low = np.full(dim, -5.12)
    high = np.full(dim, 5.12)
    return fn, grad, low, high


def test_budget_is_never_exceeded():
    dim = 6
    fn, grad, low, high = _rastrigin(dim)
    out = anneal.global_optimize(fn, low, high, budget=600, seed=7, grad_fn=grad)
    assert out["n_evals"] + out["n_grads"] <= 600
    assert math.isfinite(out["best_val"])


def test_global_optimize_rejects_inverted_bounds():
    fn, _, low, high = _rastrigin(2)
    with pytest.raises(ValueError, match="strictly less"):
        anneal.global_optimize(fn, high, low, budget=50, seed=0)


def test_global_optimize_rejects_nonfinite_bounds():
    fn, _, low, high = _rastrigin(2)
    bad = low.copy()
    bad[0] = float("nan")
    with pytest.raises(ValueError, match="finite"):
        anneal.global_optimize(fn, bad, high, budget=50, seed=0)


def test_portfolio_runs_inside_a_box_narrower_than_its_difference_step():
    low = np.array([-1e-8, -1.0, 0.25])
    high = np.array([1e-8, 1.0, 0.25 + 1e-12])
    seen = []

    def fn(x):
        seen.append(np.array(x, copy=True))
        return float(np.sum((np.asarray(x) - 0.5) ** 2))

    out = anneal.global_optimize(fn, low, high, budget=300, seed=0)
    assert seen
    for x in seen:
        assert np.all(x >= low) and np.all(x <= high)
    assert out["n_evals"] <= 300


def test_budget_respected_without_gradients():
    dim = 4
    fn, _, low, high = _rastrigin(dim)
    out = anneal.global_optimize(fn, low, high, budget=400, seed=3)
    assert out["n_evals"] <= 400
    assert out["n_grads"] == 0
    assert math.isfinite(out["best_val"])


def test_portfolio_reaches_global_basin_on_styblinski_tang():
    dim = 6
    fn, grad, low, high = _styblinski_tang(dim)
    hits = 0
    for seed in range(4):
        out = anneal.global_optimize(
            fn, low, high, budget=1500, seed=seed, grad_fn=grad
        )
        if out["best_val"] < -39.166 * dim * 0.99:
            hits += 1
    assert hits >= 3, f"global basin hit on {hits}/4 seeds"


def test_portfolio_beats_uniform_random():
    dim = 6
    fn, grad, low, high = _styblinski_tang(dim)
    budget = 1500
    out = anneal.global_optimize(fn, low, high, budget=budget, seed=11, grad_fn=grad)
    rng = np.random.default_rng(11)
    rand_best = min(fn(rng.uniform(low, high)) for _ in range(budget))
    assert out["best_val"] < rand_best


def test_arm_statistics_are_reported():
    dim = 10
    fn, grad, low, high = _rastrigin(dim)
    out = anneal.global_optimize(fn, low, high, budget=4000, seed=5, grad_fn=grad)
    assert "explore" in out["arm_pulls"]
    assert sum(out["arm_pulls"].values()) > 0
    assert set(out["arm_successes"]) == set(out["arm_pulls"])


def test_global_optimize_accepts_initial_position():
    dim = 4
    low = np.full(dim, -3.0)
    high = np.full(dim, 3.0)
    x0 = np.array([1.0, -2.0, 0.5, 1.5])
    f0 = float(np.sum(x0**2))

    def fn(x):
        return float(np.sum(np.asarray(x) ** 2))

    out = anneal.global_optimize(fn, low, high, budget=400, seed=3, x0=x0)
    assert out["best_val"] <= f0
    assert np.all(np.asarray(out["best_pos"]) >= low)
    assert np.all(np.asarray(out["best_pos"]) <= high)
    assert out["n_evals"] <= 400


def test_global_optimize_rejects_bad_initial_position():
    dim = 2
    fn, _, low, high = _rastrigin(dim)
    with pytest.raises(ValueError, match="has length"):
        anneal.global_optimize(fn, low, high, budget=50, seed=0, x0=np.array([0.0]))
    with pytest.raises(ValueError, match="not finite"):
        anneal.global_optimize(
            fn, low, high, budget=50, seed=0, x0=np.array([0.0, np.inf])
        )


def _rosenbrock(dim):
    def fn(x):
        return float(np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1.0 - x[:-1]) ** 2))

    low = np.full(dim, -2.0)
    high = np.full(dim, 2.0)
    return fn, None, low, high


def _recorded(fn):
    calls = []

    def wrapped(x):
        calls.append(np.array(x, dtype=np.float64, copy=True))
        return fn(x)

    return wrapped, calls


@pytest.mark.parametrize(("problem", "dim"), [(_rosenbrock, 6), (_rastrigin, 4)])
def test_x0_is_the_first_evaluation_and_every_call_is_charged(problem, dim):
    fn, _, low, high = problem(dim)
    x0 = np.linspace(low[0] * 0.75, high[0] * 0.75, dim)
    wrapped, calls = _recorded(fn)
    out = anneal.global_optimize(wrapped, low, high, budget=900, seed=4, x0=x0)
    np.testing.assert_array_equal(calls[0], x0)
    assert len(calls) == out["n_evals"] <= 900
    assert out["n_grads"] == 0
    assert all(np.all((c >= low) & (c <= high)) for c in calls)
    assert out["best_val"] <= fn(x0)


@pytest.mark.parametrize(("problem", "dim"), [(_styblinski_tang, 4), (_rastrigin, 6)])
def test_x0_is_the_first_evaluation_with_a_gradient(problem, dim):
    fn, grad, low, high = problem(dim)
    x0 = np.linspace(low[0] * 0.75, high[0] * 0.75, dim)
    wrapped, calls = _recorded(fn)
    out = anneal.global_optimize(
        wrapped, low, high, budget=600, seed=3, x0=x0, grad_fn=grad
    )
    np.testing.assert_array_equal(calls[0], x0)
    assert len(calls) == out["n_evals"]
    assert out["n_evals"] + out["n_grads"] <= 600
    assert out["best_val"] <= fn(x0)


def test_values_only_rosenbrock_descends_from_x0():
    dim = 10
    fn, _, low, high = _rosenbrock(dim)
    out = anneal.global_optimize(
        fn, low, high, budget=1500, seed=0, x0=np.full(dim, -1.2)
    )
    assert out["best_val"] < 1e-8


def test_x0_at_the_minimum_stays_the_incumbent():
    dim = 6
    fn, _, low, high = _rosenbrock(dim)
    x0 = np.ones(dim)
    out = anneal.global_optimize(fn, low, high, budget=300, seed=2, x0=x0)
    assert out["best_val"] == 0.0
    np.testing.assert_array_equal(out["best_pos"], x0)


def test_additive_surrogate_from_points_recovers_separable():
    rng = np.random.default_rng(5)
    dim = 3
    low = np.full(dim, -2.0)
    high = np.full(dim, 2.0)
    X = rng.uniform(low, high, size=(400, dim))
    y = np.sum(X**2, axis=1)
    surr = AdditiveSurrogate.from_points(X, y, low, high, degree=6)
    samples = surr.sample(64, 0.05, rng)
    # Low-temperature draws concentrate near the separable minimum at 0.
    assert float(np.median(np.abs(samples))) < 0.5
    assert surr.pilot_work_units() == 0.0
