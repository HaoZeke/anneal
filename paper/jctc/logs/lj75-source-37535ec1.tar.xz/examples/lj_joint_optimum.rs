//! Matched-call LJ global-minimum benchmark for joint-optimum exploration.
//!
//! The adaptive arm allocates between finite invariant basin proposals and
//! projected rgsaddle ridge/IRC actions by information about the identity and
//! energy of the lowest reachable minimum per expected PES call. Fixed-family
//! ablations, plain Wales--Doye basin hopping, rgsaddle NVE minima hopping, and
//! a history-conditioned displacement-feedback ablation use the same initial
//! coordinates, seeds, target, and charged-call ceiling.
//!
//! Usage:
//! `lj_joint_optimum <N> <budget> <seeds> [all|adaptive|ridge|basin|bh|bh-sym|bh-csm-ci|mh|mh-soft|mh-bounded|mh-bounded-soft|mh-communication|feedback] [gs2|morokuma|both] [seed0]`
//!
//! `mh-communication` pairs private and shared minimum histories at one total
//! budget, divided among `ANNEAL_MH_REPLICAS` replicas (default four). History
//! changes escape effort, never coordinates. `mh-private`, `mh-shared`,
//! `mh-private-soft`, and `mh-shared-soft` select individual ensemble arms.
//! `ANNEAL_START_COORDINATES` supplies one fixed plain Cartesian input for
//! escape probes; its coordinates are embedded in the configuration record.

use std::collections::{HashMap, HashSet};
use std::error::Error;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, atomic::AtomicUsize, atomic::Ordering};
use std::time::Instant;

use anneal_core::atomistic_hybrid::{
    AtomisticHybridConfig, AtomisticHybridPolicy, AtomisticSystem, explore_atomistic_with_policy,
};
use anneal_core::catalog::lj;
use anneal_core::descriptor_space::DescriptorSpace;
use anneal_core::methods::cluster_hopping::{
    Config as HoppingConfig, ContinuousSymmetry, Ledger, MoveLibrary, Outcome, random_cluster, run,
    run_with_gradient,
};
use anneal_core::methods::cluster_search::{Encounter, first_encounter, median_encounter};
use anneal_core::methods::minima_hopping::{
    EscapeFeedback, HistoryObservation, MdEscapeConfig, MdEscapeGeometry, MdTimeStepFeedback,
    MinimumHistory, VelocitySofteningConfig, Visit, nve_escape,
};
use anneal_core::methods::warm_lbfgs::WarmLbfgs;
use anneal_core::pes_exploration::{
    ExactStructureWitness, IrcKind, PesExplorationConfig, RideMethod, StructureContext,
    StructureView,
};
use anneal_core::potentials::{PairKind, PairPotential};
use anneal_core::shape::IraStructureWitness;
use ndarray::ArrayView1;
use rand::{SeedableRng, rngs::StdRng};
use serde_json::json;

const TARGET_TOLERANCE: f64 = 1e-3;
const MH_SOFTENING_STEPS: usize = 20;
const MH_SOFTENING_DISPLACEMENT: f64 = 0.1;
const MH_SOFTENING_MIXING: f64 = 0.15;
const CSM_INTERVAL: usize = 10;

#[derive(Clone, Copy, Debug)]
enum Arm {
    Adaptive(IrcKind),
    Ridge(IrcKind),
    Basin,
    BasinHopping,
    BasinHoppingSymmetry,
    BasinHoppingCsmCi,
    MinimaHopping,
    MinimaHoppingSoftened,
    MinimaHoppingBounded,
    MinimaHoppingBoundedSoftened,
    MinimaHoppingEnsemble { shared: bool, soften: bool },
    MinimaFeedback,
}

impl Arm {
    fn label_with_history(self, policy: HistoryExclusion) -> String {
        if matches!(self, Self::MinimaHoppingEnsemble { .. })
            && policy == HistoryExclusion::Observed
        {
            format!("{}-observed-exclusion", self.label())
        } else {
            self.label()
        }
    }

    fn label(self) -> String {
        match self {
            Self::Adaptive(kind) => format!("adaptive-{}", irc_name(kind)),
            Self::Ridge(kind) => format!("ridge-{}", irc_name(kind)),
            Self::Basin => "basin-ablation".into(),
            Self::BasinHopping => "basin-hopping".into(),
            Self::BasinHoppingSymmetry => "basin-hopping-stall-symmetry".into(),
            Self::BasinHoppingCsmCi => "basin-hopping-csm-ci".into(),
            Self::MinimaHopping => "minima-hopping".into(),
            Self::MinimaHoppingSoftened => "minima-hopping-softened".into(),
            Self::MinimaHoppingBounded => "minima-hopping-bounded".into(),
            Self::MinimaHoppingBoundedSoftened => "minima-hopping-bounded-softened".into(),
            Self::MinimaHoppingEnsemble { shared, soften } => format!(
                "minima-hopping-{}-history{}",
                if shared { "shared" } else { "private" },
                if soften { "-softened" } else { "" },
            ),
            Self::MinimaFeedback => "minima-feedback".into(),
        }
    }
}

#[derive(Default)]
struct Summary {
    encounters: Vec<Encounter>,
    deepest: f64,
    charged: u128,
    minima: u128,
    saddles: u128,
    failures: u128,
}

impl Summary {
    fn observe(
        &mut self,
        encounter: Encounter,
        best: f64,
        charged: u64,
        minima: usize,
        saddles: usize,
        failures: usize,
    ) {
        if self.encounters.is_empty() {
            self.deepest = best;
        } else {
            self.deepest = self.deepest.min(best);
        }
        self.encounters.push(encounter);
        self.charged += u128::from(charged);
        self.minima += minima as u128;
        self.saddles += saddles as u128;
        self.failures += failures as u128;
    }
}

struct MinimaHoppingRun {
    outcome: Outcome,
    initial_quench_calls: usize,
    dynamics_calls: usize,
    dynamics_steps: usize,
    proposal_quench_calls: usize,
    final_time_step: f64,
    history_seconds: f64,
    aggregate_improvements: Vec<(usize, f64)>,
}

fn reference(n: usize) -> Option<f64> {
    Some(match n {
        13 => -44.326_801,
        38 => -173.928_427,
        55 => -279.248_470,
        75 => -397.492_331,
        98 => -543.665_361,
        102 => -569.363_652,
        104 => -582.086_642,
        _ => return None,
    })
}

fn irc_name(kind: IrcKind) -> &'static str {
    match kind {
        IrcKind::Gs2 => "gs2",
        IrcKind::Morokuma => "morokuma",
    }
}

fn irc_kinds(selector: &str) -> Result<Vec<IrcKind>, String> {
    match selector {
        "gs2" => Ok(vec![IrcKind::Gs2]),
        "morokuma" => Ok(vec![IrcKind::Morokuma]),
        "both" => Ok(vec![IrcKind::Gs2, IrcKind::Morokuma]),
        _ => Err("IRC selector must be gs2, morokuma, or both".into()),
    }
}

fn selected_arms(selector: &str, irc: &[IrcKind]) -> Result<Vec<Arm>, String> {
    let mut arms = Vec::new();
    match selector {
        "all" => {
            arms.extend(irc.iter().copied().map(Arm::Adaptive));
            arms.extend(irc.iter().copied().map(Arm::Ridge));
            arms.extend([
                Arm::Basin,
                Arm::BasinHopping,
                Arm::BasinHoppingSymmetry,
                Arm::BasinHoppingCsmCi,
                Arm::MinimaHopping,
                Arm::MinimaHoppingSoftened,
                Arm::MinimaHoppingBounded,
                Arm::MinimaHoppingBoundedSoftened,
                Arm::MinimaFeedback,
            ]);
        }
        "adaptive" => arms.extend(irc.iter().copied().map(Arm::Adaptive)),
        "ridge" => arms.extend(irc.iter().copied().map(Arm::Ridge)),
        "basin" => arms.push(Arm::Basin),
        "bh" => arms.push(Arm::BasinHopping),
        "bh-sym" => arms.push(Arm::BasinHoppingSymmetry),
        "bh-csm-ci" => arms.push(Arm::BasinHoppingCsmCi),
        "mh" => arms.push(Arm::MinimaHopping),
        "mh-soft" => arms.push(Arm::MinimaHoppingSoftened),
        "mh-bounded" => arms.push(Arm::MinimaHoppingBounded),
        "mh-bounded-soft" => arms.push(Arm::MinimaHoppingBoundedSoftened),
        "mh-private" | "mh-shared" | "mh-private-soft" | "mh-shared-soft" => {
            arms.push(Arm::MinimaHoppingEnsemble {
                shared: selector.contains("shared"),
                soften: selector.ends_with("-soft"),
            });
        }
        "mh-communication" => arms.extend([
            Arm::MinimaHoppingEnsemble {
                shared: false,
                soften: false,
            },
            Arm::MinimaHoppingEnsemble {
                shared: true,
                soften: false,
            },
        ]),
        "feedback" => arms.push(Arm::MinimaFeedback),
        _ => {
            return Err(
                "arm must be all, adaptive, ridge, basin, bh, bh-sym, bh-csm-ci, mh, mh-soft, mh-bounded, mh-bounded-soft, mh-communication, mh-private[-soft], mh-shared[-soft], or feedback"
                    .into(),
            );
        }
    }
    Ok(arms)
}

fn hybrid_config(n: usize, budget: u64, irc_kind: IrcKind) -> AtomisticHybridConfig {
    let dimension = u64::try_from(3 * n).unwrap_or(u64::MAX);
    let escape_cap = budget.min((20 * dimension).max(800));
    let ride_cap = budget.min((100 * dimension).max(4_000));
    let length = PairKind::LennardJones.r_min();
    let component_tolerance = 1e-5 / (dimension as f64).sqrt();
    AtomisticHybridConfig {
        evaluation_budget: budget,
        ride_evaluation_cap: ride_cap,
        escape_evaluation_cap: escape_cap,
        ride_modes_per_atom: 1,
        localization_radius: 1.5 * length,
        escape_scales: vec![0.08 * length, 0.16 * length, 0.32 * length, 0.64 * length],
        minimum_information_samples: 256,
        information_length_scale: 1.0,
        information_amplitude: 1.0,
        information_noise: 1e-6,
        expected_ride_cost: ride_cap as f64,
        expected_escape_cost: escape_cap as f64,
        cost_prior_strength: 1.0,
        exploration: PesExplorationConfig {
            ride_method: RideMethod::Lanczos,
            quench_steps: 1_000,
            saddle_steps: 1_000,
            minimum_mode_force_tolerance: 1e-2,
            irc_steps: 200,
            prfo_steps: 300,
            activation_attempts: 6,
            activation_growth: 1.6,
            activation_relaxation_steps: 3,
            quench_gradient_tolerance: component_tolerance,
            quench_gradient_norm_tolerance: Some(1e-5),
            saddle_force_tolerance: 1e-3,
            saddle_displacement: 0.1 * length,
            negative_curvature_tolerance: 1e-6,
            hessian_step: 1e-4 * length,
            maximum_move: 0.2 * length,
            irc_step: 0.1 * length,
            irc_kind,
            branch_attempts: 4,
            branch_growth: 2.0,
            irc_force_tolerance: 0.05,
            refine_with_prfo: true,
        },
    }
}

struct HoppingMoves {
    minima_hopping: bool,
    symmetrise_on_stall: bool,
    continuous_symmetry: ContinuousSymmetry,
}

fn run_hopping(
    potential: &PairPotential,
    initial: ArrayView1<'_, f64>,
    n: usize,
    budget: usize,
    seed: u64,
    moves: HoppingMoves,
) -> Outcome {
    let mut config = HoppingConfig::for_cluster(n);
    config.bias_height = 0.0;
    config.move_library = MoveLibrary::WalesDoye;
    config.minima_hopping = moves.minima_hopping;
    config.symmetrise_on_stall = moves.symmetrise_on_stall;
    config.continuous_symmetry = moves.continuous_symmetry;
    let mut ledger = Ledger::new(budget);
    let mut optimizer = WarmLbfgs::default();
    let mut relax = |ledger: &mut Ledger, start: ArrayView1<'_, f64>, steps: usize| {
        let before = ledger.spent();
        optimizer.forget();
        let (energy, coordinates, _) = optimizer.minimize(start, steps, |point| {
            ledger.charge().then(|| potential.value_and_gradient(point))
        });
        ledger.record_quench_boundary(before, energy, coordinates.clone(), None);
        (energy, coordinates)
    };
    let mut gradient = |ledger: &mut Ledger, point: ArrayView1<'_, f64>| {
        ledger
            .charge()
            .then(|| potential.value_and_gradient(point).1)
    };
    let mut rng = StdRng::seed_from_u64(seed);
    if moves.minima_hopping || !matches!(moves.continuous_symmetry, ContinuousSymmetry::Off) {
        run_with_gradient(
            &config,
            initial,
            &mut ledger,
            &mut relax,
            Some(&mut gradient),
            &mut rng,
        )
        .expect("finite start")
    } else {
        run(&config, initial, &mut ledger, &mut relax, &mut rng).expect("finite start")
    }
}

fn charged_evaluate(
    potential: &PairPotential,
    ledger: &mut Ledger,
    point: ArrayView1<'_, f64>,
    charged: Option<&AtomicUsize>,
) -> Option<(f64, ndarray::Array1<f64>)> {
    if !ledger.charge() {
        return None;
    }
    if let Some(charged) = charged {
        charged.fetch_add(1, Ordering::SeqCst);
    }
    Some(potential.value_and_gradient(point))
}

fn quench_minimum(
    potential: &PairPotential,
    optimizer: &mut WarmLbfgs,
    ledger: &mut Ledger,
    start: ArrayView1<'_, f64>,
    steps: usize,
    gradient_tolerance: f64,
    charged: Option<&AtomicUsize>,
) -> Option<(f64, ndarray::Array1<f64>, bool)> {
    if ledger.remaining() == 0 {
        return None;
    }
    let before = ledger.spent();
    optimizer.forget();
    let (_, state, _) = optimizer.minimize(start, steps, |point| {
        // A line search cannot consume the final minimum-certificate call.
        if ledger.remaining() > 1 {
            charged_evaluate(potential, ledger, point, charged)
        } else {
            None
        }
    });
    let final_evaluation = charged_evaluate(potential, ledger, state.view(), charged);
    let (energy, gradient) = final_evaluation
        .map_or((f64::INFINITY, None), |(energy, gradient)| {
            (energy, Some(gradient))
        });
    let validated = energy.is_finite()
        && gradient.as_ref().is_some_and(|values| {
            values
                .iter()
                .all(|value| value.is_finite() && value.abs() < gradient_tolerance)
        });
    ledger.record_quench_boundary(
        before,
        energy,
        state.clone(),
        validated.then_some(gradient).flatten(),
    );
    Some((energy, state, validated))
}

fn exact_basin(
    witness: &impl ExactStructureWitness,
    minima: &[ndarray::Array1<f64>],
    candidate: ArrayView1<'_, f64>,
) -> Option<usize> {
    minima
        .iter()
        .position(|minimum| witness.equivalent(minimum.view(), candidate))
}

struct MinimaHoppingOptions {
    soften: bool,
    bound_escape: bool,
}

struct HistoryRunOptions<'a> {
    moves: MinimaHoppingOptions,
    history: Option<&'a Mutex<MinimumHistory>>,
    charged: Option<&'a AtomicUsize>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum HistoryExclusion {
    Accepted,
    Observed,
}

impl HistoryExclusion {
    fn name(self) -> &'static str {
        match self {
            Self::Accepted => "accepted",
            Self::Observed => "observed-exclusion",
        }
    }
}

fn parse_history_exclusion(value: Option<&str>) -> Result<HistoryExclusion, String> {
    match value {
        None | Some("accepted") => Ok(HistoryExclusion::Accepted),
        Some("observed-exclusion") => Ok(HistoryExclusion::Observed),
        Some(other) => Err(format!(
            "invalid NVE history policy {other:?}; expected accepted or observed-exclusion"
        )),
    }
}

struct HistoryPolicy<T> {
    options: T,
    exclusion: HistoryExclusion,
}

impl<T> From<T> for HistoryPolicy<T> {
    fn from(options: T) -> Self {
        Self {
            options,
            exclusion: HistoryExclusion::Accepted,
        }
    }
}

fn history_feedback_membership(
    policy: HistoryExclusion,
    first_observation: bool,
    observed_visits: u64,
    accepted_visits: u64,
) -> (bool, u64) {
    match policy {
        HistoryExclusion::Accepted => (accepted_visits == 0, accepted_visits),
        HistoryExclusion::Observed => (first_observation, observed_visits),
    }
}

fn observe_history<T>(
    history: &Mutex<MinimumHistory>,
    ledger: &Ledger,
    descriptor: &DescriptorSpace,
    context: &StructureContext,
    witness: &impl ExactStructureWitness,
    decide: impl FnOnce(&mut MinimumHistory, HistoryObservation) -> Result<T, String>,
) -> Result<(HistoryObservation, T), String> {
    let minimum = ledger
        .quench_boundaries()
        .last()
        .ok_or("missing quench certificate")?;
    let description = descriptor
        .describe(minimum.state(), context.species())
        .map_err(|error| error.to_string())?;
    let mut history = history
        .lock()
        .map_err(|_| "minimum history lock poisoned".to_string())?;
    let observation = history
        .observe(minimum, description, context.clone(), witness)
        .map_err(|error| error.to_string())?;
    let decision = decide(&mut history, observation)?;
    Ok((observation, decision))
}

fn run_minima_hopping(
    potential: &PairPotential,
    initial: ArrayView1<'_, f64>,
    n: usize,
    budget: usize,
    seed: u64,
    witness: &impl ExactStructureWitness,
    options: MinimaHoppingOptions,
) -> MinimaHoppingRun {
    run_minima_hopping_with_history(
        potential,
        initial,
        n,
        budget,
        seed,
        witness,
        HistoryRunOptions {
            moves: options,
            history: None,
            charged: None,
        },
    )
    .expect("private minima hopping has no fallible history service")
}

fn run_minima_hopping_with_history<'a>(
    potential: &PairPotential,
    initial: ArrayView1<'_, f64>,
    n: usize,
    budget: usize,
    seed: u64,
    witness: &impl ExactStructureWitness,
    options: impl Into<HistoryPolicy<HistoryRunOptions<'a>>>,
) -> Result<MinimaHoppingRun, String> {
    let HistoryPolicy { options, exclusion } = options.into();
    let HistoryRunOptions {
        moves: options,
        history,
        charged,
    } = options;
    let hopping = HoppingConfig::for_cluster(n);
    let mut escape_config = MdEscapeConfig {
        dt: 0.005,
        potential_minima: 2,
        maximum_steps: 2_000,
        geometry: if n >= 3 {
            MdEscapeGeometry::RigidQuotient
        } else {
            MdEscapeGeometry::Euclidean
        },
        softening: options.soften.then_some(VelocitySofteningConfig {
            steps: MH_SOFTENING_STEPS,
            displacement: MH_SOFTENING_DISPLACEMENT,
            mixing: MH_SOFTENING_MIXING,
        }),
        minimum_rise: 0.0,
        max_rms: f64::INFINITY,
        min_well_rms: 0.0,
    };
    let mut ledger = Ledger::new(budget);
    let mut optimizer = WarmLbfgs::default();
    let initial_quench_start = ledger.spent();
    let initial_quench_steps = ledger.remaining().saturating_sub(1);
    let initial = quench_minimum(
        potential,
        &mut optimizer,
        &mut ledger,
        initial,
        initial_quench_steps,
        hopping.record_gradient,
        charged,
    );
    let initial_quench_calls = ledger.spent().saturating_sub(initial_quench_start);
    let Some((mut energy, mut state, initial_valid)) = initial else {
        return Ok(MinimaHoppingRun {
            outcome: Outcome {
                best: ledger.best,
                best_state: ledger.best_state.clone(),
                final_energy: f64::INFINITY,
                charged: ledger.spent(),
                ..Outcome::default()
            },
            initial_quench_calls,
            dynamics_calls: 0,
            dynamics_steps: 0,
            proposal_quench_calls: 0,
            final_time_step: escape_config.dt,
            history_seconds: 0.0,
            aggregate_improvements: Vec::new(),
        });
    };
    if !initial_valid {
        return Ok(MinimaHoppingRun {
            outcome: Outcome {
                best: ledger.best,
                best_state: ledger.best_state.clone(),
                final_state: Some(state),
                final_energy: energy,
                charged: ledger.spent(),
                unconverged_records: 1,
                ..Outcome::default()
            },
            initial_quench_calls,
            dynamics_calls: 0,
            dynamics_steps: 0,
            proposal_quench_calls: 0,
            final_time_step: escape_config.dt,
            history_seconds: 0.0,
            aggregate_improvements: Vec::new(),
        });
    }

    ledger.record(energy, state.view());
    let mut minima = vec![state.clone()];
    let mut current_basin = 0usize;
    if let Some(softening) = escape_config.softening.as_mut() {
        softening.displacement =
            anneal_core::methods::activation::softening_displacement(state.view());
    }
    let mut feedback = EscapeFeedback::new(hopping.energy_scale, 0.5 * hopping.energy_scale);
    if !options.bound_escape {
        feedback.escape_floor = f64::MIN_POSITIVE;
        feedback.escape_ceiling = f64::MAX;
    }
    feedback.register_initial(current_basin);
    let mut time_step = MdTimeStepFeedback::new(escape_config.dt, escape_config.dt / 100.0);
    let mut rng = StdRng::seed_from_u64(seed);
    let mut hops = 0usize;
    let mut accepted = 0usize;
    let mut unconverged = 0usize;
    let mut dynamics_calls = 0usize;
    let mut dynamics_steps = 0usize;
    let mut proposal_quench_calls = 0usize;
    let mut improvements = vec![(0, ledger.spent(), minima.len(), energy)];
    let mut aggregate_improvements = vec![(
        charged.map_or(ledger.spent(), |counter| counter.load(Ordering::SeqCst)),
        energy,
    )];
    let descriptor = Some(lj::descriptor_space());
    let context = StructureContext::new(Some(vec![18; n]), None, Some(format!("lj-reduced-n{n}")));
    let mut local_basins: HashSet<usize> = HashSet::new();
    let mut accepted_visits: HashMap<usize, u64> = HashMap::new();
    let mut observed_visits: HashMap<usize, u64> = HashMap::new();
    let mut history_seconds = 0.0;

    while ledger.remaining() > 0 {
        let mut attempt_config = escape_config;
        attempt_config.dt = time_step.time_step();
        let dynamics_start = ledger.spent();
        let escape = {
            let mut evaluate =
                |point: ArrayView1<f64>| charged_evaluate(potential, &mut ledger, point, charged);
            nve_escape(
                state.view(),
                feedback.escape(),
                &attempt_config,
                &mut evaluate,
                &mut rng,
            )
        };
        dynamics_calls += ledger.spent().saturating_sub(dynamics_start);
        hops += 1;
        let Ok(escape) = escape else {
            unconverged += 1;
            if ledger.remaining() == 0 {
                break;
            }
            continue;
        };
        dynamics_steps += escape.steps;
        time_step.observe(&escape);
        if escape.potential_minima < escape_config.potential_minima {
            unconverged += 1;
            continue;
        }
        let proposal_quench_start = ledger.spent();
        let quenched = quench_minimum(
            potential,
            &mut optimizer,
            &mut ledger,
            escape.position.view(),
            hopping.relax_steps,
            hopping.record_gradient,
            charged,
        );
        proposal_quench_calls += ledger.spent().saturating_sub(proposal_quench_start);
        let Some((candidate_energy, candidate, validated)) = quenched else {
            break;
        };
        if !validated {
            unconverged += 1;
            // An unresolved quench provides no minimum identity. Escape
            // feedback responds only to certified basin observations.
            continue;
        }

        let history_start = Instant::now();
        let (reached, adopt) = if let (Some(history), Some(descriptor)) =
            (history, descriptor.as_ref())
        {
            let (observation, adopt) = observe_history(
                history,
                &ledger,
                descriptor,
                &context,
                witness,
                |history, observation| {
                    let reached = observation.minimum.id;
                    let visits = history
                        .accepted_visits(reached)
                        .ok_or("missing admitted minimum")?;
                    let (is_new, visits) = history_feedback_membership(
                        exclusion,
                        observation.minimum.is_new,
                        observation.visits,
                        visits,
                    );
                    let visit =
                        feedback.observe_shared(Some(current_basin), reached, is_new, visits);
                    let adopt = visit == Visit::New && feedback.accept(candidate_energy - energy);
                    if adopt {
                        history
                            .mark_accepted(reached)
                            .map_err(|error| error.to_string())?;
                    }
                    Ok(adopt)
                },
            )?;
            let reached = observation.minimum.id;
            if local_basins.insert(reached) {
                minima.push(candidate.clone());
            }
            (reached, adopt)
        } else {
            let reached = exact_basin(witness, &minima, candidate.view()).unwrap_or_else(|| {
                let reached = minima.len();
                minima.push(candidate.clone());
                reached
            });
            let visits = accepted_visits.get_mut(&reached).map_or(0, |visits| {
                *visits = visits.saturating_add(1);
                *visits
            });
            let observed = observed_visits.entry(reached).or_insert(0);
            *observed = observed.saturating_add(1);
            let (is_new, visits) =
                history_feedback_membership(exclusion, *observed == 1, *observed, visits);
            let visit = feedback.observe_shared(Some(current_basin), reached, is_new, visits);
            let adopt = visit == Visit::New && feedback.accept(candidate_energy - energy);
            if adopt {
                accepted_visits.insert(reached, 1);
            }
            (reached, adopt)
        };
        history_seconds += history_start.elapsed().as_secs_f64();
        let improved = candidate_energy < ledger.best;
        ledger.record(candidate_energy, candidate.view());
        if improved {
            improvements.push((hops, ledger.spent(), minima.len(), candidate_energy));
            aggregate_improvements.push((
                charged.map_or(ledger.spent(), |counter| counter.load(Ordering::SeqCst)),
                candidate_energy,
            ));
        }
        if adopt {
            current_basin = reached;
            energy = candidate_energy;
            state = candidate;
            accepted += 1;
        }
    }

    Ok(MinimaHoppingRun {
        outcome: Outcome {
            best: ledger.best,
            best_state: ledger.best_state.clone(),
            final_state: Some(state),
            final_energy: energy,
            hops,
            basins: minima.len(),
            charged: ledger.spent(),
            escape_scale: feedback.escape(),
            escape_threshold: feedback.threshold(),
            visit_counts: (feedback.n_same, feedback.n_known, feedback.n_new),
            improvements,
            accepted,
            unconverged_records: unconverged,
            ..Outcome::default()
        },
        initial_quench_calls,
        dynamics_calls,
        dynamics_steps,
        proposal_quench_calls,
        final_time_step: time_step.time_step(),
        history_seconds,
        aggregate_improvements,
    })
}

struct SerializedWitness<W>(Mutex<W>);

impl<W: ExactStructureWitness> ExactStructureWitness for SerializedWitness<W> {
    fn equivalent(&self, left: ArrayView1<f64>, right: ArrayView1<f64>) -> bool {
        self.0
            .lock()
            .expect("exact witness lock poisoned")
            .equivalent(left, right)
    }

    fn equivalent_structures(&self, left: StructureView<'_>, right: StructureView<'_>) -> bool {
        self.0
            .lock()
            .expect("exact witness lock poisoned")
            .equivalent_structures(left, right)
    }
}

#[derive(Clone, Copy)]
struct EnsembleOptions {
    replicas: usize,
    shared: bool,
    soften: bool,
}

struct MinimaHoppingEnsemble {
    runs: Vec<MinimaHoppingRun>,
    budgets: Vec<usize>,
    seeds: Vec<u64>,
    charged: usize,
    minimum_count: usize,
    wall_seconds: f64,
}

fn run_minima_hopping_ensemble<W: ExactStructureWitness + Send>(
    potential: &PairPotential,
    initial: ArrayView1<'_, f64>,
    n: usize,
    budget: usize,
    seed: u64,
    witness: W,
    options: impl Into<HistoryPolicy<EnsembleOptions>>,
) -> Result<MinimaHoppingEnsemble, String> {
    let HistoryPolicy { options, exclusion } = options.into();
    if options.replicas == 0 || budget < options.replicas {
        return Err("ensemble needs positive replicas and at least one call per replica".into());
    }
    let started = Instant::now();
    let budgets = (0..options.replicas)
        .map(|replica| budget / options.replicas + usize::from(replica < budget % options.replicas))
        .collect::<Vec<_>>();
    let seeds = (0..options.replicas)
        .map(|replica| seed.wrapping_add((replica as u64).wrapping_mul(0x9e37_79b9_7f4a_7c15)))
        .collect::<Vec<_>>();
    let history_count = if options.shared { 1 } else { options.replicas };
    let tolerance = HoppingConfig::for_cluster(n).record_gradient;
    let histories = (0..history_count)
        .map(|_| {
            MinimumHistory::new(tolerance)
                .map(Mutex::new)
                .map_err(|error| error.to_string())
        })
        .collect::<Result<Vec<_>, _>>()?;
    let charged = AtomicUsize::new(0);
    // Both arms serialize foreign exact matching without serializing their PES work.
    let witness = SerializedWitness(Mutex::new(witness));
    let runs = std::thread::scope(|scope| {
        let handles = budgets
            .iter()
            .zip(&seeds)
            .enumerate()
            .map(|(replica, (&budget, &seed))| {
                let history = &histories[if options.shared { 0 } else { replica }];
                let charged = &charged;
                let witness = &witness;
                scope.spawn(move || {
                    run_minima_hopping_with_history(
                        potential,
                        initial,
                        n,
                        budget,
                        seed,
                        witness,
                        HistoryPolicy {
                            options: HistoryRunOptions {
                                moves: MinimaHoppingOptions {
                                    soften: options.soften,
                                    bound_escape: false,
                                },
                                history: Some(history),
                                charged: Some(charged),
                            },
                            exclusion,
                        },
                    )
                })
            })
            .collect::<Vec<_>>();
        handles
            .into_iter()
            .map(|handle| {
                handle
                    .join()
                    .map_err(|_| "NVE replica panicked".to_string())?
            })
            .collect::<Result<Vec<_>, String>>()
    })?;
    let charged = charged.load(Ordering::SeqCst);
    if charged != runs.iter().map(|run| run.outcome.charged).sum::<usize>() {
        return Err("ensemble and per-replica charged counters disagree".into());
    }
    let minimum_count = histories
        .iter()
        .map(|history| {
            history
                .lock()
                .map(|history| history.minimum_count())
                .map_err(|_| "minimum history lock poisoned".to_string())
        })
        .collect::<Result<Vec<_>, _>>()?
        .into_iter()
        .sum();
    Ok(MinimaHoppingEnsemble {
        runs,
        budgets,
        seeds,
        charged,
        minimum_count,
        wall_seconds: started.elapsed().as_secs_f64(),
    })
}

fn wilson_interval(hits: usize, total: usize) -> (f64, f64) {
    if total == 0 {
        return (0.0, 0.0);
    }
    let n = total as f64;
    let probability = hits as f64 / n;
    let z = 1.959_963_984_540_054_f64;
    let z2 = z * z;
    let denominator = 1.0 + z2 / n;
    let centre = (probability + z2 / (2.0 * n)) / denominator;
    let half =
        z * ((probability * (1.0 - probability) / n + z2 / (4.0 * n * n)).sqrt()) / denominator;
    ((centre - half).max(0.0), (centre + half).min(1.0))
}

fn encounter_fields(encounter: Encounter) -> (bool, usize) {
    (encounter.found(), encounter.charged())
}

fn optbench_start_path(root: &Path, n: usize, index: usize) -> Result<PathBuf, String> {
    let name = match n {
        38 if index < 100 => format!("{index}.con"),
        75 if index < 200 => format!("coords.{}", index + 1),
        98 if index <= 100 => {
            if index == 0 {
                "coords".into()
            } else {
                format!("coords.{index}")
            }
        }
        38 => return Err("OptBench LJ38 contains 100 starts indexed 0 through 99".into()),
        75 => return Err("OptBench LJ75 contains 200 starts indexed 0 through 199".into()),
        98 => return Err("OptBench LJ98 contains 101 starts indexed 0 through 100".into()),
        _ => return Err("OptBench starts are registered for LJ38, LJ75, and LJ98".into()),
    };
    Ok(root.join(name))
}

fn parse_plain_coordinates(text: &str, n: usize) -> Result<ndarray::Array1<f64>, String> {
    let coordinates = text
        .split_whitespace()
        .map(|token| {
            token
                .parse::<f64>()
                .map_err(|error| format!("invalid coordinate {token:?}: {error}"))
        })
        .collect::<Result<Vec<_>, _>>()?;
    if coordinates.len() != 3 * n || coordinates.iter().any(|value| !value.is_finite()) {
        return Err(format!(
            "OptBench start requires {} finite coordinates, found {}",
            3 * n,
            coordinates.len()
        ));
    }
    Ok(ndarray::Array1::from(coordinates))
}

fn read_optbench_start(
    root: &Path,
    n: usize,
    index: usize,
) -> Result<ndarray::Array1<f64>, String> {
    let path = optbench_start_path(root, n, index)?;
    if n == 38 {
        let frame = readcon_core::iterators::read_first_frame(&path)
            .map_err(|error| format!("read {}: {error}", path.display()))?;
        if frame.atom_data.len() != n {
            return Err(format!(
                "{} contains {} atoms, expected {n}",
                path.display(),
                frame.atom_data.len()
            ));
        }
        let coordinates = frame
            .atom_data
            .iter()
            .flat_map(|atom| [atom.x, atom.y, atom.z])
            .collect::<Vec<_>>();
        if coordinates.iter().any(|value| !value.is_finite()) {
            return Err(format!("{} contains nonfinite coordinates", path.display()));
        }
        Ok(ndarray::Array1::from(coordinates))
    } else {
        let text = std::fs::read_to_string(&path)
            .map_err(|error| format!("read {}: {error}", path.display()))?;
        parse_plain_coordinates(&text, n)
    }
}

fn optbench_archive_digest(n: usize) -> Option<&'static str> {
    match n {
        38 => Some("9e5bb818adfad67a5afd53d083a6c8afd3addc0fe81a0f57413a73c80eb74e8f"),
        75 => Some("8590a6fddf96a8673d0e4b53aae2385b5d222a9200217d722bb017d23fc5fdb3"),
        98 => Some("e3eef6bb42a8d0b9d3b760862318aabaf932133e1dd3d63b663a556cfbef6149"),
        _ => None,
    }
}

struct StartArchiveProvenance {
    expected: Option<&'static str>,
    verified: Option<&'static str>,
}

fn start_archive_provenance(n: usize, optbench: bool) -> StartArchiveProvenance {
    // A directory layout identifies an input format, not an archive's contents.
    StartArchiveProvenance {
        expected: optbench.then(|| optbench_archive_digest(n)).flatten(),
        verified: None,
    }
}

fn start_protocol_name(optbench: bool, fixed: bool) -> Result<&'static str, String> {
    match (optbench, fixed) {
        (false, false) => Ok("random-cluster"),
        (true, false) => Ok("optbench-fixed"),
        (false, true) => Ok("fixed-coordinate-file"),
        (true, true) => Err("OptBench and fixed-coordinate starts are mutually exclusive".into()),
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    let arguments = std::env::args().collect::<Vec<_>>();
    let n = arguments
        .get(1)
        .and_then(|value| value.parse().ok())
        .unwrap_or(38);
    let budget = arguments
        .get(2)
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap_or(100_000);
    let seeds = arguments
        .get(3)
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap_or(8);
    let selector = arguments.get(4).map(String::as_str).unwrap_or("all");
    let irc_selector = arguments.get(5).map(String::as_str).unwrap_or("gs2");
    let seed0: u64 = arguments
        .get(6)
        .and_then(|value| value.parse().ok())
        .unwrap_or(0);
    let optbench_root = std::env::var_os("ANNEAL_OPTBENCH_STARTS").map(PathBuf::from);
    let fixed_path = std::env::var_os("ANNEAL_START_COORDINATES").map(PathBuf::from);
    if n < 2 || budget == 0 || seeds == 0 {
        return Err("N must be at least two and budget/seeds must be positive".into());
    }
    let start_protocol = start_protocol_name(optbench_root.is_some(), fixed_path.is_some())?;
    let archive_provenance = start_archive_provenance(n, optbench_root.is_some());
    let fixed_initial = fixed_path
        .as_ref()
        .map(|path| {
            let contents = std::fs::read_to_string(path)
                .map_err(|error| format!("read {}: {error}", path.display()))?;
            parse_plain_coordinates(&contents, n)
        })
        .transpose()?;
    let target = reference(n).ok_or("no published LJ target is registered for this size")?;
    let arms = selected_arms(selector, &irc_kinds(irc_selector)?)?;
    let replicas =
        std::env::var("ANNEAL_MH_REPLICAS").map_or(Ok(4), |value| value.parse::<usize>())?;
    let pair_cache_bytes = std::env::var("ANNEAL_MH_PAIR_CACHE_BYTES")
        .map_or(Ok(128 * 1024 * 1024), |value| value.parse::<usize>())?;
    let history_exclusion =
        parse_history_exclusion(std::env::var("ANNEAL_MH_HISTORY_POLICY").ok().as_deref())?;
    let descriptor_space = lj::descriptor_space();
    let potential = PairPotential::lennard_jones(n);
    let witness = IraStructureWitness {
        kmax_factor: if n >= 55 { 2.5 } else { 1.8 },
        radius: lj::CALIBRATION_IRA_TOLERANCE,
    };
    let system = AtomisticSystem {
        species: vec![18; n],
        masses: vec![1.0; n],
        frozen_atoms: vec![false; n],
        identity_domain: format!("lj-reduced-n{n}"),
    };
    let hopping = HoppingConfig::for_cluster(n);
    let mut summaries = (0..arms.len())
        .map(|_| Summary::default())
        .collect::<Vec<_>>();

    println!(
        "{}",
        json!({
            "kind": "lj_joint_optimum_config",
            "n": n,
            "budget": budget,
            "seeds": seeds,
            "seed0": seed0,
            "target": target,
            "target_tolerance": TARGET_TOLERANCE,
            "start_protocol": start_protocol,
            "fixed_coordinates": fixed_initial.as_ref().map(|state| state.to_vec()),
            "start_archive_sha256": archive_provenance.verified,
            "expected_start_archive_sha256": archive_provenance.expected,
            "start_archive_verified": archive_provenance.verified.is_some(),
            "nve_ensemble": {
                "replicas": replicas,
                "budget_semantics": "aggregate-per-ensemble",
                "start_semantics": "common-matched-coordinates",
                "exchange": "validated-minimum-history-only",
                "exact_witness": "serialized-in-both-arms",
                "pair_cache_payload_bytes": pair_cache_bytes,
                "pair_cache_scope": "per-ensemble-coordinate-content",
                "history_policy": history_exclusion.name(),
            },
            "minima_hopping": {
                "integrator": "rgsaddle-samd-nve",
                "dt": 0.005,
                "path_minima": 2,
                "initial_kinetic": hopping.energy_scale,
                "initial_ediff": 0.5 * hopping.energy_scale,
                "beta": 1.05,
                "enhanced_visit_coefficient": 0.1,
                "softening": {
                    "arm": "minima-hopping-softened",
                    "steps": MH_SOFTENING_STEPS,
                    "displacement": MH_SOFTENING_DISPLACEMENT,
                    "mixing": MH_SOFTENING_MIXING,
                },
            },
            "continuous_symmetry": {
                "arm": "basin-hopping-csm-ci",
                "group": "Ci",
                "interval": CSM_INTERVAL,
                "assignment": "minimum-cost-bijection",
                "orientation": "rotation-independent",
                "adoption": "downhill",
            },
            "arms": arms.iter().copied().map(|arm| arm.label_with_history(history_exclusion)).collect::<Vec<_>>(),
        })
    );

    for seed in seed0..seed0.saturating_add(seeds) {
        let initial = if let Some(fixed) = &fixed_initial {
            fixed.clone()
        } else if let Some(root) = optbench_root.as_deref() {
            read_optbench_start(
                root,
                n,
                usize::try_from(seed).map_err(|_| "seed index overflow")?,
            )?
        } else {
            let mut initial_rng =
                StdRng::seed_from_u64(seed.wrapping_mul(0x9e37_79b9_7f4a_7c15).wrapping_add(7));
            random_cluster(n, 0.7, hopping.min_separation, &mut initial_rng)
        };
        for (arm_index, arm) in arms.iter().copied().enumerate() {
            let label = arm.label_with_history(history_exclusion);
            match arm {
                Arm::MinimaHoppingEnsemble { shared, soften } => {
                    let ensemble = run_minima_hopping_ensemble(
                        &potential,
                        initial.view(),
                        n,
                        usize::try_from(budget).map_err(|_| "ensemble budget overflow")?,
                        seed,
                        IraStructureWitness {
                            kmax_factor: witness.kmax_factor,
                            radius: witness.radius,
                        }
                        .with_pair_cache(pair_cache_bytes),
                        HistoryPolicy {
                            options: EnsembleOptions {
                                replicas,
                                shared,
                                soften,
                            },
                            exclusion: history_exclusion,
                        },
                    )?;
                    let first = ensemble
                        .runs
                        .iter()
                        .flat_map(|run| {
                            run.aggregate_improvements
                                .iter()
                                .zip(&run.outcome.improvements)
                                .map(|((charged, energy), (hops, _, _, _))| {
                                    (*charged, *energy, *hops)
                                })
                        })
                        .filter(|(_, energy, _)| *energy <= target + TARGET_TOLERANCE)
                        .min_by_key(|(charged, _, _)| *charged);
                    let encounter = first.map_or(
                        Encounter::Censored {
                            charged: ensemble.charged,
                        },
                        |(charged, _, hops)| Encounter::Found { charged, hops },
                    );
                    let best = ensemble
                        .runs
                        .iter()
                        .map(|run| run.outcome.best)
                        .fold(f64::INFINITY, f64::min);
                    let failures = ensemble
                        .runs
                        .iter()
                        .map(|run| run.outcome.unconverged_records)
                        .sum();
                    println!(
                        "{}",
                        json!({
                            "kind": "lj_joint_optimum_ensemble",
                            "arm": label, "seed": seed, "target_found": first.is_some(),
                            "history_policy": history_exclusion.name(),
                            "first_aggregate_charged": first.map(|(charged, _, _)| charged),
                            "first_replica_hop": first.map(|(_, _, hops)| hops),
                            "charged": ensemble.charged,
                            "best_energy": best, "gap": best - target,
                            "minimum_count": ensemble.minimum_count,
                            "minimum_count_semantics": if shared { "shared-exact-identities" } else { "sum-private-identities" },
                            "wall_seconds": ensemble.wall_seconds,
                            "replicas": ensemble.runs.iter().enumerate().map(|(replica, run)| json!({
                                "replica": replica, "seed": ensemble.seeds[replica],
                                "budget": ensemble.budgets[replica], "charged": run.outcome.charged,
                                "best_energy": run.outcome.best, "hops": run.outcome.hops,
                                "best_coordinates": run.outcome.best_state.as_ref().map(|state| state.to_vec()),
                                "minima": run.outcome.basins, "accepted": run.outcome.accepted,
                                "visit_counts": run.outcome.visit_counts,
                                "failed_actions": run.outcome.unconverged_records,
                                "escape_kinetic": run.outcome.escape_scale,
                                "acceptance_threshold": run.outcome.escape_threshold,
                                "final_time_step": run.final_time_step,
                                "initial_quench_calls": run.initial_quench_calls,
                                "dynamics_calls": run.dynamics_calls,
                                "dynamics_steps": run.dynamics_steps,
                                "proposal_quench_calls": run.proposal_quench_calls,
                                "history_seconds": run.history_seconds,
                                "aggregate_improvements": run.aggregate_improvements,
                            })).collect::<Vec<_>>(),
                        })
                    );
                    summaries[arm_index].observe(
                        encounter,
                        best,
                        ensemble.charged as u64,
                        ensemble.minimum_count,
                        0,
                        failures,
                    );
                }
                Arm::Adaptive(irc_kind) | Arm::Ridge(irc_kind) => {
                    let policy = if matches!(arm, Arm::Adaptive(_)) {
                        AtomisticHybridPolicy::Adaptive
                    } else {
                        AtomisticHybridPolicy::RidgeOnly
                    };
                    let report = explore_atomistic_with_policy(
                        &potential,
                        &descriptor_space,
                        initial.view(),
                        &system,
                        &hybrid_config(n, budget, irc_kind),
                        &witness,
                        seed,
                        policy,
                    )?;
                    let best = report.best_energy().unwrap_or(f64::INFINITY);
                    let encounter = report.first_encounter(target, TARGET_TOLERANCE);
                    let failures = report
                        .events
                        .iter()
                        .filter(|event| !event.converged)
                        .count();
                    let (found, first_charged) = encounter_fields(encounter);
                    println!(
                        "{}",
                        json!({
                            "kind": "lj_joint_optimum_run",
                            "arm": label,
                            "seed": seed,
                            "best_energy": best,
                            "gap": best - target,
                            "target_found": found,
                            "first_charged": first_charged,
                            "charged": report.charged_evaluations,
                            "minima": report.network.minimum_count(),
                            "saddles": report.network.saddle_count(),
                            "unresolved_saddles": report.network.unresolved_saddles().len(),
                            "events": report.events.len(),
                            "ridge_pulls": report.mechanism_pulls[0],
                            "basin_pulls": report.mechanism_pulls[1],
                            "failed_actions": failures,
                            "termination": format!("{:?}", report.termination),
                        })
                    );
                    summaries[arm_index].observe(
                        encounter,
                        best,
                        report.charged_evaluations,
                        report.network.minimum_count(),
                        report.network.saddle_count(),
                        failures,
                    );
                }
                Arm::Basin => {
                    let report = explore_atomistic_with_policy(
                        &potential,
                        &descriptor_space,
                        initial.view(),
                        &system,
                        &hybrid_config(n, budget, IrcKind::Gs2),
                        &witness,
                        seed,
                        AtomisticHybridPolicy::BasinEscapeOnly,
                    )?;
                    let best = report.best_energy().unwrap_or(f64::INFINITY);
                    let encounter = report.first_encounter(target, TARGET_TOLERANCE);
                    let failures = report
                        .events
                        .iter()
                        .filter(|event| !event.converged)
                        .count();
                    let (found, first_charged) = encounter_fields(encounter);
                    println!(
                        "{}",
                        json!({
                            "kind": "lj_joint_optimum_run",
                            "arm": label,
                            "seed": seed,
                            "best_energy": best,
                            "gap": best - target,
                            "target_found": found,
                            "first_charged": first_charged,
                            "charged": report.charged_evaluations,
                            "minima": report.network.minimum_count(),
                            "saddles": 0,
                            "events": report.events.len(),
                            "ridge_pulls": 0,
                            "basin_pulls": report.mechanism_pulls[1],
                            "failed_actions": failures,
                            "termination": format!("{:?}", report.termination),
                        })
                    );
                    summaries[arm_index].observe(
                        encounter,
                        best,
                        report.charged_evaluations,
                        report.network.minimum_count(),
                        0,
                        failures,
                    );
                }
                Arm::BasinHopping
                | Arm::BasinHoppingSymmetry
                | Arm::BasinHoppingCsmCi
                | Arm::MinimaHopping
                | Arm::MinimaHoppingSoftened
                | Arm::MinimaHoppingBounded
                | Arm::MinimaHoppingBoundedSoftened
                | Arm::MinimaFeedback => {
                    let budget = usize::try_from(budget).unwrap_or(usize::MAX);
                    let minima_hopping = matches!(
                        arm,
                        Arm::MinimaHopping
                            | Arm::MinimaHoppingSoftened
                            | Arm::MinimaHoppingBounded
                            | Arm::MinimaHoppingBoundedSoftened
                    );
                    let softened = matches!(
                        arm,
                        Arm::MinimaHoppingSoftened | Arm::MinimaHoppingBoundedSoftened
                    );
                    let bound_escape = matches!(
                        arm,
                        Arm::MinimaHoppingBounded | Arm::MinimaHoppingBoundedSoftened
                    );
                    let (outcome, minima_hopping_work) = if minima_hopping {
                        let run = run_minima_hopping(
                            &potential,
                            initial.view(),
                            n,
                            budget,
                            seed,
                            &witness,
                            MinimaHoppingOptions {
                                soften: softened,
                                bound_escape,
                            },
                        );
                        let work = json!({
                            "initial_quench_calls": run.initial_quench_calls,
                            "dynamics_calls": run.dynamics_calls,
                            "dynamics_steps": run.dynamics_steps,
                            "proposal_quench_calls": run.proposal_quench_calls,
                            "final_time_step": run.final_time_step,
                            "history_seconds": run.history_seconds,
                            "aggregate_improvements": run.aggregate_improvements,
                        });
                        (run.outcome, Some(work))
                    } else {
                        (
                            run_hopping(
                                &potential,
                                initial.view(),
                                n,
                                budget,
                                seed,
                                HoppingMoves {
                                    minima_hopping: matches!(arm, Arm::MinimaFeedback),
                                    symmetrise_on_stall: matches!(arm, Arm::BasinHoppingSymmetry),
                                    continuous_symmetry: if matches!(arm, Arm::BasinHoppingCsmCi) {
                                        ContinuousSymmetry::Inversion {
                                            interval: CSM_INTERVAL,
                                        }
                                    } else {
                                        ContinuousSymmetry::Off
                                    },
                                },
                            ),
                            None,
                        )
                    };
                    let encounter =
                        first_encounter(&outcome, target, TARGET_TOLERANCE, outcome.charged);
                    let (found, first_charged) = encounter_fields(encounter);
                    println!(
                        "{}",
                        json!({
                            "kind": "lj_joint_optimum_run",
                            "arm": label,
                            "seed": seed,
                            "best_energy": outcome.best,
                            "gap": outcome.best - target,
                            "target_found": found,
                            "first_charged": first_charged,
                            "charged": outcome.charged,
                            "minima": outcome.basins,
                            "saddles": 0,
                            "hops": outcome.hops,
                            "accepted": outcome.accepted,
                            "escape_kinetic_or_scale": outcome.escape_scale,
                            "escape_bounded": bound_escape,
                            "velocity_softened": softened,
                            "acceptance_threshold": outcome.escape_threshold,
                            "visit_counts": outcome.visit_counts,
                            "minima_hopping_work": minima_hopping_work,
                            "symmetrised_attempts": outcome.symmetrised.0,
                            "symmetry_energy_gain": outcome.symmetrised.1,
                            "continuous_symmetry_attempts": outcome.continuous_symmetry.0,
                            "continuous_symmetry_energy_gain": outcome.continuous_symmetry.1,
                            "failed_actions": outcome.unconverged_records,
                        })
                    );
                    summaries[arm_index].observe(
                        encounter,
                        outcome.best,
                        outcome.charged as u64,
                        outcome.basins,
                        0,
                        outcome.unconverged_records,
                    );
                }
            }
        }
    }

    for (arm, summary) in arms.iter().copied().zip(&summaries) {
        let total = summary.encounters.len();
        let hits = summary
            .encounters
            .iter()
            .filter(|encounter| encounter.found())
            .count();
        let (hit_low, hit_high) = wilson_interval(hits, total);
        println!(
            "{}",
            json!({
                "kind": "lj_joint_optimum_summary",
                "arm": arm.label_with_history(history_exclusion),
                "runs": total,
                "hits": hits,
                "hit_probability": hits as f64 / total as f64,
                "hit_probability_wilson95": [hit_low, hit_high],
                "km_median_first_charged": median_encounter(&summary.encounters),
                "deepest_energy": summary.deepest,
                "deepest_gap": summary.deepest - target,
                "mean_charged": summary.charged as f64 / total as f64,
                "mean_minima": summary.minima as f64 / total as f64,
                "mean_saddles": summary.saddles as f64 / total as f64,
                "mean_failed_actions": summary.failures as f64 / total as f64,
            })
        );
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{
        Arm, ExactStructureWitness, MinimaHoppingOptions, PairPotential, optbench_start_path,
        parse_plain_coordinates, run_minima_hopping, selected_arms,
    };
    use ndarray::{Array1, ArrayView1};
    use std::path::Path;

    struct DistinctWitness;

    impl ExactStructureWitness for DistinctWitness {
        fn equivalent(&self, _left: ArrayView1<f64>, _right: ArrayView1<f64>) -> bool {
            false
        }
    }

    #[test]
    fn optbench_paths_follow_each_published_archive_layout() {
        let root = Path::new("/corpus");
        assert_eq!(
            optbench_start_path(root, 38, 7).unwrap(),
            root.join("7.con")
        );
        assert_eq!(
            optbench_start_path(root, 75, 0).unwrap(),
            root.join("coords.1")
        );
        assert_eq!(
            optbench_start_path(root, 98, 0).unwrap(),
            root.join("coords")
        );
        assert_eq!(
            optbench_start_path(root, 98, 100).unwrap(),
            root.join("coords.100")
        );
    }

    #[test]
    fn plain_optbench_coordinates_require_one_finite_triplet_per_atom() {
        let parsed = parse_plain_coordinates("0 1 2\n3 4 5\n", 2).unwrap();
        assert_eq!(parsed.as_slice().unwrap(), &[0.0, 1.0, 2.0, 3.0, 4.0, 5.0]);
        assert!(parse_plain_coordinates("0 1 2", 2).is_err());
        assert!(parse_plain_coordinates("0 1 NaN\n3 4 5", 2).is_err());
    }

    #[test]
    fn minima_hopping_selector_names_the_md_escape_algorithm() {
        let arms = selected_arms("mh", &[]).unwrap();

        assert!(matches!(arms.as_slice(), [Arm::MinimaHopping]));
        assert_eq!(arms[0].label(), "minima-hopping");
    }

    #[test]
    fn softened_selector_is_a_distinct_minima_hopping_arm() {
        let arms = selected_arms("mh-soft", &[]).unwrap();

        assert!(matches!(arms.as_slice(), [Arm::MinimaHoppingSoftened]));
        assert_eq!(arms[0].label(), "minima-hopping-softened");
    }

    #[test]
    fn bounded_soft_selector_names_the_cost_controlled_nve_arm() {
        let arms = selected_arms("mh-bounded-soft", &[]).unwrap();

        assert!(matches!(
            arms.as_slice(),
            [Arm::MinimaHoppingBoundedSoftened]
        ));
        assert_eq!(arms[0].label(), "minima-hopping-bounded-softened");
    }

    #[test]
    fn symmetry_selector_names_the_existing_stall_projection_arm() {
        let arms = selected_arms("bh-sym", &[]).unwrap();

        assert!(matches!(arms.as_slice(), [Arm::BasinHoppingSymmetry]));
        assert_eq!(arms[0].label(), "basin-hopping-stall-symmetry");
    }

    #[test]
    fn continuous_symmetry_selector_names_the_ci_csm_algorithm() {
        let arms = selected_arms("bh-csm-ci", &[]).unwrap();

        assert!(matches!(arms.as_slice(), [Arm::BasinHoppingCsmCi]));
        assert_eq!(arms[0].label(), "basin-hopping-csm-ci");
    }

    #[test]
    fn exhausted_initial_quench_cannot_report_zero_as_a_minimum() {
        let potential = PairPotential::lennard_jones(2);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, 1.2, 0.0, 0.0]);

        let run = run_minima_hopping(
            &potential,
            initial.view(),
            2,
            0,
            7,
            &DistinctWitness,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );

        assert_eq!(run.outcome.best, f64::INFINITY);
        assert!(run.outcome.best_state.is_none());
        assert_eq!(run.outcome.charged, 0);
    }

    #[test]
    fn a_single_call_certifies_an_already_minimized_start() {
        let potential = PairPotential::lennard_jones(2);
        let distance = 2.0_f64.powf(1.0 / 6.0);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, distance, 0.0, 0.0]);
        let run = run_minima_hopping(
            &potential,
            initial.view(),
            2,
            1,
            7,
            &DistinctWitness,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );

        assert!((run.outcome.best + 1.0).abs() < 1e-12);
        assert_eq!(run.outcome.charged, 1);
        assert_eq!(run.initial_quench_calls, 1);
        assert_eq!(run.dynamics_calls, 0);
        assert_eq!(run.outcome.best_state.as_ref(), Some(&initial));
    }

    #[test]
    fn minima_hopping_accounts_for_adaptive_escape_work_by_stage() {
        let potential = PairPotential::lennard_jones(2);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, 1.2, 0.0, 0.0]);

        let run = run_minima_hopping(
            &potential,
            initial.view(),
            2,
            2_000,
            7,
            &DistinctWitness,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );

        assert_eq!(
            run.initial_quench_calls + run.dynamics_calls + run.proposal_quench_calls,
            run.outcome.charged
        );
        assert!(run.dynamics_steps > 0);
        assert_ne!(run.final_time_step, 0.005);
    }

    #[test]
    fn minima_hopping_bootstrap_establishes_a_minimum_within_the_available_budget() {
        use rand::{SeedableRng, rngs::StdRng};

        let n = 75;
        let config = super::HoppingConfig::for_cluster(n);
        let mut initial_rng = StdRng::seed_from_u64(7);
        let initial = super::random_cluster(n, 0.7, config.min_separation, &mut initial_rng);
        let potential = PairPotential::lennard_jones(n);
        let budget = 4_000;

        let run = run_minima_hopping(
            &potential,
            initial.view(),
            n,
            budget,
            0,
            &DistinctWitness,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );

        assert!(
            run.outcome.best.is_finite(),
            "bootstrap must establish a minimum"
        );
        assert!(run.initial_quench_calls > config.relax_steps);
        assert!(
            run.dynamics_calls > 0,
            "available work must reach the escape operator"
        );
        assert!(run.outcome.charged <= budget);
        assert_eq!(
            run.initial_quench_calls + run.dynamics_calls + run.proposal_quench_calls,
            run.outcome.charged
        );
    }

    #[test]
    fn a_private_history_preserves_the_nve_trajectory_and_counts_every_call() {
        use std::sync::{Mutex, atomic::AtomicUsize, atomic::Ordering};

        let potential = PairPotential::lennard_jones(2);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, 1.2, 0.0, 0.0]);
        let local = run_minima_hopping(
            &potential,
            initial.view(),
            2,
            2_000,
            7,
            &DistinctWitness,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );
        let history = Mutex::new(super::MinimumHistory::new(1e-3).unwrap());
        let charged = AtomicUsize::new(0);
        let observed = super::run_minima_hopping_with_history(
            &potential,
            initial.view(),
            2,
            2_000,
            7,
            &DistinctWitness,
            super::HistoryRunOptions {
                moves: MinimaHoppingOptions {
                    soften: false,
                    bound_escape: false,
                },
                history: Some(&history),
                charged: Some(&charged),
            },
        )
        .unwrap();

        assert_eq!(observed.outcome.best, local.outcome.best);
        assert_eq!(observed.outcome.final_state, local.outcome.final_state);
        assert_eq!(observed.outcome.accepted, local.outcome.accepted);
        assert_eq!(observed.outcome.visit_counts, local.outcome.visit_counts);
        assert_eq!(observed.dynamics_steps, local.dynamics_steps);
        assert_eq!(observed.outcome.charged, local.outcome.charged);
        assert_eq!(charged.load(Ordering::SeqCst), observed.outcome.charged);
        assert!(history.lock().unwrap().total_visits() > 0);
    }

    #[test]
    fn an_unconverged_bootstrap_does_not_publish_shared_history() {
        use std::sync::Mutex;

        let potential = PairPotential::lennard_jones(2);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, 1.2, 0.0, 0.0]);
        let history = Mutex::new(super::MinimumHistory::new(1e-3).unwrap());
        let run = super::run_minima_hopping_with_history(
            &potential,
            initial.view(),
            2,
            1,
            7,
            &DistinctWitness,
            super::HistoryRunOptions {
                moves: MinimaHoppingOptions {
                    soften: false,
                    bound_escape: false,
                },
                history: Some(&history),
                charged: None,
            },
        )
        .unwrap();

        assert_eq!(run.outcome.best, f64::INFINITY);
        assert_eq!(run.outcome.charged, 1);
        assert_eq!(history.lock().unwrap().total_visits(), 0);
    }

    #[test]
    fn communicating_replicas_share_identity_without_copying_states_or_multiplying_budget() {
        struct EqualWitness;
        impl super::ExactStructureWitness for EqualWitness {
            fn equivalent(
                &self,
                left: ndarray::ArrayView1<f64>,
                right: ndarray::ArrayView1<f64>,
            ) -> bool {
                left == right
            }
        }

        let potential = PairPotential::lennard_jones(2);
        let distance = 2.0_f64.powf(1.0 / 6.0);
        let initial = Array1::from(vec![0.0, 0.0, 0.0, distance, 0.0, 0.0]);
        for shared in [false, true] {
            let ensemble = super::run_minima_hopping_ensemble(
                &potential,
                initial.view(),
                2,
                3,
                7,
                EqualWitness,
                super::EnsembleOptions {
                    replicas: 2,
                    shared,
                    soften: false,
                },
            )
            .unwrap();

            assert_eq!(ensemble.charged, 3);
            assert_eq!(ensemble.budgets, vec![2, 1]);
            assert_eq!(ensemble.runs.len(), 2);
            assert_eq!(ensemble.minimum_count, if shared { 1 } else { 2 });
            assert_eq!(
                ensemble
                    .runs
                    .iter()
                    .map(|run| run.outcome.charged)
                    .sum::<usize>(),
                3
            );
            for run in ensemble.runs {
                assert_eq!(run.outcome.final_state.as_ref(), Some(&initial));
                assert_eq!(run.outcome.accepted, 0);
                assert!((run.outcome.best + 1.0).abs() < 1e-12);
            }
        }
    }

    #[test]
    fn communication_selector_pairs_shared_and_private_history() {
        let arms = selected_arms("mh-communication", &[]).unwrap();
        let labels = arms.into_iter().map(|arm| arm.label()).collect::<Vec<_>>();
        assert_eq!(
            labels,
            vec![
                "minima-hopping-private-history",
                "minima-hopping-shared-history"
            ]
        );
    }

    #[test]
    fn fixed_coordinates_have_explicit_provenance_and_cannot_impersonate_optbench() {
        assert_eq!(
            super::start_protocol_name(false, false).unwrap(),
            "random-cluster"
        );
        assert_eq!(
            super::start_protocol_name(true, false).unwrap(),
            "optbench-fixed"
        );
        assert_eq!(
            super::start_protocol_name(false, true).unwrap(),
            "fixed-coordinate-file"
        );
        assert!(super::start_protocol_name(true, true).is_err());
    }

    #[test]
    fn unresolved_nve_actions_do_not_count_as_verified_basin_visits() {
        use rand::SeedableRng;

        struct OneBasin;
        impl ExactStructureWitness for OneBasin {
            fn equivalent(&self, _: ArrayView1<f64>, _: ArrayView1<f64>) -> bool {
                true
            }
        }
        let n = 75;
        let potential = PairPotential::lennard_jones(n);
        let mut rng = rand::rngs::StdRng::seed_from_u64(7);
        let hopping = super::HoppingConfig::for_cluster(n);
        let start = super::random_cluster(n, 0.7, hopping.min_separation, &mut rng);
        let run = super::run_minima_hopping(
            &potential,
            start.view(),
            n,
            50_000,
            0,
            &OneBasin,
            MinimaHoppingOptions {
                soften: false,
                bound_escape: false,
            },
        );
        let outcome = run.outcome;
        let (same, known, new) = outcome.visit_counts;
        assert!(
            outcome.unconverged_records > 1,
            "the fixture exercises failed proposals"
        );
        assert!(
            same + known + new + outcome.unconverged_records <= outcome.hops,
            "failed proposals cannot simultaneously be verified visits: {:?}",
            (
                outcome.visit_counts,
                outcome.unconverged_records,
                outcome.hops
            )
        );
        assert_eq!(known, 0);
        assert_eq!(new, 0);
        assert_eq!(outcome.charged, 50_000);
    }

    #[test]
    fn observed_exclusion_retains_the_all_observation_feedback_policy() {
        use super::{HistoryExclusion, history_feedback_membership};

        let mut accepted = super::EscapeFeedback::new(1.0, 0.8);
        let mut observed = super::EscapeFeedback::new(1.0, 0.8);
        accepted.register_initial(0);
        observed.register_initial(0);
        let mut accepted_trials = 0;
        let mut observed_trials = 0;
        for visit_number in 1..=6 {
            let first_observation = visit_number == 1;
            let (is_new, visits) = history_feedback_membership(
                HistoryExclusion::Accepted,
                first_observation,
                visit_number,
                0,
            );
            assert_eq!(
                accepted.observe_shared(Some(0), 1, is_new, visits),
                super::Visit::New
            );
            accepted_trials += 1;
            assert_eq!(accepted.accept(1.0), visit_number == 6);

            let (is_new, visits) = history_feedback_membership(
                HistoryExclusion::Observed,
                first_observation,
                visit_number,
                0,
            );
            let before = observed.threshold();
            let classification = observed.observe_shared(Some(0), 1, is_new, visits);
            if first_observation {
                assert_eq!(classification, super::Visit::New);
                observed_trials += 1;
                assert!(!observed.accept(1.0));
            } else {
                assert_eq!(classification, super::Visit::Known);
                assert_eq!(observed.threshold(), before);
            }
        }
        assert_eq!(accepted_trials, 6);
        assert_eq!(observed_trials, 1);
        assert_eq!(
            history_feedback_membership(HistoryExclusion::Accepted, false, 9, 2),
            (false, 2)
        );
        assert_eq!(
            history_feedback_membership(HistoryExclusion::Observed, false, 9, 2),
            (false, 9)
        );
    }

    #[test]
    fn an_expected_archive_digest_is_not_a_verified_input_digest() {
        let declared = super::start_archive_provenance(75, true);
        assert_eq!(
            declared.expected,
            Some("8590a6fddf96a8673d0e4b53aae2385b5d222a9200217d722bb017d23fc5fdb3")
        );
        assert_eq!(declared.verified, None);
        let diagnostic = super::start_archive_provenance(75, false);
        assert_eq!(diagnostic.expected, None);
        assert_eq!(diagnostic.verified, None);
    }

    #[test]
    fn history_policy_names_are_strict_and_alternative_labels_are_distinct() {
        use super::{HistoryExclusion, parse_history_exclusion};

        assert_eq!(
            parse_history_exclusion(None).unwrap(),
            HistoryExclusion::Accepted
        );
        assert_eq!(
            parse_history_exclusion(Some("accepted")).unwrap(),
            HistoryExclusion::Accepted
        );
        assert_eq!(
            parse_history_exclusion(Some("observed-exclusion")).unwrap(),
            HistoryExclusion::Observed
        );
        assert!(parse_history_exclusion(Some("observed")).is_err());
        let arm = Arm::MinimaHoppingEnsemble {
            shared: true,
            soften: true,
        };
        assert_eq!(
            arm.label_with_history(HistoryExclusion::Accepted),
            arm.label()
        );
        assert_eq!(
            arm.label_with_history(HistoryExclusion::Observed),
            "minima-hopping-shared-history-softened-observed-exclusion"
        );
    }

    #[test]
    fn shared_first_acceptance_is_atomic_with_history_classification() {
        use std::sync::{Barrier, Mutex};

        struct SameCoordinates;
        impl ExactStructureWitness for SameCoordinates {
            fn equivalent(&self, left: ArrayView1<f64>, right: ArrayView1<f64>) -> bool {
                left == right
            }
        }
        let history = Mutex::new(super::MinimumHistory::new(1e-3).unwrap());
        let barrier = Barrier::new(2);
        let accepted = std::thread::scope(|scope| {
            let handles = (0..2)
                .map(|_| {
                    scope.spawn(|| {
                        let point = ndarray::array![0.0, 0.0, 0.0, 1.2, 0.0, 0.0];
                        let mut ledger = super::Ledger::new(1);
                        assert!(ledger.charge());
                        assert!(ledger.record_quench_boundary(
                            0,
                            -1.0,
                            point,
                            Some(Array1::zeros(6))
                        ));
                        let descriptor = super::lj::descriptor_space();
                        let context = super::StructureContext::new(Some(vec![18; 2]), None, None);
                        let mut feedback = super::EscapeFeedback::new(1.0, 0.8);
                        barrier.wait();
                        super::observe_history(
                            &history,
                            &ledger,
                            &descriptor,
                            &context,
                            &SameCoordinates,
                            |history, observation| {
                                let reached = observation.minimum.id;
                                let visits = history.accepted_visits(reached).unwrap();
                                let visit =
                                    feedback.observe_shared(None, reached, visits == 0, visits);
                                let accept = visit == super::Visit::New && feedback.accept(-1.0);
                                if accept {
                                    history.mark_accepted(reached).unwrap();
                                }
                                Ok(accept)
                            },
                        )
                        .unwrap()
                        .1
                    })
                })
                .collect::<Vec<_>>();
            handles
                .into_iter()
                .map(|handle| usize::from(handle.join().unwrap()))
                .sum::<usize>()
        });
        assert_eq!(accepted, 1);
        let history = history.lock().unwrap();
        assert_eq!(history.minimum_count(), 1);
        assert_eq!(history.accepted_count(), 1);
        assert_eq!(history.accepted_visits(0), Some(2));
        assert_eq!(history.total_visits(), 2);
    }
}
