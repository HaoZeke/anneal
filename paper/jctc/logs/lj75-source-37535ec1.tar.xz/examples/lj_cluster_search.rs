//! End-to-end cluster search on the crate's own machinery.
//!
//! Runs the Rust driver against a Lennard-Jones cluster under a charged ledger
//! and reports whether it reaches the published global minimum. The point is to
//! close the loop: everything else in this crate is checked against a unit test
//! or a synthetic spectrum, and none of that says the search finds the answer.
//!
//! Usage: `cargo run --release --example lj_cluster_search -- <n> <budget> <seeds>`

// The driver keeps charged relax/gradient callbacks and complete catalog
// evidence explicit at their call sites so campaign accounting stays visible.
#![allow(clippy::type_complexity, clippy::too_many_arguments)]

#[cfg(feature = "bank-rpc")]
#[path = "common/checkpoint_deposits.rs"]
mod checkpoint_deposits;
#[path = "common/ensemble_report.rs"]
mod ensemble_report;
#[cfg(feature = "bank-rpc")]
use checkpoint_deposits::{with_pending_bias_update, with_pending_deposits};

#[cfg(feature = "bank-rpc")]
use anneal_core::methods::cluster_hopping::BiasUpdate;

use anneal_core::bias::BasinBias;
use anneal_core::catalog::euclidean_gradient_norm;
#[cfg(feature = "bank-rpc")]
use anneal_core::catalog::{
    ACTION_EXPLORE, ACTION_LEAVE, ACTION_LOCAL, LEAVE_REFUSAL_DWELL, LeavePath,
    OccupancyLeaveTarget, credit_action, leftover_birth_probability, occupancy_complete_at,
    occupancy_is_cluster, occupancy_leave_by_birth, occupancy_retire_at, published_energy_score,
};
#[cfg(feature = "bank-rpc")]
use anneal_core::catalog::{hops_per_core_hour, leave_crossing_slices, leave_defers};
#[cfg(feature = "bank-rpc")]
use anneal_core::methods::cluster_hopping::{AcceptedTransition, run_with_bias};
use anneal_core::methods::cluster_hopping::{
    ChainCheckpoint, CheckpointAction, ClusterFingerprint, Config, Keying, LadderMode, Ledger,
    MoveLibrary, Outcome, QuenchStatus, random_cluster, run_with_bias_at_checkpoints,
};
use anneal_core::methods::csa_cluster::{self, BankConfig};
use anneal_core::methods::warm_lbfgs::WarmLbfgs;
use anneal_core::terminate::Terminator;
use ndarray::{Array1, ArrayView1};
use std::io::{self, Write};
use std::sync::{Arc, Mutex};
#[cfg(feature = "bank-rpc")]
use std::time::Instant;

#[cfg(feature = "bank-rpc")]
const EVIDENCE_ONLY_WORK_KIND: anneal_core::cooperative_search::ledger::ChargeKind =
    anneal_core::cooperative_search::ledger::ChargeKind::BasinEscape;

#[cfg(feature = "bank-rpc")]
fn unsettled_objective_calls(charged: usize, recorded: usize) -> Option<u64> {
    let remainder = charged
        .checked_sub(recorded)
        .expect("cumulative objective work cannot decrease");
    (remainder > 0).then(|| u64::try_from(remainder).expect("objective charge must fit u64"))
}

#[cfg(all(feature = "ira", any(test, not(feature = "bank-rpc"))))]
use anneal_core::shape::IraMetric;
#[cfg(feature = "ira")]
use anneal_core::shape::IraStructureWitness;

fn apply_boolean_options(cfg: &mut Config, opts: &[&str]) {
    for option in opts {
        assert!(
            matches!(
                *option,
                // The paper's control arm. It sets nothing: naming it leaves
                // the plain Wales-Doye `for_cluster` protocol in place, and it
                // stays accepted so the deposited `lj*_base_*.out` campaigns
                // can be reproduced by the command line that produced them.
                "base"
                    | "rec"
                    | "askmc"
                    | "shape"
                    | "bfwt"
                    | "thompson"
                    | "height"
                    | "noheight"
                    | "climb"
                    | "noclimb"
                    | "sym"
                    | "nosym"
                    | "csa"
                    | "corekey"
                    | "reocc"
                    | "coreclass"
                    | "twophase"
                    | "aniso"
                    | "surfaces"
                    | "path"
                    | "trail"
                    | "rscreen"
                    | "soapclass"
                    | "soapmean"
                    | "mh"
                    | "mhmd"
                    | "orbit"
                    | "recognition"
                    | "comm"
                    | "communicating"
                    | "calib"
                    | "restart"
                    | "angular"
                    | "psym"
                    | "psymnew"
                    | "novel"
                    | "sbkey"
                    | "repel"
                    | "jump"
                    | "psymall"
                    | "tabu"
                    | "bayes"
                    | "flat"
                    | "stemp"
                    | "ebias"
                    | "visit"
                    | "reseed"
                    | "selfseed"
                    | "learncon"
                    | "lean"
                    | "burst"
                    | "hollow"
                    | "fill"
                    | "twin"
                    | "gtwin"
                    | "depth"
                    | "softsub"
                    | "covper"
                    | "staged"
                    | "ctx"
                    | "sites"
                    | "canon"
                    | "indep"
                    | "nrpt"
                    | "rpt"
                    | "ptt"
                    | "pt"
                    | "rungbias"
                    | "bank"
                    | "acq"
                    | "early"
                    | "catalog"
            ),
            "unknown search mechanism: {option}"
        );
    }
    let height = opts.contains(&"height");
    let noheight = opts.contains(&"noheight");
    assert!(
        !(height && noheight),
        "height and noheight are contradictory"
    );
    cfg.adaptive_height = (cfg.adaptive_height || height) && !noheight;

    let climb = opts.contains(&"climb");
    let noclimb = opts.contains(&"noclimb");
    assert!(!(climb && noclimb), "climb and noclimb are contradictory");
    cfg.escape_on_stall = (cfg.escape_on_stall || climb) && !noclimb;

    let sym = opts.contains(&"sym");
    let nosym = opts.contains(&"nosym");
    assert!(!(sym && nosym), "sym and nosym are contradictory");
    cfg.symmetrise_on_stall = (cfg.symmetrise_on_stall || sym) && !nosym;
}

/// Occupancy catalog: leftover-SOAP packing key plus AS-KMC height
/// on the occupied well. Not the paper-budget recommended hop, and
/// not applied on CATALOG_RPC startup.
#[cfg(test)]
fn apply_occupancy_superbasin(cfg: &mut Config, n: usize) {
    let sb = Config::packing_superbasin(n);
    cfg.adaptive_height = sb.adaptive_height;
    cfg.height_revisits = sb.height_revisits;
    cfg.keying = sb.keying;
    cfg.merge_radius = sb.merge_radius;
    // Landfold aims in the packing book. A raw quench is the identity
    // projector onto the occupied funnel, so the aim is undone. The
    // diameter first phase reweights catchment; the portfolio keeps
    // the plain surface as an arm. Kappa 0.7 is the measured fastest
    // relative cutoff that still crosses on 38 and 75.
    if cfg.surfaces.is_empty() && cfg.two_phase.is_none() {
        cfg.surfaces = vec![anneal_core::methods::two_phase::TwoPhase::relative(
            0.7, 1.0,
        )];
    }
}

/// Lennard-Jones value and gradient in reduced units, no cutoff.
fn lj(x: ArrayView1<f64>) -> (f64, Array1<f64>) {
    let n = x.len() / 3;
    let mut e = 0.0;
    let mut g = Array1::zeros(x.len());
    for i in 0..n {
        for j in (i + 1)..n {
            let d = [
                x[3 * i] - x[3 * j],
                x[3 * i + 1] - x[3 * j + 1],
                x[3 * i + 2] - x[3 * j + 2],
            ];
            let r2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
            let inv2 = 1.0 / r2;
            let inv6 = inv2 * inv2 * inv2;
            let inv12 = inv6 * inv6;
            e += 4.0 * (inv12 - inv6);
            let coef = 24.0 * inv2 * (2.0 * inv12 - inv6);
            for k in 0..3 {
                g[3 * i + k] -= coef * d[k];
                g[3 * j + k] += coef * d[k];
            }
        }
    }
    (e, g)
}

#[cfg(all(feature = "bank-rpc", feature = "ira"))]
struct LjRideSurface;

#[cfg(all(feature = "bank-rpc", feature = "ira"))]
impl anneal_core::pes_exploration::PesSurface for LjRideSurface {
    type Error = std::convert::Infallible;

    fn evaluate(
        &self,
        coordinates: ArrayView1<'_, f64>,
    ) -> Result<(f64, Array1<f64>), Self::Error> {
        Ok(lj(coordinates))
    }
}

#[cfg(test)]
mod option_tests {
    use super::*;

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn evidence_only_work_kind_accepts_charged_objective_calls() {
        let mut run = anneal_core::cooperative_search::CooperativeRun::new([0], 1_000).unwrap();
        run.record_work(0, EVIDENCE_ONLY_WORK_KIND, 509).unwrap();
        run.record_work(0, EVIDENCE_ONLY_WORK_KIND, 491).unwrap();
        assert_eq!(run.events().last().unwrap().aggregate_charged, 1_000);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn settled_objective_work_has_no_duplicate_terminal_charge() {
        assert_eq!(unsettled_objective_calls(509, 0), Some(509));
        assert_eq!(unsettled_objective_calls(1_000, 509), Some(491));
        assert_eq!(unsettled_objective_calls(1_000, 1_000), None);
        assert_eq!(unsettled_objective_calls(0, 0), None);
        assert!(std::panic::catch_unwind(|| unsettled_objective_calls(508, 509)).is_err());
    }

    #[test]
    fn zero_step_queries_preserve_geometry_and_charge_one_objective() {
        let state = Array1::from_vec(vec![0.0, 0.0, 0.0, 1.3, 0.0, 0.0]);
        let mut ledger = Ledger::new(1);
        let (energy, returned) = evaluate_without_quenching(&mut ledger, state.view());
        assert_eq!(energy, lj(state.view()).0);
        assert_eq!(returned, state);
        assert_eq!(ledger.spent(), 1);
        assert!(ledger.quench_boundaries().is_empty());
        let (exhausted, returned) = evaluate_without_quenching(&mut ledger, state.view());
        assert_eq!(exhausted, f64::INFINITY);
        assert_eq!(returned, state);
        assert_eq!(ledger.spent(), 1);
    }

    #[test]
    fn production_zero_step_queries_bypass_surface_learning() {
        let source = include_str!("lj_cluster_search.rs");
        let callback = source
            .rsplit_once("let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {")
            .unwrap()
            .1;
        let query = callback
            .find("return evaluate_without_quenching(led, x)")
            .unwrap();
        assert!(query < callback.find("opt.forget()").unwrap());
        assert!(callback[..query].contains("if iters == 0"));
    }

    #[test]
    fn production_reports_and_learns_the_validated_objective_not_the_search_transform() {
        let source = include_str!("lj_cluster_search.rs");
        let callback = source
            .rsplit_once("let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {")
            .unwrap()
            .1;
        let callback = &callback[..callback
            .find("// The gradient the soft-mode escape needs")
            .unwrap()];
        assert!(callback.contains(".observe(screening_pass, boundary_energy, led.best)"));
        assert!(callback.contains("(boundary_energy, xr)"));
        assert!(
            callback.contains("let mut boundary_energy = f64::INFINITY"),
            "an exhausted ledger cannot certify a transformed energy as an objective value"
        );
        let charged = source.rsplit_once("fn charged(led:").unwrap().1;
        let charged = &charged[..charged.find("fn charged_noisy").unwrap()];
        assert!(
            charged.contains("led.is_diagnostic_quench()"),
            "diagnostic objectives must bypass the armed adaptive transform"
        );
    }

    #[test]
    fn unknown_mechanism_is_rejected_before_search() {
        let result = std::panic::catch_unwind(|| {
            let mut cfg = Config::recommended(75);
            apply_boolean_options(&mut cfg, &["rec", "unknown_mechanism"]);
        });
        assert!(result.is_err(), "an unknown mechanism must not label a run");
    }

    #[test]
    fn unrelated_recommended_options_preserve_default_true_mechanisms() {
        let mut cfg = Config::recommended(75);
        apply_boolean_options(&mut cfg, &["rec", "catalog"]);
        assert!(!cfg.adaptive_height);
        assert!(!cfg.escape_on_stall);
    }

    #[test]
    fn explicit_negative_options_disable_default_true_mechanisms() {
        let mut cfg = Config::recommended(75);
        apply_boolean_options(&mut cfg, &["rec", "noheight", "noclimb", "nosym"]);
        assert!(!cfg.adaptive_height);
        assert!(!cfg.escape_on_stall);
        assert!(!cfg.symmetrise_on_stall);
    }

    #[test]
    fn positive_options_add_mechanisms_to_plain_configuration() {
        let mut cfg = Config::for_cluster(75);
        apply_boolean_options(&mut cfg, &["height", "climb"]);
        assert!(cfg.adaptive_height);
        assert!(cfg.escape_on_stall);
    }

    #[test]
    fn occupancy_catalog_builds_soap_packing_superbasins() {
        let mut cfg = Config::recommended(75);
        apply_boolean_options(&mut cfg, &["rec", "catalog"]);
        apply_occupancy_superbasin(&mut cfg, 75);
        assert!(cfg.adaptive_height);
        assert_eq!(cfg.height_revisits, 20.0);
        assert_eq!(cfg.surfaces.len(), 1);
        assert!(cfg.surfaces[0].is_active());
        #[cfg(feature = "featomic")]
        assert_eq!(cfg.keying, Keying::SoapPacking);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn cooperative_policy_point_is_the_live_chain_endpoint() {
        let current = Array1::from(vec![1.0, 2.0, 3.0]);
        let (state, energy) = cooperative_policy_point(current.view(), -7.5);

        assert_eq!(state, current);
        assert_eq!(energy, -7.5);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn cooperative_population_point_is_the_post_policy_live_endpoint() {
        let transported = Array1::from(vec![4.0, 5.0, 6.0]);
        let (state, energy) = cooperative_population_point(transported.view(), -9.25);

        assert_eq!(state, transported);
        assert_eq!(energy, -9.25);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn only_the_coordinator_saddle_role_runs_a_ride() {
        use anneal_core::discovery_roster::DiscoveryRole;

        assert!(!discovery_role_allows_ride(None));
        assert!(!discovery_role_allows_ride(Some(
            DiscoveryRole::BasinEscape
        )));
        assert!(discovery_role_allows_ride(Some(DiscoveryRole::SaddleRide)));
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn committed_seam_anchor_is_applied_once_per_snapshot() {
        use anneal_core::raft::wire::ReplicaAssignment;

        let assignment = ReplicaAssignment {
            replica: 2,
            right_side: true,
            histogram_classes: Vec::new(),
            histogram_masses: Vec::new(),
            anchor_basin: 29,
            bridge_duty: false,
            decree_index: 11,
        };

        assert_eq!(
            decree_anchor_action(None, Some(&assignment), Some(7)),
            DecreeAnchorAction::Fetch {
                snapshot: 11,
                basin: 29,
            }
        );
        assert_eq!(
            decree_anchor_action(None, Some(&assignment), Some(29)),
            DecreeAnchorAction::MarkApplied {
                snapshot: 11,
                basin: 29,
            }
        );
        assert_eq!(
            decree_anchor_action(
                Some(AppliedDecree {
                    snapshot: 11,
                    basin: 29,
                }),
                Some(&assignment),
                Some(7),
            ),
            DecreeAnchorAction::Ignore
        );
        assert_eq!(
            decree_anchor_action(
                Some(AppliedDecree {
                    snapshot: 12,
                    basin: 29,
                }),
                Some(&assignment),
                Some(7),
            ),
            DecreeAnchorAction::Ignore,
            "a delayed committed decree cannot roll a chain back"
        );
        let mut unchanged_side = assignment.clone();
        unchanged_side.decree_index = 13;
        assert_eq!(
            decree_anchor_action(
                Some(AppliedDecree {
                    snapshot: 12,
                    basin: 29,
                }),
                Some(&unchanged_side),
                Some(7),
            ),
            DecreeAnchorAction::MarkApplied {
                snapshot: 13,
                basin: 29,
            },
            "new evidence for the same segment cannot restart its chain"
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn committed_decree_audit_names_the_local_assignment() {
        use anneal_core::raft::wire::{ExplorationDecree, ReplicaAssignment};

        let decree = ExplorationDecree {
            algebraic_connectivity: 0.03125,
            seam_conductance: 0.0625,
            left_basin: 11,
            right_basin: 29,
            assignments: vec![ReplicaAssignment {
                replica: 2,
                right_side: true,
                histogram_classes: Vec::new(),
                histogram_masses: Vec::new(),
                anchor_basin: 29,
                bridge_duty: true,
                decree_index: 17,
            }],
        };

        let line = committed_decree_audit_line(2, &decree).expect("local assignment");
        let value: serde_json::Value = serde_json::from_str(&line).expect("audit JSON");
        assert_eq!(value["kind"], "brain_commit");
        assert_eq!(value["replica"], 2);
        assert_eq!(value["snapshot"], 17);
        assert_eq!(value["anchor_basin"], 29);
        assert_eq!(value["right_side"], true);
        assert_eq!(value["bridge_duty"], true);
        assert_eq!(value["left_basin"], 11);
        assert_eq!(value["right_basin"], 29);
        assert_eq!(value["normalized_lambda2"], 0.03125);
        assert_eq!(value["conductance"], 0.0625);
        assert!(committed_decree_audit_line(9, &decree).is_none());

        let applied: serde_json::Value =
            serde_json::from_str(&applied_decree_audit_line(2, 17, 29)).expect("application JSON");
        assert_eq!(applied["kind"], "spectral_anchor");
        assert_eq!(applied["replica"], 2);
        assert_eq!(applied["snapshot"], 17);
        assert_eq!(applied["anchor_basin"], 29);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn external_mechanism_charge_is_bounded_by_live_ledger_room() {
        assert_eq!(settled_external_calls(140, 200), 140);
        assert_eq!(settled_external_calls(140, 97), 97);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn local_checkpoint_early_return_emits_one_analyzer_slice() {
        use anneal_core::cooperative_search::CooperativeRun;
        use anneal_core::cooperative_search::ledger::ChargeKind;

        let mut cooperative = CooperativeRun::new([0], 100).unwrap();
        cooperative
            .record_work(0, ChargeKind::AcceptedQuench, 7)
            .unwrap();
        let mut slice_sequence = 0;

        let action = complete_checkpoint_trace(
            &mut cooperative,
            0,
            &mut slice_sequence,
            7,
            -3.25,
            |_cooperative, _slice_sequence| CheckpointAction::Continue,
        );

        assert!(matches!(action, CheckpointAction::Continue));
        assert_eq!(slice_sequence, 1);
        let slices = cooperative
            .events()
            .iter()
            .filter_map(|event| event.slice)
            .collect::<Vec<_>>();
        assert_eq!(slices.len(), 1);
        assert_eq!(slices[0].slice, 1);
        assert_eq!(slices[0].policy_reason, "local_checkpoint");
        assert_eq!(slices[0].energy, Some(-3.25));
        assert_eq!(slices[0].charged_work, 7);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn local_checkpoint_without_finite_best_omits_slice_energy() {
        use anneal_core::cooperative_search::CooperativeRun;
        use anneal_core::cooperative_search::ledger::ChargeKind;

        let mut cooperative = CooperativeRun::new([0], 100).unwrap();
        cooperative
            .record_work(0, ChargeKind::AcceptedQuench, 7)
            .unwrap();
        let mut slice_sequence = 0;

        let action = complete_checkpoint_trace(
            &mut cooperative,
            0,
            &mut slice_sequence,
            7,
            f64::INFINITY,
            |_cooperative, _slice_sequence| CheckpointAction::Continue,
        );

        assert!(matches!(action, CheckpointAction::Continue));
        let slices = cooperative
            .events()
            .iter()
            .filter_map(|event| event.slice)
            .collect::<Vec<_>>();
        assert_eq!(slices.len(), 1);
        assert_eq!(slices[0].energy, None);
        assert_eq!(slices[0].charged_work, 7);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn certified_duplicate_ride_enters_the_live_chain_as_a_counted_proposal() {
        use anneal_core::cooperative_search::RideReportOutcome;
        use anneal_core::ride_ledger::RideCredit;

        let destination = Array1::from(vec![0.0, 0.0, 0.0, 2.0, 0.0, 0.0]);
        let action = ride_checkpoint_action(
            RideReportOutcome::Credited(RideCredit {
                certified_connection: true,
                degenerate_rearrangement: false,
                failure: None,
                novel_saddle: false,
                novel_edge: false,
                total_charged_evaluations: 140,
            }),
            Some(destination.clone()),
            81,
        );

        assert_eq!(
            action,
            CheckpointAction::ExternalProposal {
                state: destination,
                action: "certified_ride".into(),
                external_calls: 140,
            }
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn uncertified_ride_charges_the_receiver_without_proposing_a_transition() {
        use anneal_core::cooperative_search::RideReportOutcome;
        use anneal_core::ride_ledger::RideCredit;

        let action = ride_checkpoint_action(
            RideReportOutcome::Credited(RideCredit {
                certified_connection: false,
                degenerate_rearrangement: false,
                failure: Some(anneal_core::ride_ledger::RideFailure::Surface),
                novel_saddle: false,
                novel_edge: false,
                total_charged_evaluations: 97,
            }),
            Some(Array1::from(vec![0.0, 0.0, 0.0, 2.0, 0.0, 0.0])),
            81,
        );

        assert_eq!(
            action,
            CheckpointAction::ExternalWork { external_calls: 97 }
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn rejected_ride_report_charges_only_known_producer_work() {
        use anneal_core::cooperative_search::RideReportOutcome;

        let action = ride_checkpoint_action(RideReportOutcome::Rejected, None, 81);

        assert_eq!(
            action,
            CheckpointAction::ExternalWork { external_calls: 81 }
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn typed_ride_failures_have_stage_specific_trace_reasons() {
        use anneal_core::ride_ledger::RideFailure;

        let cases = [
            (RideFailure::QuenchNotConverged, "ride_quench_not_converged"),
            (RideFailure::SaddleNotConverged, "ride_saddle_not_converged"),
            (
                RideFailure::MinimumModeNotConverged,
                "ride_minimum_mode_not_converged",
            ),
            (RideFailure::PrfoNotConverged, "ride_prfo_not_converged"),
            (
                RideFailure::SaddleForceNotConverged,
                "ride_saddle_force_not_converged",
            ),
            (
                RideFailure::ActivationNotEscaped,
                "ride_activation_not_escaped",
            ),
            (
                RideFailure::MinimumModeLostCurvature,
                "ride_minimum_mode_lost_curvature",
            ),
            (RideFailure::NoNegativeMode, "ride_no_negative_mode"),
            (RideFailure::HigherIndex, "ride_higher_index"),
            (RideFailure::IrcNotConverged, "ride_irc_not_converged"),
            (
                RideFailure::CollapsedConnection,
                "ride_collapsed_connection",
            ),
            (RideFailure::Surface, "ride_surface_error"),
            (RideFailure::BudgetExhausted, "ride_budget_exhausted"),
            (
                RideFailure::DisconnectedConnection,
                "ride_disconnected_connection",
            ),
        ];

        for (failure, expected) in cases {
            assert_eq!(ride_failure_reason(failure), expected);
        }
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn ride_budget_reserves_receiver_certification_and_the_live_quench() {
        assert_eq!(ride_producer_budget(10_000, 453, 4_002, 5_000), Some(5_000));
        assert_eq!(ride_producer_budget(5_000, 453, 4_002, 5_000), Some(545));
        assert_eq!(ride_producer_budget(4_455, 453, 4_002, 5_000), None);
    }

    #[cfg(all(feature = "bank-rpc", feature = "ira"))]
    #[test]
    fn lj_ride_identity_absorbs_rigid_permutations_but_not_distortion() {
        let source = Array1::from(vec![
            1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0,
        ]);
        let permutation = [2usize, 0, 3, 1];
        let mut equivalent = Array1::zeros(source.len());
        for (destination, source_atom) in permutation.into_iter().enumerate() {
            let x = source[3 * source_atom];
            let y = source[3 * source_atom + 1];
            let z = source[3 * source_atom + 2];
            equivalent[3 * destination] = -y + 3.0;
            equivalent[3 * destination + 1] = x - 2.0;
            equivalent[3 * destination + 2] = z + 0.5;
        }
        let mut distorted = equivalent.clone();
        distorted[0] += 0.05;
        let witness = IraStructureWitness {
            kmax_factor: IraMetric::default().kmax_factor,
            radius: 1e-4,
        };

        assert!(
            anneal_core::pes_exploration::ExactStructureWitness::equivalent(
                &witness,
                source.view(),
                equivalent.view(),
            )
        );
        assert!(
            !anneal_core::pes_exploration::ExactStructureWitness::equivalent(
                &witness,
                source.view(),
                distorted.view(),
            )
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn fixed_probe_is_seeded_target_blind_and_translation_free() {
        let current = Array1::from(vec![0.0; 12]);
        let mut first_rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(71);
        let mut second_rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(71);
        let first = fixed_probe_trial(current.view(), 0.2, &mut first_rng).unwrap();
        let second = fixed_probe_trial(current.view(), 0.2, &mut second_rng).unwrap();

        assert_eq!(first, second);
        assert_ne!(first, current);
        for axis in 0..3 {
            let mean = (0..4).map(|atom| first[3 * atom + axis]).sum::<f64>() / 4.0;
            assert!(mean.abs() < 1e-12);
        }
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn validated_adaptive_edge_builds_both_coordinator_endpoints() {
        let cfg = Config::for_cluster(2);
        let signature = anneal_core::catalog::lj::system_signature(2).unwrap();
        let descriptor_space = anneal_core::catalog::lj::descriptor_space();
        let separation = 2.0_f64.powf(1.0 / 6.0);
        let source = Array1::from(vec![0.0, 0.0, 0.0, separation, 0.0, 0.0]);
        let destination = Array1::from(vec![0.0, 0.0, 0.0, 0.0, separation, 0.0]);
        let (source_energy, source_gradient) = lj(source.view());
        let (destination_energy, destination_gradient) = lj(destination.view());
        let transition = AcceptedTransition {
            hop: 3,
            action: "surface_relocate".into(),
            from_energy: source_energy,
            to_energy: destination_energy,
            from_state: source.clone(),
            from_gradient: Some(source_gradient),
            to_state: destination.clone(),
            to_gradient: Some(destination_gradient),
            validated: true,
            adopted: true,
        };

        let (from, to) = lj_transition_candidates(
            &descriptor_space,
            &signature.atomic_numbers,
            0,
            11,
            12,
            71,
            400,
            &transition,
        )
        .unwrap();

        assert_eq!(from.coordinates, source.to_vec());
        assert_eq!(to.coordinates, destination.to_vec());
        assert_eq!(from.event_sequence, 11);
        assert_eq!(to.event_sequence, 12);
        assert!(from.gradient_norm < cfg.record_gradient);
        assert!(to.gradient_norm < cfg.record_gradient);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn failed_probe_builds_a_source_and_an_unresolved_record() {
        let signature = anneal_core::catalog::lj::system_signature(2).unwrap();
        let descriptor_space = anneal_core::catalog::lj::descriptor_space();
        let separation = 2.0_f64.powf(1.0 / 6.0);
        let source = Array1::from(vec![0.0, 0.0, 0.0, separation, 0.0, 0.0]);
        let (energy, gradient) = lj(source.view());
        let transition = AcceptedTransition {
            hop: 3,
            action: "probe".into(),
            from_energy: energy,
            to_energy: f64::INFINITY,
            from_state: source.clone(),
            from_gradient: Some(gradient),
            to_state: source,
            to_gradient: None,
            validated: false,
            adopted: false,
        };
        let mut sequence = 20;
        let operations = adaptive_catalog_operations(
            &descriptor_space,
            &signature.atomic_numbers,
            0,
            &mut sequence,
            71,
            400,
            &[transition],
        );
        assert_eq!(
            operations.len(),
            2,
            "failed probe must retain its source and outcome"
        );
        assert!(matches!(
            operations[0],
            AdaptiveCatalogOperation::RegisterCurrent(_)
        ));
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn contiguous_adaptive_path_registers_one_source_then_adopts_each_edge() {
        let signature = anneal_core::catalog::lj::system_signature(2).unwrap();
        let descriptor_space = anneal_core::catalog::lj::descriptor_space();
        let separation = 2.0_f64.powf(1.0 / 6.0);
        let first = Array1::from(vec![0.0, 0.0, 0.0, separation, 0.0, 0.0]);
        let second = Array1::from(vec![0.0, 0.0, 0.0, 0.0, separation, 0.0]);
        let third = Array1::from(vec![0.0, 0.0, 0.0, -separation, 0.0, 0.0]);
        let (first_energy, first_gradient) = lj(first.view());
        let (second_energy, second_gradient) = lj(second.view());
        let (third_energy, third_gradient) = lj(third.view());
        let transitions = vec![
            AcceptedTransition {
                hop: 3,
                action: "surface_relocate".into(),
                from_energy: first_energy,
                to_energy: second_energy,
                from_state: first,
                from_gradient: Some(first_gradient),
                to_state: second.clone(),
                to_gradient: Some(second_gradient.clone()),
                validated: true,
                adopted: true,
            },
            AcceptedTransition {
                hop: 4,
                action: "shell_rotate".into(),
                from_energy: second_energy,
                to_energy: third_energy,
                from_state: second,
                from_gradient: Some(second_gradient),
                to_state: third,
                to_gradient: Some(third_gradient),
                validated: true,
                adopted: true,
            },
        ];
        let mut sequence = 20;

        let operations = adaptive_catalog_operations(
            &descriptor_space,
            &signature.atomic_numbers,
            0,
            &mut sequence,
            71,
            400,
            &transitions,
        );

        assert_eq!(sequence, 23);
        assert_eq!(operations.len(), 3);
        assert!(matches!(
            operations[0],
            AdaptiveCatalogOperation::RegisterCurrent(_)
        ));
        assert!(matches!(
            &operations[1],
            AdaptiveCatalogOperation::Adopt { action, .. } if action == "surface_relocate"
        ));
        assert!(matches!(
            &operations[2],
            AdaptiveCatalogOperation::Adopt { action, .. } if action == "shell_rotate"
        ));
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn failed_probe_is_one_unresolved_observation() {
        let signature = anneal_core::catalog::lj::system_signature(2).unwrap();
        let descriptor_space = anneal_core::catalog::lj::descriptor_space();
        let separation = 2.0_f64.powf(1.0 / 6.0);
        let source = Array1::from(vec![0.0, 0.0, 0.0, separation, 0.0, 0.0]);
        let (energy, gradient) = lj(source.view());
        let transitions = vec![AcceptedTransition {
            hop: 1,
            action: "probe".into(),
            from_energy: energy,
            to_energy: energy,
            from_state: source.clone(),
            from_gradient: Some(gradient),
            to_state: source,
            to_gradient: None,
            validated: false,
            adopted: false,
        }];
        let mut sequence = 4;

        let operations = adaptive_catalog_operations(
            &descriptor_space,
            &signature.atomic_numbers,
            0,
            &mut sequence,
            71,
            40,
            &transitions,
        );

        assert_eq!(sequence, 5);
        assert_eq!(operations.len(), 2);
        assert!(matches!(
            operations[0],
            AdaptiveCatalogOperation::RegisterCurrent(_)
        ));
        assert!(matches!(
            &operations[1],
            AdaptiveCatalogOperation::Unresolved { action } if action == "probe"
        ));
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn shared_crossing_is_aligned_into_the_live_lj_frame() {
        let crossing = anneal_core::catalog_rpc::BoundaryCrossingRecord {
            action: "surface_relocate".into(),
            from: vec![0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0],
            to: vec![0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 0.0],
            source_basin: 3,
            destination_basin: 7,
        };
        let current = Array1::from(vec![3.0, 4.0, 0.0, 3.0, 5.0, 0.0, 2.0, 4.0, 0.0]);
        let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(71);

        let proposal =
            boundary_crossing_trial(current.view(), &crossing, 0.0, 10.0, &mut rng).unwrap();

        let expected = [3.0, 4.0, 0.0, 3.0, 5.0, 0.0, 1.0, 4.0, 0.0];
        for (actual, expected) in proposal.iter().zip(expected) {
            assert!((actual - expected).abs() < 1e-8);
        }
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn population_sibling_uses_seeded_boundary_transport() {
        let crossing = anneal_core::catalog_rpc::BoundaryCrossingRecord {
            action: "shell_rotate".into(),
            from: vec![0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0],
            to: vec![0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 0.0],
            source_basin: 3,
            destination_basin: 7,
        };
        let parent = Array1::from(vec![3.0, 4.0, 0.0, 3.0, 5.0, 0.0, 2.0, 4.0, 0.0]);

        let first = population_boundary_trial(parent.view(), &crossing, 0.05, 10.0, 71).unwrap();
        let second = population_boundary_trial(parent.view(), &crossing, 0.05, 10.0, 71).unwrap();

        assert_eq!(first, second);
        assert_ne!(first, parent);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn population_assignment_never_clones_a_parent_minimum() {
        let live = Array1::from(vec![3.0, 4.0, 0.0, 3.0, 5.0, 0.0, 2.0, 4.0, 0.0]);
        let parent = Array1::from(vec![8.0, 1.0, 0.0, 8.0, 2.0, 0.0, 7.0, 1.0, 0.0]);

        let next = population_region_trial(live.view(), None, 0.05, 10.0, 71);

        assert_eq!(next, live);
        assert_ne!(next, parent);
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn pending_population_epoch_polls_after_another_local_slice() {
        let mut progress = PopulationEpochProgress::default();

        assert_eq!(progress.action(true, true), PopulationEpochAction::Submit);
        progress.observe_pending();
        assert_eq!(progress.action(true, true), PopulationEpochAction::Poll);
        assert_eq!(progress.epoch(), 0);

        progress.observe_ready();
        assert_eq!(progress.epoch(), 1);
        assert_eq!(
            progress.action(false, false),
            PopulationEpochAction::LocalWork
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn active_checkpoint_schedules_population_from_charged_work() {
        let mut progress = PopulationEpochProgress::default();

        assert_eq!(
            active_population_action(&progress, 999, 2_001, 1_000, true),
            PopulationEpochAction::LocalWork
        );
        assert_eq!(
            active_population_action(&progress, 1_000, 2_000, 1_000, true),
            PopulationEpochAction::Submit
        );

        progress.observe_pending();
        assert_eq!(
            active_population_action(&progress, 1_500, 1_500, 1_000, false),
            PopulationEpochAction::Poll
        );

        progress.observe_ready();
        assert_eq!(
            active_population_action(&progress, 1_999, 1_001, 1_000, true),
            PopulationEpochAction::LocalWork
        );
        assert_eq!(
            active_population_action(&progress, 2_000, 1_000, 1_000, true),
            PopulationEpochAction::Submit
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn a_barrier_without_a_representative_abstains_rather_than_working_locally() {
        // The epoch requires every replica. A replica that reaches the
        // barrier with nothing valid to submit and quietly does local work
        // instead leaves the replicas that did submit polling until their
        // budgets drain, which is the deadlock this reports.
        let progress = PopulationEpochProgress::default();

        assert_eq!(
            active_population_action(&progress, 1_000, 2_000, 1_000, false),
            PopulationEpochAction::Abstain
        );
        assert_eq!(
            active_population_action(&progress, 1_000, 2_000, 1_000, true),
            PopulationEpochAction::Submit
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn active_checkpoint_catches_up_missed_epochs_at_the_terminal_boundary() {
        let mut progress = PopulationEpochProgress::default();
        progress.observe_ready();

        assert_eq!(
            active_population_action(&progress, 3_000, 0, 1_000, true),
            PopulationEpochAction::Submit
        );

        progress.observe_ready();
        assert_eq!(
            active_population_action(&progress, 3_000, 0, 1_000, true),
            PopulationEpochAction::LocalWork
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn active_checkpoint_resolves_a_pending_population_barrier() {
        use anneal_core::cooperative_search::PopulationSynchronizationOutcome;

        let mut polls = 0;
        let outcome = resolve_population_barrier(
            PopulationSynchronizationOutcome::Pending {
                submitted: 1,
                required: 4,
            },
            || {
                polls += 1;
                if polls == 1 {
                    PopulationSynchronizationOutcome::Pending {
                        submitted: 3,
                        required: 4,
                    }
                } else {
                    PopulationSynchronizationOutcome::Rejected
                }
            },
        );

        assert_eq!(outcome, PopulationSynchronizationOutcome::Rejected);
        assert_eq!(polls, 2);
    }

    #[cfg(feature = "bank-rpc")]
    fn open_epoch_retries(
        outcome: &anneal_core::cooperative_search::PopulationSynchronizationOutcome,
    ) -> bool {
        matches!(
            outcome,
            anneal_core::cooperative_search::PopulationSynchronizationOutcome::Pending { .. }
                | anneal_core::cooperative_search::PopulationSynchronizationOutcome::Rejected
        )
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn rejected_join_stays_pending_and_retries_at_the_next_checkpoint() {
        use anneal_core::cooperative_search::PopulationSynchronizationOutcome;

        // Mid-run join rejection is not an exit. The replica stays on
        // the open epoch and polls (retries join) after more local work,
        // the same as a pending barrier. Abstaining would retire it.
        let mut progress = PopulationEpochProgress::default();
        assert!(open_epoch_retries(
            &PopulationSynchronizationOutcome::Rejected
        ));
        assert!(open_epoch_retries(
            &PopulationSynchronizationOutcome::Pending {
                submitted: 1,
                required: 4,
            }
        ));
        assert!(!open_epoch_retries(
            &PopulationSynchronizationOutcome::Unaddressed
        ));
        progress.observe_pending();

        assert_eq!(progress.epoch(), 0);
        assert_eq!(progress.action(true, true), PopulationEpochAction::Poll);
        assert_eq!(
            active_population_action(&progress, 1_000, 2_000, 1_000, true),
            PopulationEpochAction::Poll
        );
        assert_ne!(
            active_population_action(&progress, 1_000, 2_000, 1_000, true),
            PopulationEpochAction::Abstain
        );
    }

    #[cfg(feature = "bank-rpc")]
    #[test]
    fn quenched_transport_destination_keeps_its_action_label() {
        let signature = anneal_core::catalog::lj::system_signature(2).unwrap();
        let descriptor_space = anneal_core::catalog::lj::descriptor_space();
        let separation = 2.0_f64.powf(1.0 / 6.0);
        let state = Array1::from(vec![0.0, 0.0, 0.0, separation, 0.0, 0.0]);
        let (energy, gradient) = lj(state.view());

        let (action, candidate) = boundary_transition_destination(
            &descriptor_space,
            &signature.atomic_numbers,
            0,
            11,
            71,
            400,
            energy,
            state.view(),
            gradient.view(),
        )
        .unwrap();

        assert_eq!(action, "boundary_transport");
        assert_eq!(candidate.coordinates, state.to_vec());
        assert!(candidate.quench_converged);
    }
}

/// Value and gradient, charged to the ledger, or `None` when it is spent.
fn charged(led: &mut Ledger, x: ArrayView1<f64>) -> Option<(f64, Array1<f64>)> {
    let (energy, grad) = charged_physical(led, x)?;
    Some(if led.is_diagnostic_quench() {
        (energy, grad)
    } else {
        anneal_core::known_basin::effective(x, energy, grad)
    })
}

/// Physical value and gradient, independent of every adaptive search field.
fn charged_physical(led: &mut Ledger, x: ArrayView1<f64>) -> Option<(f64, Array1<f64>)> {
    led.charge().then(|| lj(x))
}

/// One physical-objective query, without optimization or quench evidence.
fn evaluate_without_quenching(led: &mut Ledger, x: ArrayView1<f64>) -> (f64, Array1<f64>) {
    let energy = charged_physical(led, x).map_or(f64::INFINITY, |(energy, _)| energy);
    (energy, x.to_owned())
}

/// The objective with isotropic noise on the gradient, for the screening pass.
///
/// The basin of attraction of a starting point is a property of the minimiser,
/// not of the landscape alone, so perturbing the descent sends the same
/// starting point to a different minimum. That is the one factor in
/// "perturbation then quench" that no acceptance rule, sampling weight,
/// temperature or bias reaches, and measurement puts the funnel crossing
/// squarely inside it: every crossing observed arrives in a single quench.
///
/// The noise is isotropic and scaled to the gradient's own magnitude, so it
/// carries no information about any structure and cannot encode an answer the
/// way a template library does. It is also dimensionless: `eta` is a fraction
/// of the local gradient, so nothing here is a length or an energy belonging to
/// a particular system.
///
/// Applied to the screening pass only. The full relaxation stays clean, because
/// the driver puts its output into the chain and every mechanism above assumes
/// the chain stands on a minimum.
fn charged_noisy<R: rand::Rng + ?Sized>(
    led: &mut Ledger,
    x: ArrayView1<f64>,
    eta: f64,
    rng: &mut R,
) -> Option<(f64, Array1<f64>)> {
    if !led.charge() {
        return None;
    }
    let (e, mut g) = lj(x);
    let norm = g.iter().fold(0.0_f64, |a, v| a + v * v).sqrt();
    if norm > 0.0 && eta > 0.0 {
        let scale = eta * norm / (g.len() as f64).sqrt();
        for v in g.iter_mut() {
            let u1: f64 = rng.random::<f64>().max(1e-12);
            let u2: f64 = rng.random::<f64>();
            let z = (-2.0 * u1.ln()).sqrt() * (std::f64::consts::TAU * u2).cos();
            *v += scale * z;
        }
    }
    Some((e, g))
}

/// Gradient of the pair energy with respect to the listed atoms only.
///
/// Computes the k rows of the interaction that involve a moved atom: k*n pair
/// terms against n(n-1)/2 for the full system, which is the fraction charged.
/// Frozen atoms contribute forces to the moved ones; their own entries stay
/// zero, which is the frozen-environment constraint.
fn lj_partial_grad(x: ndarray::ArrayView1<f64>, moved: &[usize]) -> Array1<f64> {
    let n = x.len() / 3;
    let mut g = Array1::zeros(x.len());
    for &i in moved {
        for j in 0..n {
            if j == i {
                continue;
            }
            let d = [
                x[3 * i] - x[3 * j],
                x[3 * i + 1] - x[3 * j + 1],
                x[3 * i + 2] - x[3 * j + 2],
            ];
            let r2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
            let inv2 = 1.0 / r2;
            let inv6 = inv2 * inv2 * inv2;
            let inv12 = inv6 * inv6;
            let coef = 24.0 * inv2 * (2.0 * inv12 - inv6);
            for k in 0..3 {
                g[3 * i + k] -= coef * d[k];
            }
        }
    }
    g
}

/// Published global minima. A score for known hurdles; occupancy
/// does not stop on these numbers.
fn reference(n: usize) -> Option<f64> {
    Some(match n {
        13 => -44.326801,
        38 => -173.928427,
        55 => -279.248470,
        75 => -397.492331,
        98 => -543.665361,
        102 => -569.363652,
        104 => -582.086642,
        _ => return None,
    })
}

fn main() {
    // Campaign file first, before any thread exists: the TOML is the
    // single written source of the CATALOG_* environment, and a dark
    // channel is a parse error there, not a silent default here.
    match anneal_core::campaign::CampaignConfig::bootstrap() {
        Ok(Some(cfg)) => print!("{}", cfg.banner()),
        Ok(None) => {}
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(2);
        }
    }
    let args: Vec<String> = std::env::args().collect();
    let n: usize = args.get(1).and_then(|v| v.parse().ok()).unwrap_or(38);
    let budget: usize = args.get(2).and_then(|v| v.parse().ok()).unwrap_or(400_000);
    let seeds: u64 = args.get(3).and_then(|v| v.parse().ok()).unwrap_or(8);
    // Where the seed numbering starts, so a campaign can put one seed on each
    // core instead of walking them in one process. Seeds are the same runs
    // either way: seed 5 of one process and seed 5 of another are identical.
    let seed0: u64 = anneal_core::env::parsed("SEED_OFFSET").unwrap_or(0);

    let reference = reference(n);
    // Random structure search: the evaluation-matched baseline. Random starts,
    // full quenches, nothing else, so every stack above it is measured against
    // what pure sampling buys at the same number of charged evaluations.
    if std::env::args()
        .nth(4)
        .map(|v| v.contains("rss"))
        .unwrap_or(false)
    {
        let mut solved = 0usize;
        for seed in seed0..(seed0 + seeds) {
            let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(
                seed.wrapping_mul(0x9E3779B9).wrapping_add(7),
            );
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut best = f64::INFINITY;
            let mut relaxes = 0usize;
            while ledger.remaining() > 0 {
                let x0 =
                    anneal_core::methods::cluster_hopping::random_cluster(n, 0.7, 0.5, &mut rng);
                opt.forget();
                let (e, _xr, _) = opt.minimize(x0.view(), 500, |v| {
                    if !ledger.charge() {
                        return None;
                    }
                    Some(lj(v))
                });
                relaxes += 1;
                if let Ok(prefix) = std::env::var("ANNEAL_MIN_DUMP") {
                    use std::io::Write as _;
                    if let Ok(mut fh) = std::fs::OpenOptions::new()
                        .create(true)
                        .append(true)
                        .open(&prefix)
                    {
                        let mut line = format!("{e:.8}");
                        for v in _xr.iter() {
                            line.push_str(&format!(" {v:.6}"));
                        }
                        line.push('\n');
                        let _ = fh.write_all(line.as_bytes());
                    }
                }
                if e < best {
                    best = e;
                }
            }
            let hit = reference.map(|r| best < r + 1e-4).unwrap_or(false);
            if hit {
                solved += 1;
            }
            println!(
                "  seed {seed}: best {best:.6}  relaxes {relaxes}{}",
                if hit { "  SOLVED" } else { "" }
            );
        }
        println!("{solved}/{seeds} solved (rss)");
        return;
    }
    // Dynamic lattice search: construct from the structure's own hollow
    // sites, relax, restart on stall. The evaluation-matched published
    // baseline for the hard sizes, run under the same ledger.
    if std::env::args()
        .nth(4)
        .map(|v| v.split(',').any(|t| t == "dls"))
        .unwrap_or(false)
    {
        use anneal_core::methods::lattice_search::{LatticeSearchConfig, run as lattice_run};
        let lcfg = LatticeSearchConfig::lennard_jones(n);
        let mut solved = 0usize;
        for seed in seed0..(seed0 + seeds) {
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                opt.forget();
                let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                (f, xr)
            };
            let out = lattice_run(&lcfg, &mut ledger, &mut relax, seed);
            let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
            if hit {
                solved += 1;
            }
            println!(
                "  seed {seed}: best {:.6}  constructions {}  restarts {}  improvements {}  charged {}{}",
                out.best,
                out.hops,
                out.basins,
                out.returned,
                out.charged,
                if hit { "  SOLVED" } else { "" }
            );
            if let Some((_, spent, _, e)) = out.improvements.first() {
                println!("      best {e:.6} reached at charged {spent}");
            }
        }
        println!("{solved}/{seeds} solved (dls)");
        return;
    }
    // Archive-ratchet mode: the minima network explored from a permanent
    // keyed archive, launches by discovery posterior.
    #[cfg(feature = "graphkey")]
    if std::env::args()
        .nth(4)
        .map(|v| v.contains("archive"))
        .unwrap_or(false)
    {
        use anneal_core::methods::ffs::{FfsConfig, ffs_descent};
        let fcfg = FfsConfig::for_cluster(n);
        let mut solved = 0usize;
        for seed in seed0..(seed0 + seeds) {
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                opt.forget();
                let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                (f, xr)
            };
            let out = ffs_descent(&fcfg, &mut ledger, &mut relax, seed);
            let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
            if hit {
                solved += 1;
            }
            println!(
                "  seed {seed}: best {:.6}  archive {} inserts {} launches {} barren {}{}",
                out.best,
                out.descents,
                out.stored,
                out.continuations,
                out.returns,
                if hit { "  SOLVED" } else { "" }
            );
        }
        println!("{solved}/{seeds} solved (archive)");
        return;
    }
    // Committor-population mode: short chains of the configured stack,
    // resampled by improvement posterior.
    if std::env::args()
        .nth(4)
        .map(|v| v.contains("committor"))
        .unwrap_or(false)
    {
        use anneal_core::methods::committor_pop::committor_population;
        let mut ccfg = Config::for_cluster(n);
        ccfg.move_library = MoveLibrary::LeanBurst;
        ccfg.allocate_moves = true;
        ccfg.depth_reward = true;
        let walkers = 6usize;
        let seg = (budget / (walkers * 6)).max(20_000);
        let mut solved = 0usize;
        for seed in seed0..(seed0 + seeds) {
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                opt.forget();
                let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                (f, xr)
            };
            let out = committor_population(&ccfg, walkers, seg, &mut ledger, &mut relax, seed);
            let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
            if hit {
                solved += 1;
            }
            println!(
                "  seed {seed}: best {:.6}  segments {} improvements {} resamples {}{}",
                out.best,
                out.segments,
                out.improvements,
                out.resamples,
                if hit { "  SOLVED" } else { "" }
            );
        }
        println!("{solved}/{seeds} solved (committor)");
        return;
    }
    // Nested mode replaces the chain entirely: population under a descending
    // ceiling, stopping by the run's own volume curve.
    if std::env::args()
        .nth(4)
        .map(|v| v.contains("nested"))
        .unwrap_or(false)
    {
        use anneal_core::methods::nested::{NestedConfig, nested_search};
        let ncfg = NestedConfig::for_cluster(n);
        let mut solved = 0usize;
        for seed in seed0..(seed0 + seeds) {
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                opt.forget();
                let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                (f, xr)
            };
            let out = nested_search(&ncfg, &mut ledger, &mut relax, seed);
            let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
            if hit {
                solved += 1;
            }
            println!(
                "  seed {seed}: best {:.6}  replacements {}  steps {}  taken {}  ceiling {:.4}  repop {}{}",
                out.best,
                out.replacements,
                out.steps,
                out.taken,
                out.final_ceiling,
                out.repopulations,
                if hit { "  SOLVED" } else { "" }
            );
        }
        println!("{solved}/{seeds} solved (nested)");
        return;
    }
    // Residual archive search. Token is `ras`, not `archive` (that is FFS).
    #[cfg(feature = "graphkey")]
    if std::env::args()
        .nth(4)
        .map(|v| v.split(',').any(|t| t == "ras" || t == "pair"))
        .unwrap_or(false)
    {
        use anneal_core::methods::archive_search::{Archive, archive_search};
        use anneal_core::methods::cluster_hopping::{random_cluster_in_radius, run_with_gradient};
        use rand::SeedableRng;
        let pair = std::env::args()
            .nth(4)
            .map(|v| v.split(',').any(|t| t == "pair"))
            .unwrap_or(false);
        let cfg = Config::recommended(n);
        println!(
            "LJ{n}, budget {budget} charged evaluations, {seeds} seeds{}  arm {}",
            reference
                .map(|r| format!(", reference {r:.6}"))
                .unwrap_or_default(),
            if pair { "pair rec+ras" } else { "ras" }
        );
        let mut rec_solved = 0usize;
        let mut ras_solved = 0usize;
        let mut rec_hit_at = Vec::new();
        let mut ras_hit_at = Vec::new();
        for seed in seed0..(seed0 + seeds) {
            let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
            let start =
                random_cluster_in_radius(n, cfg.start_radius(), cfg.min_separation, &mut rng);
            let mut rng_ras = rng.clone();
            if pair {
                let mut ledger = Ledger::new(budget);
                let mut opt = WarmLbfgs::default();
                let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                    opt.forget();
                    let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                    (f, xr)
                };
                let mut grad = |led: &mut Ledger, x: ArrayView1<f64>| -> Option<Array1<f64>> {
                    if !led.charge() {
                        return None;
                    }
                    Some(lj(x).1)
                };
                let mut rng_rec = rng_ras.clone();
                let out = run_with_gradient(
                    &cfg,
                    start.view(),
                    &mut ledger,
                    &mut relax,
                    Some(&mut grad),
                    &mut rng_rec,
                )
                .expect("finite start");
                let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
                if hit {
                    rec_solved += 1;
                }
                let hat = out
                    .improvements
                    .iter()
                    .find(|(_, _, _, e)| reference.map(|r| *e < r + 1e-4).unwrap_or(false))
                    .map(|(_, sp, _, _)| *sp);
                if let Some(sp) = hat {
                    rec_hit_at.push(sp);
                }
                println!(
                    "  seed {seed} rec: best {:.6}  charged {}  hit_at {}{}",
                    out.best,
                    ledger.spent(),
                    hat.map(|v| v.to_string()).unwrap_or_else(|| "-".into()),
                    if hit { "  SOLVED" } else { "" }
                );
                let _ = io::stdout().flush();
            }
            let mut ledger = Ledger::new(budget);
            let mut opt = WarmLbfgs::default();
            let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
                opt.forget();
                let (f, xr, _) = opt.minimize(x, iters, |v| charged(led, v));
                (f, xr)
            };
            let mut grad = |led: &mut Ledger, x: ArrayView1<f64>| -> Option<Array1<f64>> {
                if !led.charge() {
                    return None;
                }
                Some(lj(x).1)
            };
            let mut archive = Archive::new();
            let out = archive_search(
                &cfg,
                start.view(),
                &mut ledger,
                &mut relax,
                Some(&mut grad),
                &mut archive,
                &mut rng_ras,
            );
            let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
            if hit {
                ras_solved += 1;
            }
            if hit {
                ras_hit_at.push(out.best_at);
            }
            println!(
                "  seed {seed} ras: best {:.6}  charged {}  hit_at {}  screens {} full {} returned {} same_floor {} floors {} events {} artn {}{}",
                out.best,
                out.charged,
                if hit {
                    out.best_at.to_string()
                } else {
                    "-".into()
                },
                out.screens,
                out.full,
                out.returned,
                out.same_floor,
                out.floors,
                out.events,
                out.artn,
                if hit { "  SOLVED" } else { "" }
            );
            let _ = io::stdout().flush();
        }
        if pair {
            let rec_mean = if rec_hit_at.is_empty() {
                0
            } else {
                rec_hit_at.iter().sum::<usize>() / rec_hit_at.len()
            };
            let ras_mean = if ras_hit_at.is_empty() {
                0
            } else {
                ras_hit_at.iter().sum::<usize>() / ras_hit_at.len()
            };
            println!(
                "{rec_solved}/{seeds} solved (rec)  {ras_solved}/{seeds} solved (ras)  mean_hit_at rec {rec_mean} ras {ras_mean}"
            );
        } else {
            println!("{ras_solved}/{seeds} solved (ras)");
        }
        return;
    }
    println!(
        "LJ{n}, budget {budget} charged evaluations, {seeds} seeds{}",
        reference
            .map(|r| format!(", reference {r:.6}"))
            .unwrap_or_default()
    );

    // The temperature and step come from Wales and Doye's protocol for basin
    // hopping on the quenched surface, a reduced temperature of 0.8 and a step
    // between 0.36 and 0.40, rather than from tuning here.
    let named: Vec<&str> = args
        .get(4)
        .map(|v| v.split(',').collect())
        .unwrap_or_default();
    let mut cfg = if named.iter().any(|o| *o == "comm" || *o == "communicating") {
        println!("  communicating configuration");
        Config::communicating(n)
    } else if named.iter().any(|o| *o == "rec" || *o == "recommended") {
        println!("  recommended configuration");
        Config::recommended(n)
    } else {
        Config::for_cluster(n)
    };
    // Keying on shape rather than on the descriptor, so the merge threshold is
    // a length. Enabled by the fourth argument so both are measurable.
    // Mechanisms named on the command line, so each is measurable against the
    // others rather than all arriving at once.
    let mut opts: Vec<&str> = args
        .get(4)
        .map(|v| v.split(',').collect())
        .unwrap_or_default();
    // The working Python driver (askmc_hopping) is Thompson over moves, the
    // budget-window temperature, and the per-basin bias the crate always
    // carries. Naming that stack keeps the measurement comparable without
    // assembling the flags from memory each time.
    if opts.contains(&"askmc") {
        opts.extend_from_slice(&["thompson", "bfwt"]);
    }
    cfg.shape_keyed = opts.contains(&"shape");
    cfg.budget_window = opts.contains(&"bfwt");
    cfg.allocate_moves = cfg.allocate_moves || opts.contains(&"thompson");
    apply_boolean_options(&mut cfg, &opts);
    // Catalog talking must keep Config::recommended. SOAP packing
    // superbasin plus AS-KMC height is an intra-packing leftover walk:
    // LJ75 sits on the Mackay shelf and never reaches ico or Marks.
    cfg.anneal_diversity = opts.contains(&"csa");
    // Key the basin bias on the prospective superbasin: the coloured core
    // ring-graph key, so every shelf isomer deposits into one well and the
    // filling raises the whole family at once.
    if opts.contains(&"corekey") {
        cfg.keying = anneal_core::methods::cluster_hopping::Keying::Core;
        cfg.merge_radius = 0.5;
        println!("  keying on the core ring-graph key, merge radius 0.5");
    }
    // Reoccupation move on the lattice grown from the interior;
    // REOCCUPY_INTERVAL sets the charged calls between moves.
    if opts.contains(&"reocc") {
        cfg.reoccupy =
            Some(anneal_core::methods::lattice_search::LatticeSearchConfig::lennard_jones(n));
        cfg.reoccupy_interval = anneal_core::env::parsed("REOCCUPY_INTERVAL").unwrap_or(5_000);
        println!(
            "  reoccupation move every {} charged calls",
            cfg.reoccupy_interval
        );
    }
    let coreclass = opts.contains(&"coreclass");
    let core_patience = anneal_core::env::parsed("CORE_PATIENCE").unwrap_or(10_000);
    let core_trial = anneal_core::env::parsed("CORE_TRIAL").unwrap_or(2_000);
    if coreclass {
        println!("  core-class table: patience {core_patience}, trial {core_trial}");
    }
    // Two-phase relaxation on the compacted surface (Locatelli and Schoen;
    // Doye). TWO_PHASE_KAPPA sets a relative cutoff, TWO_PHASE_D a fixed
    // one in pair-well units, TWO_PHASE_BETA the penalty strength and
    // TWO_PHASE_MU a centroid compression.
    if opts.contains(&"twophase") {
        let envf = |k: &str, d: f64| {
            std::env::var(k)
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(d)
        };
        let beta = envf("TWO_PHASE_BETA", 1.0);
        let fixed = envf("TWO_PHASE_D", 0.0);
        let cutoff = if fixed > 0.0 {
            anneal_core::methods::two_phase::Cutoff::Fixed(
                fixed * cfg.length_scale * 2f64.powf(1.0 / 6.0),
            )
        } else {
            // Measured on 38 and 75 points: every fraction from 0.7 to 0.85
            // of the entering diameter crosses, 0.7 fastest.
            anneal_core::methods::two_phase::Cutoff::Relative(envf("TWO_PHASE_KAPPA", 0.7))
        };
        cfg.two_phase = Some(anneal_core::methods::two_phase::TwoPhase {
            cutoff,
            beta,
            mu: envf("TWO_PHASE_MU", 0.0),
            anisotropic: false,
        });
        println!("  two-phase relaxation: {:?}", cfg.two_phase);
    }
    // The ellipsoidal metric read from the entering structure's own gyration
    // tensor, so the compaction keeps the walker's aspect.
    if opts.contains(&"aniso")
        && let Some(two) = cfg.two_phase.as_mut()
    {
        two.anisotropic = true;
        println!("  two-phase relaxation in the entering structure's own metric");
    }
    // A learned portfolio of relaxation surfaces: SURFACES names the arms
    // beside the plain one, comma-separated, as `mu:5`, `d:3.5` (pair-well
    // units) or `kappa:0.75`, with an optional `:beta` suffix on the two
    // diameter forms. The depth-rewarded allocator picks one per hop.
    if opts.contains(&"surfaces") {
        let spec = std::env::var("SURFACES").unwrap_or_else(|_| "kappa:0.7,mu:5".into());
        let unit = cfg.length_scale * 2f64.powf(1.0 / 6.0);
        let mut arms = Vec::new();
        for item in spec.split(',').map(str::trim).filter(|s| !s.is_empty()) {
            let parts: Vec<&str> = item.split(':').collect();
            let value: f64 = parts
                .get(1)
                .and_then(|v| v.parse().ok())
                .unwrap_or_else(|| panic!("SURFACES item {item:?} needs a number"));
            let beta: f64 = parts.get(2).and_then(|v| v.parse().ok()).unwrap_or(1.0);
            arms.push(match parts[0] {
                "mu" => anneal_core::methods::two_phase::TwoPhase {
                    cutoff: anneal_core::methods::two_phase::Cutoff::Fixed(0.0),
                    beta: 0.0,
                    mu: value,
                    anisotropic: false,
                },
                "d" => anneal_core::methods::two_phase::TwoPhase::diameter(value * unit, beta),
                "kappa" => anneal_core::methods::two_phase::TwoPhase::relative(value, beta),
                other => panic!("SURFACES item {item:?}: unknown kind {other:?}"),
            });
        }
        cfg.surfaces = arms;
        println!("  surface portfolio: plain + {:?}", cfg.surfaces);
    }
    cfg.path_on_stall = opts.contains(&"path");
    // Stall exits through the recorded basin entry, named so it is
    // measurable against the Lanczos climb rather than replacing it.
    cfg.trail_on_stall = opts.contains(&"trail") || anneal_core::env::flag("CLUSTER_TRAIL_EXIT");
    // Do not clobber Config::recommended: that hop already turns the
    // return screen on. The flag only adds it to for_cluster.
    if opts.contains(&"rscreen") {
        cfg.return_screen = true;
    }
    if opts.contains(&"soapclass") {
        cfg.soap_class_residual = true;
        println!("  SOAP residual: class 555->421 (oracle)");
    }
    if opts.contains(&"soapmean") {
        cfg.soap_class_residual = false;
        println!("  SOAP residual: mean (2p-mu)");
    }
    if cfg.soap_mode != anneal_core::methods::cluster_hopping::SoapProposalMode::Off {
        #[cfg(feature = "featomic")]
        println!(
            "  SOAP hop: observed-cloud featomic leftover / packing-mean kick, l>=5, no named morphology or prototype"
        );
        #[cfg(feature = "ira")]
        println!(
            "  IRA: libira_match Hausdorff on the shared bank, SOFI libira_try_mat on the hop"
        );
        if cfg.keying == Keying::SoapPacking {
            println!(
                "  SOAP superbasin: mean-SOAP merge {}, adaptive height N_f={}",
                cfg.merge_radius, cfg.height_revisits
            );
        }
        #[cfg(not(feature = "featomic"))]
        println!("  SOAP hop: in-crate leftover (rebuild with --features featomic)");
    }
    cfg.minima_hopping = opts.contains(&"mh") || opts.contains(&"mhmd");
    // Goedecker's MD escape under the controller; MD_DT and MD_KINETIC
    // set the time step and the kinetic energy per unit escape scale.
    cfg.md_escape = opts.contains(&"mhmd");
    cfg.orbit_complete_on_new = cfg.orbit_complete_on_new || opts.contains(&"orbit");
    if opts.contains(&"recognition") {
        cfg.shared_visit_policy =
            anneal_core::methods::minima_hopping::SharedVisitPolicy::Recognition;
        cfg.shared_deposits = 0;
    }
    if let Some(dt) = anneal_core::env::parsed("MD_DT") {
        cfg.md_escape_dt = dt;
    }
    if let Some(k) = anneal_core::env::parsed("MD_KINETIC") {
        cfg.md_escape_kinetic = k;
    }
    if let Some(m) = anneal_core::env::parsed("MD_MINIMA") {
        cfg.md_escape_minima = m;
    }
    if let Some(m) = anneal_core::env::parsed("MD_STEPS") {
        cfg.md_escape_max_steps = m;
    }
    if let Some(m) = anneal_core::env::parsed("MD_SOFTEN") {
        cfg.md_escape_soften = m;
    }
    // The radius read off the search's own step length rather than swept.
    cfg.calibrate_radius = opts.contains(&"calib");
    // The walker restarted, the landscape memory kept.
    cfg.restart_on_stall = opts.contains(&"restart");
    // RESTART_PATIENCE sets the charged calls without a new best before a
    // stalled chain restarts from a fresh random cluster.
    if let Some(patience) = anneal_core::env::parsed::<usize>("RESTART_PATIENCE") {
        cfg.restart_patience = patience.max(1);
        println!("  restart patience {} charged calls", cfg.restart_patience);
    }
    // STALL_PATIENCE sets the hops without improvement before a stall.
    if let Some(patience) = anneal_core::env::parsed::<usize>("STALL_PATIENCE") {
        cfg.stall_patience = patience.max(1);
        println!("  stall patience {} hops", cfg.stall_patience);
    }
    // Wales and Doye's angular move on the worst-bound point.
    cfg.angular_moves = opts.contains(&"angular");
    // Oakley-Johnston-Wales point-group symmetrisation as a proposal arm.
    cfg.point_symmetrise = opts.contains(&"psym");
    // Core symmetrisation once per new basin (Oakley-Johnston-Wales), quenched.
    cfg.point_symmetrise_on_new = opts.contains(&"psymnew");
    // Population repulsion in SOAP space, pulled back through the Jacobian.
    cfg.soap_repel = opts.contains(&"repel");
    // Occasional jumping on stagnation (Iwamatsu-Okabe).
    cfg.jump_on_stall = opts.contains(&"jump");
    if let Some(p) = anneal_core::env::parsed::<usize>("JUMP_PATIENCE") {
        cfg.jump_patience = p;
    }
    if let Some(k) = anneal_core::env::parsed::<usize>("JUMP_STEPS") {
        cfg.jump_steps = k;
    }
    if let Some(h) = anneal_core::env::parsed::<f64>("JUMP_STEP") {
        cfg.jump_step = h * cfg.length_scale;
    }
    if cfg.jump_on_stall {
        println!(
            "  occasional jumping: patience {} hops, {} steps of half-width {}",
            cfg.jump_patience, cfg.jump_steps, cfg.jump_step
        );
    }
    // Heard structures face the receiving chain's biased-energy filter
    // unless unconditional adoption is requested explicitly.
    cfg.exchange_metropolis = !anneal_core::env::flag("CATALOG_HEAR_UNCONDITIONAL");
    if let Some(g) = anneal_core::env::parsed::<f64>("BIAS_GAMMA") {
        cfg.bias_gamma = g;
        println!("  bias gamma {g}");
    }
    if let Some(frac) = anneal_core::env::parsed::<f64>("PSYM_CORE") {
        cfg.symmetrise_core_fraction = frac;
        println!("  symmetrise core fraction {frac}");
    }
    if let Some(tol) = anneal_core::env::parsed::<f64>("SYM_TOL") {
        cfg.symmetry_tolerance = tol * cfg.length_scale;
        println!("  symmetry tolerance {tol}");
    }
    cfg.point_symmetrise_every_accept = opts.contains(&"psymall");
    if cfg.point_symmetrise_every_accept {
        cfg.point_symmetrise_on_new = true;
    }
    // Allocator rewarded by accepted new basins rather than by acceptance.
    cfg.novel_reward = opts.contains(&"novel");
    // Key the per-basin bias on the SOAP packing family instead of the
    // pair spectrum, with adaptive height: every shelf isomer deposits into
    // one well, so a chain absorbed on a family is pushed off the family
    // rather than off one minimum. Nothing else of the occupancy stack.
    if opts.contains(&"sbkey") {
        #[cfg(feature = "featomic")]
        {
            cfg.keying = Keying::SoapPacking;
            cfg.merge_radius = anneal_core::featomic_hop::SOAP_PACK_MERGE;
        }
        cfg.adaptive_height = true;
        cfg.height_revisits = anneal_core::env::parsed::<f64>("HEIGHT_REVISITS").unwrap_or(20.0);
        println!(
            "  packing-family keyed bias, merge {}, adaptive height N_f={}",
            cfg.merge_radius, cfg.height_revisits
        );
    }
    // The funnel forbidden rather than penalised.
    cfg.tabu_on_stall = cfg.tabu_on_stall || opts.contains(&"tabu");
    // The relaxation decision taken under a posterior.
    cfg.bayes_screen = opts.contains(&"bayes");
    // Acceptance against the density of minima rather than against the energy.
    cfg.flat_histogram = opts.contains(&"flat");
    // The temperature taken from the entropy the run measures for itself.
    cfg.statistical_temperature = opts.contains(&"stemp");
    // A well-tempered bias in quenched energy, scales from the run itself.
    cfg.energy_bias = opts.contains(&"ebias");
    let requested_libraries = [
        ("visit", MoveLibrary::Visit),
        ("reseed", MoveLibrary::Reseed),
        ("selfseed", MoveLibrary::SelfReseed),
        ("learncon", MoveLibrary::LearnedReseed),
        ("lean", MoveLibrary::Lean),
        ("burst", MoveLibrary::LeanBurst),
        ("hollow", MoveLibrary::LeanBurstHollow),
        ("fill", MoveLibrary::LeanBurstFill),
        ("twin", MoveLibrary::Twin),
        ("gtwin", MoveLibrary::GrowthAndTwin),
    ];
    let selected: Vec<MoveLibrary> = requested_libraries
        .into_iter()
        .filter_map(|(name, library)| opts.contains(&name).then_some(library))
        .collect();
    assert!(
        selected.len() <= 1,
        "select at most one move library: visit,reseed,selfseed,learncon,lean,burst,twin,gtwin"
    );
    if let Some(library) = selected.into_iter().next() {
        cfg.move_library = library;
    }
    // Local order and global twinning together use one typed library.
    // Arms rewarded by depth reached rather than by acceptance.
    cfg.depth_reward = cfg.depth_reward || opts.contains(&"depth");
    // Perturbation drawn in the soft subspace of the incumbent's curvature.
    cfg.soft_perturb = opts.contains(&"softsub");
    // Proposal covariance learned from the run's accepted displacements.
    cfg.cov_perturb = opts.contains(&"covper");
    // Settle moved atoms at fractional price before the full-system screen.
    cfg.staged_quench = opts.contains(&"staged");
    // Arm selection has to be under an allocator at all before the reward rule
    // matters: without this the arm is drawn uniformly and both allocators are
    // inert.
    if cfg.depth_reward {
        cfg.allocate_moves = true;
    }
    // The screening pass is the quench, so its length is the one number that
    // decides whether the chain moves on the transformed landscape at all.
    if let Ok(v) = std::env::var("SCREEN_STEPS")
        && let Ok(k) = v.parse::<usize>()
    {
        cfg.screen_steps = k;
        println!("  screen steps {k}");
    }
    if let Ok(v) = std::env::var("RELAX_STEPS")
        && let Ok(k) = v.parse::<usize>()
    {
        cfg.relax_steps = k;
        println!("  relax steps {k}");
    }
    if let Ok(v) = std::env::var("SCREEN_MARGIN")
        && let Ok(m) = v.parse::<f64>()
    {
        cfg.screen_margin = m * cfg.energy_scale;
        println!("  screen margin {m}");
    }
    if let Ok(v) = std::env::var("FLAT_QUANTILE")
        && let Ok(q) = v.parse::<f64>()
    {
        cfg.flat_quantile = q;
        println!("  flat below the {q} quantile of each sweep");
    }
    // The move chosen from the structure the chain is standing on.
    cfg.contextual_moves = opts.contains(&"ctx");
    // Basins keyed on how well each point is bound.
    if opts.contains(&"sites") {
        cfg.keying = Keying::Sites;
        println!("  keying on sorted site energies");
    }
    if opts.contains(&"canon") {
        // A length in coordinate space now: two structures whose points can be
        // brought within this root-mean-square of each other by a permutation
        // and a rigid motion are one basin.
        cfg.keying = Keying::Canonical;
        cfg.merge_radius = 0.3;
        println!(
            "  keying on a canonical order, merge radius {}",
            cfg.merge_radius
        );
    }
    // A ladder sharing one budget, not four budgets. The comparison is against
    // a single chain at the same total cost. The four names are the four arms:
    // the ladder as it ran, the same ladder with each rung actually at its own
    // temperature, whole parity classes with a coin-flipped parity, and the
    // non-reversible sweep on a ladder placed by the measured barrier.
    let ladder_mode = if opts.contains(&"indep") {
        Some(LadderMode::Independent)
    } else if opts.contains(&"nrpt") {
        Some(LadderMode::NonReversible)
    } else if opts.contains(&"rpt") {
        Some(LadderMode::Reversible)
    } else if opts.contains(&"ptt") {
        Some(LadderMode::Cyclic)
    } else if opts.contains(&"pt") {
        Some(LadderMode::Shipped)
    } else {
        None
    };
    if let Some(mode) = ladder_mode {
        cfg.replicas = anneal_core::env::parsed("REPLICAS").unwrap_or(4);
        cfg.ladder_mode = mode;
        // The swap period is the ladder's unit of time and the budget decides
        // how many units there are: at LJ38 with 4e5 charged evaluations a run
        // takes about six thousand hops, so a period of 50 over four rungs
        // buys thirty sweeps and a period of 10 buys a hundred and fifty. A
        // ladder cannot transport anything in thirty sweeps, which is why the
        // period is on the command line rather than fixed.
        if let Ok(p) = std::env::var("SWAP_PERIOD")
            && let Ok(v) = p.parse::<usize>()
        {
            cfg.swap_period = v.max(1);
        }
        if let Ok(a) = std::env::var("LADDER_ACCEPT")
            && let Ok(v) = a.parse::<f64>()
        {
            cfg.ladder_target_accept = v.clamp(0.01, 0.95);
        }
        cfg.bias_by_rung = opts.contains(&"rungbias");
        // The top is a knob with a ceiling, not a free win: the ladder
        // pays exactly while the hot rung still crosses more often than
        // the cold one, and past the melt it stops being a solid at all.
        // Measured on LJ75, the crossing is an accepted excursion three
        // to four eps above the floor, so the useful top sits where that
        // acceptance has grown tenfold and the rung still freezes back;
        // at the default 4.0 the two upper rungs of a 0.8 chain run at
        // 2.0 and 3.2, which is liquid.
        if let Some(top) = anneal_core::env::parsed::<f64>("PT_LADDER_TOP")
            .filter(|value| value.is_finite() && *value > 1.0)
        {
            cfg.ladder_top = top;
        }
        println!(
            "  replica exchange: {} chains, swap every {} hops, top x{}",
            cfg.replicas, cfg.swap_period, cfg.ladder_top
        );
    }
    // The deposit height matters only now that basins are revisited: at 33
    // revisits a height of 0.25 accumulates to about 8, against escape gaps
    // measured at 0.09 for the cheapest and 0.18 at the tenth percentile.
    // How coarse a basin is, which decides how deep the bias gets anywhere.
    //
    // Traced at 75 points, a hundred thousand hops register about three
    // thousand basins, so each one collects around thirty deposits and the
    // icosahedral funnel never fills: a run can spend ninety-eight thousand
    // hops inside it without a single improvement. A radius that merges the
    // variants of a funnel into one basin puts the same deposits in one place.
    if let Ok(v) = std::env::var("MERGE_RADIUS")
        && let Ok(r) = v.parse::<f64>()
    {
        cfg.merge_radius = r;
        println!("  merge radius {r}");
    }
    // Acceptance temperature in energy units; Wales--Doye's 0.8 is the preset.
    if let Some(t) = anneal_core::env::parsed::<f64>("TEMPERATURE") {
        cfg.temperature = t * cfg.energy_scale;
        println!("  acceptance temperature {t} E0");
    }
    if let Ok(h) = std::env::var("BIAS_HEIGHT")
        && let Ok(v) = h.parse::<f64>()
    {
        cfg.bias_height = v;
        println!("  bias height {v}");
    }
    // Revisits a basin takes before the adaptive deposits clear its escape
    // gap: the AS-KMC filling count, so the absorbing shelf is raised as one
    // block after that many returns while rarely visited doorway states
    // keep their depth.
    if let Ok(h) = std::env::var("HEIGHT_REVISITS")
        && let Ok(v) = h.parse::<f64>()
    {
        cfg.height_revisits = v;
        println!("  height revisits {v}");
    }
    if !opts.is_empty() {
        println!("  mechanisms: {}", opts.join(", "));
    }
    if cfg.shape_keyed {
        // A length now, not a number in descriptor space: two structures whose
        // atoms can be brought within this of each other by a permutation and
        // a rigid motion are the same basin.
        cfg.merge_radius = 0.2;
        println!(
            "  keying on IRA shape distance, merge radius {} (a length)",
            cfg.merge_radius
        );
    }
    if let Ok(path) = std::env::var("ANNEAL_RESOLVED_CONFIG") {
        std::fs::write(
            &path,
            cfg.resolved_json()
                .expect("serialize resolved configuration"),
        )
        .unwrap_or_else(|error| panic!("write resolved configuration {path}: {error}"));
    }

    // The bank arm. Runs the same chains under the same total budget, with
    // where-to-start-next and what-to-keep decided by the diversity rule
    // rather than by the chain itself.
    let use_bank = opts.contains(&"bank");
    // The slice length is the shape of the method, not a tuning knob. A bank
    // whose slices are long is a handful of medium chains: at a sixteenth of
    // the budget each, a bank of eight saw every member twice and scored 0
    // seeds in 5. Conformational space annealing runs thousands of short
    // perturbations against a bank of tens, so each member is revisited on the
    // order of a hundred times.
    let env = |k: &str, d: usize| {
        std::env::var(k)
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(d)
    };
    let capacity = env("BANK_CAPACITY", 30);
    let bank_cfg = BankConfig {
        capacity,
        acquisition: opts.contains(&"acq"),
        slice: env("BANK_SLICE", 3_000),
        seeding: capacity,
        dcut_floor: anneal_core::env::parsed("BANK_DCUT_FLOOR").unwrap_or(0.4),
        mix_fraction: anneal_core::env::parsed("BANK_MIX").unwrap_or(0.0),
        mix_images: env("BANK_MIX_IMAGES", 20),
        random_images: env("BANK_RANDOM", 10),
        deadlock_iters: env("BANK_DEADLOCK_ITERS", 3),
        deadlock_inject: env("BANK_DEADLOCK", 50),
    };
    if use_bank {
        println!(
            "  bank of {} chains, {} charged per slice, Dcut floor {}, mix {} ({} splice + {} random), deadlock {}x{}, acq {}",
            bank_cfg.capacity,
            bank_cfg.slice,
            bank_cfg.dcut_floor,
            bank_cfg.mix_fraction,
            bank_cfg.mix_images,
            bank_cfg.random_images,
            bank_cfg.deadlock_iters,
            bank_cfg.deadlock_inject,
            bank_cfg.acquisition
        );
    }

    // Thread-replica ensembles sharing one exact minimum history, under the
    // contract of the NVE escape-history comparison: identical replica seeds
    // and starts in both arms, one aggregate budget, first-discovery
    // aggregate calls on the record.
    if let Some(replicas) = anneal_core::env::parsed::<usize>("HISTORY_REPLICAS") {
        run_history_ensembles(&cfg, n, budget, seed0, seeds, reference, replicas, &opts);
        return;
    }
    let core_table = coreclass.then(|| {
        Arc::new(Mutex::new(anneal_core::coreclass::CoreClassTable::new(
            core_patience,
            core_trial,
        )))
    });
    let mut solved = 0usize;
    let mut deepest = f64::INFINITY;
    let mut total_hops = 0usize;
    let mut total_charged = 0usize;
    for seed in seed0..(seed0 + seeds) {
        let mut ledger = Ledger::new(budget);
        // The driver owns the search; the numerics under it are the caller's.
        // A hand-rolled steepest descent with backtracking cost 830 charged
        // evaluations per hop here against about 79 for a quasi-Newton
        // relaxation, so a three million unit budget bought a few thousand
        // hops rather than tens of thousands, and the search failed for want
        // of relaxations rather than for want of a mechanism.
        // Convergence is counted, not assumed. A driver on the quenched
        // landscape is only on it if its relaxations reach minima; one that
        // stops at the iteration cap is hopping between arbitrary points and
        // every mechanism above it is acting on noise.
        // The screening pass stopped as soon as its limit is decided.
        let early_stop = opts.contains(&"early");
        let mut early_stopped = 0usize;
        let mut early_saved = 0usize;
        let mut converged = 0usize;
        let mut capped = 0usize;
        let mut opt = WarmLbfgs::default();
        let screen_steps = cfg.screen_steps;
        // Noise on the screening descent, as a fraction of the local gradient.
        // Zero reproduces the clean quench exactly.
        let noise_eta: f64 = anneal_core::env::parsed("QUENCH_NOISE").unwrap_or(0.0);
        let mut qrng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(
            seed.wrapping_mul(0x9E3779B97F4A7C15).wrapping_add(17),
        );
        let two_phase = cfg.two_phase.filter(|two| two.is_active());
        let surface_block = anneal_core::env::parsed("SURFACE_BLOCK")
            .unwrap_or(anneal_core::methods::two_phase::DEFAULT_SURFACE_BLOCK);
        let surfaces = (!cfg.surfaces.is_empty()).then(|| {
            Arc::new(Mutex::new(
                anneal_core::methods::two_phase::SurfacePortfolio::with_block(
                    &cfg.surfaces,
                    seed,
                    surface_block,
                ),
            ))
        });
        let mut relax = |led: &mut Ledger, x: ArrayView1<f64>, iters: usize| {
            if iters == 0 {
                return evaluate_without_quenching(led, x);
            }
            let charged_before = led.spent();
            let diagnostic = led.is_diagnostic_quench();
            // Curvature is not carried between relaxations: measured on this
            // problem, retaining it across a structural change costs more than
            // it saves.
            opt.forget();
            // Early termination applies to the screening pass only.
            //
            // The screen's output is allowed to be unconverged; the full
            // relaxation's is not, because the driver puts it into the chain
            // and every mechanism above assumes the chain stands on a minimum.
            // Stopping the full relaxation early is the same defect that broke
            // the escape controller, where 94 relaxations in 3148 reached a
            // minimum and the curvature it steered by came back negative at a
            // point being treated as one.
            if !diagnostic && early_stop && iters <= screen_steps {
                let mut term = Terminator::default();
                let mut cur = x.to_owned();
                let mut done = 0usize;
                // Four at a time: enough for the ratio estimate to move, small
                // enough that the saving is not given back.
                while done < iters {
                    let take = 4.min(iters - done);
                    let (fi, xi, _) = opt.minimize(cur.view(), take, |v| charged(led, v));
                    cur = xi;
                    done += take;
                    term.observe(fi);
                    if term.settled_above(led.best) {
                        early_stopped += 1;
                        early_saved += iters - done;
                        break;
                    }
                }
                capped += 1;
                let (f, cur) = evaluate_without_quenching(led, cur.view());
                led.record_quench_boundary(charged_before, f, cur.clone(), None);
                return (f, cur);
            }
            // Phase one, when configured: the compacted-surface relaxation
            // whose minimum the plain relaxation below starts from.
            let compacted;
            let screening_pass = iters <= screen_steps;
            let surface = if diagnostic {
                None
            } else {
                match surfaces.as_ref() {
                    Some(portfolio) => portfolio
                        .lock()
                        .expect("surface portfolio")
                        .begin(screening_pass),
                    None => two_phase,
                }
            };
            let x = match surface {
                Some(two) => {
                    let cutoff = two.cutoff_for(x);
                    let shape = two.shape_for(x);
                    let (_, phase_one, _) = opt.minimize(x, iters, |v| {
                        let (e, g) = charged(led, v)?;
                        let (pe, pg) = anneal_core::methods::two_phase::penalty_shaped(
                            v,
                            cutoff,
                            two.beta,
                            two.mu,
                            shape.as_ref(),
                        );
                        Some((e + pe, g + pg))
                    });
                    opt.forget();
                    compacted = phase_one;
                    compacted.view()
                }
                None => x,
            };
            let (_, xr, _) = if !diagnostic && anneal_core::known_basin::is_armed() {
                let (f, xr) =
                    anneal_core::known_basin::step_rgmin(&mut opt, x, iters, |v| charged(led, v));
                (f, xr, 0)
            } else if !diagnostic && noise_eta > 0.0 && iters <= screen_steps {
                opt.minimize(x, iters, |v| charged_noisy(led, v, noise_eta, &mut qrng))
            } else {
                opt.minimize(x, iters, |v| charged(led, v))
            };
            let mut boundary_energy = f64::INFINITY;
            let mut validated_gradient = None;
            let mut xr = xr;
            if led.charge() {
                let (fresh_energy, mut g) = lj(xr.view());
                boundary_energy = fresh_energy;
                let mut gnorm =
                    euclidean_gradient_norm(g.as_slice().expect("LJ gradient is contiguous"));
                // The share tolerance is a Euclidean bound over every
                // component, which sits severalfold above the max-abs a
                // converged relaxation reports on larger systems, so a fixed
                // step count that satisfies one size stalls just short on
                // another. A relaxation that lands near the bound therefore
                // continues in bounded chunks until it crosses it or proves
                // it will not, exactly as the census calibration converged
                // its own quenches. Only near-minima enter this loop, so the
                // cost lands on the rare states worth validating.
                let mut chunks = 0;
                while (1e-5..1e-3).contains(&gnorm) && chunks < 10 && led.remaining() > 0 {
                    // A stalled line search poisons the curvature memory; a
                    // restarted optimizer descends where a warm one stands
                    // still, which is the difference between the plateau a
                    // whisker above the bound and crossing it.
                    opt.forget();
                    let (_, xc, _) = opt.minimize(xr.view(), 500, |v| charged_physical(led, v));
                    boundary_energy = f64::INFINITY;
                    xr = xc;
                    if !led.charge() {
                        break;
                    }
                    let (fe, ge) = lj(xr.view());
                    boundary_energy = fe;
                    gnorm =
                        euclidean_gradient_norm(ge.as_slice().expect("LJ gradient is contiguous"));
                    g = ge;
                    chunks += 1;
                    // The last few percent yield to plain steepest descent
                    // with a fixed small step when the quasi-Newton stalls:
                    // near a minimum the gradient direction is exact enough
                    // and each step is one charged evaluation.
                    let mut descents = 0;
                    while (1e-5..3e-5).contains(&gnorm) && descents < 200 && led.charge() {
                        // Fixed step alpha = 0.01 sits well under the
                        // stability bound 2 over the stiffest LJ curvature,
                        // so every mode contracts and the few percent above
                        // the bound take tens of one-evaluation steps.
                        for (value, gradient) in xr.iter_mut().zip(g.iter()) {
                            *value -= 0.01 * gradient;
                        }
                        let (fe, ge) = lj(xr.view());
                        boundary_energy = fe;
                        gnorm = euclidean_gradient_norm(
                            ge.as_slice().expect("LJ gradient is contiguous"),
                        );
                        g = ge;
                        descents += 1;
                    }
                }
                if gnorm < 1e-5 {
                    converged += 1;
                    validated_gradient = Some(g);
                } else {
                    if std::env::var("ANNEAL_POLISH_TRACE").is_ok() && chunks > 0 {
                        eprintln!("POLISH_PLATEAU gnorm {gnorm:.3e} after {chunks} chunks");
                    }
                    capped += 1;
                }
            } else {
                capped += 1;
            }
            if !diagnostic && let Some(portfolio) = surfaces.as_ref() {
                let mut portfolio = portfolio.lock().expect("surface portfolio");
                portfolio.observe(screening_pass, boundary_energy, led.best);
            }
            led.record_quench_boundary(
                charged_before,
                boundary_energy,
                xr.clone(),
                validated_gradient,
            );
            (boundary_energy, xr)
        };
        // The gradient the soft-mode escape needs, charged like everything
        // else: a Lanczos pass is two evaluations per step and the escape
        // must pay for them.
        let mut grad = |led: &mut Ledger, x: ArrayView1<f64>| -> Option<Array1<f64>> {
            if !led.charge() {
                return None;
            }
            Some(lj(x).1)
        };
        let catalog_rpc = std::env::var("CATALOG_RPC")
            .ok()
            .filter(|value| !value.is_empty());
        let bank_rpc = std::env::var("BANK_RPC")
            .ok()
            .filter(|value| !value.is_empty());
        let catalog_control = opts.contains(&"catalog");
        let out = if catalog_rpc.is_some() || catalog_control {
            #[cfg(feature = "bank-rpc")]
            {
                if let Some(endpoint) = catalog_rpc.as_deref() {
                    println!("  isolated descriptor catalog {endpoint}");
                } else {
                    println!("  descriptor-catalog control with sharing disabled");
                }
                run_capnp_catalog(
                    &cfg,
                    &mut ledger,
                    &mut relax,
                    &mut grad,
                    seed,
                    catalog_rpc.as_deref(),
                    coreclass.then_some((core_patience, core_trial)),
                    surfaces.as_ref().map(Arc::clone),
                )
            }
            #[cfg(not(feature = "bank-rpc"))]
            {
                let _ = catalog_rpc;
                panic!("catalog mode requires --features bank-rpc");
            }
        } else if let Some(endpoint) = bank_rpc {
            #[cfg(feature = "bank-rpc")]
            {
                println!("  capnp compatibility bank {endpoint}");
                run_capnp_bank(&cfg, &mut ledger, &mut relax, &mut grad, seed, &endpoint)
            }
            #[cfg(not(feature = "bank-rpc"))]
            {
                let _ = endpoint;
                panic!("BANK_RPC requires --features bank-rpc");
            }
        } else if use_bank {
            {
                // Shape distance when IRA is linked; otherwise the pairwise
                // spectrum. The bank rule is Lee's Dcut replacement, not the
                // metric: two members closer than Dcut are one solution.
                #[cfg(feature = "featomic")]
                let mut dist = {
                    let rcut = 3.5 * cfg.length_scale;
                    let z = cfg.species.clone();
                    println!(
                        "  bank Dcut: featomic soap_bank_distance, fallback {}",
                        anneal_core::featomic_hop::SOAP_DCUT_FALLBACK
                    );
                    move |p: ArrayView1<f64>, q: ArrayView1<f64>| {
                        anneal_core::featomic_hop::soap_bank_distance(
                            p,
                            q,
                            rcut,
                            z.as_deref(),
                            None,
                        )
                    }
                };
                #[cfg(all(feature = "ira", not(feature = "featomic")))]
                let mut dist = {
                    let ira = IraMetric::default();
                    move |p: ArrayView1<f64>, q: ArrayView1<f64>| ira.distance(p, q)
                };
                #[cfg(not(any(feature = "ira", feature = "featomic")))]
                let mut dist = csa_cluster::spectrum_distance(n);
                let b = csa_cluster::run(
                    &cfg,
                    &bank_cfg,
                    &mut ledger,
                    &mut relax,
                    Some(&mut grad),
                    &mut dist,
                    seed,
                );
                println!(
                    "      bank: {} slices, Dcut {:.3} -> {:.3}, {} improved, {} novel, \
                     {} duplicate, {} mixes ({} admitted, {} below both ends), \
                     {} deadlocks ({} injected), holding {:?}",
                    b.slices,
                    b.dcut.0,
                    b.dcut.1,
                    b.improved,
                    b.novel,
                    b.duplicates,
                    b.mixes,
                    b.mix_admitted,
                    b.mix_below_both,
                    b.deadlocks,
                    b.injected,
                    b.bank
                        .iter()
                        .map(|e| (e * 100.0).round() / 100.0)
                        .collect::<Vec<_>>()
                );
                Outcome {
                    best: b.best,
                    best_state: b.best_state,
                    hops: b.hops,
                    basins: b.basins,
                    screened_out: b.screened_out,
                    returned: b.returned,
                    ..Outcome::default()
                }
            }
        } else if let Some(table) = core_table.as_ref() {
            use anneal_core::coreclass::CoreVerdict;
            use anneal_core::corekey::motif_class;
            use rand::SeedableRng;
            let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
            let start = random_cluster(n, 0.7, cfg.min_separation, &mut rng);
            let mut bias = BasinBias::new(
                ClusterFingerprint::for_keying(n, cfg.shape_keyed),
                cfg.merge_radius,
                cfg.bias_height,
                cfg.bias_gamma,
            );
            let table = Arc::clone(table);
            let mut adopt_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0xC0A1);
            let interval = anneal_core::env::parsed("CHECKPOINT").unwrap_or(500).max(1);
            let mut checkpoint = |snapshot: ChainCheckpoint<'_>| {
                let class = motif_class(snapshot.current_state()).index();
                let mut table = table.lock().expect("core-class table");
                match table.report(
                    seed as usize,
                    class,
                    snapshot.current_energy(),
                    snapshot.charged(),
                ) {
                    CoreVerdict::Restart => {
                        let fresh = random_cluster(n, 0.7, cfg.min_separation, &mut adopt_rng);
                        CheckpointAction::ExternalAdopt {
                            state: fresh,
                            action: "coreclass".to_owned(),
                            external_calls: 0,
                        }
                    }
                    CoreVerdict::Continue => CheckpointAction::Continue,
                }
            };
            run_with_bias_at_checkpoints(
                &cfg,
                start.view(),
                &mut ledger,
                &mut relax,
                Some(&mut grad),
                &mut bias,
                &mut rng,
                interval,
                &mut checkpoint,
            )
            .expect("finite start")
        } else {
            {
                // The settle stage: steepest descent of the moved atoms in the
                // frozen field, charged at the exact fraction of a full
                // evaluation the partial rows represent. Audited on the first
                // call against the full gradient when AUDIT_SETTLE is set.
                let mut audited = false;
                let mut settle = |led: &mut Ledger,
                                  x: ArrayView1<f64>,
                                  moved: &[usize],
                                  iters: usize|
                 -> Array1<f64> {
                    let np = x.len() / 3;
                    let frac = (2.0 * moved.len() as f64) / ((np.max(2) - 1) as f64);
                    if std::env::var("AUDIT_SETTLE").is_ok() && !audited {
                        audited = true;
                        let (_, full) = lj(x);
                        let part = lj_partial_grad(x, moved);
                        for &m in moved {
                            for k in 0..3 {
                                assert!(
                                    (full[3 * m + k] - part[3 * m + k]).abs() < 1e-9,
                                    "partial gradient diverges from full at atom {m}"
                                );
                            }
                        }
                        println!("  settle audit passed: partial rows match the full gradient");
                    }
                    let mut cur = x.to_owned();
                    for _ in 0..iters {
                        if !led.charge_frac(frac) {
                            break;
                        }
                        let g = lj_partial_grad(cur.view(), moved);
                        let mut gmax = 0.0_f64;
                        for &m in moved {
                            for k in 0..3 {
                                gmax = gmax.max(g[3 * m + k].abs());
                            }
                        }
                        if gmax < 1e-4 {
                            break;
                        }
                        // A conservative step against the stiffest component,
                        // enough to drain the worst of the overlap the move
                        // created; the full screen finishes the job.
                        let step = 0.05 / gmax.max(1.0);
                        for &m in moved {
                            for k in 0..3 {
                                cur[3 * m + k] -= step * g[3 * m + k];
                            }
                        }
                    }
                    cur
                };
                anneal_core::methods::cluster_hopping::optimize_with_settle(
                    &cfg,
                    &mut ledger,
                    &mut relax,
                    Some(&mut grad),
                    if cfg.staged_quench {
                        Some(&mut settle)
                    } else {
                        None
                    },
                    seed,
                )
                .expect("finite start")
            }
        };

        // A read-only audit checks the returned coordinates and objective.
        // It cannot optimize coordinates or change the charged search answer.
        let verified = match out.best_state.as_ref() {
            Some(x) => {
                assert_eq!(
                    x.len(),
                    3 * n,
                    "seed {seed} returned {} coordinates for {n} points",
                    x.len()
                );
                let (e, g) = lj(x.view());
                let gmax = g.iter().fold(0.0_f64, |a, v| a.max(v.abs()));
                assert!(
                    e.is_finite() && (e - out.best).abs() < 1e-6,
                    "seed {seed} reports {} but its returned coordinates have energy {e}",
                    out.best
                );
                assert!(
                    g.iter().all(|v| v.is_finite()) && gmax < 1e-3,
                    "seed {seed} returned a structure with gradient {gmax:.2e}, \
                     which is not a minimum"
                );
                println!("ANSWER_AUDIT seed {seed} objective_calls 1 read_only true");
                Some((e, gmax))
            }
            None => None,
        };
        let hit = reference.map(|r| out.best < r + 1e-4).unwrap_or(false);
        if hit {
            solved += 1;
        }
        // Where the run got its answer. Printed for the last few improvements
        // only: the early ones are a descent from a random start and say
        // nothing.
        // Every validated minimum of this seed goes to the readcon-db corpus
        // rooted at ANNEAL_MINIMA_DB and isolated by the complete LJ system
        // signature. Temperature and seed identify trajectories within it.
        if let Ok(path) = std::env::var("ANNEAL_MINIMA_DB") {
            let signature_digest = anneal_core::catalog::lj::system_signature(n)
                .expect("LJ minima corpus requires a valid system signature")
                .digest();
            let set = anneal_core::minima_db::MinimaSet {
                system: format!("lj{n}"),
                temperature: cfg.temperature,
                seed,
            };
            let mut entries: Vec<(f64, ArrayView1<f64>)> = ledger
                .quench_boundaries()
                .iter()
                .filter(|b| b.status() == QuenchStatus::Validated)
                .map(|b| (b.energy(), b.state()))
                .collect();
            if let Some(best) = out.best_state.as_ref() {
                entries.push((out.best, best.view()));
            }
            let provenance = serde_json::json!({
                "driver": "lj_cluster_search",
                "mechanisms": opts.join(","),
                "budget": budget,
                "config_digest": cfg.resolved_sha256().unwrap_or_default(),
            });
            match anneal_core::minima_db::MinimaCorpus::open(&path, signature_digest).and_then(
                |corpus| {
                    corpus.record(
                        &set,
                        &[],
                        &anneal_core::minima_db::MinimaUnits {
                            length: "sigma".into(),
                            energy: "epsilon".into(),
                        },
                        &entries,
                        1e-6,
                        provenance,
                    )
                },
            ) {
                Ok(stored) => println!("      minima corpus {path}: {stored} minima recorded"),
                Err(error) => eprintln!("minima corpus {path}: {error}"),
            }
        }
        if std::env::var("DUMP_IMPROVEMENTS").is_ok() {
            for (h, sp, b, en) in out.improvements.iter() {
                println!("IMP hop {h} spend {sp} basins {b} energy {en:.6}");
            }
        }
        if let Some(r) = reference {
            // A record carries the hop, the evaluations charged by then, the
            // basins open and the energy. The spend is what the budget is
            // denominated in, so it is printed alongside the hop rather than
            // dropped.
            if let Some((h, spent, b, e)) =
                out.improvements.iter().find(|(_, _, _, e)| *e < r + 1e-4)
            {
                println!(
                    "      crossed at hop {h} of {} ({:.1}% in), {spent} charged, {b} basins, {e:.6}",
                    out.hops,
                    100.0 * *h as f64 / out.hops.max(1) as f64
                );
            } else if let Some((h, spent, b, e)) = out.improvements.last() {
                println!(
                    "      last improvement at hop {h} of {} ({:.1}% in), {spent} charged, {b} basins, {e:.6}",
                    out.hops,
                    100.0 * *h as f64 / out.hops.max(1) as f64
                );
            }
        }
        deepest = deepest.min(out.best);
        if seed == 0 && out.rungs.len() > 1 {
            for (t, b, en) in &out.rungs {
                println!("      rung T={t:.3}  basins {b:>5}  energy {en:>11.4}");
            }
        }
        // Transport, on every seed, because it is the quantity the ladder is
        // supposed to change and a solve count cannot report it. A scheme can
        // move configurations across the ladder far better and still not find
        // the minimum, and both halves belong in the record.
        if let Some((trips, sw, barrier)) = out.transport {
            let per_tag = if trips > 0 {
                out.rungs.len() as f64 * sw as f64 / trips as f64
            } else {
                f64::INFINITY
            };
            println!(
                "      seed {seed}: round trips {trips} in {sw} sweeps \
                 (rate {:.4}/sweep, {per_tag:.0} sweeps per tag), barrier {barrier:.2}",
                trips as f64 / sw.max(1) as f64
            );
        }
        // Per-arm draws, accepts and deepest quench, so whether an arm fires
        // and whether it ever deepens is on the seed record rather than
        // inferred from a solve count.
        for (name, draws, accepts, best) in &out.arms {
            println!("    arm {name:<10} draws {draws:>7}  accepts {accepts:>7}  best {best:.6}");
        }
        total_hops += out.hops;
        total_charged += ledger.spent();
        if let Some(portfolio) = surfaces.as_ref() {
            let portfolio = portfolio.lock().expect("surface portfolio");
            println!(
                "SURFACE_EVIDENCE seed {seed} local_blocks {} peer_blocks {} local_draws {:?} local_means {:?}",
                portfolio.draws().iter().sum::<usize>(),
                portfolio.peer_observations(),
                portfolio.draws(),
                portfolio.means()
            );
        }
        println!(
            "  seed {seed}: best {:.6}  hops {}  screened {}  charged {}  \
             basins {} ({:.1} hops each)  returned {}  \
             swaps {}/{}  paths {} improved {} gain {:.3}  \
             escape {:.3} thr {:.4} same/known/new {}/{}/{} soft {}/{} sub {}/{} lmin {:.4} climbs {} gain {:.2} radius {:.3} step {:.3} restarts {} xrefused {} jumps {} angular {}/{} R {:.3} tabu {} vetoed {} screen {}/{} expl {} obs {} ctx {:?} sym {}/{:.2} orbits {}/{:.2}  \
             relaxed {converged}/{} converged  early {early_stopped} saved {early_saved}  \
             verified {}{}",
            out.best,
            out.hops,
            out.screened_out,
            ledger.spent(),
            out.basins,
            out.hops as f64 / out.basins.max(1) as f64,
            out.returned,
            out.swaps_accepted,
            out.swaps_tried,
            out.paths,
            out.path_improvements,
            out.path_gain,
            out.escape_scale,
            out.escape_threshold,
            out.visit_counts.0,
            out.visit_counts.1,
            out.visit_counts.2,
            out.soft_crossed,
            out.soft_escapes,
            out.soft_perturbs,
            out.soft_subspaces,
            out.soft_lambda,
            out.stall_escapes,
            out.stall_escape_gain,
            out.merge_radius,
            out.mean_step,
            out.restarts,
            out.exchanges_refused,
            out.jumps,
            out.angular.1,
            out.angular.0,
            out.angular.2,
            out.tabu.0,
            out.tabu.1,
            out.screen.1,
            out.screen.0,
            out.screen.2,
            out.screen.3,
            out.contextual.0,
            out.symmetrised.0,
            out.symmetrised.1,
            out.orbits.0,
            out.orbits.1,
            converged + capped,
            verified
                .map(|(e, gmax)| format!("{e:.6} |g| {gmax:.1e}"))
                .unwrap_or_else(|| "NO STATE".into()),
            if hit { "  SOLVED" } else { "" }
        );
        let _ = io::stdout().flush();
    }
    // Both counts, since a force budget and a hop budget are different
    // contests and the literature reports hops.
    println!(
        "{solved}/{seeds} solved, deepest {deepest:.6}   \
         mean hops {:.0}, force per hop {:.0}",
        total_hops as f64 / seeds as f64,
        total_charged as f64 / total_hops.max(1) as f64
    );
    if let Some(r) = reference {
        println!("gap to reference {:+.6}", deepest - r);
    }
}

/// Good-Turing missing mass on shared packings. Each well height is
/// `visits * w0`. n1/N is the chance the next deposit is a new packing.
/// Saturated: enough observations and few singletons — the catalog is
/// as complete as aKMC's confidence test, so the next start should
/// leave rather than redraw the same cloud.
#[cfg(feature = "bank-rpc")]
fn catalog_saturated(wells: &[(Array1<f64>, f64)], w0: f64) -> bool {
    let w0 = w0.max(1e-9);
    let mut n = 0u32;
    let mut n1 = 0u32;
    for (_, h) in wells {
        let v = (*h / w0).round().max(0.0) as u32;
        if v == 0 {
            continue;
        }
        n += v;
        if v == 1 {
            n1 += 1;
        }
    }
    n >= 12 && (n1 as f64 / n as f64) < 0.20
}

#[cfg(feature = "bank-rpc")]
fn packing_is_known(x: ArrayView1<f64>, cfg: &Config, wells: &[Array1<f64>]) -> bool {
    if wells.is_empty() {
        return false;
    }
    let s = packing_of(x, cfg);
    let merge = {
        #[cfg(feature = "featomic")]
        {
            anneal_core::featomic_hop::SOAP_PACK_MERGE
        }
        #[cfg(not(feature = "featomic"))]
        {
            0.10
        }
    };
    wells.iter().any(|w| {
        if w.len() != s.len() || s.is_empty() {
            return false;
        }
        s.iter()
            .zip(w.iter())
            .map(|(a, b)| (a - b) * (a - b))
            .sum::<f64>()
            .sqrt()
            <= merge
    })
}

/// Move the current packing mean into a hole of the shared SOAP cloud.
///
/// Cartesian 0.35 pullbacks sit inside one packing; the quench is a
/// projector onto that packing. This inverts a far point on the unit
/// sphere through `∂μ/∂x` with a SOAP step, then relaxes once. A second
/// flow runs only if that quench landed back in the archive.
#[cfg(feature = "bank-rpc")]
fn leave_known_packing<R: rand::Rng + ?Sized>(
    x: ArrayView1<f64>,
    cfg: &Config,
    wells: &[Array1<f64>],
    ledger: &mut Ledger,
    relax: &mut (dyn FnMut(&mut Ledger, ArrayView1<f64>, usize) -> (f64, Array1<f64>) + Send),
    rng: &mut R,
) -> Array1<f64> {
    #[cfg(feature = "featomic")]
    {
        let rcut = 3.5 * cfg.length_scale;
        let mut y = anneal_core::featomic_hop::step_into_hole(
            x,
            wells,
            anneal_core::featomic_hop::SOAP_PACK_MERGE,
            rcut,
            cfg.species.as_deref(),
            None,
            rng,
        );
        if ledger.remaining() < 8 {
            return y;
        }
        let steps = cfg.relax_steps.min(ledger.remaining());
        let (_e, q) = relax(ledger, y.view(), steps);
        if !packing_is_known(q.view(), cfg, wells) {
            return q;
        }
        y = anneal_core::featomic_hop::step_into_hole(
            q.view(),
            wells,
            anneal_core::featomic_hop::SOAP_PACK_MERGE * 1.5,
            rcut,
            cfg.species.as_deref(),
            None,
            rng,
        );
        y
    }
    #[cfg(not(feature = "featomic"))]
    {
        let _ = (cfg, wells, ledger, relax, rng);
        x.to_owned()
    }
}

#[cfg(feature = "bank-rpc")]
fn remember_packing_well(
    x: ArrayView1<f64>,
    rcut: f64,
    species: Option<&[u32]>,
    wells: &mut Vec<Array1<f64>>,
) {
    // The leftover archive holds cloud means, which are the wrong length to
    // be structures. The packing invert and the Leave accept both need the
    // structure, so it is remembered beside the mean.
    if let Some(coordinates) = x.as_slice() {
        anneal_core::catalog::remember_packing_reference(coordinates);
    }
    #[cfg(feature = "featomic")]
    {
        let well = anneal_core::featomic_hop::soap_cloud_mean(x, rcut, species, None);
        let known = wells.iter().any(|stored| {
            stored.len() == well.len()
                && stored
                    .iter()
                    .zip(well.iter())
                    .map(|(a, b)| (a - b) * (a - b))
                    .sum::<f64>()
                    .sqrt()
                    < anneal_core::featomic_hop::SOAP_PACK_MERGE
        });
        if !known && !well.is_empty() {
            wells.push(well);
            if wells.len() > 30 {
                wells.remove(0);
            }
            anneal_core::featomic_hop::set_packing_archive(wells.clone());
        }
    }
    #[cfg(not(feature = "featomic"))]
    {
        let _ = (x, rcut, species, wells);
    }
}

/// First rung of the Leave ladder: a packing-map step along one covering
/// direction, pointed away from the packings on file.
///
/// A Cartesian covering point at a fixed size is a rattle of the occupied
/// packing, and the quench that follows is a projector back onto it. The
/// step is taken in the DECAF mean instead, and its size is the one that
/// reaches the first rung's barrier at the measured curvature of this
/// structure, not a length. When the quench still lands in the same packing
/// the hop loop walks the rest of the ladder rather than drawing another
/// hole of the same size.
#[cfg(feature = "bank-rpc")]
fn leave_packing_state<R: rand::Rng + ?Sized>(
    x: ArrayView1<f64>,
    energy: f64,
    wells: &[Array1<f64>],
    rcut: f64,
    species: Option<&[u32]>,
    cover_index: usize,
    rng: &mut R,
) -> Array1<f64> {
    let _ = (wells, rcut, rng);
    let atoms = x.len() / 3;
    let depth = energy.abs() / atoms.max(1) as f64;
    // Two gradients: the curvature of the step this rung is about to take.
    // They are not charged, because the checkpoint path holds no ledger, and
    // they are the price of a step sized by the structure instead of by a
    // length that suits one cluster and melts another.
    let mobile =
        anneal_core::soap::packing_active_volume(x, anneal_core::catalog::PACKING_SPEC, species);
    anneal_core::known_basin::leave_packing_rung_to(
        x,
        cover_index,
        anneal_core::known_basin::rung_barrier(depth, 0),
        &anneal_core::catalog::packing_references(),
        species,
        Some(mobile.as_slice()),
        |v: ArrayView1<f64>| Some(lj(v).0),
    )
}

/// Covering index for ArchiveHole: replica, then later Leaves of the
/// same extra. Plasencia Gutiérrez, Argáez, Jónsson, *J. Chem. Theory
/// Comput.* **2017**, *13* (1), 125-134.
/// <https://doi.org/10.1021/acs.jctc.5b01216>
#[cfg(feature = "bank-rpc")]
fn archive_cover_index(replica: u32, leave: usize) -> usize {
    use anneal_core::catalog::{cover_arm_count, pick_leave_cover};
    use rand::SeedableRng;
    use rand::rngs::StdRng;
    let n = cover_arm_count();
    let mut rng = StdRng::seed_from_u64(
        (u64::from(replica).wrapping_mul(0x9E37_79B9_7F4A_7C15)) ^ leave as u64,
    );
    pick_leave_cover(n, &mut rng)
}

#[cfg(feature = "bank-rpc")]
fn packing_of(x: ArrayView1<f64>, cfg: &Config) -> Array1<f64> {
    #[cfg(feature = "featomic")]
    {
        anneal_core::featomic_hop::soap_cloud_mean(
            x,
            3.5 * cfg.length_scale,
            cfg.species.as_deref(),
            None,
        )
    }
    #[cfg(not(feature = "featomic"))]
    {
        let _ = (x, cfg);
        Array1::zeros(0)
    }
}

#[cfg(test)]
#[cfg(feature = "bank-rpc")]
fn cooperative_policy_point(current: ArrayView1<f64>, current_energy: f64) -> (Array1<f64>, f64) {
    (current.to_owned(), current_energy)
}

#[cfg(test)]
#[cfg(feature = "bank-rpc")]
fn cooperative_population_point(
    current: ArrayView1<f64>,
    current_energy: f64,
) -> (Array1<f64>, f64) {
    (current.to_owned(), current_energy)
}

#[cfg(feature = "bank-rpc")]
/// Per-center class histogram of a state against a mutable codebook of
/// environment leaders, leader-clustered at a fixed radius. The
/// codebook grows as new local motifs appear, so histograms from
/// different times share class identities.
fn class_histogram(
    state: ArrayView1<f64>,
    leaders: &mut Vec<Array1<f64>>,
    radius: f64,
) -> std::collections::BTreeMap<usize, usize> {
    use anneal_core::soap::{SoapSpec, local_nu3_z};
    let rows = local_nu3_z(state, SoapSpec::default(), None);
    let mut histogram = std::collections::BTreeMap::new();
    for row_index in 0..rows.nrows() {
        let row = rows.row(row_index);
        let mut assigned = None;
        for (class, leader) in leaders.iter().enumerate() {
            let distance = row
                .iter()
                .zip(leader.iter())
                .map(|(p, q)| (p - q) * (p - q))
                .sum::<f64>()
                .sqrt();
            if distance <= radius {
                assigned = Some(class);
                break;
            }
        }
        let class = assigned.unwrap_or_else(|| {
            leaders.push(row.to_owned());
            leaders.len() - 1
        });
        *histogram.entry(class).or_insert(0usize) += 1;
    }
    histogram
}

/// Normalized L1 distance between two class histograms.
#[cfg(feature = "bank-rpc")]
fn histogram_l1(
    a: &std::collections::BTreeMap<usize, usize>,
    b: &std::collections::BTreeMap<usize, usize>,
) -> f64 {
    let total_a = a.values().sum::<usize>().max(1) as f64;
    let total_b = b.values().sum::<usize>().max(1) as f64;
    let classes: std::collections::BTreeSet<usize> = a.keys().chain(b.keys()).copied().collect();
    classes
        .iter()
        .map(|class| {
            let p = *a.get(class).unwrap_or(&0) as f64 / total_a;
            let q = *b.get(class).unwrap_or(&0) as f64 / total_b;
            (p - q).abs()
        })
        .sum()
}

#[cfg(feature = "bank-rpc")]
fn fixed_probe_trial<R: rand::Rng + ?Sized>(
    current: ArrayView1<f64>,
    scale: f64,
    rng: &mut R,
) -> Option<Array1<f64>> {
    if current.is_empty() || !current.len().is_multiple_of(3) || !scale.is_finite() || scale <= 0.0
    {
        return None;
    }
    let atoms = current.len() / 3;
    let mut displacement = Array1::zeros(current.len());
    for coordinate in &mut displacement {
        let u1 = rng.random::<f64>().max(1e-12);
        let u2 = rng.random::<f64>();
        *coordinate = scale * (-2.0 * u1.ln()).sqrt() * (std::f64::consts::TAU * u2).cos();
    }
    for axis in 0..3 {
        let mean = (0..atoms)
            .map(|atom| displacement[3 * atom + axis])
            .sum::<f64>()
            / atoms as f64;
        for atom in 0..atoms {
            displacement[3 * atom + axis] -= mean;
        }
    }
    Some(current.to_owned() + displacement)
}

#[cfg(feature = "bank-rpc")]
/// The bridge region owning a descriptor: the nearest string image, or
/// `None` when the descriptor sits farther than the tube radius from
/// every image.
fn bridge_region_of(images: &[f64], dim: usize, descriptor: &[f64], tube: f64) -> Option<usize> {
    if dim == 0 || !images.len().is_multiple_of(dim) || images.is_empty() {
        return None;
    }
    let mut best = 0usize;
    let mut best_distance = f64::INFINITY;
    for (index, image) in images.chunks_exact(dim).enumerate() {
        let distance = image
            .iter()
            .zip(descriptor)
            .map(|(a, b)| (a - b) * (a - b))
            .sum::<f64>()
            .sqrt();
        if distance < best_distance {
            best_distance = distance;
            best = index;
        }
    }
    (best_distance <= tube).then_some(best)
}

#[cfg(feature = "bank-rpc")]
fn boundary_crossing_trial<R: rand::Rng + ?Sized>(
    current: ArrayView1<f64>,
    crossing: &anneal_core::catalog_rpc::BoundaryCrossingRecord,
    noise_scale: f64,
    trust_radius: f64,
    rng: &mut R,
) -> Option<Array1<f64>> {
    let crossing = anneal_core::boundary_transport::ObservedCrossing::new(
        Array1::from_vec(crossing.from.clone()),
        Array1::from_vec(crossing.to.clone()),
    )
    .ok()?;
    let mut noise = Array1::zeros(current.len());
    for coordinate in &mut noise {
        let u1 = rng.random::<f64>().max(1e-12);
        let u2 = rng.random::<f64>();
        *coordinate = (-2.0 * u1.ln()).sqrt() * (std::f64::consts::TAU * u2).cos();
    }
    anneal_core::boundary_transport::boundary_transport(
        current,
        &crossing,
        noise.view(),
        &anneal_core::boundary_transport::BoundaryTransportConfig {
            noise_scale,
            trust_radius,
            frozen_coordinates: Vec::new(),
            rigid_groups: Vec::new(),
        },
    )
    .ok()
}

#[cfg(all(test, feature = "bank-rpc"))]
fn population_boundary_trial(
    current: ArrayView1<f64>,
    crossing: &anneal_core::catalog_rpc::BoundaryCrossingRecord,
    noise_scale: f64,
    trust_radius: f64,
    draw: u64,
) -> Option<Array1<f64>> {
    let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(draw);
    boundary_crossing_trial(current, crossing, noise_scale, trust_radius, &mut rng)
}

#[cfg(all(test, feature = "bank-rpc"))]
fn population_region_trial(
    current: ArrayView1<f64>,
    crossing: Option<&anneal_core::catalog_rpc::BoundaryCrossingRecord>,
    noise_scale: f64,
    trust_radius: f64,
    draw: u64,
) -> Array1<f64> {
    crossing
        .and_then(|crossing| {
            population_boundary_trial(current, crossing, noise_scale, trust_radius, draw)
        })
        .unwrap_or_else(|| current.to_owned())
}

#[cfg(feature = "bank-rpc")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PopulationEpochAction {
    /// The barrier is here but this replica has nothing valid to submit.
    Abstain,
    LocalWork,
    Submit,
    Poll,
}

#[cfg(feature = "bank-rpc")]
#[derive(Debug, Default)]
struct PopulationEpochProgress {
    epoch: u64,
    pending: bool,
}

#[cfg(feature = "bank-rpc")]
impl PopulationEpochProgress {
    fn epoch(&self) -> u64 {
        self.epoch
    }

    fn action(
        &self,
        threshold_reached: bool,
        representative_available: bool,
    ) -> PopulationEpochAction {
        if self.pending {
            PopulationEpochAction::Poll
        } else if threshold_reached && representative_available {
            PopulationEpochAction::Submit
        } else if threshold_reached {
            // The barrier is here and this replica cannot produce a
            // validated representative for it. Doing local work instead
            // leaves every replica that has already submitted polling
            // until its budget drains, because the epoch requires this
            // one and it is not coming.
            PopulationEpochAction::Abstain
        } else {
            PopulationEpochAction::LocalWork
        }
    }

    fn observe_pending(&mut self) {
        self.pending = true;
    }

    fn observe_ready(&mut self) {
        self.pending = false;
        self.epoch = self
            .epoch
            .checked_add(1)
            .expect("population epoch must fit u64");
    }
}

#[cfg(feature = "bank-rpc")]
fn population_call(
    result: Result<
        anneal_core::cooperative_search::PopulationSynchronizationOutcome,
        anneal_core::cooperative_search::CooperativeRunError,
    >,
) -> anneal_core::cooperative_search::PopulationSynchronizationOutcome {
    match result {
        Ok(outcome) => outcome,
        Err(anneal_core::cooperative_search::CooperativeRunError::InvalidPopulationPlan {
            ..
        }) => anneal_core::cooperative_search::PopulationSynchronizationOutcome::Unaddressed,
        Err(error) => {
            panic!("population call must preserve cooperative invariants: {error}")
        }
    }
}

#[cfg(feature = "bank-rpc")]
fn active_population_action(
    progress: &PopulationEpochProgress,
    charged: usize,
    remaining: usize,
    interval: usize,
    representative_available: bool,
) -> PopulationEpochAction {
    assert!(interval > 0, "population interval must be positive");
    let threshold = usize::try_from(
        progress
            .epoch()
            .checked_add(1)
            .and_then(|epoch| {
                epoch.checked_mul(u64::try_from(interval).expect("population interval fits u64"))
            })
            .expect("population charged-work threshold must fit u64"),
    )
    .expect("population charged-work threshold must fit usize");
    let budget = charged
        .checked_add(remaining)
        .expect("charged and remaining work must fit usize");
    progress.action(
        charged >= threshold && threshold < budget,
        representative_available,
    )
}

#[cfg(test)]
#[cfg(feature = "bank-rpc")]
fn resolve_population_barrier<F>(
    mut outcome: anneal_core::cooperative_search::PopulationSynchronizationOutcome,
    mut poll: F,
) -> anneal_core::cooperative_search::PopulationSynchronizationOutcome
where
    F: FnMut() -> anneal_core::cooperative_search::PopulationSynchronizationOutcome,
{
    while matches!(
        outcome,
        anneal_core::cooperative_search::PopulationSynchronizationOutcome::Pending { .. }
    ) {
        outcome = poll();
    }
    outcome
}

#[cfg(feature = "bank-rpc")]
fn finite_trace_energy(energy: f64) -> Option<f64> {
    energy.is_finite().then_some(energy)
}

#[cfg(all(feature = "bank-rpc", feature = "ira"))]
fn snapshot_index_cost(coordinate_dim: usize) -> usize {
    coordinate_dim
        .checked_mul(2)
        .and_then(|evaluations| evaluations.checked_add(3))
        .expect("receiving ride certification cost must fit usize")
}

#[cfg(feature = "bank-rpc")]
fn ride_producer_budget(
    remaining: usize,
    receiver_reserve: usize,
    proposal_reserve: usize,
    configured_cap: u64,
) -> Option<u64> {
    let reserved = receiver_reserve.checked_add(proposal_reserve)?;
    let available = remaining.checked_sub(reserved)?;
    let available = u64::try_from(available).unwrap_or(u64::MAX);
    (available > 0).then_some(available.min(configured_cap))
}

#[cfg(feature = "bank-rpc")]
fn ride_failure_reason(failure: anneal_core::ride_ledger::RideFailure) -> &'static str {
    use anneal_core::ride_ledger::RideFailure;

    match failure {
        RideFailure::QuenchNotConverged => "ride_quench_not_converged",
        RideFailure::SaddleNotConverged => "ride_saddle_not_converged",
        RideFailure::MinimumModeNotConverged => "ride_minimum_mode_not_converged",
        RideFailure::PrfoNotConverged => "ride_prfo_not_converged",
        RideFailure::SaddleForceNotConverged => "ride_saddle_force_not_converged",
        RideFailure::ActivationNotEscaped => "ride_activation_not_escaped",
        RideFailure::MinimumModeLostCurvature => "ride_minimum_mode_lost_curvature",
        RideFailure::NoNegativeMode => "ride_no_negative_mode",
        RideFailure::HigherIndex => "ride_higher_index",
        RideFailure::IrcNotConverged => "ride_irc_not_converged",
        RideFailure::CollapsedConnection => "ride_collapsed_connection",
        RideFailure::Surface => "ride_surface_error",
        RideFailure::BudgetExhausted => "ride_budget_exhausted",
        RideFailure::DisconnectedConnection => "ride_disconnected_connection",
    }
}

#[cfg(feature = "bank-rpc")]
fn discovery_role_allows_ride(role: Option<anneal_core::discovery_roster::DiscoveryRole>) -> bool {
    matches!(
        role,
        Some(anneal_core::discovery_roster::DiscoveryRole::SaddleRide)
    )
}

#[cfg(feature = "bank-rpc")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AppliedDecree {
    snapshot: u64,
    basin: u64,
}

#[cfg(feature = "bank-rpc")]
fn committed_decree_audit_line(
    replica: u32,
    decree: &anneal_core::raft::wire::ExplorationDecree,
) -> Option<String> {
    let assignment = decree
        .assignments
        .iter()
        .find(|assignment| assignment.replica == replica)?;
    Some(
        serde_json::json!({
            "kind": "brain_commit",
            "replica": replica,
            "snapshot": assignment.decree_index,
            "anchor_basin": assignment.anchor_basin,
            "right_side": assignment.right_side,
            "bridge_duty": assignment.bridge_duty,
            "left_basin": decree.left_basin,
            "right_basin": decree.right_basin,
            "normalized_lambda2": decree.algebraic_connectivity,
            "conductance": decree.seam_conductance,
        })
        .to_string(),
    )
}

#[cfg(feature = "bank-rpc")]
fn applied_decree_audit_line(replica: u32, snapshot: u64, anchor_basin: u64) -> String {
    serde_json::json!({
        "kind": "spectral_anchor",
        "replica": replica,
        "snapshot": snapshot,
        "anchor_basin": anchor_basin,
    })
    .to_string()
}

#[cfg(feature = "bank-rpc")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DecreeAnchorAction {
    Ignore,
    MarkApplied { snapshot: u64, basin: u64 },
    Fetch { snapshot: u64, basin: u64 },
}

#[cfg(feature = "bank-rpc")]
fn decree_anchor_action(
    applied: Option<AppliedDecree>,
    assignment: Option<&anneal_core::raft::wire::ReplicaAssignment>,
    current_basin: Option<u64>,
) -> DecreeAnchorAction {
    let Some(assignment) = assignment else {
        return DecreeAnchorAction::Ignore;
    };
    if applied.is_some_and(|applied| assignment.decree_index <= applied.snapshot) {
        return DecreeAnchorAction::Ignore;
    }
    if current_basin == Some(assignment.anchor_basin)
        || applied.is_some_and(|applied| applied.basin == assignment.anchor_basin)
    {
        DecreeAnchorAction::MarkApplied {
            snapshot: assignment.decree_index,
            basin: assignment.anchor_basin,
        }
    } else {
        DecreeAnchorAction::Fetch {
            snapshot: assignment.decree_index,
            basin: assignment.anchor_basin,
        }
    }
}

#[cfg(feature = "bank-rpc")]
fn settled_external_calls(requested: u64, remaining: usize) -> u64 {
    requested.min(u64::try_from(remaining).unwrap_or(u64::MAX))
}

#[cfg(feature = "bank-rpc")]
fn ride_total_charged_calls(
    report: anneal_core::cooperative_search::RideReportOutcome,
    producer_calls: u64,
) -> u64 {
    match report {
        anneal_core::cooperative_search::RideReportOutcome::Credited(credit) => {
            credit.total_charged_evaluations
        }
        anneal_core::cooperative_search::RideReportOutcome::Rejected
        | anneal_core::cooperative_search::RideReportOutcome::LocalFallback
        | anneal_core::cooperative_search::RideReportOutcome::SharingDisabled => producer_calls,
    }
}

#[cfg(feature = "bank-rpc")]
fn ride_checkpoint_action(
    report: anneal_core::cooperative_search::RideReportOutcome,
    destination: Option<Array1<f64>>,
    producer_calls: u64,
) -> CheckpointAction {
    use anneal_core::cooperative_search::RideReportOutcome;

    let total_calls =
        usize::try_from(ride_total_charged_calls(report, producer_calls)).unwrap_or(usize::MAX);
    match report {
        RideReportOutcome::Credited(credit) => match (credit.certified_connection, destination) {
            (true, Some(state)) => CheckpointAction::ExternalProposal {
                state,
                action: "certified_ride".into(),
                external_calls: total_calls,
            },
            _ => CheckpointAction::ExternalWork {
                external_calls: total_calls,
            },
        },
        RideReportOutcome::Rejected
        | RideReportOutcome::LocalFallback
        | RideReportOutcome::SharingDisabled => CheckpointAction::ExternalWork {
            external_calls: total_calls,
        },
    }
}

#[cfg(feature = "bank-rpc")]
fn complete_checkpoint_trace<T>(
    cooperative: &mut anneal_core::cooperative_search::CooperativeRun,
    replica: u32,
    slice_sequence: &mut u64,
    charged_work: usize,
    energy: f64,
    body: impl FnOnce(&mut anneal_core::cooperative_search::CooperativeRun, &mut u64) -> T,
) -> T {
    use anneal_core::cooperative_search::{
        PolicyRole, ProposalFamily, SliceAdoption, SliceQuench, SliceTrace, SliceValidation,
    };

    let slices_before = cooperative
        .events()
        .iter()
        .filter(|event| event.slice.is_some())
        .count();
    let sequence_before = *slice_sequence;
    let result = body(cooperative, slice_sequence);
    let slices_after = cooperative
        .events()
        .iter()
        .filter(|event| event.slice.is_some())
        .count();
    match slices_after.saturating_sub(slices_before) {
        0 => {
            assert_eq!(
                *slice_sequence, sequence_before,
                "slice sequence cannot advance without a diagnostic"
            );
            let slice = sequence_before
                .checked_add(1)
                .expect("slice sequence must fit u64");
            cooperative
                .record_slice(
                    replica,
                    SliceTrace {
                        slice,
                        current_basin: None,
                        active_relation: None,
                        policy_role: PolicyRole::Local,
                        policy_reason: "local_checkpoint",
                        proposal_family: ProposalFamily::Local,
                        sampled_basin: None,
                        descriptor_step_norm: None,
                        cartesian_step_norm: None,
                        validation: SliceValidation::NotAttempted,
                        quench: SliceQuench::NotAttempted,
                        adoption: SliceAdoption::NotAttempted,
                        novelty: None,
                        energy: finite_trace_energy(energy),
                        charged_work: u64::try_from(charged_work)
                            .expect("checkpoint charge must fit u64"),
                    },
                )
                .expect("local checkpoint trace must remain complete");
            *slice_sequence = slice;
        }
        1 => assert_eq!(
            *slice_sequence,
            sequence_before
                .checked_add(1)
                .expect("slice sequence must fit u64"),
            "one checkpoint diagnostic must advance one slice"
        ),
        count => panic!("one checkpoint emitted {count} slice diagnostics"),
    }
    result
}

/// Records one population-phase reconfiguration slice and returns the
/// boundary proposal that adopts `state`. The three population outcomes
/// (hyperband reseed of a surplus replica, adoption of a better isomer of
/// the same packing from a foreign parent, and the leave of a replica
/// whose parent is foreign) differ only in role, reason, family and the
/// state they hand back; the trace bookkeeping is one thing.
#[cfg(feature = "bank-rpc")]
fn population_reconfiguration(
    cooperative: &mut anneal_core::cooperative_search::CooperativeRun,
    replica: u32,
    slice_sequence: &mut u64,
    checkpoint_charged: usize,
    snapshot: &ChainCheckpoint<'_>,
    sampled_basin: Option<u64>,
    policy_role: anneal_core::cooperative_search::PolicyRole,
    policy_reason: &'static str,
    proposal_family: anneal_core::cooperative_search::ProposalFamily,
    state: Array1<f64>,
) -> CheckpointAction {
    use anneal_core::cooperative_search::{
        SliceAdoption, SliceQuench, SliceTrace, SliceValidation,
    };

    *slice_sequence = slice_sequence
        .checked_add(1)
        .expect("slice sequence must fit u64");
    let reconfiguration = SliceTrace {
        slice: *slice_sequence,
        current_basin: None,
        active_relation: None,
        policy_role,
        policy_reason,
        proposal_family,
        sampled_basin,
        descriptor_step_norm: None,
        cartesian_step_norm: Some(vector_distance(
            snapshot
                .current_state()
                .as_slice()
                .expect("LJ state is contiguous"),
            state.as_slice().expect("LJ proposal is contiguous"),
        )),
        validation: SliceValidation::Accepted,
        quench: SliceQuench::Converged,
        adoption: SliceAdoption::Adopted,
        novelty: None,
        energy: finite_trace_energy(snapshot.best_energy()),
        charged_work: u64::try_from(checkpoint_charged).expect("checkpoint charge must fit u64"),
    };
    cooperative
        .record_slice(replica, reconfiguration)
        .expect("population checkpoint trace must remain complete");
    CheckpointAction::BoundaryProposal {
        state,
        action: policy_reason.to_owned(),
    }
}

#[cfg(feature = "bank-rpc")]
/// Counts which phase of the cooperative checkpoint took each checkpoint.
///
/// The closure returns from a dozen places (probe, core-class restart,
/// ride, population barrier, hear, invert, leave gate, policy, jump, the
/// decision itself); a phase with zero firings over a run is inert, which
/// is what every mechanism that "did nothing" turned out to be. The tally
/// is printed on the seed record; a smoke run that expects a mechanism
/// asserts its count is positive.
#[derive(Default)]
struct PhaseTally {
    counts: std::collections::BTreeMap<&'static str, usize>,
}

impl PhaseTally {
    fn fire(&mut self, phase: &'static str) {
        *self.counts.entry(phase).or_insert(0) += 1;
    }

    fn report(&self) -> String {
        self.counts
            .iter()
            .map(|(phase, count)| format!("{phase}={count}"))
            .collect::<Vec<_>>()
            .join(" ")
    }
}

/// Which occupancy certificates this replica has already printed.
#[derive(Default)]
struct RetireAnnouncements {
    putative: bool,
    done: bool,
}

/// Occupancy retire phase: when the coordinator's policy evidence certifies
/// the ensemble's coverage (certified attractor, saturated packing census,
/// leftover dwell, occupied families at the measured floor) and the
/// retire rule accepts it for a cluster-shaped putative structure, the
/// replica retires with the certificate as its reason. A certificate
/// that is complete but not yet retirable is announced once as putative.
#[cfg(feature = "bank-rpc")]
fn occupancy_retire_phase(
    announced: &mut RetireAnnouncements,
    policy: &anneal_core::catalog_policy::CatalogPolicyInput,
    snapshot: &ChainCheckpoint<'_>,
) -> Option<String> {
    let n_occupied_families = policy.occupied_family_count;
    let certificate = occupancy_complete_at(
        policy.mixing.certified_attractor,
        policy.packing_saturated,
        policy.leftover_dwell,
        n_occupied_families,
        policy.min_families,
    )?;
    let putative = snapshot
        .best_state()
        .map(|state| state.to_vec())
        .unwrap_or_else(|| snapshot.current_state().to_vec());
    if occupancy_retire_at(
        certificate,
        policy.packing_saturated,
        policy.leftover_dwell,
        policy.ei_exhausted,
        n_occupied_families,
        policy.min_families,
    ) && occupancy_is_cluster(&putative)
    {
        if !announced.done {
            println!(
                "  done {}  hops {}  best {:.6}",
                certificate.as_str(),
                snapshot.hops(),
                snapshot.best_energy()
            );
            let _ = std::io::stdout().flush();
            announced.done = true;
        }
        return Some(certificate.as_str().to_owned());
    }
    let mut announced_putative = announced.putative;
    if !announced_putative {
        println!(
            "  putative {}  hops {}  best {:.6}",
            certificate.as_str(),
            snapshot.hops(),
            snapshot.best_energy()
        );
        let _ = std::io::stdout().flush();
        announced_putative = true;
        announced.putative = announced_putative;
    }
    None
}

/// Whether odd replicas take the APE ridge-seed path at checkpoints
/// (`CATALOG_APE_SEEDS`, default on; `0` turns it off). The armed leave
/// quench needs the SOAP Jacobian at every force evaluation and runs at
/// about ten seconds a hop on LJ75, so a cooperative ensemble's wall is
/// the odd half's; turning the seeds off gives a coordinator-only
/// comparison against private chains at equal wall.
#[cfg(feature = "bank-rpc")]
fn ape_seeds_enabled() -> bool {
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED.get_or_init(|| !std::env::var("CATALOG_APE_SEEDS").is_ok_and(|v| v == "0"))
}

/// The checkpoint takes no action: the tally counts a "continue", the
/// trace is completed for the slice, and the chain goes on.
#[cfg(feature = "bank-rpc")]
fn continue_checkpoint(
    phases: &mut PhaseTally,
    cooperative: &mut anneal_core::cooperative_search::CooperativeRun,
    replica: u32,
    slice_sequence: &mut u64,
    checkpoint_charged: usize,
    best_energy: f64,
) -> CheckpointAction {
    phases.fire("continue");
    complete_checkpoint_trace(
        cooperative,
        replica,
        slice_sequence,
        checkpoint_charged,
        best_energy,
        |_cooperative, _slice_sequence| CheckpointAction::Continue,
    )
}

/// State of the census restart phase across checkpoints.
#[derive(Default)]
struct RestartState {
    /// Hop of the last restart, for the quiet cooldown.
    last_hop: usize,
    /// Restarts taken.
    restarts: usize,
}

/// Population stopping rule (=CATALOG_RESTART_VISITS=k=,
/// =CATALOG_RESTART_QUIET=q=): a region `k` other replicas have reached
/// that this replica has not deepened from for `q` hops is dead by the
/// ensemble's count, and the replica hands its remaining budget to a
/// fresh random start. Measured on LJ75 a shelf-absorbed chain crosses at
/// about 8.5e-7 per hop and a fresh chain at about 5e-6, so the exchange
/// pays six to one once the region is known dead. Returns the fresh
/// start; `hear` is told the best-hop clock restarted.
#[cfg(feature = "bank-rpc")]
#[allow(clippy::too_many_arguments)]
fn census_restart_phase(
    state: &mut RestartState,
    hear: &mut HearState,
    replica: u32,
    snapshot: &ChainCheckpoint<'_>,
    checkpoint_sequence: u64,
    crowd: u64,
    quiet_now: usize,
    run_cfg: &Config,
) -> Option<Array1<f64>> {
    use rand::SeedableRng;
    let visits: u64 = anneal_core::env::parsed("CATALOG_RESTART_VISITS").unwrap_or(0);
    let quiet: usize = anneal_core::env::parsed("CATALOG_RESTART_QUIET").unwrap_or(20_000);
    if visits == 0
        || crowd < visits
        || quiet_now < quiet
        || snapshot.hops().saturating_sub(state.last_hop) < quiet
    {
        return None;
    }
    let mut restart_rng = rand::rngs::StdRng::seed_from_u64(
        (u64::from(replica) << 41) ^ checkpoint_sequence.wrapping_mul(0xD6E8_FEB8_6659_FD93),
    );
    let fresh = random_cluster(
        run_cfg.n_points,
        0.7,
        run_cfg.min_separation,
        &mut restart_rng,
    );
    state.last_hop = snapshot.hops();
    hear.last_best_hop = snapshot.hops();
    state.restarts += 1;
    println!(
        "  census restart hops {}  crowd {}  restarts {}",
        snapshot.hops(),
        crowd,
        state.restarts
    );
    let _ = std::io::stdout().flush();
    Some(fresh)
}

/// State of the census jump phase across checkpoints.
#[derive(Default)]
struct JumpState {
    /// Hop of the last jump, for the cooldown.
    last_hop: usize,
    /// Jumps taken.
    jumps: usize,
}

/// Census jump phase (Iwamatsu and Okabe): when the ensemble census has
/// visited this replica's basin at least `CATALOG_JUMP_VISITS` times and
/// the cooldown of `CATALOG_JUMP_COOLDOWN` hops has passed, a short
/// unquenched walk of `JUMP_STEPS` steps of half-width `JUMP_STEP` times
/// the length scale leaves the region. The shared visit count is the
/// population's, so a region many replicas exhausted is left by all of
/// them without any being handed a structure. Returns the walked state.
fn census_jump_phase(
    state: &mut JumpState,
    replica: u32,
    snapshot: &ChainCheckpoint<'_>,
    checkpoint_sequence: u64,
    local_basin_visits: u64,
    length_scale: f64,
) -> Option<Vec<f64>> {
    use rand::{Rng, SeedableRng};
    let census_jump_visits: u64 = anneal_core::env::parsed("CATALOG_JUMP_VISITS").unwrap_or(0);
    let census_jump_cooldown: usize =
        anneal_core::env::parsed("CATALOG_JUMP_COOLDOWN").unwrap_or(2000);
    if census_jump_visits == 0
        || local_basin_visits < census_jump_visits
        || snapshot.hops().saturating_sub(state.last_hop) < census_jump_cooldown
    {
        return None;
    }
    let state_view = snapshot.current_state();
    let here = state_view.as_slice()?;
    let mut jump_rng = rand::rngs::StdRng::seed_from_u64(
        (u64::from(replica) << 40) ^ checkpoint_sequence.wrapping_mul(0x9E37_79B9_7F4A_7C15),
    );
    let steps: usize = anneal_core::env::parsed("JUMP_STEPS").unwrap_or(10);
    let half: f64 = anneal_core::env::parsed("JUMP_STEP").unwrap_or(0.38) * length_scale;
    let mut jumped = here.to_vec();
    for _ in 0..steps.max(1) {
        for v in jumped.iter_mut() {
            *v += jump_rng.random_range(-half..half);
        }
    }
    state.last_hop = snapshot.hops();
    state.jumps += 1;
    println!(
        "  census jump hops {}  visits {}  jumps {}",
        snapshot.hops(),
        local_basin_visits,
        state.jumps
    );
    let _ = std::io::stdout().flush();
    Some(jumped)
}

/// State of the hear phase across checkpoints.
struct HearState {
    /// Best energy at the last hear clock reset.
    last_best: f64,
    /// Hop of the last own improvement or adoption.
    last_best_hop: usize,
    /// The structure last adopted, for the post-hear walk trace.
    heard_structure: Option<Vec<f64>>,
    /// Adoptions of another family's structure.
    other_family: usize,
}

impl Default for HearState {
    fn default() -> Self {
        Self {
            last_best: f64::INFINITY,
            last_best_hop: 0,
            heard_structure: None,
            other_family: 0,
        }
    }
}

/// One independently budgeted LJ replica against an isolated descriptor catalog.
fn run_capnp_catalog(
    cfg: &Config,
    ledger: &mut Ledger,
    relax: &mut (dyn FnMut(&mut Ledger, ArrayView1<f64>, usize) -> (f64, Array1<f64>) + Send),
    grad: &mut (dyn FnMut(&mut Ledger, ArrayView1<f64>) -> Option<Array1<f64>> + Send),
    seed: u64,
    endpoint: Option<&str>,
    core_class: Option<(usize, usize)>,
    surfaces: Option<Arc<Mutex<anneal_core::methods::two_phase::SurfacePortfolio>>>,
) -> Outcome {
    use anneal_core::catalog::lj::{descriptor_space, system_signature};
    use anneal_core::catalog_policy::{ActiveCatalogRelation, PolicyAction, PolicyReason};
    use anneal_core::catalog_rpc::client::{CatalogClient, ClientConfig};
    use anneal_core::catalog_rpc::{BridgeAssignmentRecord, BridgeCrossingRecord};
    use anneal_core::catalog_rpc::{CatalogIdentity, INCUMBENT_SAMPLE_DRAW, SPARSE_SAMPLE_DRAW};
    use anneal_core::cooperative_search::ledger::ChargeKind;
    use anneal_core::cooperative_search::{
        CatalogBridgeOutcome, CatalogHoleOutcome, CatalogSampleOutcome, CatalogSamplesOutcome,
        CooperativeRun, PolicyEvidenceOutcome, PolicyRole, PopulationSynchronizationOutcome,
        ProposalFamily, RunManifest, SliceAdoption, SliceQuench, SliceTrace, SliceValidation,
    };
    #[cfg(feature = "ira")]
    use anneal_core::cooperative_search::{RideClaimOutcome, RideReportOutcome};
    use anneal_core::methods::feynman_kac::{
        population_family_position, population_rejuvenation_draw,
    };
    #[cfg(feature = "ira")]
    use anneal_core::pes_exploration::{PesExplorationConfig, RideMethod};
    #[cfg(feature = "ira")]
    use anneal_core::ride_execution::{
        CatalogRideExecutionConfig, connected_destination, execute_catalog_ride,
    };
    use rand::{Rng, SeedableRng};

    let campaign = required_catalog_env("CATALOG_CAMPAIGN");
    let ensemble = required_catalog_env("CATALOG_ENSEMBLE");
    let sharing_mode = std::env::var("CATALOG_SHARING").ok();
    let sharing = anneal_core::campaign::catalog_transport_is_shared(
        sharing_mode.as_deref(),
        endpoint.is_some(),
    )
    .unwrap_or_else(|error| panic!("{error}"));
    let evidence_only = anneal_core::env::flag("CATALOG_EVIDENCE_ONLY");
    if evidence_only {
        println!("  catalog channels: surface evidence only; geometry policy disabled");
    }
    let replica = required_catalog_env("CATALOG_REPLICA")
        .parse::<u32>()
        .expect("CATALOG_REPLICA must be an unsigned integer");
    let signature = system_signature(cfg.n_points).expect("LJ catalog signature must be valid");
    let signature_digest = signature.digest();
    let descriptor_space = descriptor_space();
    let mut cooperative = CooperativeRun::new(
        [replica],
        u64::try_from(ledger.budget()).expect("LJ budget must fit the cooperative ledger"),
    )
    .expect("single-replica local ledger must be valid");
    if let Some((patience, trial)) = core_class {
        cooperative.enable_core_class(patience, trial);
    }
    if let Some(endpoint) = endpoint {
        let address = endpoint
            .parse()
            .expect("CATALOG_RPC must be a host:port socket address");
        let identity = CatalogIdentity {
            campaign: campaign.clone(),
            ensemble: ensemble.clone(),
            replica,
            signature_digest,
        };
        match CatalogClient::connect(address, identity, ClientConfig::default()) {
            Ok(mut client) => {
                if let Err(error) = client.attach(1) {
                    eprintln!("catalog attach rejected ({error}); local execution remains active");
                }
                cooperative
                    .attach_client(replica, client)
                    .expect("configured replica must accept its catalog client");
            }
            Err(error) => eprintln!(
                "catalog {endpoint} unavailable ({error}); local execution remains active"
            ),
        }
    }

    // Server brains: each replica process runs a raft node over the
    // decree bus; the elected leader reads the coordinator's seam
    // through the observer protocol on its own cadence, far slower
    // than minimization, and proposes exploration decrees the group
    // replicates. Chains apply the newest committed decree at their
    // next checkpoint and never wait for one. Enabled by the brain
    // environment; absent variables spawn nothing.
    #[cfg(feature = "bank-rpc")]
    let decree_slot: std::sync::Arc<
        std::sync::Mutex<Option<anneal_core::raft::wire::ExplorationDecree>>,
    > = std::sync::Arc::new(std::sync::Mutex::new(None));
    #[cfg(feature = "bank-rpc")]
    let brain_stop = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
    #[cfg(feature = "bank-rpc")]
    let brain_handle = if !evidence_only
        && let (Ok(listen), Ok(peers_raw)) = (
            std::env::var("CATALOG_BRAIN_LISTEN"),
            std::env::var("CATALOG_BRAIN_PEERS"),
        ) {
        use anneal_core::raft::wire::{
            ExplorationDecree, assign_seam_work, decode_decree, encode_decree,
        };
        use anneal_core::raft::{RaftNode, Role};
        let mut peer_ids = Vec::new();
        let mut peers = Vec::new();
        for part in peers_raw.split(',').filter(|p| !p.is_empty()) {
            let (peer_id, url) = part
                .split_once('=')
                .expect("CATALOG_BRAIN_PEERS holds id=url pairs");
            let peer_id = peer_id
                .parse::<u32>()
                .expect("brain peer id must be an unsigned integer");
            peer_ids.push(peer_id);
            peers.push((peer_id, url.to_owned()));
        }
        let slot = std::sync::Arc::clone(&decree_slot);
        let stop = std::sync::Arc::clone(&brain_stop);
        let brain_endpoint = endpoint.map(str::to_owned);
        let brain_campaign = campaign.clone();
        let brain_ensemble = ensemble.clone();
        let brain_signature_digest = signature_digest;
        let decree_members = anneal_core::raft::decree_members(replica, &peer_ids);
        let brain_publish = std::env::var("CATALOG_BRAIN_PUBLISH").ok();
        Some(std::thread::spawn(move || {
            let bus = anneal_core::decree_bus::DecreeBus::new(replica, &listen, &peers)
                .expect("brain bus must bind its own address");
            // Observation is opt-in: without an address the brain
            // opens no publisher and nothing watches it.
            let bus = match brain_publish.as_deref() {
                Some(url) => bus
                    .publishing(url)
                    .expect("brain publish address must bind"),
                None => bus,
            };
            let mut node = RaftNode::new(replica, peer_ids, 200, 37);
            let mut observer = None;
            let mut now = 0u64;
            let mut last_lead_work = 0u64;
            let mut last_proposed_snapshot = 0u64;
            while !stop.load(std::sync::atomic::Ordering::Relaxed) {
                std::thread::sleep(std::time::Duration::from_millis(10));
                now += 1;
                for (to, message) in node.tick(now) {
                    let _ = bus.send(to, &message);
                }
                for (from, message) in bus.poll() {
                    for (to, out) in node.receive(from, message, now) {
                        let _ = bus.send(to, &out);
                    }
                }
                for decree in node.take_committed() {
                    if let Ok(decoded) = decode_decree(&decree.payload) {
                        if let Some(line) = committed_decree_audit_line(replica, &decoded) {
                            println!("{line}");
                            let _ = io::stdout().flush();
                        }
                        if let Ok(mut held) = slot.lock() {
                            *held = Some(decoded);
                        }
                    }
                }
                // Leader duty every ~2 s of brain time: read the seam,
                // decree the split.
                if node.role() == Role::Leader
                    && now.saturating_sub(last_lead_work) >= 200
                    && let Some(endpoint) = brain_endpoint.as_deref()
                {
                    last_lead_work = now;
                    if observer.is_none() {
                        let identity = anneal_core::catalog_rpc::CatalogIdentity {
                            campaign: brain_campaign.clone(),
                            ensemble: brain_ensemble.clone(),
                            replica: u32::MAX,
                            signature_digest: brain_signature_digest,
                        };
                        observer = endpoint.parse().ok().and_then(|address| {
                            anneal_core::catalog_rpc::client::CatalogClient::connect(
                                address,
                                identity,
                                anneal_core::catalog_rpc::client::ClientConfig::default(),
                            )
                            .ok()
                            .map(|client| (client, 1u64))
                        });
                    }
                    if let Some((client, sequence)) = observer.as_mut() {
                        match client.observer_status(*sequence) {
                            Ok(status) => {
                                *sequence += 1;
                                if status.snapshot_version > last_proposed_snapshot
                                    && let Some(seam) = status.seam
                                {
                                    let assignments = assign_seam_work(
                                        &decree_members,
                                        seam.left_basin,
                                        seam.right_basin,
                                        status.snapshot_version,
                                    );
                                    let decree = ExplorationDecree {
                                        algebraic_connectivity: seam.algebraic_connectivity,
                                        seam_conductance: seam.conductance,
                                        left_basin: seam.left_basin,
                                        right_basin: seam.right_basin,
                                        assignments,
                                    };
                                    if node.propose(encode_decree(&decree)).is_ok() {
                                        last_proposed_snapshot = status.snapshot_version;
                                    }
                                }
                            }
                            Err(_) => {
                                observer = None;
                            }
                        }
                    }
                }
            }
        }))
    } else {
        None
    };

    let mut run_cfg = cfg.clone();
    // The checkpoint path forced budget_window on, so every coordinated
    // chain ran an adaptive-temperature acceptance the serial baseline
    // runs without. The measured crossing is an excursion of about
    // thirty-five accepted steps, and Hop.shave_convicts puts the cost
    // of any per-step acceptance shave at its k-th power: six percent a
    // step is an order of magnitude at that length, which is the
    // suppression the coordinated runs show against the serial rate --
    // zero crossings in seven hundred thousand hops where the serial
    // rate predicts nine. Hop.alone_mul_split exonerates checkpoint
    // interruptions at the same stroke: one reset per five hundred hops
    // costs seven percent of the crossings, not ninety.
    //
    // The acceptance law of a coordinated chain is now byte-identical
    // to the serial baseline unless the caller's config says otherwise.
    run_cfg.budget_window = cfg.budget_window;
    // An ensemble at one temperature is one search repeated. Spreading
    // replicas across a geometric ladder is the reference answer to the
    // funnel problem, so it is available here, opt-in: the recommended
    // protocol leaves the temperature alone and the published runs used
    // it that way, so this only applies when a ladder top is named.
    if let Some(top) = anneal_core::env::parsed::<f64>("CATALOG_TEMP_LADDER")
        .filter(|value| value.is_finite() && *value > 0.0)
    {
        let rungs = std::env::var("CATALOG_BRAIN_PEERS")
            .ok()
            .map(|peers| peers.split(',').filter(|p| !p.is_empty()).count() + 1)
            .unwrap_or(1);
        let walked = anneal_core::replica_exchange::replica_temperature(
            replica,
            rungs,
            run_cfg.temperature,
            top,
        );
        println!(
            "  temperature ladder rung {replica}/{rungs}: {walked:.4} (base {:.4} top {top:.4})",
            run_cfg.temperature
        );
        run_cfg.temperature = walked;
    }
    if let Ok(hops) = std::env::var("CATALOG_MAX_HOPS") {
        let hops: usize = hops
            .parse()
            .expect("CATALOG_MAX_HOPS must be a positive hop count");
        assert!(hops >= 1, "CATALOG_MAX_HOPS must be a positive hop count");
        run_cfg.max_hops = Some(hops);
        println!("  hop cap {hops}");
        println!("  leftover-SOAP TIS seats");
        println!("  occupancy min families spectral");
        println!("  occupancy leave archive hole");
        println!("  packing invert nu3 pullback");
        println!("  leave ridge climb");
        println!(
            "  gt stop packing  n>={}  p0<{}  families>=spectral  (coordinator occupancy_gt)",
            anneal_core::catalog::PRODUCTION_MINIMUM_VISITS,
            anneal_core::catalog::PRODUCTION_MAX_UNSEEN_MASS,
        );
    }
    // Cooperative wells: the SOAP archive the hole step walks away
    // from, fed with every minimum the coordinator hands this replica.
    // Off only when CATALOG_COOP_WELLS=0.
    let coop_wells_enabled = std::env::var("CATALOG_COOP_WELLS")
        .ok()
        .is_none_or(|value| value != "0");
    // Shared bias: remote minima are handed back to the run loop for
    // deposit into this chain's own well-tempered bias, so acceptance
    // feels what the ensemble has visited continuously rather than only
    // at steering decisions. Gated until the paired smoke measures it.
    let shared_bias_enabled = anneal_core::env::flag("CATALOG_SHARED_BIAS");
    // The ensemble frontier ladder ships raw doorway states through the
    // coordinator at checkpoint cadence; the hop loop queues and folds,
    // this layer only moves the mail.
    let frontier_exchange_enabled = anneal_core::env::flag("CATALOG_FRONTIER_EXCHANGE");
    // Bridge segments: when the coordinator has commissioned a bridge
    // across the referee's seam, this replica takes a region assignment,
    // jumps to a stored entry state when one exists, and reports every
    // region change as a crossing. Confinement is soft: crossings are
    // recorded rather than moves rejected, so the weights and the
    // committor surrogate accumulate without touching the acceptance
    // rule. Gated until the paired smoke measures it.
    let bridge_enabled = anneal_core::env::flag("CATALOG_BRIDGE");
    // Histogram screen: on stall, candidate escape perturbations are
    // ranked by the novelty of their per-center class histogram against
    // the chain's own visited histograms, and the most novel one is
    // proposed. The measured basis: the sealed best is class-identical
    // to the icosahedral reference while Marks separates by class
    // counts alone, so distance in histogram space is exactly the
    // direction a funnel exchange must move, named without naming any
    // structure. Gated until the paired smoke measures it.
    let histo_screen = anneal_core::env::flag("CATALOG_HISTO_SCREEN");
    // Difficulty retargeting, the proof-of-work governor transplanted:
    // a blockchain holds its block rate constant by adjusting the
    // difficulty against measured production; here the measured
    // quantity is ensemble basin discovery per force evaluation, from
    // the exact census counters every policy reply already carries.
    // When discovery dries up against the run's own history the
    // exploration gain rises, scaling escape perturbations; recovery
    // decays it back toward one. Self-relative, no structural prior,
    // no protocol change. Gated until the paired smoke measures it.
    let difficulty_enabled = anneal_core::env::flag("CATALOG_DIFFICULTY");
    let mut difficulty_gain = 1.0_f64;
    let mut governor_last: Option<(u64, u64)> = None;
    let mut governor_ema: Option<f64> = None;
    let histo_radius = anneal_core::env::parsed::<f64>("CATALOG_HISTO_RADIUS")
        .filter(|value| value.is_finite() && *value > 0.0)
        .unwrap_or(1.4);
    let mut histo_leaders: Vec<Array1<f64>> = Vec::new();
    let mut histo_history: std::collections::VecDeque<std::collections::BTreeMap<usize, usize>> =
        std::collections::VecDeque::new();
    // External MD segments: a burst of thermostatted dynamics from the
    // live state, quenched through the ordinary proposal path, with the
    // engine's force calls settled into the same ledger every other
    // evaluation draws from. Diversity from physics rather than from
    // the proposal family's geometry. Gated until measured.
    let md_engine = std::env::var("CATALOG_MD_ENGINE").ok().and_then(|name| {
        // LAMMPS runs in process through liblammps and needs no binary;
        // GROMACS has no embeddable C API and needs its gmx path.
        let binary = std::env::var("CATALOG_MD_BIN").unwrap_or_else(|_| {
            assert_ne!(
                name, "gromacs",
                "CATALOG_MD_ENGINE=gromacs requires CATALOG_MD_BIN naming gmx"
            );
            String::new()
        });
        let workdir =
            std::env::temp_dir().join(format!("anneal-md-{campaign}-{ensemble}-{replica}"));
        let engine =
            anneal_core::md_engine::engine_by_name(&name, std::path::Path::new(&binary), &workdir);
        if engine.is_none() {
            panic!("CATALOG_MD_ENGINE must be lammps or gromacs, got {name}");
        }
        engine
    });
    let md_steps = anneal_core::env::parsed::<usize>("CATALOG_MD_STEPS")
        .unwrap_or(500)
        .max(1);
    let md_temperature = anneal_core::env::parsed::<f64>("CATALOG_MD_TEMP")
        .filter(|value| value.is_finite() && *value > 0.0)
        .unwrap_or(1.2);
    let mut active_bridge: Option<BridgeAssignmentRecord> = None;
    let mut pending_deposits: Vec<Array1<f64>> = Vec::new();
    // Peer-to-peer census over nng (CENSUS_BUS_BASE=port, CATALOG_REPLICAS=n):
    // every replica's live minimum, no coordinator in the loop.
    let configured_census_base = std::env::var("CENSUS_BUS_BASE").ok();
    let mut census_bus: Option<anneal_core::census_bus::CensusBus> =
        census_bus_base(sharing, evidence_only, configured_census_base.as_deref()).and_then(
            |base| {
                let n: u32 = anneal_core::env::parsed("CATALOG_REPLICAS").unwrap_or(0);
                if n == 0 {
                    return None;
                }
                match anneal_core::census_bus::CensusBus::new(replica, base, n) {
                    Ok(bus) => {
                        println!("  census bus: nng pub/sub, base port {base}, {n} replicas");
                        Some(bus)
                    }
                    Err(error) => {
                        println!("  census bus unavailable: {error}");
                        None
                    }
                }
            },
        );
    let _packing_peer_scope =
        anneal_core::catalog::packing::PackingPeerScope::new(census_bus.is_some());
    let mut peer_crowd: usize = 0;
    let mut bus_received: usize = 0;
    let mut bus_last_minimum: Option<(f64, Vec<f64>)> = None;
    let mut shared_wells: Vec<Array1<f64>> = Vec::new();
    let coop_rcut = 3.5 * run_cfg.length_scale;
    let coop_species = run_cfg.species.clone();
    // A cooperative run must produce states at the share tolerance or the
    // coordinator has nothing valid to hold; solo runs leave this off and
    // keep the screened economy untouched.
    // Extra local geometry optimization is a few hundred steps per
    // record or visit, as Config::polish_records documents. Ten full
    // quenches per improvement spend a short replica on one record.
    run_cfg.polish_records = run_cfg.relax_steps;
    let checkpoint_interval = std::env::var("CATALOG_SLICE")
        .or_else(|_| std::env::var("BANK_SLICE"))
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(500)
        .max(1);
    let probe_interval = anneal_core::env::parsed::<u64>("CATALOG_PROBE_INTERVAL")
        .unwrap_or(8)
        .max(1);
    let probe_scale = anneal_core::env::parsed::<f64>("CATALOG_PROBE_SCALE")
        .filter(|value| value.is_finite() && *value > 0.0)
        .unwrap_or(0.2 * run_cfg.length_scale);
    let transport_noise = anneal_core::env::parsed::<f64>("CATALOG_TRANSPORT_NOISE")
        .filter(|value| value.is_finite() && *value >= 0.0)
        .unwrap_or(0.05 * run_cfg.length_scale);
    let minimum_population_interval = checkpoint_interval
        .checked_mul(2)
        .and_then(|value| value.checked_add(2))
        .expect("catalog checkpoint must admit a charged-work population interval");
    let population_interval = anneal_core::env::parsed::<usize>("CATALOG_POPULATION_INTERVAL")
        .unwrap_or(50_000)
        .max(minimum_population_interval);
    let md_interval = anneal_core::env::parsed::<u64>("CATALOG_MD_INTERVAL")
        .unwrap_or(32)
        .max(1);
    let bridge_interval = anneal_core::env::parsed::<u64>("CATALOG_BRIDGE_INTERVAL")
        .unwrap_or(64)
        .max(1);
    #[cfg(not(feature = "ira"))]
    if std::env::var("CATALOG_RIDES").is_ok_and(|value| value != "0") {
        panic!("CATALOG_RIDES requires --features ira for exact LJ endpoint identity");
    }
    #[cfg(feature = "ira")]
    let rides_enabled = std::env::var("CATALOG_RIDES")
        .ok()
        .map_or(endpoint.is_some(), |value| value != "0");
    #[cfg(feature = "ira")]
    let ride_interval = anneal_core::env::parsed::<u64>("CATALOG_RIDE_INTERVAL")
        .unwrap_or(8)
        .max(1);
    #[cfg(feature = "ira")]
    let ride_budget_cap = anneal_core::env::parsed::<u64>("CATALOG_RIDE_BUDGET")
        .unwrap_or(5_000)
        .max(1);
    #[cfg(feature = "ira")]
    let ride_localization_radius = anneal_core::env::parsed::<f64>("CATALOG_RIDE_LOCAL_RADIUS")
        .filter(|value| value.is_finite() && *value > 0.0)
        .unwrap_or(1.5 * run_cfg.length_scale);
    #[cfg(feature = "ira")]
    let ride_identity_radius = anneal_core::env::parsed::<f64>("CATALOG_RIDE_IDENTITY_RADIUS")
        .filter(|value| value.is_finite() && *value > 0.0)
        .unwrap_or(anneal_core::catalog::lj::CALIBRATION_IRA_TOLERANCE * run_cfg.length_scale);
    #[cfg(feature = "ira")]
    let ride_receiver_reserve = snapshot_index_cost(3 * run_cfg.n_points);
    #[cfg(feature = "ira")]
    let ride_proposal_reserve = run_cfg
        .relax_steps
        .checked_add(2)
        .expect("ride proposal reserve must fit usize");
    #[cfg(feature = "ira")]
    let mut ride_exploration = PesExplorationConfig::default();
    #[cfg(feature = "ira")]
    {
        let stationary_component_tolerance = 0.5
            * anneal_core::catalog::lj::CALIBRATION_GRADIENT_TOLERANCE
            / ((3 * run_cfg.n_points) as f64).sqrt();
        ride_exploration.ride_method = RideMethod::Dimer;
        ride_exploration.quench_steps = run_cfg.relax_steps.max(1_000);
        ride_exploration.saddle_steps = 1_000;
        ride_exploration.irc_steps = 200;
        ride_exploration.prfo_steps = 300;
        ride_exploration.quench_gradient_tolerance = stationary_component_tolerance;
        ride_exploration.saddle_force_tolerance = stationary_component_tolerance;
        ride_exploration.saddle_displacement = 0.1 * run_cfg.length_scale;
        ride_exploration.negative_curvature_tolerance = 1e-6;
        ride_exploration.hessian_step = 1e-4 * run_cfg.length_scale;
        ride_exploration.maximum_move = 0.2 * run_cfg.length_scale;
        ride_exploration.irc_step = 0.1 * run_cfg.length_scale;
        ride_exploration.irc_force_tolerance = 0.05;
        ride_exploration.refine_with_prfo = true;
    }
    #[cfg(feature = "ira")]
    let ride_witness = IraStructureWitness {
        kmax_factor: if run_cfg.n_points >= 55 { 2.5 } else { 1.8 },
        radius: ride_identity_radius,
    };
    #[cfg(feature = "ira")]
    let ride_surface = LjRideSurface;
    #[cfg(feature = "ira")]
    let ride_masses = Array1::ones(run_cfg.n_points);
    #[cfg(feature = "ira")]
    let ride_frozen = signature.frozen_mask.clone();
    let mut local_rng = rand::rngs::StdRng::seed_from_u64(seed);
    let mut probe_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x90be_4a11_7a2e_0001);
    let mut transport_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0xc04f_5a7a_109e_57a1);
    let mut bridge_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0xb41d_6e55_0b41_d6e5);
    let mut md_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x3d5e_9a1c_44d0_77ff);
    let mut histo_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x715a_0c1a_5571_5a0c);
    #[cfg(feature = "ira")]
    let mut ride_rng = rand::rngs::StdRng::seed_from_u64(seed ^ 0x7a21_d3e5_c4b8_910f);
    let mut bias = BasinBias::new(
        ClusterFingerprint::of_config(&run_cfg, &Array1::zeros(0)),
        run_cfg.merge_radius,
        run_cfg.bias_height,
        run_cfg.bias_gamma,
    );
    // A seeded start places one replica in a chosen basin, which is how
    // a bridge scenario is constructed on demand: one replica in a
    // second funnel splits the referee's landscape graph and the
    // commissioning condition becomes reachable inside a smoke. The
    // file holds an xyz body: a count line, a comment line, then one
    // element and three coordinates per line.
    let seeded_start = std::env::var("CATALOG_START_FILE").ok().filter(|_| {
        match std::env::var("CATALOG_START_REPLICA").as_deref() {
            Ok("all") | Ok("*") => true,
            Ok(value) => value.parse::<u32>().ok() == Some(replica),
            Err(_) => replica == 0,
        }
    });
    let start = match seeded_start {
        Some(path) => {
            let text = std::fs::read_to_string(&path)
                .expect("CATALOG_START_FILE must name a readable file");
            let values: Vec<f64> = text
                .lines()
                .skip(2)
                .flat_map(|line| {
                    line.split_whitespace()
                        .skip(1)
                        .filter_map(|token| token.parse::<f64>().ok())
                })
                .collect();
            assert_eq!(
                values.len(),
                3 * run_cfg.n_points,
                "CATALOG_START_FILE must hold three coordinates per atom"
            );
            Array1::from(values)
        }
        None => random_cluster(
            run_cfg.n_points,
            0.7,
            run_cfg.min_separation,
            &mut local_rng,
        ),
    };
    if let Some(coordinates) = start.as_slice() {
        anneal_core::catalog::remember_packing_reference(coordinates);
    }
    let mut candidate_sequence = 0u64;
    let mut checkpoint_sequence = 0u64;
    let mut probe_due = false;
    let mut slice_sequence = 0u64;
    let mut last_charged = 0usize;
    #[cfg(feature = "ira")]
    let mut assigned_discovery_role = None;
    let mut applied_decree = None;
    let mut best_at_checkpoint = f64::INFINITY;
    let mut announced_score = false;
    let mut announced_personal = None;
    let mut announced = RetireAnnouncements::default();
    let mut population_progress = PopulationEpochProgress::default();
    let mut stall = 0u32;
    #[cfg(feature = "bank-rpc")]
    let mut leave_path = LeavePath::default();
    let mut archive_hole_count = 0usize;
    // A Leave restarts the walk, and the walk is what crosses. Measured on
    // LJ75 with this binary in serial recommended mode: of 39 independent
    // seeds at 400k evaluations, the three that reached the Marks minimum
    // -397.492331 crossed at hops 4160, 6226 and 4411 of about 11000, while
    // a checkpoint slice is 500 hops. A replica whose own floor is still
    // falling is on that trajectory.
    //
    // The dwell is not a constant. It is the longest run of quiet
    // checkpoints this replica has itself come back from: while it has
    // improved after n quiet slices before, n quiet slices are not evidence
    // that it is done.
    let mut leave_best = f64::INFINITY;
    let mut leave_quiet = 0usize;
    let mut leave_patience = 0usize;
    let leave_crossing = leave_crossing_slices(checkpoint_interval);
    let occupancy_started = Instant::now();
    // The packing this replica stood on when it last decided to Leave,
    // and how many consecutive Leaves have failed to move it off one.
    //
    // Extras keep drawing holes while the book shows fewer than two
    // communities, and on LJ75 the book shows one for the whole run, so
    // every checkpoint spends its budget covering and quenching the same
    // packing. Measured on the sealed icosahedral minimum, no walk of any
    // kind leaves it: twenty-four raw quenches dropped along a
    // transformed trajectory reaching four times the distance to Marks
    // all return to the floor. A mechanism that never installs a packing
    // should not keep being asked, so a run of refusals hands the
    // checkpoint back to plain hopping, which is what finds Marks.
    let mut leave_anchor: Option<Vec<f64>> = None;
    let mut leave_refused = 0usize;
    // Selection-level talking, counted so the coordinated layer is
    // measurable from a worker log instead of inferred from silence:
    // Leaves decided, exchanges adopted, walks kept, holes drawn.
    let mut count_leave = 0usize;
    // Own-progress clock for family hearing: the hop at which this replica
    // last deepened its own best. A replica that has not deepened for
    // CATALOG_HEAR_STALL hops is stalled in its packing.
    // The structure last adopted by hearing, kept so the walk after a hear
    // can be reported: whether the replica is still in the adopted packing
    // family or has slid back to where it was.
    let mut hear_state = HearState::default();
    // Last minimum registered and last candidate offered, so an unchanged
    // occupied state does not cost the coordinator another validation.
    let mut last_registered: Option<(f64, Vec<f64>)> = None;
    let mut last_offered: Option<(f64, Vec<f64>)> = None;
    // Census jumps: the population's visit count of this replica's basin,
    // not this replica's own stall, triggers an occasional jump.
    let mut jump_state = JumpState::default();
    let mut restart_state = RestartState::default();
    let mut count_walk = 0usize;
    let mut count_hole = 0usize;
    let mut extra_cover = 0usize;
    let mut last_policy_action = ACTION_LOCAL;
    // Gossip over the census bus: at every GOSSIP_INTERVAL charged calls
    // publish the GOSSIP_TOP deepest wells (0 for the whole table) and step
    // toward the latest peer table by GOSSIP_WEIGHT. The peer set is the
    // bus subscription, so CENSUS_BUS_NEIGHBORS=k is the ring topology.
    let coop_gossip: Option<(usize, f64, Option<usize>)> = std::env::var("GOSSIP")
        .ok()
        .filter(|v| !v.is_empty())
        .map(|_| {
            let parsed = |name: &str| std::env::var(name).ok().and_then(|v| v.parse::<f64>().ok());
            (
                parsed("GOSSIP_INTERVAL")
                    .map_or(20_000, |v| v as usize)
                    .max(1),
                parsed("GOSSIP_WEIGHT").unwrap_or(0.5),
                match parsed("GOSSIP_TOP").map(|v| v as usize) {
                    Some(0) => None,
                    Some(k) => Some(k),
                    None => Some(64),
                },
            )
        });
    let mut next_gossip = coop_gossip.map_or(usize::MAX, |(interval, _, _)| interval);
    let sync_policy = anneal_core::env::flag("CATALOG_SYNC_POLICY");
    let mut gossip_published = 0usize;
    let mut gossip_merged = 0usize;
    let mut gossip_merge: Option<BiasUpdate> = None;
    // Which phase took each checkpoint; printed on the seed record so a
    // mechanism that never fires is visible as zero rather than assumed.
    let mut phases = PhaseTally::default();
    let mut checkpoint = |snapshot: ChainCheckpoint<'_>| {
        /// Hear phase: whether a structure another replica published should be
        /// adopted at this checkpoint.
        ///
        /// Adoption is off unless `CATALOG_HEAR` is set: `CATALOG_HEAR=1` adopts an
        /// incumbent deeper than the own best by 1e-3, `CATALOG_HEAR=family` adopts
        /// the coordinator's sparsest-family entry only after `CATALOG_HEAR_STALL`
        /// hops without an own improvement, whatever its energy, and never the
        /// incumbent draw; `CATALOG_NO_HEAR=1` forces it off. Off is the default
        /// because handing the incumbent to stalled replicas resets the ensemble's
        /// independent starts to one funnel: measured 1 of 48 ensembles at Marks
        /// against 16 of 48 with adoption off and 23 of 48 for private chains
        /// (LJ75, 48 replicas of 5e4, 2026-09-07), the branching scheme Procacci
        /// (2015) rejects for the same reason in nonequilibrium work averages.
        /// Sampled candidates are registered as packing references either way.
        /// Returns the candidate to adopt; the caller records the trace and fires
        /// the phase.
        fn hear_phase(
            state: &mut HearState,
            cooperative: &mut anneal_core::cooperative_search::CooperativeRun,
            replica: u32,
            snapshot: &ChainCheckpoint<'_>,
            checkpoint_sequence: u64,
            hear_enabled: bool,
        ) -> Option<anneal_core::catalog_rpc::CatalogCandidate> {
            use anneal_core::catalog_rpc::{INCUMBENT_SAMPLE_DRAW, SPARSE_SAMPLE_DRAW};
            use anneal_core::cooperative_search::CatalogSampleOutcome;
            let floor_energy = snapshot.best_energy();
            let current_len = snapshot.current_state().len();
            let family_mode = std::env::var("CATALOG_HEAR").is_ok_and(|v| v == "family");
            let hear_stall: usize = anneal_core::env::parsed("CATALOG_HEAR_STALL").unwrap_or(5000);
            if snapshot.best_energy() < state.last_best - 1e-9 {
                state.last_best = snapshot.best_energy();
                state.last_best_hop = snapshot.hops();
            }
            let stalled = snapshot.hops().saturating_sub(state.last_best_hop) >= hear_stall;
            // After a hear, one line every ten checkpoints: where the walk is.
            if let Some(adopted) = state.heard_structure.as_ref()
                && checkpoint_sequence.is_multiple_of(10)
            {
                let same_family = snapshot.current_state().as_slice().is_some_and(|here| {
                    !anneal_core::catalog::different_packing_family(here, adopted)
                });
                println!(
                    "  walk hops {}  energy {:.6}  best {:.6}  in-adopted-family {}",
                    snapshot.hops(),
                    snapshot.current_energy(),
                    snapshot.best_energy(),
                    same_family
                );
            }
            if !hear_enabled {
                return None;
            }
            for draw in [INCUMBENT_SAMPLE_DRAW, SPARSE_SAMPLE_DRAW] {
                if family_mode && draw == INCUMBENT_SAMPLE_DRAW {
                    continue;
                }
                let outcome = cooperative.try_sample_candidate(replica, draw);
                let _ = cooperative.try_sample_candidate(replica, draw);
                if let Ok(CatalogSampleOutcome::Candidate(held)) = outcome {
                    if held.coordinates.len() != current_len {
                        continue;
                    }
                    anneal_core::catalog::include_packing_reference(&held.coordinates);
                    anneal_core::catalog::offer_known_minimum(held.energy, &held.coordinates);
                    // Mid-hop current energy sits above the ico floor. Comparing
                    // against it yanks every walk back onto ico.
                    let deeper = held.energy < floor_energy - 1e-3;
                    if family_mode {
                        if !stalled {
                            continue;
                        }
                    } else if !deeper {
                        continue;
                    }
                    let elsewhere = snapshot.current_state().as_slice().is_none_or(|here| {
                        anneal_core::catalog::different_packing_family(here, &held.coordinates)
                    });
                    if elsewhere || (!family_mode && draw == INCUMBENT_SAMPLE_DRAW) {
                        return Some(held);
                    }
                }
            }
            None
        }
        let action = with_pending_deposits(
            &mut pending_deposits,
            shared_bias_enabled,
            |pending_deposits| {
                if sharing && let Some(portfolio) = surfaces.as_ref() {
                    cooperative
                        .post_surface_evidence(replica, Arc::clone(portfolio))
                        .expect("surface exchange must name the live replica");
                }
                if evidence_only {
                    if let Some(charged) =
                        unsettled_objective_calls(snapshot.charged(), last_charged)
                    {
                        cooperative
                            .record_work(replica, EVIDENCE_ONLY_WORK_KIND, charged)
                            .expect("evidence-only work must enter the cooperative ledger");
                    }
                    last_charged = snapshot.charged();
                    phases.fire("continue");
                    return CheckpointAction::Continue;
                }
                checkpoint_sequence = checkpoint_sequence
                    .checked_add(1)
                    .expect("checkpoint sequence must fit u64");
                probe_due |= checkpoint_sequence.is_multiple_of(probe_interval);
                // Census bus: publish this replica's minimum, read every peer's.
                // Peers on this side of the packing map become repulsion
                // references and the crowd the stopping rule reads; every fresh
                // peer minimum is a shared-bias deposit when shared bias is on.
                if let Some(bus) = census_bus.as_mut()
                    && let Some(here) = snapshot.current_state().as_slice()
                {
                    if lj_catalog_gradient_norm(
                        snapshot.current_energy(),
                        snapshot.current_state(),
                        snapshot.current_gradient(),
                    )
                    .is_some()
                    {
                        bus.publish(snapshot.hops() as u64, snapshot.current_energy(), here);
                    }
                    let fresh = bus.poll();
                    bus_received += fresh.len();
                    if let Some((interval, weight, top)) = coop_gossip
                        && snapshot.charged() >= next_gossip
                        && let Some(bias) = snapshot.bias()
                    {
                        next_gossip = snapshot.charged() + interval;
                        let table = match top {
                            Some(count) => bias.deepest_wells(count),
                            None => bias.wells(),
                        };
                        if bus.publish_wells(&table) {
                            gossip_published += 1;
                        }
                        if let Some((_, wells)) = bus.poll_wells().into_iter().last() {
                            gossip_merged += 1;
                            gossip_merge = Some(BiasUpdate::MergeWells {
                                wells,
                                weight,
                                complete: top.is_none(),
                            });
                        }
                    }
                    // Locality-limited repulsive history: admit bus deposits from
                    // nearby packings. This does not average coordinates or guarantee
                    // one cluster per funnel. CENSUS_BUS_UNBOUNDED=1 admits distant
                    // bus observations for a controlled comparison. Population-parent
                    // and own-visit deposits retain their separate admission rules.
                    let unbounded = anneal_core::env::flag("CENSUS_BUS_UNBOUNDED");
                    if shared_bias_enabled {
                        for peer in &fresh {
                            if peer.coordinates.len() == here.len()
                                && (unbounded
                                    || anneal_core::catalog::nearby_packing(
                                        here,
                                        &peer.coordinates,
                                    ))
                            {
                                pending_deposits.push(Array1::from(peer.coordinates.clone()));
                            }
                        }
                    }
                    // Recompute the nearby flags only for peers whose minimum
                    // changed, or for all peers when this replica's own minimum
                    // changed; otherwise reuse them. This keeps the bus at the cost
                    // of the messages, not of 47 packing comparisons a checkpoint.
                    let peers: Vec<_> = bus.peers().collect();
                    let (updates, crowd) = census_nearby_updates(
                        &mut bus_last_minimum,
                        checkpoint_sequence,
                        snapshot.current_energy(),
                        here,
                        &peers,
                        &fresh,
                        &bus.nearby,
                    );
                    bus.nearby.extend(updates);
                    peer_crowd = crowd;
                    if anneal_core::env::flag("CATALOG_CENSUS_TRACE")
                        && checkpoint_sequence.is_multiple_of(7)
                    {
                        println!(
                            "  bus hops {}  peers {}  crowd {}  received {}  gossip published {} merged {}",
                            snapshot.hops(),
                            bus.peer_count(),
                            peer_crowd,
                            bus_received,
                            gossip_published,
                            gossip_merged
                        );
                    }
                }
                // Quiet-stretch bookkeeping for the Leave gate: an improvement ends
                // the stretch and records how long the replica took to come back.
                if snapshot.best_energy() < leave_best - 1e-10 {
                    credit_action(last_policy_action, true);
                    leave_best = snapshot.best_energy();
                    leave_patience = leave_patience.max(leave_quiet);
                    leave_quiet = 0;
                } else {
                    credit_action(last_policy_action, false);
                    leave_quiet += 1;
                }
                let boundary_charged = snapshot
                    .quench_boundaries()
                    .iter()
                    .map(|boundary| boundary.charged_calls())
                    .sum::<usize>();
                let mut checkpoint_work =
                    Vec::with_capacity(snapshot.quench_boundaries().len() + 1);
                for boundary in snapshot.quench_boundaries() {
                    checkpoint_work.push((
                        ChargeKind::BasinEscape,
                        u64::try_from(boundary.charged_calls())
                            .expect("quench charge must fit u64"),
                    ));
                }
                let checkpoint_charged = snapshot.charged().saturating_sub(last_charged);
                let auxiliary_charged = checkpoint_charged
                    .checked_sub(boundary_charged)
                    .expect("quench boundaries cannot exceed checkpoint work");
                if auxiliary_charged > 0 {
                    checkpoint_work.push((
                        ChargeKind::AuxiliaryEvaluation,
                        u64::try_from(auxiliary_charged).expect("auxiliary charge must fit u64"),
                    ));
                } else if checkpoint_charged == 0 {
                    checkpoint_work.push((ChargeKind::LocalProposal, 0));
                }
                cooperative
                    .record_work_batch(replica, checkpoint_work)
                    .expect("checkpoint work batch must enter the cooperative ledger");
                last_charged = snapshot.charged();

                for transition in snapshot.accepted_transitions() {
                    cooperative
                        .record_executed_transition(
                            replica,
                            u64::try_from(transition.hop).expect("transition hop must fit u64"),
                            transition.action.clone(),
                            transition.from_energy,
                            if transition.validated {
                                transition.to_energy
                            } else {
                                f64::NAN
                            },
                            transition.adopted,
                        )
                        .expect("validated local transition execution must remain traceable");
                }

                // Diagnostic probes define comparable return evidence. Adaptive
                // accepted hops remain discovery records, not samples of this kernel.
                let probes = snapshot
                    .accepted_transitions()
                    .iter()
                    .filter(|transition| transition.action == "probe" && !transition.adopted)
                    .cloned()
                    .collect::<Vec<_>>();
                let operations = adaptive_catalog_operations(
                    &descriptor_space,
                    &signature.atomic_numbers,
                    replica,
                    &mut candidate_sequence,
                    seed,
                    snapshot.charged(),
                    &probes,
                );
                // The mailbox preserves source/outcome ordering without blocking the
                // hop. Publication is bounded by the diagnostic probe cadence.
                for operation in operations {
                    match operation {
                        AdaptiveCatalogOperation::RegisterCurrent(candidate) => {
                            let _ = cooperative.post_record_current(replica, candidate);
                        }
                        AdaptiveCatalogOperation::Adopt {
                            action,
                            destination,
                            adopted,
                        } => {
                            let _ = cooperative.post_record_transition(
                                replica,
                                action,
                                anneal_core::catalog_rpc::TransitionDestination::Resolved(
                                    destination,
                                ),
                                adopted,
                            );
                        }
                        AdaptiveCatalogOperation::Unresolved { action } => {
                            let _ = cooperative.post_record_transition(
                                replica,
                                action,
                                anneal_core::catalog_rpc::TransitionDestination::Unresolved,
                                false,
                            );
                        }
                    }
                }
                // A checkpoint registers its occupied minimum, not the origin of a
                // sampled trajectory segment. Registration does not invent an edge.
                // Coalesced: a chain sits in one minimum for hundreds of checkpoints,
                // and every registration costs the coordinator a validation (0.28 s
                // on LJ75, measured); re-sending an unchanged minimum is what
                // saturated it with 48 replicas. Only a changed minimum is sent.
                let occupied_changed = snapshot.current_gradient().is_some()
                    && last_registered.as_ref().is_none_or(|(energy, state)| {
                        (energy - snapshot.current_energy()).abs() > 1e-9
                            || Some(state.as_slice()) != snapshot.current_state().as_slice()
                    });
                if let Some(gradient) = snapshot.current_gradient()
                    && occupied_changed
                {
                    last_registered =
                        Some((snapshot.current_energy(), snapshot.current_state().to_vec()));
                    candidate_sequence += 1;
                    if let Some(candidate) = lj_catalog_candidate(
                        &descriptor_space,
                        &signature.atomic_numbers,
                        replica,
                        candidate_sequence,
                        seed,
                        snapshot.charged(),
                        snapshot.current_energy(),
                        snapshot.current_state(),
                        gradient,
                    ) {
                        cooperative
                            .record_work(replica, ChargeKind::DescriptorEvaluation, 0)
                            .expect("source descriptor work must enter the cooperative ledger");
                        let _ = cooperative.post_record_current(replica, candidate);
                    }
                }

                let mut boundary_candidates = Vec::new();
                let mut descriptor_work = Vec::new();
                for boundary in snapshot
                    .quench_boundaries()
                    .iter()
                    .filter(|boundary| boundary.status() == QuenchStatus::Validated)
                {
                    let Some(gradient) = boundary.gradient() else {
                        continue;
                    };
                    candidate_sequence = candidate_sequence
                        .checked_add(1)
                        .expect("candidate sequence must fit u64");
                    descriptor_work.push((ChargeKind::DescriptorEvaluation, 0));
                    if let Some(candidate) = lj_catalog_candidate(
                        &descriptor_space,
                        &signature.atomic_numbers,
                        replica,
                        candidate_sequence,
                        seed,
                        snapshot.charged(),
                        boundary.energy(),
                        boundary.state(),
                        gradient,
                    ) {
                        boundary_candidates.push(candidate);
                    }
                }
                cooperative
                    .record_work_batch(replica, descriptor_work)
                    .expect("quench descriptor batch must enter the cooperative ledger");
                // One offer per checkpoint. A slice can hold hundreds of validated
                // quenches; each offer runs coordinator DECAF and parks the ensemble.
                let freshest_boundary = boundary_candidates.into_iter().min_by(|left, right| {
                    left.energy
                        .total_cmp(&right.energy)
                        .then_with(|| left.event_sequence.cmp(&right.event_sequence))
                });
                // One offer per checkpoint, and only for a minimum not offered
                // before: the offer is the other validated request kind.
                if let Some(candidate) = freshest_boundary.as_ref()
                    && last_offered.as_ref().is_none_or(|(energy, coordinates)| {
                        (energy - candidate.energy).abs() > 1e-9
                            || coordinates != &candidate.coordinates
                    })
                {
                    last_offered = Some((candidate.energy, candidate.coordinates.clone()));
                    let _ = cooperative.post_offer_candidate(replica, candidate.clone());
                }

                // Bookkeeping and the position report run on every checkpoint,
                // before any phase that can take the checkpoint: a probe, a ride or
                // a hear must not silence the stall clock or the census position.
                let local_deepened = snapshot.best_energy() < best_at_checkpoint - 1e-10;
                if local_deepened {
                    best_at_checkpoint = snapshot.best_energy();
                    stall = 0;
                    let jump = announced_personal
                        .is_none_or(|previous| snapshot.best_energy() < previous - 1e-3);
                    if jump {
                        println!(
                            "  personal best {:.6}  hops {}  refs {}  leaves {} other {} walk {} hole {}",
                            snapshot.best_energy(),
                            snapshot.hops(),
                            // Packings this chain's quench is repelled from. Own
                            // history plus every structure the coordinator has
                            // handed over, which is the interaction at the
                            // minimisation level and the thing chain count is
                            // supposed to scale.
                            anneal_core::catalog::packing_references().len(),
                            count_leave,
                            hear_state.other_family,
                            count_walk,
                            count_hole
                        );
                        let _ = std::io::stdout().flush();
                        announced_personal = Some(snapshot.best_energy());
                    }
                } else {
                    stall = stall.saturating_add(1);
                }
                if snapshot.hops() > 0 && snapshot.hops().is_multiple_of(500) {
                    println!(
                        "  occupancy hops {} best {:.6} refs {} leaves {} other {} walk {} hole {}",
                        snapshot.hops(),
                        snapshot.best_energy(),
                        anneal_core::catalog::packing_references().len(),
                        count_leave,
                        hear_state.other_family,
                        count_walk,
                        count_hole
                    );
                    let _ = std::io::stdout().flush();
                }
                if !announced_score
                    && published_energy_score(snapshot.best_energy(), reference(cfg.n_points))
                {
                    println!(
                        "  score {:.6}  hops {}",
                        snapshot.best_energy(),
                        snapshot.hops()
                    );
                    if cfg.n_points == 75 {
                        println!(
                            "  Marks {:.6}  hops {}",
                            snapshot.best_energy(),
                            snapshot.hops()
                        );
                    }
                    let _ = std::io::stdout().flush();
                    announced_score = true;
                }
                // Conversation is not identity. A position report every checkpoint
                // is how the chains talk: the descriptor of wherever the chain
                // stands, mid-hop or not, asked against the census the validated
                // registrations have built, with no purity gate, because reporting
                // a position claims nothing about minimality. The identity tier,
                // the census and catalog entries themselves, stays fed exclusively
                // by share-grade validated states through the offer loop above.
                let _ = freshest_boundary;
                candidate_sequence = candidate_sequence
                    .checked_add(1)
                    .expect("candidate sequence must fit u64");
                cooperative
                    .record_work(replica, ChargeKind::DescriptorEvaluation, 0)
                    .expect("current descriptor work must enter the cooperative ledger");
                let Ok(position) = descriptor_space
                    .describe(snapshot.current_state(), Some(&signature.atomic_numbers))
                else {
                    return continue_checkpoint(
                        &mut phases,
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        checkpoint_charged,
                        snapshot.best_energy(),
                    );
                };
                let descriptor = position.values().to_vec();
                #[cfg(feature = "bank-rpc")]
                let decree_assignment = decree_slot
                    .try_lock()
                    .ok()
                    .and_then(|held| held.clone())
                    .and_then(|decree| {
                        decree
                            .assignments
                            .into_iter()
                            .find(|assignment| assignment.replica == replica)
                    });
                // Due probes wait for a validated origin and precede adaptive
                // checkpoint actions. Their unresolved outcomes remain observations,
                // not reasons to change the declared perturb-quench kernel.
                if sharing
                    && checkpoint_sequence.is_multiple_of(probe_interval)
                    && snapshot.remaining() > run_cfg.relax_steps.saturating_add(2)
                {
                    let draw = checkpoint_sequence.wrapping_mul(0x9E37_79B9_7F4A_7C15)
                        ^ u64::from(replica);
                    if let anneal_core::cooperative_search::CatalogBoundaryOutcome::Crossing(
                        crossing,
                    ) = cooperative
                        .boundary_crossing(replica, snapshot.current_state().to_vec(), draw)
                        .expect("boundary crossing poll must preserve local execution")
                        && let Some(state) = boundary_crossing_trial(
                            snapshot.current_state(),
                            &crossing,
                            0.0,
                            10.0,
                            &mut probe_rng,
                        )
                    {
                        phases.fire("boundary");
                        return complete_checkpoint_trace(
                            &mut cooperative,
                            replica,
                            &mut slice_sequence,
                            snapshot.charged(),
                            snapshot.best_energy(),
                            |_, _| CheckpointAction::ProbeProposal {
                                state,
                                action: "boundary".to_owned(),
                            },
                        );
                    }
                }
                if probe_due
                    && snapshot.current_gradient().is_some()
                    && snapshot.remaining() > run_cfg.relax_steps.saturating_add(2)
                    && let Some(state) =
                        fixed_probe_trial(snapshot.current_state(), probe_scale, &mut probe_rng)
                {
                    probe_due = false;
                    phases.fire("probe");
                    return complete_checkpoint_trace(
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        snapshot.charged(),
                        snapshot.best_energy(),
                        |_, _| CheckpointAction::ProbeProposal {
                            state,
                            action: "probe".to_owned(),
                        },
                    );
                }

                if core_class.is_some() {
                    let class = anneal_core::corekey::motif_class(snapshot.current_state()).index();
                    let verdict = cooperative
                        .report_core_class(
                            replica,
                            class,
                            snapshot.current_energy(),
                            snapshot.charged(),
                        )
                        .expect("core-class report must stay on the cooperative ledger");
                    if verdict == anneal_core::coreclass::CoreVerdict::Restart {
                        let mut adopt_rng = rand::rngs::StdRng::seed_from_u64(
                            seed.wrapping_add(u64::from(replica))
                                .wrapping_add(snapshot.charged() as u64),
                        );
                        let fresh =
                            random_cluster(cfg.n_points, 0.7, cfg.min_separation, &mut adopt_rng);
                        phases.fire("coreclass");
                        return complete_checkpoint_trace(
                            &mut cooperative,
                            replica,
                            &mut slice_sequence,
                            snapshot.charged(),
                            snapshot.best_energy(),
                            |_, _| CheckpointAction::ExternalAdopt {
                                state: fresh,
                                action: "coreclass".to_owned(),
                                external_calls: 0,
                            },
                        );
                    }
                }

                #[cfg(feature = "ira")]
                if rides_enabled
                    && discovery_role_allows_ride(assigned_discovery_role)
                    && checkpoint_sequence.is_multiple_of(ride_interval)
                    && let Some(maximum_evaluations) = ride_producer_budget(
                        snapshot.remaining(),
                        ride_receiver_reserve,
                        ride_proposal_reserve,
                        ride_budget_cap,
                    )
                    && let RideClaimOutcome::Work(work) = cooperative
                        .claim_ride(replica, ride_rng.random())
                        .expect("ride claim must preserve cooperative invariants")
                {
                    let producer_event_sequence = candidate_sequence
                        .checked_add(1)
                        .expect("ride event sequence must fit u64");
                    candidate_sequence = candidate_sequence
                        .checked_add(3)
                        .expect("ride event sequence must fit u64");
                    let execution = CatalogRideExecutionConfig {
                        exploration: ride_exploration.clone(),
                        localization_radius: ride_localization_radius,
                        maximum_evaluations,
                        producer_event_sequence,
                        producer_charged_work: u64::try_from(snapshot.charged())
                            .expect("LJ charged work must fit u64"),
                    };
                    let report = execute_catalog_ride(
                        &ride_surface,
                        &descriptor_space,
                        &work,
                        &signature.atomic_numbers,
                        ride_masses.view(),
                        &ride_frozen,
                        &execution,
                        &ride_witness,
                    );
                    let producer_calls = report.charged_evaluations;
                    let destination = connected_destination(&work, &report, &ride_witness)
                        .map(|candidate| Array1::from(candidate.coordinates));
                    let cartesian_step_norm = destination.as_ref().map(|state| {
                        vector_distance(
                            snapshot
                                .current_state()
                                .as_slice()
                                .expect("LJ state is contiguous"),
                            state.as_slice().expect("LJ ride endpoint is contiguous"),
                        )
                    });
                    let report_outcome = cooperative
                        .report_ride(replica, report)
                        .expect("ride report must preserve cooperative invariants");
                    let ride_calls = ride_total_charged_calls(report_outcome, producer_calls);
                    let settled_ride_calls =
                        settled_external_calls(ride_calls, snapshot.remaining());
                    if settled_ride_calls > 0 {
                        cooperative
                            .record_work(replica, ChargeKind::SaddleRide, settled_ride_calls)
                            .expect("ride work must enter the cooperative ledger");
                        last_charged = snapshot.charged().saturating_add(
                            usize::try_from(settled_ride_calls).unwrap_or(usize::MAX),
                        );
                    }
                    let (policy_reason, validation, quench, adoption, novelty) =
                        match report_outcome {
                            RideReportOutcome::Credited(credit)
                                if credit.certified_connection && destination.is_some() =>
                            {
                                (
                                    "ride_certified",
                                    SliceValidation::Accepted,
                                    SliceQuench::Converged,
                                    SliceAdoption::NotAttempted,
                                    Some(if credit.novel_saddle || credit.novel_edge {
                                        1.0
                                    } else {
                                        0.0
                                    }),
                                )
                            }
                            RideReportOutcome::Credited(credit)
                                if credit.degenerate_rearrangement =>
                            {
                                (
                                    "ride_degenerate_rearrangement",
                                    SliceValidation::Accepted,
                                    SliceQuench::Converged,
                                    SliceAdoption::NotAttempted,
                                    Some(if credit.novel_saddle { 1.0 } else { 0.0 }),
                                )
                            }
                            RideReportOutcome::Credited(credit) => {
                                let reason = credit
                                    .failure
                                    .map(ride_failure_reason)
                                    .unwrap_or("ride_destination_unavailable");
                                (
                                    reason,
                                    SliceValidation::Rejected,
                                    SliceQuench::Rejected,
                                    SliceAdoption::Rejected,
                                    Some(0.0),
                                )
                            }
                            RideReportOutcome::Rejected => (
                                "ride_report_rejected",
                                SliceValidation::Rejected,
                                SliceQuench::NotAttempted,
                                SliceAdoption::Rejected,
                                None,
                            ),
                            RideReportOutcome::LocalFallback => (
                                "ride_report_fallback",
                                SliceValidation::NotAttempted,
                                SliceQuench::NotAttempted,
                                SliceAdoption::Rejected,
                                None,
                            ),
                            RideReportOutcome::SharingDisabled => (
                                "ride_sharing_disabled",
                                SliceValidation::NotAttempted,
                                SliceQuench::NotAttempted,
                                SliceAdoption::Rejected,
                                None,
                            ),
                        };
                    slice_sequence = slice_sequence
                        .checked_add(1)
                        .expect("slice sequence must fit u64");
                    cooperative
                        .record_slice(
                            replica,
                            SliceTrace {
                                slice: slice_sequence,
                                current_basin: None,
                                active_relation: None,
                                policy_role: PolicyRole::Explore,
                                policy_reason,
                                proposal_family: ProposalFamily::TransitionRide,
                                sampled_basin: work.source.census_basin,
                                descriptor_step_norm: None,
                                cartesian_step_norm,
                                validation,
                                quench,
                                adoption,
                                novelty,
                                energy: finite_trace_energy(snapshot.best_energy()),
                                charged_work: settled_ride_calls,
                            },
                        )
                        .expect("ride checkpoint trace must remain complete");
                    phases.fire("ride");
                    return ride_checkpoint_action(report_outcome, destination, producer_calls);
                }

                // The population barrier is serviced before any local gate. A
                // checkpoint often finds the chain mid-hop with nothing that passes
                // candidate validation; that must not silence its participation and
                // must never block the chain. Membership is joined by reference to
                // the best candidate the coordinator has already validated for this
                // replica; a replica with nothing on file abstains so the epoch
                // completes without it; a pending or rejected join is answered by
                // returning to local work until the next checkpoint rather than by
                // polling in place or retiring, which is what left one replica
                // asleep for its whole budget.
                let mut population_assignment = None;
                loop {
                    let outcome = match active_population_action(
                        &population_progress,
                        snapshot.charged(),
                        snapshot.remaining(),
                        population_interval,
                        true,
                    ) {
                        PopulationEpochAction::Submit => population_call(
                            cooperative.join_population(replica, population_progress.epoch()),
                        ),
                        PopulationEpochAction::Poll => population_call(
                            cooperative.poll_population(replica, population_progress.epoch()),
                        ),
                        PopulationEpochAction::Abstain => population_call(
                            cooperative.abstain_population(replica, population_progress.epoch()),
                        ),
                        PopulationEpochAction::LocalWork => break,
                    };
                    match outcome {
                        PopulationSynchronizationOutcome::Pending { .. }
                        | PopulationSynchronizationOutcome::Rejected => {
                            population_progress.observe_pending();
                            break;
                        }
                        PopulationSynchronizationOutcome::Ready { parent, plan } => {
                            let completed_epoch = population_progress.epoch();
                            population_progress.observe_ready();
                            population_assignment = Some((completed_epoch, parent, plan));
                        }
                        PopulationSynchronizationOutcome::Unaddressed => {
                            population_progress.observe_ready();
                        }
                        PopulationSynchronizationOutcome::LocalFallback
                        | PopulationSynchronizationOutcome::SharingDisabled => break,
                    }
                }
                if let Some((completed_epoch, parent, plan)) = population_assignment
                    && snapshot.remaining() > 0
                {
                    let family =
                        population_family_position(&plan.destinations, &plan.parents, replica)
                            .expect("validated population plan must address this replica");
                    let draw = population_rejuvenation_draw(
                        seed,
                        completed_epoch,
                        replica,
                        family.ordinal(),
                    );
                    if shared_bias_enabled {
                        pending_deposits.push(Array1::from(parent.coordinates.clone()));
                    }
                    if coop_wells_enabled {
                        #[cfg(feature = "featomic")]
                        {
                            let well = anneal_core::featomic_hop::soap_cloud_mean(
                                ndarray::ArrayView1::from(parent.coordinates.as_slice()),
                                coop_rcut,
                                coop_species.as_deref(),
                                None,
                            );
                            let known = shared_wells.iter().any(|w| {
                                w.iter()
                                    .zip(well.iter())
                                    .map(|(a, b)| (a - b) * (a - b))
                                    .sum::<f64>()
                                    .sqrt()
                                    < anneal_core::featomic_hop::SOAP_PACK_MERGE
                            });
                            if !known {
                                shared_wells.push(well);
                                if shared_wells.len() > 30 {
                                    shared_wells.remove(0);
                                }
                                anneal_core::featomic_hop::set_packing_archive(
                                    shared_wells.clone(),
                                );
                            }
                        }
                    }
                    // Occupancy: champion stays; kept extra may take a better
                    // isomer of the same packing; leftover extras reseed.
                    // A deeper different funnel is never copied.
                    let live_state = snapshot.current_state();
                    let live = live_state.as_slice().expect("LJ state is contiguous");
                    let extra_of_occupied_packing =
                        plan.parent_candidates.iter().any(|candidate| {
                            candidate.producer_replica != replica
                                && candidate.energy < snapshot.current_energy() - 1e-10
                                && same_packing_coordinates(live, &candidate.coordinates)
                        });
                    if parent.producer_replica == replica && extra_of_occupied_packing {
                        let left: Option<Array1<f64>> = {
                            #[cfg(feature = "featomic")]
                            {
                                anneal_core::featomic_hop::surplus_reseed(
                                    live_state,
                                    &shared_wells,
                                    coop_rcut,
                                    coop_species.as_deref(),
                                    None,
                                    &mut transport_rng,
                                )
                            }
                            #[cfg(not(feature = "featomic"))]
                            {
                                None
                            }
                        };
                        if let Some(left) = left {
                            phases.fire("population_reseed");
                            return population_reconfiguration(
                                &mut cooperative,
                                replica,
                                &mut slice_sequence,
                                checkpoint_charged,
                                &snapshot,
                                parent.census_basin,
                                PolicyRole::Explore,
                                "population_reseed",
                                ProposalFamily::HyperbandReseed,
                                left,
                            );
                        }
                    }
                    let foreign_parent = parent.producer_replica != replica;
                    if foreign_parent && parent.coordinates.len() == live_state.len() {
                        let live = live_state.as_slice().expect("LJ state is contiguous");
                        let better_isomer = same_packing_coordinates(live, &parent.coordinates)
                            && parent.energy < snapshot.current_energy() - 1e-10;
                        if better_isomer {
                            let mut state = Array1::from(parent.coordinates.clone());
                            let atoms = state.len() / 3;
                            if atoms > 0 {
                                let mut jitter = rand::rngs::StdRng::seed_from_u64(draw);
                                for coordinate in state.iter_mut() {
                                    *coordinate += transport_noise * (jitter.random::<f64>() - 0.5);
                                }
                                for axis in 0..3 {
                                    let mean =
                                        (0..atoms).map(|atom| state[3 * atom + axis]).sum::<f64>()
                                            / atoms as f64;
                                    for atom in 0..atoms {
                                        state[3 * atom + axis] -= mean;
                                    }
                                }
                            }
                            if state
                                .iter()
                                .zip(snapshot.current_state().iter())
                                .any(|(a, b)| (a - b).abs() > 1e-12)
                            {
                                phases.fire("population_parent");
                                return population_reconfiguration(
                                    &mut cooperative,
                                    replica,
                                    &mut slice_sequence,
                                    checkpoint_charged,
                                    &snapshot,
                                    parent.census_basin,
                                    PolicyRole::Exploit,
                                    "population_assignment",
                                    ProposalFamily::PopulationReconfiguration,
                                    state,
                                );
                            }
                        }
                    }
                    if foreign_parent {
                        let live = snapshot.current_state();
                        let reseed = {
                            #[cfg(feature = "featomic")]
                            {
                                anneal_core::featomic_hop::surplus_reseed(
                                    live,
                                    &shared_wells,
                                    coop_rcut,
                                    coop_species.as_deref(),
                                    None,
                                    &mut transport_rng,
                                )
                            }
                            #[cfg(not(feature = "featomic"))]
                            {
                                None::<Array1<f64>>
                            }
                        };
                        let left = reseed.unwrap_or_else(|| {
                            let index = archive_cover_index(replica, archive_hole_count);
                            archive_hole_count += 1;
                            leave_packing_state(
                                live,
                                snapshot.current_energy(),
                                &shared_wells,
                                coop_rcut,
                                coop_species.as_deref(),
                                index,
                                &mut transport_rng,
                            )
                        });
                        if left
                            .iter()
                            .zip(live.iter())
                            .all(|(a, b)| (a - b).abs() <= 1e-12)
                        {
                            return continue_checkpoint(
                                &mut phases,
                                &mut cooperative,
                                replica,
                                &mut slice_sequence,
                                checkpoint_charged,
                                snapshot.best_energy(),
                            );
                        }
                        phases.fire("population_reseed");
                        return population_reconfiguration(
                            &mut cooperative,
                            replica,
                            &mut slice_sequence,
                            checkpoint_charged,
                            &snapshot,
                            parent.census_basin,
                            PolicyRole::Explore,
                            "population_reseed",
                            ProposalFamily::HyperbandReseed,
                            left,
                        );
                    }
                }
                // The decree steers without touching any chain-local law: a
                // replica under decree screens escapes more aggressively (the
                // leader has seen a seam this chain cannot see locally), and
                // bridge duty turns bridge polling on for exactly the replicas
                // the leader named.
                #[cfg(feature = "bank-rpc")]
                let (decree_stall_floor, decree_bridge_duty) = decree_assignment
                    .as_ref()
                    .map_or((4u32, false), |assignment| (2u32, assignment.bridge_duty));
                #[cfg(not(feature = "bank-rpc"))]
                let (decree_stall_floor, decree_bridge_duty) = (4u32, false);
                if (bridge_enabled || decree_bridge_duty)
                    && let Some(assignment) = &active_bridge
                {
                    match bridge_region_of(
                        &assignment.images,
                        descriptor.len(),
                        &descriptor,
                        assignment.tube_radius,
                    ) {
                        Some(region) if region != assignment.region as usize => {
                            cooperative
                                .bridge_crossing(
                                    replica,
                                    BridgeCrossingRecord {
                                        bridge: assignment.bridge,
                                        from_region: assignment.region,
                                        to_region: u32::try_from(region)
                                            .expect("bridge region is bounded by image count"),
                                        descriptor: descriptor.clone(),
                                        state: snapshot.current_state().to_vec(),
                                        energy: snapshot.current_energy(),
                                    },
                                )
                                .expect("bridge crossing report must preserve local execution");
                            active_bridge = None;
                        }
                        Some(_) => {}
                        None => {
                            // Off the bridge tube entirely: the segment is over.
                            active_bridge = None;
                        }
                    }
                }
                // Hear a packing another replica published. Hops stay silent;
                // this is the message that moves a chain onto a deeper well
                // the ensemble already holds. PolicyState Leave is not that
                // channel, and catalog_leave would refuse Marks if the
                // throwaway book chained it to ico. catalog_incumbent adopts
                // on energy. post_offer_candidate above is the publish.
                let hear_enabled = std::env::var("CATALOG_HEAR").is_ok()
                    && !anneal_core::env::flag("CATALOG_NO_HEAR");
                let heard = hear_phase(
                    &mut hear_state,
                    &mut cooperative,
                    replica,
                    &snapshot,
                    checkpoint_sequence,
                    hear_enabled,
                );
                if let Some(held) = heard {
                    hear_state.other_family += 1;
                    // The new packing gets a full stall window before the next hear.
                    hear_state.last_best_hop = snapshot.hops();
                    hear_state.heard_structure = Some(held.coordinates.clone());
                    println!(
                        "  hear {:.6}  hops {}  refs {}  other {}",
                        held.energy,
                        snapshot.hops(),
                        anneal_core::catalog::packing_references().len(),
                        hear_state.other_family
                    );
                    let _ = std::io::stdout().flush();
                    phases.fire("catalog_incumbent");
                    return complete_checkpoint_trace(
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        checkpoint_charged,
                        snapshot.best_energy(),
                        |_cooperative, _slice_sequence| CheckpointAction::BoundaryProposal {
                            state: Array1::from(held.coordinates),
                            action: "catalog_incumbent".to_owned(),
                        },
                    );
                }
                // Single-ended invert against nearby chains only, at checkpoint
                // cadence. Far packings are a hear. jacobian_nu3 is not a
                // per-hop all-to-all: the Householder stays armed for the slice.
                if let Some(here) = snapshot.current_state().as_slice() {
                    let neighbor_draws =
                        (0..anneal_core::catalog::INVERT_NEIGHBOR_DRAWS).map(|step| {
                            ((u64::from(replica) << 33)
                                ^ checkpoint_sequence.wrapping_mul(0xBF58_476D_1CE4_E5B9)
                                ^ (step as u64).wrapping_mul(0x94D0_049B_B133_111E))
                                & (u64::MAX >> 2)
                        });
                    if let Ok(CatalogSamplesOutcome::Candidates(held)) =
                        cooperative.try_sample_candidates(replica, neighbor_draws)
                    {
                        for held in held {
                            if held.coordinates.len() != here.len() {
                                continue;
                            }
                            if anneal_core::catalog::nearby_packing(here, &held.coordinates) {
                                anneal_core::catalog::include_packing_reference(&held.coordinates);
                            }
                        }
                    }
                    let neighbors = anneal_core::catalog::nearby_packing_book(here);
                    // Population stopping rule (CATALOG_RESTART_VISITS=k,
                    // CATALOG_RESTART_QUIET=q). The crowd is the number of other
                    // replicas' minima on this replica's side of the packing map, the
                    // same references the repulsion arm reads; a region k replicas
                    // have reached that this replica has not deepened from for q hops
                    // is dead by the ensemble's count, and the replica hands its
                    // remaining budget to a fresh random start. Measured on LJ75 a
                    // shelf-absorbed chain crosses at about 8.5e-7 per hop and a fresh
                    // chain at about 5e-6, so the exchange pays six to one once the
                    // region is known dead. This runs before the coordinator-gated
                    // policy section so it fires on every checkpoint.
                    let crowd = if census_bus.is_some() {
                        peer_crowd as u64
                    } else {
                        neighbors.len() as u64
                    };
                    if snapshot.best_energy() < hear_state.last_best - 1e-9 {
                        hear_state.last_best = snapshot.best_energy();
                        hear_state.last_best_hop = snapshot.hops();
                    }
                    let quiet_now = snapshot.hops().saturating_sub(hear_state.last_best_hop);
                    if anneal_core::env::flag("CATALOG_CENSUS_TRACE")
                        && checkpoint_sequence.is_multiple_of(7)
                    {
                        println!(
                            "  census hops {}  crowd {}  quiet {}  energy {:.6}",
                            snapshot.hops(),
                            crowd,
                            quiet_now,
                            snapshot.current_energy()
                        );
                    }
                    if let Some(fresh) = census_restart_phase(
                        &mut restart_state,
                        &mut hear_state,
                        replica,
                        &snapshot,
                        checkpoint_sequence,
                        crowd,
                        quiet_now,
                        &run_cfg,
                    ) {
                        phases.fire("census_restart");
                        return complete_checkpoint_trace(
                            &mut cooperative,
                            replica,
                            &mut slice_sequence,
                            checkpoint_charged,
                            snapshot.best_energy(),
                            |_cooperative, _slice_sequence| CheckpointAction::BoundaryProposal {
                                state: fresh,
                                action: "census_restart".to_owned(),
                            },
                        );
                    }
                    if neighbors.is_empty() || !ape_seeds_enabled() {
                        anneal_core::known_basin::disarm();
                    } else if replica % 2 == 1 {
                        // Occupied local environments. APE queues a dimer on
                        // one classified atom. The destination family is not
                        // a target. A residual that exists on this structure
                        // (fivefold or otherwise) is an offered seed, not a
                        // named morphology.
                        anneal_core::known_basin::arm_leave_free(
                            snapshot.current_state(),
                            anneal_core::known_basin::LEAVE_RUNG_RMSD,
                            &neighbors,
                            run_cfg.temperature,
                            run_cfg.temperature,
                        );
                        extra_cover = extra_cover.saturating_add(1);
                        let queue = anneal_core::catalog::ape_highlight_queue(here);
                        if queue.is_empty() {
                            anneal_core::known_basin::disarm();
                        } else {
                            let (atom, class) = queue[(extra_cover - 1) % queue.len()];
                            anneal_core::known_basin::arm_leave_cover(atom);
                            let offered =
                                if anneal_core::soap::fivefold_axis_count(snapshot.current_state())
                                    >= 2
                                {
                                    let mut residual_rng = rand::rngs::StdRng::seed_from_u64(
                                        (u64::from(replica) << 17)
                                            ^ checkpoint_sequence
                                                .wrapping_mul(0x9E37_79B9_7F4A_7C15)
                                            ^ extra_cover as u64,
                                    );
                                    anneal_core::soap::step_away_fivefold(
                                        snapshot.current_state(),
                                        anneal_core::known_basin::LEAVE_RUNG_RMSD,
                                        &mut residual_rng,
                                    )
                                } else {
                                    snapshot.current_state().to_owned()
                                };
                            println!(
                                "  ape seed atom {} class {} hops {} neighbors {}",
                                atom,
                                class,
                                snapshot.hops(),
                                neighbors.len()
                            );
                            let _ = std::io::stdout().flush();
                            phases.fire("catalog_ridge");
                            return complete_checkpoint_trace(
                                &mut cooperative,
                                replica,
                                &mut slice_sequence,
                                checkpoint_charged,
                                snapshot.best_energy(),
                                |_cooperative, _slice_sequence| {
                                    CheckpointAction::BoundaryProposal {
                                        state: offered,
                                        action: "catalog_ridge".to_owned(),
                                    }
                                },
                            );
                        }
                    }
                }
                if leave_defers(leave_quiet, leave_patience, leave_crossing) {
                    // Still inside the recovered quiet stretch or the
                    // measured crossing floor (LEAVE_CROSSING_HOPS). Policy
                    // RPC is the measured hop-cost gap; census still sees
                    // posted minima.
                    return continue_checkpoint(
                        &mut phases,
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        checkpoint_charged,
                        snapshot.best_energy(),
                    );
                }
                // The asynchronous request returns LocalFallback until the
                // next checkpoint, so a decision acts on a slice-old snapshot
                // and half the checkpoints skip the policy. CATALOG_SYNC_POLICY=1
                // waits for the reply under the client's io timeout instead,
                // which is the measured hop-cost gap paid for a current decision.
                let policy_outcome = if sync_policy {
                    cooperative.policy_input_with_lambda(
                        replica,
                        descriptor.clone(),
                        snapshot.current_energy(),
                        leave_path.max_lambda(),
                        stall,
                        local_deepened,
                    )
                } else {
                    cooperative.try_policy_input_with_lambda(
                        replica,
                        descriptor.clone(),
                        snapshot.current_energy(),
                        leave_path.max_lambda(),
                        stall,
                        local_deepened,
                    )
                };
                let policy = match policy_outcome
                    .expect("coordinator policy evidence must preserve local invariants")
                {
                    PolicyEvidenceOutcome::Remote(input) => {
                        if cooperative
                            .events()
                            .last()
                            .and_then(|event| event.policy)
                            .is_some_and(|policy| policy.retired)
                        {
                            phases.fire("retire");
                            return complete_checkpoint_trace(
                                &mut cooperative,
                                replica,
                                &mut slice_sequence,
                                checkpoint_charged,
                                snapshot.best_energy(),
                                |_cooperative, _slice_sequence| CheckpointAction::Retire {
                                    reason: "halving".to_owned(),
                                },
                            );
                        }
                        input
                    }
                    PolicyEvidenceOutcome::Rejected
                    | PolicyEvidenceOutcome::LocalFallback
                    | PolicyEvidenceOutcome::SharingDisabled => {
                        return continue_checkpoint(
                            &mut phases,
                            &mut cooperative,
                            replica,
                            &mut slice_sequence,
                            checkpoint_charged,
                            snapshot.best_energy(),
                        );
                    }
                };
                leave_path.push(
                    snapshot.current_state().to_vec(),
                    descriptor.clone(),
                    policy.leftover_lambda,
                );
                if let Some(reason) = occupancy_retire_phase(&mut announced, &policy, &snapshot) {
                    complete_checkpoint_trace(
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        checkpoint_charged,
                        snapshot.best_energy(),
                        |_cooperative, _slice_sequence| (),
                    );
                    phases.fire("retire");
                    return CheckpointAction::Retire { reason };
                }
                let policy_trace = cooperative
                    .events()
                    .last()
                    .and_then(|event| event.policy)
                    .expect("registered policy evidence must remain attached to its snapshot");
                #[cfg(feature = "ira")]
                {
                    assigned_discovery_role = Some(policy_trace.discovery_role);
                }
                if difficulty_enabled && checkpoint_sequence.is_multiple_of(32) {
                    let charged = policy.progress.charged();
                    let singles = policy.census.singleton_basins();
                    if let Some((last_charged, last_singles)) = governor_last
                        && charged > last_charged
                    {
                        let rate = singles.saturating_sub(last_singles) as f64
                            / (charged - last_charged) as f64;
                        let ema = governor_ema.get_or_insert(rate);
                        if rate < 0.25 * *ema {
                            difficulty_gain = (difficulty_gain * 1.5).min(4.0);
                        } else {
                            difficulty_gain = 1.0 + (difficulty_gain - 1.0) * 0.5;
                        }
                        *ema = 0.9 * *ema + 0.1 * rate;
                    }
                    governor_last = Some((charged, singles));
                }
                // CATALOG_JUMP_VISITS=k: when the ensemble census has visited this
                // replica's basin at least k times, the replica takes an
                // Iwamatsu-Okabe jump (a short unquenched walk, then a quench) with
                // a cooldown of CATALOG_JUMP_COOLDOWN hops. The shared visit history
                // is what Goedecker's minima hopping keeps per chain to escalate its
                // escapes; here it is the population's, so a region many replicas
                // have exhausted is left by all of them without any of them being
                // handed a structure.
                if let Some(jumped) = census_jump_phase(
                    &mut jump_state,
                    replica,
                    &snapshot,
                    checkpoint_sequence,
                    policy.census.local_basin_visits(),
                    run_cfg.length_scale,
                ) {
                    phases.fire("census_jump");
                    return complete_checkpoint_trace(
                        &mut cooperative,
                        replica,
                        &mut slice_sequence,
                        checkpoint_charged,
                        snapshot.best_energy(),
                        |_cooperative, _slice_sequence| CheckpointAction::BoundaryProposal {
                            state: Array1::from(jumped),
                            action: "census_jump".to_owned(),
                        },
                    );
                }
                let decision = cooperative
                    .decide(replica, policy)
                    .expect("policy decision must name the configured replica");
                last_policy_action = match decision.action {
                    PolicyAction::ContinueLocal | PolicyAction::Exploit { .. } => ACTION_LOCAL,
                    PolicyAction::Explore => ACTION_EXPLORE,
                    PolicyAction::Leave => ACTION_LEAVE,
                };
                slice_sequence = slice_sequence
                    .checked_add(1)
                    .expect("slice sequence must fit u64");
                let mut trace = SliceTrace {
                    slice: slice_sequence,
                    current_basin: policy_trace.local_basin,
                    active_relation: Some(policy_trace.relation),
                    policy_role: PolicyRole::Local,
                    policy_reason: decision.reason.code(),
                    proposal_family: ProposalFamily::Local,
                    sampled_basin: None,
                    descriptor_step_norm: None,
                    cartesian_step_norm: None,
                    validation: SliceValidation::Accepted,
                    quench: SliceQuench::Converged,
                    adoption: SliceAdoption::NotAttempted,
                    novelty: Some(policy_trace.novelty),
                    energy: finite_trace_energy(snapshot.best_energy()),
                    charged_work: u64::try_from(checkpoint_charged)
                        .expect("checkpoint charge must fit u64"),
                };
                if snapshot.remaining() == 0 {
                    cooperative
                        .record_slice(replica, trace)
                        .expect("terminal checkpoint trace must remain complete");
                    phases.fire("continue");
                    return CheckpointAction::Continue;
                }
                match decree_anchor_action(
                    applied_decree,
                    decree_assignment.as_ref(),
                    policy_trace.local_basin,
                ) {
                    DecreeAnchorAction::Ignore => {}
                    DecreeAnchorAction::MarkApplied { snapshot, basin } => {
                        applied_decree = Some(AppliedDecree { snapshot, basin });
                    }
                    DecreeAnchorAction::Fetch {
                        snapshot: decree_snapshot,
                        basin,
                    } => {
                        if let CatalogSampleOutcome::Candidate(candidate) = cooperative
                            .try_sample_basin(replica, basin)
                            .expect("seam-anchor access must preserve local execution")
                            && candidate.census_basin == Some(basin)
                            && candidate.coordinates.len() == snapshot.current_state().len()
                        {
                            cooperative
                                .record_work(replica, ChargeKind::RemoteProposal, 0)
                                .expect("seam-anchor transfer must enter the cooperative ledger");
                            anneal_core::catalog::include_packing_reference(&candidate.coordinates);
                            anneal_core::catalog::offer_known_minimum(
                                candidate.energy,
                                &candidate.coordinates,
                            );
                            applied_decree = Some(AppliedDecree {
                                snapshot: decree_snapshot,
                                basin,
                            });
                            println!(
                                "{}",
                                applied_decree_audit_line(replica, decree_snapshot, basin)
                            );
                            let _ = io::stdout().flush();
                            trace.policy_role = PolicyRole::Explore;
                            trace.policy_reason = "spectral_anchor";
                            trace.proposal_family = ProposalFamily::CatalogSample;
                            trace.sampled_basin = Some(basin);
                            trace.adoption = SliceAdoption::Adopted;
                            cooperative
                                .record_slice(replica, trace)
                                .expect("seam-anchor checkpoint trace must remain complete");
                            phases.fire("spectral_anchor");
                            return CheckpointAction::BoundaryProposal {
                                state: Array1::from(candidate.coordinates),
                                action: "spectral_anchor".to_owned(),
                            };
                        }
                    }
                }
                if histo_screen {
                    cooperative
                        .record_work(replica, ChargeKind::DescriptorEvaluation, 0)
                        .expect("histogram descriptor work must enter the cooperative ledger");
                    let own =
                        class_histogram(snapshot.current_state(), &mut histo_leaders, histo_radius);
                    let novel_here = histo_history
                        .iter()
                        .map(|past| histogram_l1(&own, past))
                        .fold(f64::INFINITY, f64::min);
                    histo_history.push_back(own);
                    if histo_history.len() > 256 {
                        histo_history.pop_front();
                    }
                    // Screen when stalled. Familiarity was a third gate here
                    // and measured out: thermal fluctuation alone moves a
                    // 75-atom histogram by a few flips per checkpoint, so the
                    // familiar-neighborhood test almost never passed and the
                    // mechanism fired once or twice per forty thousand
                    // evaluations. The stall counter is the gate.
                    let _ = novel_here;
                    if stall >= decree_stall_floor
                        && checkpoint_sequence.is_multiple_of(8)
                        && snapshot.remaining() > run_cfg.relax_steps.saturating_add(2)
                    {
                        let mut best: Option<(f64, Array1<f64>)> = None;
                        for _ in 0..6 {
                            let Some(candidate) = fixed_probe_trial(
                                snapshot.current_state(),
                                2.0 * probe_scale * difficulty_gain,
                                &mut histo_rng,
                            ) else {
                                continue;
                            };
                            cooperative
                                .record_work(replica, ChargeKind::DescriptorEvaluation, 0)
                                .expect("histogram screen work must enter the cooperative ledger");
                            let histogram =
                                class_histogram(candidate.view(), &mut histo_leaders, histo_radius);
                            let novelty = histo_history
                                .iter()
                                .map(|past| histogram_l1(&histogram, past))
                                .fold(f64::INFINITY, f64::min);
                            if best.as_ref().is_none_or(|(kept, _)| novelty > *kept) {
                                best = Some((novelty, candidate));
                            }
                        }
                        if let Some((novelty, candidate)) = best
                            && novelty > 0.0
                        {
                            cooperative
                                .record_slice(replica, trace)
                                .expect("histogram checkpoint trace must remain complete");
                            // Adoption, not a diagnostic probe: a screen that
                            // cannot move the live chain contributes records
                            // and no exploration, which the paired smokes
                            // measured as bit-identical endpoints at every
                            // gate setting.
                            phases.fire("histo");
                            return CheckpointAction::BoundaryProposal {
                                state: candidate,
                                action: "histo".to_owned(),
                            };
                        }
                    }
                }
                if let Some(engine) = md_engine.as_ref()
                    && checkpoint_sequence.is_multiple_of(md_interval)
                    && snapshot.remaining()
                        > md_steps
                            .saturating_add(run_cfg.relax_steps)
                            .saturating_add(2)
                {
                    match engine.propagate(
                        snapshot.current_state(),
                        md_steps,
                        md_temperature,
                        md_rng.random(),
                    ) {
                        Ok(state) if state.len() == snapshot.current_state().len() => {
                            cooperative
                                .record_work(
                                    replica,
                                    ChargeKind::AuxiliaryEvaluation,
                                    u64::try_from(md_steps).expect("md steps fit u64"),
                                )
                                .expect("md segment work must enter the cooperative ledger");
                            cooperative
                                .record_slice(replica, trace)
                                .expect("md checkpoint trace must remain complete");
                            phases.fire("externalproposal");
                            return CheckpointAction::ExternalProposal {
                                state,
                                action: format!("md_{}", engine.name()),
                                external_calls: md_steps,
                            };
                        }
                        Ok(_) => {}
                        Err(error) => {
                            eprintln!("md segment failed, local search continues: {error}");
                        }
                    }
                }
                if (bridge_enabled || decree_bridge_duty)
                    && active_bridge.is_none()
                    && checkpoint_sequence.is_multiple_of(bridge_interval)
                    && snapshot.remaining() > run_cfg.relax_steps.saturating_add(2)
                    && let CatalogBridgeOutcome::Assignment(assignment) = cooperative
                        .bridge_assignment(replica, bridge_rng.random())
                        .expect("bridge assignment poll must preserve local execution")
                {
                    let entry = assignment
                        .entry
                        .clone()
                        .filter(|state| state.len() == snapshot.current_state().len());
                    active_bridge = Some(assignment);
                    if let Some(state) = entry {
                        cooperative
                            .record_slice(replica, trace)
                            .expect("bridge checkpoint trace must remain complete");
                        phases.fire("bridge");
                        return CheckpointAction::ProbeProposal {
                            state: Array1::from(state),
                            action: "bridge".to_owned(),
                        };
                    }
                }
                if frontier_exchange_enabled {
                    for (gap, energy, coordinates) in anneal_core::catalog::take_frontier_posts() {
                        let post = anneal_core::catalog_rpc::CatalogFrontierPost {
                            gap,
                            energy,
                            coordinates,
                            producer_replica: replica,
                            posted_sequence: checkpoint_sequence,
                        };
                        let _ = cooperative.offer_frontier(replica, post);
                    }
                    // A deterministic draw untangled from every sampling stream:
                    // the checkpoint index hashed with the replica identity.
                    let draw = checkpoint_sequence.wrapping_mul(0x9E37_79B9_7F4A_7C15)
                        ^ u64::from(replica);
                    if let Ok(Some(post)) = cooperative.draw_frontier(replica, draw)
                        && post.producer_replica != replica
                    {
                        anneal_core::catalog::deliver_frontier_post(
                            post.gap,
                            post.energy,
                            post.coordinates,
                        );
                    }
                }
                match decision.action {
                    PolicyAction::ContinueLocal => {}
                    PolicyAction::Exploit { win_only } => {
                        trace.policy_role = PolicyRole::Exploit;
                        trace.proposal_family = ProposalFamily::CatalogSample;
                        if let CatalogSampleOutcome::Candidate(candidate) = cooperative
                            .try_sample_candidate(replica, INCUMBENT_SAMPLE_DRAW)
                            .expect("incumbent sample must preserve local execution")
                        {
                            // Every structure the catalog hands over is another
                            // chain's packing. The invert repels this chain's quench
                            // from the packings it holds, so a sample is worth
                            // keeping whether or not this arm adopts it: that is the
                            // interaction at the minimisation level, and without it
                            // the reference cloud is only ever this chain's own
                            // history and the chains do not talk during the quench.
                            anneal_core::catalog::include_packing_reference(&candidate.coordinates);
                            anneal_core::catalog::offer_known_minimum(
                                candidate.energy,
                                &candidate.coordinates,
                            );
                            let improves = candidate.energy < snapshot.current_energy() - 1e-10;
                            if candidate.coordinates.len() == snapshot.current_state().len()
                                && (!win_only || improves)
                            {
                                trace.sampled_basin = candidate.census_basin;
                                trace.energy = Some(snapshot.best_energy());
                                trace.adoption = SliceAdoption::Adopted;
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("catalog_incumbent");
                                return CheckpointAction::BoundaryProposal {
                                    state: Array1::from(candidate.coordinates),
                                    action: "catalog_incumbent".to_owned(),
                                };
                            }
                            trace.adoption = if win_only && !improves {
                                SliceAdoption::NotImproved
                            } else {
                                SliceAdoption::Rejected
                            };
                        } else {
                            trace.adoption = SliceAdoption::Rejected;
                        }
                    }
                    PolicyAction::Leave => {
                        trace.policy_role = PolicyRole::Leave;
                        if leave_defers(leave_quiet, leave_patience, leave_crossing) {
                            // Still inside the recovered quiet stretch or the
                            // measured crossing floor. Keep walking.
                            trace.adoption = SliceAdoption::Rejected;
                            cooperative
                                .record_slice(replica, trace)
                                .expect("checkpoint trace must remain complete");
                            phases.fire("continue");
                            return CheckpointAction::Continue;
                        }
                        // Did the last Leave install anything? The anchor is the
                        // packing this replica stood on when it last decided to
                        // Leave, so standing in the same one now is a refusal
                        // whatever the Leave reported at the time.
                        if let Some(here) = snapshot.current_state().as_slice() {
                            match leave_anchor.as_deref() {
                                Some(anchor)
                                    if !anneal_core::catalog::different_packing_family(
                                        anchor, here,
                                    ) =>
                                {
                                    leave_refused += 1;
                                }
                                _ => leave_refused = 0,
                            }
                            leave_anchor = Some(here.to_vec());
                        }
                        if leave_refused >= LEAVE_REFUSAL_DWELL {
                            // This replica has asked for a packing it did not get,
                            // this many times running. Plain hopping is what found
                            // Marks in the serial runs, and it is what the
                            // checkpoint spends its budget on instead of drawing
                            // another hole in the packing it is already in.
                            trace.adoption = SliceAdoption::Rejected;
                            cooperative
                                .record_slice(replica, trace)
                                .expect("checkpoint trace must remain complete");
                            phases.fire("continue");
                            return CheckpointAction::Continue;
                        }
                        // Chains interact during minimisation only through the
                        // reference cloud the packing invert repels the quench
                        // from, and the cloud was fed one catalog structure per
                        // checkpoint. That rate is the same whatever the ensemble
                        // size, so forty-eight chains pushed on each other exactly
                        // as hard as one did and "more chains reach Marks sooner"
                        // had no mechanism under it. What the others are standing
                        // on is already in the shared catalog, whose size does
                        // grow with the ensemble, so the arm reads several entries
                        // at once.
                        let reference_draws = (0..anneal_core::catalog::PACKING_REFERENCE_DRAWS)
                            .map(|step| {
                                // Any draw that is neither sentinel indexes an entry
                                // modulo the catalog length; masking the top bits
                                // keeps it off INCUMBENT_SAMPLE_DRAW and
                                // SPARSE_SAMPLE_DRAW, which mean a policy rather than
                                // a slot.
                                ((u64::from(replica) << 40)
                                    ^ checkpoint_sequence.wrapping_mul(0x9E37_79B9_7F4A_7C15)
                                    ^ (step as u64).wrapping_mul(0x85EB_CA6B))
                                    & (u64::MAX >> 2)
                            });
                        if let Ok(CatalogSamplesOutcome::Candidates(held)) =
                            cooperative.try_sample_candidates(replica, reference_draws)
                        {
                            for held in held {
                                if held.coordinates.len() != snapshot.current_state().len() {
                                    continue;
                                }
                                anneal_core::catalog::include_packing_reference(&held.coordinates);
                                anneal_core::catalog::offer_known_minimum(
                                    held.energy,
                                    &held.coordinates,
                                );
                            }
                        }
                        // Energy landscape paving, with occupancy for the
                        // histogram. Standing on a packing another replica owns
                        // deposits under the replica's own feet, so the funnel
                        // it keeps quenching back into becomes expensive to it
                        // and the pile stops re-forming after each Leave.
                        // Nothing else makes an occupied funnel unattractive to
                        // the replica already in it, only to the coordinator
                        // watching. One deposit per checkpoint spent here is
                        // the count: the repetition is the histogram.
                        if shared_bias_enabled
                            && policy.relation == ActiveCatalogRelation::SameBasin
                        {
                            pending_deposits.push(snapshot.current_state().to_owned());
                        }
                        if decision.reason == PolicyReason::HyperbandPruned {
                            if coop_wells_enabled {
                                remember_packing_well(
                                    snapshot.current_state(),
                                    coop_rcut,
                                    coop_species.as_deref(),
                                    &mut shared_wells,
                                );
                            }
                            let left = {
                                #[cfg(feature = "featomic")]
                                {
                                    anneal_core::featomic_hop::surplus_reseed(
                                        snapshot.current_state(),
                                        &shared_wells,
                                        coop_rcut,
                                        coop_species.as_deref(),
                                        None,
                                        &mut transport_rng,
                                    )
                                }
                                #[cfg(not(feature = "featomic"))]
                                {
                                    None
                                }
                            };
                            if let Some(state) = left {
                                trace.proposal_family = ProposalFamily::HyperbandReseed;
                                trace.adoption = SliceAdoption::Adopted;
                                leave_path.clear();
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("hyperband_reseed");
                                return CheckpointAction::BoundaryProposal {
                                    state,
                                    action: "hyperband_reseed".to_owned(),
                                };
                            }
                        }
                        // Funnel exchange first when Fiedler F>=2: a
                        // representative of another packing community. A
                        // one-community book with open EI aims in landfold
                        // (ArchiveHole) and the hop quench is compacted.
                        // Occupancy extras do not draw a random cluster.
                        let other_family = {
                            if let CatalogSampleOutcome::Candidate(sparse) = cooperative
                                .try_sample_candidate(replica, SPARSE_SAMPLE_DRAW)
                                .expect("catalog sample access must preserve local execution")
                                && sparse.coordinates.len() == snapshot.current_state().len()
                            {
                                // Another packing, not another book cell: a draw
                                // that only clears the cell grain hands the extra
                                // an isomer of the packing it is trying to leave.
                                anneal_core::catalog::include_packing_reference(
                                    &sparse.coordinates,
                                );
                                anneal_core::catalog::offer_known_minimum(
                                    sparse.energy,
                                    &sparse.coordinates,
                                );
                                let elsewhere =
                                    snapshot.current_state().as_slice().is_none_or(|here| {
                                        anneal_core::catalog::different_packing_family(
                                            here,
                                            &sparse.coordinates,
                                        )
                                    });
                                let deeper = sparse.energy < snapshot.current_energy() - 1e-3;
                                (elsewhere && deeper).then_some(sparse)
                            } else {
                                None
                            }
                        };
                        let p_new = leftover_birth_probability(
                            policy.census.total_visits(),
                            policy.census.singleton_basins().max(1),
                        );
                        let birth_draw = {
                            // leave_quiet stands where the cloud-feed loop's step
                            // index cannot reach: it counts checkpoints this
                            // replica has spent without improving, so it advances
                            // once per Leave decision and gives the draw a stream
                            // that varies between consecutive Leaves from one
                            // replica rather than only between replicas.
                            let bits = (u64::from(replica) << 17)
                                ^ checkpoint_sequence.wrapping_mul(0xBF58_476D_1CE4_E5B9)
                                ^ (leave_quiet as u64).wrapping_mul(0x94D0_49BB_1331_11EB);
                            (bits as f64) / (u64::MAX as f64)
                        };
                        count_leave += 1;
                        match occupancy_leave_by_birth(
                            other_family.is_some(),
                            policy.packing_saturated,
                            policy.occupied_family_count,
                            policy.ei_exhausted,
                            p_new,
                            birth_draw,
                            policy.leftover_dwell,
                        ) {
                            OccupancyLeaveTarget::Walk => {
                                count_walk += 1;
                                trace.adoption = SliceAdoption::Rejected;
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("continue");
                                return CheckpointAction::Continue;
                            }
                            OccupancyLeaveTarget::Ridge => {
                                if replica % 2 == 0 {
                                    count_walk += 1;
                                    trace.adoption = SliceAdoption::Rejected;
                                    cooperative
                                        .record_slice(replica, trace)
                                        .expect("checkpoint trace must remain complete");
                                    phases.fire("catalog_ridge");
                                    return CheckpointAction::Continue;
                                }
                                count_hole += 1;
                                trace.proposal_family = ProposalFamily::DescriptorHole;
                                trace.adoption = SliceAdoption::Adopted;
                                leave_path.clear();
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("catalog_ridge");
                                return CheckpointAction::BoundaryProposal {
                                    state: snapshot.current_state().to_owned(),
                                    action: "catalog_ridge".to_owned(),
                                };
                            }
                            OccupancyLeaveTarget::OtherFamily => {
                                hear_state.other_family += 1;
                                let sparse = other_family.expect("other family is on file");
                                anneal_core::catalog::include_packing_reference(
                                    &sparse.coordinates,
                                );
                                trace.proposal_family = ProposalFamily::CatalogSample;
                                trace.adoption = SliceAdoption::Adopted;
                                leave_path.clear();
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("catalog_leave");
                                return CheckpointAction::BoundaryProposal {
                                    state: Array1::from(sparse.coordinates.clone()),
                                    action: "catalog_leave".to_owned(),
                                };
                            }
                            OccupancyLeaveTarget::ArchiveHole => {
                                count_hole += 1;
                                trace.proposal_family = ProposalFamily::DescriptorHole;
                                if coop_wells_enabled {
                                    remember_packing_well(
                                        snapshot.current_state(),
                                        coop_rcut,
                                        coop_species.as_deref(),
                                        &mut shared_wells,
                                    );
                                }
                                let live = snapshot.current_state();
                                let live_slice = live.as_slice().unwrap_or(&[]);
                                let shoot_coords =
                                    leave_path.shoot_coordinates().unwrap_or(live_slice);
                                // Landfold covering start. The hop quench applies
                                // the compacted first phase, then polishes on the
                                // plain potential; landfold names the landing.
                                let index = archive_cover_index(replica, archive_hole_count);
                                archive_hole_count += 1;
                                let left = leave_packing_state(
                                    ArrayView1::from(shoot_coords),
                                    snapshot.current_energy(),
                                    &shared_wells,
                                    coop_rcut,
                                    coop_species.as_deref(),
                                    index,
                                    &mut transport_rng,
                                );
                                if left
                                    .iter()
                                    .zip(snapshot.current_state().iter())
                                    .any(|(a, b)| (a - b).abs() > 1e-12)
                                {
                                    trace.adoption = SliceAdoption::Adopted;
                                    leave_path.clear();
                                    cooperative
                                        .record_slice(replica, trace)
                                        .expect("checkpoint trace must remain complete");
                                    phases.fire("catalog_leave");
                                    return CheckpointAction::BoundaryProposal {
                                        state: left,
                                        action: "catalog_leave".to_owned(),
                                    };
                                }
                                trace.adoption = SliceAdoption::Rejected;
                            }
                        }
                    }
                    PolicyAction::Explore => {
                        trace.policy_role = PolicyRole::Explore;
                        trace.proposal_family = ProposalFamily::DescriptorHole;
                        if let CatalogHoleOutcome::Proposal(_) = cooperative
                            .descriptor_hole(
                                replica,
                                descriptor.clone(),
                                128,
                                transport_rng.random(),
                            )
                            .expect("descriptor-hole access must preserve local execution")
                        {
                            let left = anneal_core::soap::step_away_cloud(
                                snapshot.current_state(),
                                anneal_core::soap::SoapSpec {
                                    n_max: 3,
                                    l_max: 6,
                                    rcut_nn: coop_rcut,
                                },
                                0.35,
                                coop_species.as_deref(),
                                None,
                                None,
                                &mut transport_rng,
                            );
                            if left
                                .iter()
                                .zip(snapshot.current_state().iter())
                                .any(|(a, b)| (a - b).abs() > 1e-12)
                            {
                                trace.proposal_family = ProposalFamily::DescriptorHole;
                                trace.adoption = SliceAdoption::Adopted;
                                cooperative
                                    .record_slice(replica, trace)
                                    .expect("checkpoint trace must remain complete");
                                phases.fire("catalog_explore");
                                return CheckpointAction::BoundaryProposal {
                                    state: left,
                                    action: "catalog_explore".to_owned(),
                                };
                            }
                        }
                        trace.adoption = SliceAdoption::Rejected;
                    }
                }
                cooperative
                    .record_slice(replica, trace)
                    .expect("checkpoint trace must remain complete");
                CheckpointAction::Continue
            },
        );
        with_pending_bias_update(action, &mut gossip_merge)
    };
    let outcome = run_with_bias_at_checkpoints(
        &run_cfg,
        start.view(),
        ledger,
        relax,
        Some(grad),
        &mut bias,
        &mut local_rng,
        checkpoint_interval,
        &mut checkpoint,
    )
    .expect("finite start");
    println!("  checkpoint phases {}", phases.report());
    if evidence_only && let Some(charged) = unsettled_objective_calls(ledger.spent(), last_charged)
    {
        cooperative
            .record_work(replica, EVIDENCE_ONLY_WORK_KIND, charged)
            .expect("terminal evidence-only work must enter the cooperative ledger");
    }
    // The policy layer's own tally, printed where the run ends rather
    // than only on improvement lines: Leaves fire mostly in the quiet
    // stretches after the last improvement, so a count carried on the
    // personal-best line systematically misses the tail.
    println!(
        "  policy: leaves {count_leave} other {} walk {count_walk} hole {count_hole} refused {leave_refused}",
        hear_state.other_family
    );
    let wall = occupancy_started.elapsed().as_secs_f64();
    if let Some(rate) = hops_per_core_hour(outcome.hops as u64, wall, 1) {
        println!(
            "  hops-per-core-hour {rate:.1}  hops {}  wall {wall:.3}s",
            outcome.hops
        );
    }
    let open_epoch = population_progress.epoch();
    let _ = population_call(cooperative.abstain_population(replica, open_epoch));
    if open_epoch != 0 {
        let _ = population_call(cooperative.abstain_population(replica, 0));
    }
    #[cfg(feature = "bank-rpc")]
    {
        brain_stop.store(true, std::sync::atomic::Ordering::Relaxed);
        if let Some(handle) = brain_handle {
            let _ = handle.join();
        }
    }
    let trace = cooperative.json_lines(&RunManifest {
        campaign,
        ensemble,
        sharing,
        engine: anneal_core::compatibility::EngineDescriptor::default(),
    });
    if let Ok(path) = std::env::var("CATALOG_TRACE") {
        let mut output = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)
            .expect("CATALOG_TRACE must be writable");
        output
            .write_all(trace.as_bytes())
            .expect("catalog trace write must succeed");
    } else {
        eprint!("{trace}");
    }
    outcome
}

/// Whether two Cartesian states belong to one packing family.
///
/// Histograms share one [`anneal_core::catalog::PackingBook`] so class
/// labels line up; independent [`anneal_core::catalog::packing_vector`]
/// calls mint separate codebooks.
#[cfg(feature = "bank-rpc")]
fn same_packing_coordinates(live: &[f64], parent: &[f64]) -> bool {
    use anneal_core::catalog::{PackingBook, same_packing};
    let mut book = PackingBook::default();
    if book.observe(live).is_none() || book.observe(parent).is_none() {
        return false;
    }
    match (book.histogram(live), book.histogram(parent)) {
        (Some(live_hist), Some(parent_hist)) => same_packing(&live_hist, &parent_hist),
        _ => false,
    }
}

#[cfg(feature = "bank-rpc")]
fn vector_distance(left: &[f64], right: &[f64]) -> f64 {
    assert_eq!(left.len(), right.len(), "diagnostic vectors must align");
    left.iter()
        .zip(right)
        .map(|(left, right)| {
            let difference = left - right;
            difference * difference
        })
        .sum::<f64>()
        .sqrt()
}

#[cfg(feature = "bank-rpc")]
fn required_catalog_env(name: &str) -> String {
    std::env::var(name).unwrap_or_else(|_| panic!("{name} is required with CATALOG_RPC"))
}

#[cfg(feature = "bank-rpc")]
fn census_bus_base(sharing: bool, evidence_only: bool, configured: Option<&str>) -> Option<u16> {
    if !sharing || evidence_only {
        return None;
    }
    configured?.parse().ok()
}

#[cfg(feature = "bank-rpc")]
fn census_nearby_updates(
    last_minimum: &mut Option<(f64, Vec<f64>)>,
    _checkpoint_sequence: u64,
    energy: f64,
    here: &[f64],
    peers: &[&anneal_core::census_bus::PeerMinimum],
    fresh: &[anneal_core::census_bus::PeerMinimum],
    nearby: &std::collections::HashMap<u32, bool>,
) -> (Vec<(u32, bool)>, usize) {
    // Latest admitted peers are live occupancy, not an archive count. Keep
    // distant peers available for classification if this chain changes family.
    let mut ordered_peers = peers.to_vec();
    ordered_peers.sort_unstable_by_key(|peer| peer.replica);
    anneal_core::catalog::packing::set_packing_peers(
        ordered_peers
            .iter()
            .map(|peer| peer.coordinates.clone())
            .collect(),
    );
    // Packing classification depends on coordinates, not objective values.
    let own_moved = last_minimum
        .as_ref()
        .is_none_or(|(_, coordinates)| coordinates != here);
    if own_moved || last_minimum.is_none() {
        *last_minimum = Some((energy, here.to_vec()));
    }
    let fresh_ids: Vec<u32> = fresh.iter().map(|peer| peer.replica).collect();
    let mut updates = Vec::new();
    let mut crowd = 0;
    for peer in peers {
        if peer.coordinates.len() != here.len() {
            updates.push((peer.replica, false));
            continue;
        }
        let stale =
            own_moved || fresh_ids.contains(&peer.replica) || !nearby.contains_key(&peer.replica);
        let near = if stale {
            let near = anneal_core::catalog::nearby_packing(here, &peer.coordinates);
            // Register the peer's structure as a repulsion reference only
            // when it becomes nearby or its minimum changed; the registry
            // rebuilds its packing book over every held reference on each
            // call, which at forty references was the remaining cost.
            let was_near = nearby.get(&peer.replica).copied().unwrap_or(false);
            if near && (!was_near || fresh_ids.contains(&peer.replica)) {
                anneal_core::catalog::include_packing_reference(&peer.coordinates);
            }
            updates.push((peer.replica, near));
            near
        } else {
            nearby[&peer.replica]
        };
        crowd += usize::from(near);
    }
    (updates, crowd)
}

#[cfg(feature = "bank-rpc")]
fn lj_catalog_gradient_norm(
    energy: f64,
    coordinates: ArrayView1<f64>,
    gradient: Option<ArrayView1<f64>>,
) -> Option<f64> {
    let gradient = gradient?;
    if !energy.is_finite()
        || coordinates.is_empty()
        || !coordinates.len().is_multiple_of(3)
        || gradient.len() != coordinates.len()
        || coordinates.iter().any(|value| !value.is_finite())
    {
        return None;
    }
    let norm = euclidean_gradient_norm(gradient.as_slice()?);
    (norm.is_finite() && norm <= 1e-5).then_some(norm)
}

#[cfg(all(test, feature = "bank-rpc"))]
mod census_policy_tests {
    use super::{census_bus_base, census_nearby_updates, lj_catalog_gradient_norm};
    use anneal_core::census_bus::PeerMinimum;
    use ndarray::{arr1, array};

    fn packing_coordinates(text: &str) -> Vec<f64> {
        text.lines()
            .skip(2)
            .filter(|line| !line.trim().is_empty())
            .flat_map(|line| line.split_whitespace().skip(1).take(3))
            .map(|value| value.parse().unwrap())
            .collect()
    }

    #[test]
    fn crowd_cache_tracks_own_geometry_even_at_equal_energy() {
        let ico = packing_coordinates(include_str!("../tests/fixtures/lj75_ico.xyz"));
        let marks = packing_coordinates(include_str!("../tests/fixtures/lj75_marks.xyz"));
        let peer = PeerMinimum {
            replica: 1,
            hops: 7,
            energy: -396.0,
            coordinates: ico.clone(),
        };
        let mut anchor = None;
        let mut nearby = std::collections::HashMap::new();
        let (updates, crowd) =
            census_nearby_updates(&mut anchor, 4, -396.0, &ico, &[&peer], &[], &nearby);
        nearby.extend(updates);
        assert_eq!(crowd, 1);
        let (updates, crowd) =
            census_nearby_updates(&mut anchor, 4, -396.0, &marks, &[&peer], &[], &nearby);
        assert_eq!(
            crowd, 0,
            "changed local geometry invalidates the crowd cache"
        );
        assert_eq!(updates, vec![(1, false)]);
    }

    #[test]
    fn every_checkpoint_phase_classifies_the_occupied_geometry() {
        let ico = packing_coordinates(include_str!("../tests/fixtures/lj75_ico.xyz"));
        let marks = packing_coordinates(include_str!("../tests/fixtures/lj75_marks.xyz"));
        let peer = PeerMinimum {
            replica: 1,
            hops: 7,
            energy: -396.0,
            coordinates: ico.clone(),
        };
        for checkpoint_sequence in 1..=8 {
            let mut anchor = None;
            let mut nearby = std::collections::HashMap::new();
            let (updates, crowd) =
                census_nearby_updates(&mut anchor, 0, -396.0, &ico, &[&peer], &[], &nearby);
            nearby.extend(updates);
            assert_eq!(crowd, 1);
            let (updates, crowd) = census_nearby_updates(
                &mut anchor,
                checkpoint_sequence,
                -396.0,
                &marks,
                &[&peer],
                &[],
                &nearby,
            );
            assert_eq!(
                crowd, 0,
                "checkpoint {checkpoint_sequence} cannot reuse another occupied geometry's crowd"
            );
            assert_eq!(updates, vec![(1, false)]);
        }
    }

    #[test]
    fn incompatible_peer_geometry_cannot_remain_in_the_crowd() {
        let ico = packing_coordinates(include_str!("../tests/fixtures/lj75_ico.xyz"));
        let mut peer = PeerMinimum {
            replica: 1,
            hops: 7,
            energy: -396.0,
            coordinates: ico.clone(),
        };
        let mut anchor = None;
        let mut nearby = std::collections::HashMap::new();
        let (updates, crowd) =
            census_nearby_updates(&mut anchor, 4, -396.0, &ico, &[&peer], &[], &nearby);
        nearby.extend(updates);
        assert_eq!(crowd, 1);
        peer.coordinates.truncate(6);
        let (updates, crowd) = census_nearby_updates(
            &mut anchor,
            4,
            -396.0,
            &ico,
            &[&peer],
            std::slice::from_ref(&peer),
            &nearby,
        );
        assert_eq!(crowd, 0, "an incompatible peer cannot be a nearby packing");
        assert_eq!(updates, vec![(1, false)]);
    }

    #[test]
    fn private_controls_cannot_activate_an_inherited_census_port() {
        assert_eq!(census_bus_base(false, false, Some("32000")), None);
        assert_eq!(census_bus_base(false, true, Some("32000")), None);
    }

    #[test]
    fn evidence_only_exchange_cannot_activate_geometry_census() {
        assert_eq!(census_bus_base(true, true, Some("32000")), None);
    }

    #[test]
    fn shared_geometry_exchange_requires_a_valid_configured_port() {
        assert_eq!(census_bus_base(true, false, Some("32000")), Some(32000));
        for configured in [None, Some(""), Some("invalid"), Some("65536")] {
            assert_eq!(census_bus_base(true, false, configured), None);
        }
    }

    #[test]
    fn publication_requires_matching_finite_gradient_evidence() {
        let coordinates = array![0.0, 0.0, 0.0, 1.0, 0.0, 0.0];
        assert_eq!(
            lj_catalog_gradient_norm(-1.0, coordinates.view(), None),
            None
        );
        for gradient in [
            array![],
            arr1(&[0.0; 3]),
            arr1(&[f64::NAN; 6]),
            arr1(&[f64::INFINITY; 6]),
        ] {
            assert_eq!(
                lj_catalog_gradient_norm(-1.0, coordinates.view(), Some(gradient.view())),
                None
            );
        }
        let gradient = arr1(&[0.0; 6]);
        assert_eq!(
            lj_catalog_gradient_norm(-1.0, coordinates.view(), Some(gradient.view())),
            Some(0.0)
        );
        assert_eq!(
            lj_catalog_gradient_norm(f64::NAN, coordinates.view(), Some(gradient.view())),
            None
        );
        let invalid = arr1(&[f64::NAN; 6]);
        assert_eq!(
            lj_catalog_gradient_norm(-1.0, invalid.view(), Some(gradient.view())),
            None
        );
    }

    #[test]
    fn census_stationarity_uses_the_catalog_norm_not_the_answer_component_limit() {
        let coordinates = array![0.0, 0.0, 0.0, 1.0, 0.0, 0.0];
        let too_large = array![8e-6, 8e-6, 0.0, 0.0, 0.0, 0.0];
        assert_eq!(
            lj_catalog_gradient_norm(-1.0, coordinates.view(), Some(too_large.view())),
            None
        );
        let boundary = array![1e-5, 0.0, 0.0, 0.0, 0.0, 0.0];
        assert_eq!(
            lj_catalog_gradient_norm(-1.0, coordinates.view(), Some(boundary.view())),
            Some(1e-5)
        );
    }
}

#[cfg(all(test, feature = "bank-rpc"))]
mod census_repulsion_tests {
    use super::census_nearby_updates;
    use anneal_core::catalog::{nearby_packing, packing_references, set_packing_references};
    use anneal_core::census_bus::PeerMinimum;
    use anneal_core::methods::cluster_hopping::ClusterMove;
    use anneal_core::soap::{SoapSpec, push_away_clouds, step_away_cloud};
    use ndarray::{Array1, array};
    use rand::{SeedableRng, rngs::StdRng};
    use std::collections::HashMap;

    fn structure() -> Array1<f64> {
        array![0.0, 0.0, 0.0, 1.1, 0.0, 0.0, 0.0, 1.2, 0.0, 0.0, 0.0, 1.3]
    }

    #[test]
    fn a_nearby_ring_peer_activates_separation_even_when_archive_entries_merge() {
        let x = structure();
        let peer = &x * 1.0001;
        assert!(nearby_packing(
            x.as_slice().unwrap(),
            peer.as_slice().unwrap()
        ));
        let spec = SoapSpec::default();
        let cap = 1e-4;
        let expected = push_away_clouds(x.view(), &[peer.to_vec()], spec, cap).unwrap();
        for count in 1..=3 {
            set_packing_references(Vec::new());
            let peers: Vec<_> = (1..=count)
                .map(|replica| PeerMinimum {
                    replica,
                    hops: 7,
                    energy: -1.0,
                    coordinates: peer.to_vec(),
                })
                .collect();
            let (_, crowd) = census_nearby_updates(
                &mut None,
                1,
                -1.0,
                x.as_slice().unwrap(),
                &peers.iter().collect::<Vec<_>>(),
                &peers,
                &HashMap::new(),
            );
            assert_eq!(crowd, count as usize);
            assert_eq!(
                packing_references().len(),
                1,
                "history merges one occupied well"
            );
            let proposed = ClusterMove::SoapRepel {
                rmsd: cap,
                cutoff: spec.rcut_nn,
            }
            .propose(x.view(), 1.0, &mut StdRng::seed_from_u64(53));
            assert_eq!(
                proposed, expected,
                "{count} nearby peers supply directed separation"
            );
        }
    }

    #[test]
    fn empty_live_census_cannot_repel_from_archived_peer_positions() {
        let x = structure();
        let peer = &x * 1.03;
        let archive = vec![peer.to_vec(); 3];
        set_packing_references(archive.clone());
        let (_, crowd) = census_nearby_updates(
            &mut None,
            1,
            -1.0,
            x.as_slice().unwrap(),
            &[],
            &[],
            &HashMap::new(),
        );
        assert_eq!(crowd, 0);
        assert_eq!(
            packing_references(),
            archive,
            "live occupancy does not erase history"
        );
        let spec = SoapSpec::default();
        let cap = 1e-4;
        let expected = step_away_cloud(
            x.view(),
            spec,
            cap,
            None,
            None,
            None,
            &mut StdRng::seed_from_u64(53),
        );
        let proposed = ClusterMove::SoapRepel {
            rmsd: cap,
            cutoff: spec.rcut_nn,
        }
        .propose(x.view(), 1.0, &mut StdRng::seed_from_u64(53));
        assert_eq!(
            proposed, expected,
            "no live crowd means the independent escape"
        );
    }
}

#[cfg(feature = "bank-rpc")]
fn lj_catalog_candidate(
    descriptor_space: &anneal_core::descriptor_space::DescriptorSpace,
    species: &[u32],
    replica: u32,
    event_sequence: u64,
    seed: u64,
    charged_work: usize,
    energy: f64,
    coordinates: ArrayView1<f64>,
    gradient: ArrayView1<f64>,
) -> Option<anneal_core::catalog_rpc::CatalogCandidate> {
    let gradient_norm = lj_catalog_gradient_norm(energy, coordinates, Some(gradient))?;
    let descriptor = descriptor_space.describe(coordinates, Some(species)).ok()?;
    Some(anneal_core::catalog_rpc::CatalogCandidate {
        producer_replica: replica,
        coordinates: coordinates.to_vec(),
        cell: None,
        energy,
        forces: gradient.iter().map(|value| -*value).collect(),
        gradient_norm,
        descriptor: descriptor.values().to_vec(),
        descriptor_schema_version: descriptor.schema_version(),
        quench_converged: true,
        charged_work: u64::try_from(charged_work).ok()?,
        event_sequence,
        seed,
        census_basin: None,
    })
}

#[cfg(test)]
#[cfg(feature = "bank-rpc")]
#[allow(clippy::too_many_arguments)]
fn lj_transition_candidates(
    descriptor_space: &anneal_core::descriptor_space::DescriptorSpace,
    species: &[u32],
    replica: u32,
    source_sequence: u64,
    destination_sequence: u64,
    seed: u64,
    charged_work: usize,
    transition: &AcceptedTransition,
) -> Option<(
    anneal_core::catalog_rpc::CatalogCandidate,
    anneal_core::catalog_rpc::CatalogCandidate,
)> {
    if !transition.validated {
        return None;
    }
    let source = lj_catalog_candidate(
        descriptor_space,
        species,
        replica,
        source_sequence,
        seed,
        charged_work,
        transition.from_energy,
        transition.from_state.view(),
        transition.from_gradient.as_ref()?.view(),
    )?;
    let destination = lj_catalog_candidate(
        descriptor_space,
        species,
        replica,
        destination_sequence,
        seed,
        charged_work,
        transition.to_energy,
        transition.to_state.view(),
        transition.to_gradient.as_ref()?.view(),
    )?;
    Some((source, destination))
}

#[cfg(test)]
#[cfg(feature = "bank-rpc")]
#[allow(clippy::too_many_arguments)]
fn boundary_transition_destination(
    descriptor_space: &anneal_core::descriptor_space::DescriptorSpace,
    species: &[u32],
    replica: u32,
    event_sequence: u64,
    seed: u64,
    charged_work: usize,
    energy: f64,
    coordinates: ArrayView1<f64>,
    gradient: ArrayView1<f64>,
) -> Option<(&'static str, anneal_core::catalog_rpc::CatalogCandidate)> {
    lj_catalog_candidate(
        descriptor_space,
        species,
        replica,
        event_sequence,
        seed,
        charged_work,
        energy,
        coordinates,
        gradient,
    )
    .map(|candidate| ("boundary_transport", candidate))
}

#[cfg(feature = "bank-rpc")]
enum AdaptiveCatalogOperation {
    RegisterCurrent(anneal_core::catalog_rpc::CatalogCandidate),
    Adopt {
        action: String,
        destination: anneal_core::catalog_rpc::CatalogCandidate,
        adopted: bool,
    },
    Unresolved {
        action: String,
    },
}

#[cfg(feature = "bank-rpc")]
#[allow(clippy::too_many_arguments)]
fn adaptive_catalog_operations(
    descriptor_space: &anneal_core::descriptor_space::DescriptorSpace,
    species: &[u32],
    replica: u32,
    candidate_sequence: &mut u64,
    seed: u64,
    charged_work: usize,
    transitions: &[AcceptedTransition],
) -> Vec<AdaptiveCatalogOperation> {
    let mut operations = Vec::new();
    let mut registered_state: Option<Array1<f64>> = None;
    for transition in transitions {
        let failed_probe = transition.action == "probe"
            && !transition.validated
            && transition.from_gradient.is_some();
        if failed_probe {
            let continues_registered_path = registered_state
                .as_ref()
                .is_some_and(|state| *state == transition.from_state);
            if !continues_registered_path {
                let source_sequence = candidate_sequence
                    .checked_add(1)
                    .expect("candidate sequence must fit u64");
                let Some(source) = lj_catalog_candidate(
                    descriptor_space,
                    species,
                    replica,
                    source_sequence,
                    seed,
                    charged_work,
                    transition.from_energy,
                    transition.from_state.view(),
                    transition
                        .from_gradient
                        .as_ref()
                        .expect("probe source gradient checked")
                        .view(),
                ) else {
                    registered_state = None;
                    continue;
                };
                *candidate_sequence = source_sequence;
                operations.push(AdaptiveCatalogOperation::RegisterCurrent(source));
            }
            operations.push(AdaptiveCatalogOperation::Unresolved {
                action: transition.action.clone(),
            });
            registered_state = Some(transition.from_state.clone());
            continue;
        }
        if !transition.validated
            || transition.from_gradient.is_none()
            || transition.to_gradient.is_none()
        {
            registered_state = None;
            continue;
        }
        let continues_registered_path = registered_state
            .as_ref()
            .is_some_and(|state| *state == transition.from_state);
        if !continues_registered_path {
            let source_sequence = candidate_sequence
                .checked_add(1)
                .expect("candidate sequence must fit u64");
            let Some(source) = lj_catalog_candidate(
                descriptor_space,
                species,
                replica,
                source_sequence,
                seed,
                charged_work,
                transition.from_energy,
                transition.from_state.view(),
                transition
                    .from_gradient
                    .as_ref()
                    .expect("validated transition source gradient checked")
                    .view(),
            ) else {
                registered_state = None;
                continue;
            };
            *candidate_sequence = source_sequence;
            operations.push(AdaptiveCatalogOperation::RegisterCurrent(source));
        }
        if !transition.validated || transition.to_gradient.is_none() {
            operations.push(AdaptiveCatalogOperation::Unresolved {
                action: transition.action.clone(),
            });
            registered_state = Some(transition.from_state.clone());
            continue;
        }
        let destination_sequence = candidate_sequence
            .checked_add(1)
            .expect("candidate sequence must fit u64");
        let Some(destination) = lj_catalog_candidate(
            descriptor_space,
            species,
            replica,
            destination_sequence,
            seed,
            charged_work,
            transition.to_energy,
            transition.to_state.view(),
            transition
                .to_gradient
                .as_ref()
                .expect("validated transition destination gradient checked")
                .view(),
        ) else {
            registered_state = None;
            continue;
        };
        *candidate_sequence = destination_sequence;
        operations.push(AdaptiveCatalogOperation::Adopt {
            action: transition.action.clone(),
            destination,
            adopted: transition.adopted,
        });
        registered_state = Some(if transition.adopted {
            transition.to_state.clone()
        } else {
            transition.from_state.clone()
        });
    }
    operations
}

/// One HQ chain against the Cap'n Proto bank: slice, offer, deposit, repeat.
#[cfg(feature = "bank-rpc")]
fn run_capnp_bank(
    cfg: &Config,
    ledger: &mut Ledger,
    relax: &mut (dyn FnMut(&mut Ledger, ArrayView1<f64>, usize) -> (f64, Array1<f64>) + Send),
    grad: &mut (dyn FnMut(&mut Ledger, ArrayView1<f64>) -> Option<Array1<f64>> + Send),
    seed: u64,
    sock: &str,
) -> Outcome {
    use anneal_core::bank_rpc::BankClient;
    use anneal_core::diversity::DiversityAnnealer;
    use rand::Rng;
    let mut cfg = cfg.clone();
    cfg.budget_window = true;
    let cfg = &cfg;
    // Kubelet: the walk owns the hop. The bank is optional. A refused
    // connect (worker moved, login bank dead) is a solo leftover run.
    let mut client = match BankClient::connect(sock) {
        Ok(c) => Some(c),
        Err(e) => {
            println!("  bank {sock} down ({e}); own walk");
            None
        }
    };
    let sync_every = anneal_core::env::parsed("BANK_SYNC")
        .unwrap_or(8usize)
        .max(1);
    let mut bias = BasinBias::new(
        ClusterFingerprint::of_config(cfg, &Array1::zeros(0)),
        cfg.merge_radius,
        cfg.bias_height,
        cfg.bias_gamma,
    );
    let slice = anneal_core::env::parsed("BANK_SLICE").unwrap_or(500);
    let mut rng = <rand::rngs::StdRng as rand::SeedableRng>::seed_from_u64(seed);
    let mut best = f64::INFINITY;
    let mut best_state: Option<Array1<f64>> = None;
    let mut hops = 0usize;
    let mut basins = 0usize;
    let mut screened_out = 0usize;
    let mut returned = 0usize;
    let mut slices = 0usize;
    let mut null_starts = 0usize;
    let total = ledger.remaining();
    let mut schedule: Option<DiversityAnnealer> = None;
    let mut well_pairs: Vec<(Array1<f64>, f64)> = Vec::new();
    let mut catalog_best = f64::INFINITY;
    let mut catalog_size = 0usize;
    let mut stall = 0u32;
    while ledger.remaining() > 0 {
        let progress = 1.0 - ledger.remaining() as f64 / total.max(1) as f64;
        let pull = slices == 0 || slices.is_multiple_of(sync_every);
        if pull && client.is_none() {
            client = BankClient::connect(sock).ok();
        }
        if pull && let Some(c) = client.as_mut() {
            match c.snapshot() {
                Ok(s) => {
                    for (soap, h) in &s.wells {
                        bias.import_well(soap.clone(), *h);
                    }
                    #[cfg(feature = "featomic")]
                    anneal_core::featomic_hop::set_packing_archive(
                        s.wells.iter().map(|(soap, _)| soap.clone()).collect(),
                    );
                    well_pairs = s.wells.clone();
                    catalog_size = s.size as usize;
                    if !s.energies.is_empty() {
                        catalog_best = s.energies.iter().copied().fold(f64::INFINITY, f64::min);
                    }
                    if s.size >= 2 {
                        let sched = schedule.get_or_insert_with(|| {
                            let floor = {
                                #[cfg(feature = "featomic")]
                                {
                                    anneal_core::featomic_hop::SOAP_PACK_MERGE
                                }
                                #[cfg(not(feature = "featomic"))]
                                {
                                    0.10
                                }
                            };
                            DiversityAnnealer::from_initial(s.dcut.max(floor))
                                .with_final_fraction(0.4)
                        });
                        let progress = 1.0 - ledger.remaining() as f64 / total.max(1) as f64;
                        if c.set_dcut(sched.threshold(progress)).is_err() {
                            client = None;
                        }
                    }
                }
                Err(_) => client = None,
            }
        }
        let wells: Vec<Array1<f64>> = well_pairs.iter().map(|(w, _)| w.clone()).collect();
        let mut start = if let Some(bx) = best_state.as_ref() {
            bx.clone()
        } else {
            random_cluster(cfg.n_points, 0.7, cfg.min_separation, &mut rng)
        };
        let mine = packing_of(start.view(), cfg);
        let gap = {
            #[cfg(feature = "featomic")]
            {
                anneal_core::featomic_hop::SOAP_PACK_GAP
            }
            #[cfg(not(feature = "featomic"))]
            {
                0.15
            }
        };
        let sat = catalog_saturated(&well_pairs, cfg.bias_height);
        let on_known = packing_is_known(start.view(), cfg, &wells);
        let swarm = anneal_core::swarm::policy(
            progress,
            best,
            best,
            catalog_best,
            catalog_size,
            sat,
            on_known && sat,
            stall,
        );
        if pull
            && swarm.pull
            && let Some(c) = client.as_mut()
        {
            match c.sample(rng.random()) {
                Ok(Some((e, x))) if x.len() == 3 * cfg.n_points => {
                    let theirs = packing_of(x.view(), cfg);
                    let dist = if mine.is_empty() || mine.len() != theirs.len() {
                        f64::INFINITY
                    } else {
                        mine.iter()
                            .zip(theirs.iter())
                            .map(|(a, b)| (a - b) * (a - b))
                            .sum::<f64>()
                            .sqrt()
                    };
                    let take = if swarm.win_only {
                        e < best - 0.05
                    } else {
                        e < best - 0.05 || (dist > gap && e < best + 1.0)
                    };
                    if take {
                        if e < best {
                            best = e;
                            best_state = Some(x.clone());
                        }
                        start = x;
                    }
                }
                Ok(_) => {}
                Err(_) => client = None,
            }
        }
        if swarm.leave {
            null_starts += 1;
            start = leave_known_packing(start.view(), cfg, &wells, ledger, relax, &mut rng);
        }
        let mut slice_led = Ledger::new(slice.min(ledger.remaining()));
        let out = run_with_bias(
            cfg,
            start.view(),
            &mut slice_led,
            relax,
            Some(grad),
            &mut bias,
            &mut rng,
        )
        .expect("finite start");
        ledger.charge_many(slice_led.spent());
        if let Some(st) = slice_led.best_state.as_ref() {
            ledger.record(slice_led.best, st.view());
        }
        hops += out.hops;
        basins += out.basins;
        screened_out += out.screened_out;
        returned += out.returned;
        slices += 1;
        let improved = out.best < best;
        if improved {
            best = out.best;
            best_state = out.best_state.clone();
            stall = 0;
        } else {
            stall = stall.saturating_add(1);
        }
        // Publish a win only. Depositing every slice is 48 chains
        // IRA-matching on the login node.
        if improved
            && let Some(st) = out.best_state.as_ref()
            && let Some(c) = client.as_mut()
        {
            let soap = packing_of(st.view(), cfg);
            if c.offer(out.best, st.view(), soap.view()).is_err()
                || c.deposit(soap.view(), cfg.bias_height).is_err()
            {
                client = None;
            }
        }
        println!(
            "      slice {slices} spent {} best {best:.6} null {null_starts}",
            ledger.spent()
        );
        let _ = std::io::stdout().flush();
    }
    println!(
        "      capnp bank: {slices} slices, {null_starts} archive-null starts, best {best:.6}"
    );
    Outcome {
        best,
        best_state,
        hops,
        basins,
        screened_out,
        returned,
        ..Outcome::default()
    }
}

/// Thread replicas of the production hop loop over the channels the
/// environment names, under the comparison contract: identical replica
/// seeds and starts in every arm, one aggregate budget per seed equal to
/// `budget`, the first-discovery aggregate call count on the record and
/// the executable digest on the header.
fn run_history_ensembles(
    cfg: &Config,
    n: usize,
    budget: usize,
    seed0: u64,
    seeds: u64,
    reference: Option<f64>,
    replicas: usize,
    opts: &[&str],
) {
    use anneal_core::methods::cluster_hopping::random_cluster_in_radius;
    use anneal_core::methods::ensemble::{EnsembleProblem, ObjectiveFactory, StartFactory};
    #[cfg(feature = "ira")]
    use anneal_core::methods::minima_hopping::SerializedWitness;
    use anneal_core::pes_exploration::StructureContext;
    #[cfg(not(feature = "ira"))]
    use ensemble_report::sorted_pairs_witness;
    use ensemble_report::{config_from_env, print_header, run_seeds};

    let ens = config_from_env(replicas, budget, reference.map(|r| r + 1e-4));
    let mut cfg = cfg.clone();
    if let Some(cap) = anneal_core::env::parsed::<usize>("SHARED_DEPOSITS") {
        cfg.shared_deposits = cap;
    }
    ens.validate(&cfg).unwrap_or_else(|error| panic!("{error}"));
    let pair_cache_bytes: usize =
        anneal_core::env::parsed("HISTORY_PAIR_CACHE_BYTES").unwrap_or(128 * 1024 * 1024);
    let descriptor = anneal_core::catalog::lj::descriptor_space();
    let ira_radius = anneal_core::catalog::lj::CALIBRATION_IRA_TOLERANCE;
    #[cfg(feature = "ira")]
    let witness = SerializedWitness(Mutex::new(
        IraStructureWitness {
            kmax_factor: if n >= 55 { 2.5 } else { 1.8 },
            radius: ira_radius,
        }
        .with_pair_cache(pair_cache_bytes),
    ));
    #[cfg(not(feature = "ira"))]
    let witness = {
        let _ = pair_cache_bytes;
        sorted_pairs_witness(n, ira_radius)
    };
    let witness_name = if cfg!(feature = "ira") {
        "ira-cached"
    } else {
        "sorted-pairs-fallback"
    };
    let context = StructureContext::new(Some(vec![18; n]), None, Some(format!("lj-reduced-n{n}")));
    let objective: ObjectiveFactory<'_> = &|_| Box::new(|x: ArrayView1<f64>| lj(x));
    let start: StartFactory<'_> =
        &|_, rng| random_cluster_in_radius(n, cfg.start_radius(), cfg.min_separation, rng);
    let same_family = |a: &[f64], b: &[f64]| !anneal_core::catalog::different_packing_family(a, b);
    let problem = EnsembleProblem {
        objective,
        start,
        descriptor: &descriptor,
        context: &context,
        witness: &witness,
        same_family: &same_family,
        // The share bound and the answer bound of the LJ campaign, in
        // reduced units.
        certificate: 1e-5,
        polish_below: 1e-3,
        callbacks_per_objective: 1,
    };
    print_header(
        &ens,
        witness_name,
        &opts.join(","),
        &format!("shared deposits {},", cfg.shared_deposits),
    );
    // The read-only answer audit of the seed loop, per replica.
    let verify = |replica: usize, x: &Array1<f64>, reported: f64| {
        assert_eq!(
            x.len(),
            3 * n,
            "replica {replica} returned {} coordinates",
            x.len()
        );
        let (e, g) = lj(x.view());
        let gmax = g.iter().fold(0.0_f64, |a, v| a.max(v.abs()));
        assert!(
            e.is_finite() && (e - reported).abs() < 1e-6,
            "replica {replica} reports {reported} but its coordinates have energy {e}"
        );
        assert!(
            g.iter().all(|v| v.is_finite()) && gmax < 1e-3,
            "replica {replica} returned a structure with gradient {gmax:.2e}"
        );
        (e, gmax)
    };
    run_seeds(&cfg, &ens, seed0, seeds, &problem, "", &verify, reference);
}
