# Copyright (c) anneal developers

# Prose false positives

These warnings stay.
The string is required, or the span is TeX markup.

## Frozen author block

SURF and B.V. are the affiliation text from main.
The manuscript, the supporting information, and the cover letter keep
them.
The checker asks to spell SURF out and to restyle B.V.
That expansion waits on Rohit.

## Copyright line

The header is `Copyright (c) anneal developers`.
The checker asks for a copyright symbol.
The required line keeps the letters.

## Title span

The subject-verb warning at the email line runs from the affiliation
brace through the title into the abstract.
The title is not a clause.
The abstract opens with "We describe".

## Numeric table

The subject-verb warning at the counter-table label runs through the
numeric rows.
The cells have no sentence period.
A period in a numeric cell was removed on purpose.
The next sentence states the anneal ledger.

## Symmetrisation subsection

The subsection follows the sentence that calls the burst one arm.
Openers on burst, arm, figure, search, count, and campaign were tried.
The cohesion warning remains.
The subsection still states the symmetry step.
