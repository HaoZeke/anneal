#!/usr/bin/env python3
# Copyright (c) anneal developers
"""Redraw the landfold figure without a seed count.

The deposited maps quoted 72, 48, 200, and 4 seeds. Those counts are
not a result of this draft. Each panel is marked stale, and no seed
count is printed.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PANELS = (
    "LJ38 derived",
    "LJ38 recommended",
    "LJ55 derived",
    "LJ55 recommended",
    "LJ75 derived",
    "LJ75 recommended",
    "LJ98 derived",
    "LJ98 recommended",
    "TIP4P hexamer",
)


def main() -> None:
    figure, axes = plt.subplots(3, 3, figsize=(7.2, 6.2))
    for axis, title in zip(axes.ravel(), PANELS):
        axis.set_xticks([])
        axis.set_yticks([])
        axis.set_title(title, fontsize=9)
        axis.text(
            0.5,
            0.5,
            "STALE",
            ha="center",
            va="center",
            fontsize=14,
            color="#9a3412",
            transform=axis.transAxes,
        )
        for spine in axis.spines.values():
            spine.set_color("#9a3412")
    figure.suptitle("Landfold maps, stale until a fresh run", fontsize=12)
    figure.tight_layout()
    dest = Path(__file__).resolve().parents[1] / "figs" / "landfold_maps.pdf"
    figure.savefig(dest)
    plt.close(figure)


if __name__ == "__main__":
    main()
