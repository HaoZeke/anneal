# Claims kept beside the edit

The Wales-group program (GMIN) is the external basin-hopping code named
below.
This note lists the softened sentences from the earlier draft.
The edit removes those sentences.
The title, the author block, the Metropolis step, and the bibliography
stay.

## What changed

The 38-atom and 75-atom Oakley means stay in the data file.
The preset keeps one move library at every size.
The hit is read from converged improvements.
The LJ75 campaign typed in the article is 200 seeds, and the abstract
marks it stale.
The water comparison in this draft is six seeds.
The 192-seed paragraph is gone.
The deferred budget section is not in this article.
