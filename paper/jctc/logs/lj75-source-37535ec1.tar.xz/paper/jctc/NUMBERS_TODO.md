# Copyright (c) anneal developers

# Numbers still open

## STALE-pending-remeasure

These values were measured under the constructor on main at `3675c9c3`.
That constructor used a reseed library at 38 atoms, installed the
surface below 98, and turned restart on.
The integration tree compiles develop's `Config::recommended`.
Lean burst stays at every size, the surface is installed below 98, and
restart stays off.
The sentences remain in `manuscript.tex`.
They are not deleted.
The LJ38 sentence is 72 of 72, median 726, type-7 interquartile range
912.25.
The LJ98 sentence is 47 of 48, median 450877, type-7 interquartile range
902434.5.
The source files are
`data/lj38-recommended-seeds.csv` and `data/lj98-recommended-seeds.csv`.

Those source files sit beside a digest in `CONSTANTS.tsv`.
`CONSTANTS.tsv` still records the digest
`dc17734b70a2cc8082919be75440246be3823c0ef7777dcd9f3e9b5fc16e9f0f` for
`recommended(38)`.
That pin belongs to the removed-branch description.
It is STALE-pending-remeasure.
No replacement digest is written here.

## Typed, and not a new measurement

The LJ75 sentences for 200 seeds, a cap of 4e6 force calls, and the
three PAR-2 rows stay as typed text.
No CSV for that campaign is in the tree.
The Wales-group basin-hopping program (GMIN) todo marks that
head-to-head as still open.
This file does not add a count for it.

## Counters from the conformer rotamer ensemble sampling tool (CREST)

The manuscript table uses the hexamer logs.
The old counter is dynamics steps plus optimization steps.
CREST's line ``Total number of energy+grad calls'' is larger on every
seed.
The old counter undercounted CREST.
The equal-effort claim is withdrawn.
Five polished gaps lie within 1e-7 Eh.
Seed 1 reaches 1.3509e-7 Eh and sits just outside that threshold.
LJ38 72/72 and LJ98 47/48 stay inside `\todo{STALE: rerun on main}`.
The LJ75 count of 200 of 200 is marked the same way in the abstract.

## Replaced

The replaced paragraph follows.
The old water paragraph is gone.
It had printed 121/192, 97/192, 148/192, and 114/192.
The subsection now uses the six-seed hexamer logs.
Open work remains on the 16-mer, the Atomic Simulation Environment
panel, the atomistic global optimization framework (AGOX), and the GMIN
head-to-head.
Each of those slots is a `\todo`.
No number was invented for them.
